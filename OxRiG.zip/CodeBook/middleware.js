import { NextResponse } from 'next/server'

const protectedRoutes = ['/dashboard', '/sertifikat']
const authRoutes = ['/login', '/register']

export function middleware(request) {
  // Token only from httpOnly cookie
  const token = request.cookies.get('cb_token')?.value
  const { pathname } = request.nextUrl

  // Block path traversal attempts
  if (pathname.includes('..') || pathname.includes('%2e%2e')) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  }

  const isProtected = protectedRoutes.some(r => pathname.startsWith(r))
  const isAuth = authRoutes.some(r => pathname.startsWith(r))

  if (isProtected && !token) {
    return NextResponse.redirect(new URL('/login', request.url))
  }
  if (isAuth && token) {
    return NextResponse.redirect(new URL('/dashboard', request.url))
  }

  const response = NextResponse.next()
  // Add security headers to every response
  response.headers.set('X-Content-Type-Options', 'nosniff')
  response.headers.set('X-Frame-Options', 'SAMEORIGIN')
  return response
}

export const config = {
  matcher: ['/((?!_next/static|_next/image|favicon.ico).*)'],
}
