'use client'
import { useState, useEffect } from 'react'
import { getPositionBadge, calculateLevel, ACHIEVEMENTS } from '@/lib/gamification'

export default function EnhancedLeaderboard({ users, myId, activeTab, loading }) {
  const [sortedUsers, setSortedUsers] = useState([])
  const [myRank, setMyRank] = useState(0)

  useEffect(() => {
    if (users && users.length > 0) {
      setSortedUsers(users)
      const rank = users.findIndex(u => u._id === myId) + 1
      setMyRank(rank)
    }
  }, [users, myId])

  const getRankBadge = (position) => {
    if (position === 1) return { text: '🥇', bg: 'bg-yellow-500/15 text-yellow-400 border-yellow-500/25' }
    if (position === 2) return { text: '🥈', bg: 'bg-slate-400/15 text-slate-300 border-slate-400/25' }
    if (position === 3) return { text: '🥉', bg: 'bg-orange-600/15 text-orange-400 border-orange-600/25' }
    if (position <= 10) return { text: `🏆`, bg: 'bg-blue-500/15 text-blue-400 border-blue-500/25' }
    return { text: `#${position}`, bg: 'bg-white/[0.04] text-slate-500 border-white/[0.06]' }
  }

  const getLeagueInfo = (position) => {
    if (position === 1) return { name: 'Legendary', color: 'from-yellow-500 to-orange-500', emoji: '👑' }
    if (position <= 3) return { name: 'Elite', color: 'from-purple-500 to-pink-500', emoji: '💎' }
    if (position <= 10) return { name: 'Champion', color: 'from-blue-500 to-cyan-500', emoji: '🏆' }
    if (position <= 50) return { name: 'Pro', color: 'from-green-500 to-emerald-500', emoji: '⭐' }
    return { name: 'Rising Star', color: 'from-gray-500 to-slate-500', emoji: '🌟' }
  }

  const getValue = (user, tab) => {
    switch (tab) {
      case 'xp':
        return `${user.xp || 0} XP`
      case 'streak':
        return `${user.currentStreak || 0} 🔥`
      case 'certs':
        return `${user.certificates?.length || 0} 📜`
      default:
        return '0'
    }
  }

  if (loading) {
    return (
      <div className="space-y-2">
        {[...Array(8)].map((_, i) => (
          <div key={i} className="skeleton h-16 rounded-xl" />
        ))}
      </div>
    )
  }

  if (sortedUsers.length === 0) {
    return (
      <div className="text-center py-16">
        <div className="text-5xl mb-3">🏆</div>
        <p className="text-gray-600 dark:text-slate-500 font-semibold">Belum ada data</p>
        <p className="text-gray-500 dark:text-slate-600 text-sm mt-1">Jadilah yang pertama masuk leaderboard!</p>
      </div>
    )
  }

  return (
    <div className="space-y-3">
      {/* Podium Top 3 */}
      {sortedUsers.length >= 3 && (
        <div className="mb-8 p-4 bg-gradient-to-r from-yellow-500/5 to-orange-500/5 border border-yellow-500/10 rounded-xl">
          <p className="text-xs font-semibold text-yellow-600 dark:text-yellow-400 uppercase tracking-wide mb-4">🏆 Top 3 Podium</p>
          <div className="flex items-end justify-center gap-3">
            {[1, 0, 2].map((pos, displayIdx) => {
              const u = sortedUsers[pos]
              if (!u) return null
              const level = calculateLevel(u.xp || 0)
              const league = getLeagueInfo(pos + 1)
              const heights = ['h-24', 'h-32', 'h-20']
              const isMe = u._id === myId
              return (
                <div key={u._id} className="flex flex-col items-center flex-1">
                  <div className={`w-11 h-11 rounded-xl flex items-center justify-center text-white font-black text-base mb-1.5 shadow-xl ${isMe ? 'bg-gradient-to-br from-violet-500 to-purple-600 ring-2 ring-violet-400' : 'bg-gradient-to-br from-slate-600 to-slate-700'}`}>
                    {u.name[0].toUpperCase()}
                  </div>
                  <p className="text-xs font-bold text-gray-900 dark:text-white mb-0.5 truncate max-w-[70px] text-center">{u.name}</p>
                  <p className="text-[10px] font-semibold mb-1.5 text-gray-600 dark:text-slate-400">{level.icon} {level.level}</p>
                  <div className={`w-full ${heights[displayIdx]} bg-gradient-to-b ${league.color} rounded-t-xl flex flex-col items-center justify-center text-white font-black shadow-lg`}>
                    <span className="text-2xl">{getRankBadge(pos + 1).text}</span>
                    <span className="text-xs mt-1">{league.emoji}</span>
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      )}

      {/* Full Leaderboard List */}
      {sortedUsers.map((u, i) => {
        const level = calculateLevel(u.xp || 0)
        const league = getLeagueInfo(i + 1)
        const badge = getRankBadge(i + 1)
        const isMe = u._id === myId
        const value = getValue(u, activeTab)

        return (
          <div
            key={u._id}
            className={`flex items-center gap-3 p-4 rounded-xl border transition-all ${
              isMe
                ? 'bg-violet-600/10 dark:bg-violet-600/10 border-violet-500/30 dark:border-violet-500/30 ring-1 ring-violet-500/20 dark:ring-violet-500/20'
                : 'bg-gray-50 dark:bg-[#0f172a] border-gray-200 dark:border-white/[0.06] hover:border-gray-300 dark:hover:border-white/[0.1]'
            }`}
          >
            {/* Rank Badge */}
            <div className={`w-10 h-10 rounded-lg border flex items-center justify-center text-sm font-black flex-shrink-0 ${badge.bg}`}>
              {badge.text}
            </div>

            {/* Avatar */}
            <div className={`w-9 h-9 rounded-lg flex items-center justify-center text-white font-black text-sm flex-shrink-0 ${isMe ? 'bg-gradient-to-br from-violet-500 to-purple-600' : 'bg-gray-300 dark:bg-[#1e293b]'}`}>
              {u.name[0].toUpperCase()}
            </div>

            {/* User Info */}
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <p className={`font-bold text-sm truncate ${isMe ? 'text-violet-700 dark:text-violet-300' : 'text-gray-900 dark:text-white'}`}>
                  {u.name}
                </p>
                {isMe && <span className="text-[10px] text-violet-600 dark:text-violet-500 font-normal bg-violet-100 dark:bg-violet-500/20 px-2 py-0.5 rounded">(Kamu)</span>}
                <span className="text-xs px-2 py-0.5 rounded-full bg-gradient-to-r font-semibold text-white" style={{
                  background: `linear-gradient(135deg, ${league.color.split(' ')[1]}, ${league.color.split(' ')[3]})`
                }}>
                  {league.emoji} {league.name}
                </span>
              </div>
              <div className="flex items-center gap-2 mt-1 text-xs text-gray-600 dark:text-slate-400">
                <span>{level.icon} {level.level}</span>
                <span>•</span>
                <span>{u.completedMateri?.length || 0} materi</span>
                {u.currentStreak > 0 && (
                  <>
                    <span>•</span>
                    <span className="text-orange-600 dark:text-orange-400 font-semibold">🔥 {u.currentStreak} hari</span>
                  </>
                )}
              </div>
            </div>

            {/* Value */}
            <span className={`font-bold text-sm tabular-nums ${isMe ? 'text-violet-600 dark:text-violet-400' : 'text-gray-600 dark:text-slate-400'}`}>
              {value}
            </span>
          </div>
        )
      })}

      {/* League Info */}
      <div className="mt-8 p-4 bg-blue-50 dark:bg-blue-600/10 border border-blue-200 dark:border-blue-500/20 rounded-xl">
        <p className="text-xs font-semibold text-blue-700 dark:text-blue-400 uppercase tracking-wide mb-3">📊 Sistem Liga</p>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-2 text-xs">
          {[
            { emoji: '👑', name: 'Legendary', desc: '#1' },
            { emoji: '💎', name: 'Elite', desc: '#2-3' },
            { emoji: '🏆', name: 'Champion', desc: '#4-10' },
            { emoji: '⭐', name: 'Pro', desc: '#11-50' },
            { emoji: '🌟', name: 'Rising Star', desc: '#51+' },
          ].map((league, idx) => (
            <div key={idx} className="p-2 bg-white/50 dark:bg-white/[0.05] rounded-lg text-center">
              <p className="text-lg mb-1">{league.emoji}</p>
              <p className="font-semibold text-gray-900 dark:text-white">{league.name}</p>
              <p className="text-gray-600 dark:text-slate-400">{league.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
