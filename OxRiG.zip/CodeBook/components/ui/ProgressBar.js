export default function ProgressBar({ value = 0, max = 100, color = 'navy', size = 'md', label, showPercent }) {
  const pct = Math.min(100, Math.max(0, (value / max) * 100))
  const heights = { sm: 'h-1.5', md: 'h-2.5', lg: 'h-3' }
  const colors = {
    navy: 'from-[#6171f5] to-[#a5bbff]',
    green: 'from-emerald-500 to-teal-400',
    yellow: 'from-yellow-500 to-orange-400',
    red: 'from-red-500 to-pink-400',
  }

  return (
    <div>
      {(label || showPercent) && (
        <div className="flex justify-between text-xs text-slate-500 mb-1.5">
          {label && <span>{label}</span>}
          {showPercent && <span className="text-[#8095ff] font-medium">{Math.round(pct)}%</span>}
        </div>
      )}
      <div className={`w-full bg-[#1a1d2e] rounded-full overflow-hidden ${heights[size]}`}>
        <div
          className={`${heights[size]} rounded-full bg-gradient-to-r ${colors[color]} transition-all duration-700 ease-out`}
          style={{ width: `${pct}%` }}
        />
      </div>
    </div>
  )
}
