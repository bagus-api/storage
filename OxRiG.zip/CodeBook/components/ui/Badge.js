export function BadgeChip({ icon, name, earned, small }) {
  return (
    <div className={`relative group ${!earned ? 'opacity-40 grayscale' : ''}`}>
      <div className={`${small ? 'w-12 h-12' : 'w-16 h-16'} rounded-2xl bg-gradient-to-br from-[#1a1d2e] to-[#0f1117] border ${earned ? 'border-[#6171f5]/30' : 'border-white/[0.06]'} flex items-center justify-center transition-all ${earned ? 'group-hover:border-[#6171f5]/60 group-hover:shadow-lg group-hover:shadow-[#6171f5]/10' : ''}`}>
        <span className={small ? 'text-xl' : 'text-2xl'}>{icon}</span>
      </div>
      <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-2.5 py-1.5 bg-[#1a1d2e] border border-white/10 rounded-lg text-xs text-slate-300 whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-10">
        {name}
      </div>
    </div>
  )
}
