'use client'
import { useState, useRef, useEffect, useCallback } from 'react'

// ─── Token types & colors (VSCode Dark+ theme) ───────────────────────────
const THEMES = {
  python: {
    keywords: /\b(def|class|import|from|return|if|elif|else|for|while|in|not|and|or|is|None|True|False|try|except|finally|with|as|pass|break|continue|lambda|yield|raise|del|global|nonlocal|assert|async|await)\b/g,
    builtins: /\b(print|input|len|range|type|int|float|str|bool|list|dict|tuple|set|sum|min|max|abs|round|sorted|enumerate|zip|map|filter|open|help|dir)\b/g,
    strings: /("""[\s\S]*?"""|'''[\s\S]*?'''|"(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*')/g,
    comments: /(#.*$)/gm,
    numbers: /\b(\d+\.?\d*)\b/g,
    decorators: /(@\w+)/g,
    functions: /\b(\w+)(?=\s*\()/g,
    selfParam: /\b(self|cls)\b/g,
  },
  javascript: {
    keywords: /\b(const|let|var|function|return|if|else|for|while|do|switch|case|break|continue|new|this|typeof|instanceof|in|of|import|export|default|class|extends|super|try|catch|finally|throw|async|await|yield|delete|void|null|undefined|true|false)\b/g,
    builtins: /\b(console|Math|JSON|Array|Object|String|Number|Boolean|Promise|Map|Set|Date|Error|fetch|setTimeout|setInterval|clearTimeout|clearInterval|document|window|localStorage|parseInt|parseFloat|isNaN|isFinite)\b/g,
    strings: /(`(?:[^`\\]|\\.)*`|"(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*')/g,
    comments: /(\/\/.*$|\/\*[\s\S]*?\*\/)/gm,
    numbers: /\b(\d+\.?\d*)\b/g,
    functions: /\b(\w+)(?=\s*[=(])/g,
    arrows: /(=>)/g,
    template: /(\$\{[^}]+\})/g,
  },
  html: {
    doctype: /(<!DOCTYPE[^>]*>)/gi,
    comments: /(<!--[\s\S]*?-->)/g,
    tags: /(<\/?\w+(?:\s+[^>]*)?\/?>)/g,
    attributes: /\s(\w[\w-]*)(?==)/g,
    strings: /("[^"]*"|'[^']*')/g,
    entities: /(&\w+;|&#\d+;)/g,
  },
  css: {
    selectors: /^([^{]+)(?={)/gm,
    properties: /(\w[\w-]*)(?=\s*:)/g,
    values: /:\s*([^;{}\n]+)/g,
    comments: /(\/\*[\s\S]*?\*\/)/g,
    numbers: /\b(\d+\.?\d*(?:px|em|rem|vh|vw|%|s|ms|deg)?)\b/g,
    atRules: /(@\w[\w-]*)/g,
    colors: /(#[0-9a-fA-F]{3,8})\b/g,
    strings: /("[^"]*"|'[^']*')/g,
  },
  bash: {
    keywords: /\b(git|npm|node|cd|ls|mkdir|rm|cp|mv|cat|echo|export|source|chmod|sudo|apt|brew|curl|wget|grep|find|ps|kill)\b/g,
    strings: /("[^"]*"|'[^']*')/g,
    comments: /(#.*$)/gm,
    numbers: /\b(\d+)\b/g,
    flags: /(--[\w-]+|-[a-zA-Z]+)/g,
  },
  git: {
    keywords: /\b(git|init|add|commit|push|pull|clone|merge|rebase|branch|checkout|switch|status|log|diff|stash|reset|revert|fetch|remote|tag|cherry-pick)\b/g,
    strings: /("[^"]*"|'[^']*')/g,
    comments: /(#.*$)/gm,
    flags: /(--[\w-]+|-[a-zA-Z]+)/g,
    sha: /\b([0-9a-f]{7,40})\b/g,
  },
  sql: {
    keywords: /\b(SELECT|FROM|WHERE|INSERT|INTO|UPDATE|SET|DELETE|CREATE|TABLE|DROP|ALTER|ADD|INDEX|JOIN|LEFT|RIGHT|INNER|OUTER|ON|AND|OR|NOT|IN|IS|NULL|LIKE|ORDER|BY|GROUP|HAVING|LIMIT|OFFSET|DISTINCT|AS|PRIMARY|KEY|FOREIGN|REFERENCES|UNIQUE|DEFAULT|AUTO_INCREMENT|CONSTRAINT|BEGIN|COMMIT|ROLLBACK|TRANSACTION)\b/gi,
    strings: /('[^']*')/g,
    comments: /(--.*$|\/\*[\s\S]*?\*\/)/gm,
    numbers: /\b(\d+\.?\d*)\b/g,
    functions: /\b(COUNT|SUM|AVG|MIN|MAX|CONCAT|LENGTH|UPPER|LOWER|TRIM|NOW|DATE|COALESCE|NULLIF|CAST|CONVERT)\b/gi,
  },
  java: {
    keywords: /\b(public|private|protected|class|interface|extends|implements|new|return|if|else|for|while|do|switch|case|break|continue|void|int|long|double|float|boolean|char|byte|short|String|null|true|false|static|final|abstract|try|catch|finally|throw|throws|import|package|this|super|instanceof|enum|var|record)\b/g,
    builtins: /\b(System|Math|Arrays|Collections|List|ArrayList|Map|HashMap|Set|HashSet|Optional|Stream|StringBuilder|Integer|Double|Boolean|Object|Exception|RuntimeException|Thread|Runnable|Override)\b/g,
    strings: /("(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*')/g,
    comments: /(\/\/.*$|\/\*[\s\S]*?\*\/)/gm,
    numbers: /\b(\d+\.?\d*[fFlLdD]?)\b/g,
    annotations: /(@\w+)/g,
    functions: /\b(\w+)(?=\s*\()/g,
  },
  php: {
    keywords: /\b(echo|print|function|class|public|private|protected|static|return|if|else|elseif|foreach|for|while|do|switch|case|break|continue|new|null|true|false|array|string|int|float|bool|void|namespace|use|extends|implements|abstract|interface|trait|try|catch|finally|throw|match|fn|readonly|enum)\b/g,
    builtins: /\b(strlen|str_replace|explode|implode|array_push|array_pop|count|in_array|array_map|array_filter|array_keys|array_values|json_encode|json_decode|header|session_start|htmlspecialchars|trim|strtolower|strtoupper|date|time|printf|sprintf|var_dump|isset|empty|unset)\b/g,
    strings: /("(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*')/g,
    comments: /(\/\/.*$|#.*$|\/\*[\s\S]*?\*\/)/gm,
    numbers: /\b(\d+\.?\d*)\b/g,
    variables: /(\$\w+)/g,
    functions: /\b(\w+)(?=\s*\()/g,
  },
  cpp: {
    keywords: /\b(int|long|double|float|char|bool|void|auto|const|static|class|struct|public|private|protected|virtual|override|return|if|else|for|while|do|switch|case|break|continue|new|delete|nullptr|true|false|try|catch|throw|namespace|using|template|typename|inline|explicit|operator|sizeof|typedef|enum|union)\b/g,
    builtins: /\b(cout|cin|endl|string|vector|map|set|pair|array|list|queue|stack|sort|find|begin|end|push_back|size|empty|front|back|make_pair|printf|scanf|malloc|free|strlen|abs|min|max|swap)\b/g,
    strings: /("(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*')/g,
    comments: /(\/\/.*$|\/\*[\s\S]*?\*\/)/gm,
    numbers: /\b(\d+\.?\d*[fFlLuU]?)\b/g,
    preprocessor: /(#\w+)/g,
    functions: /\b(\w+)(?=\s*[<(])/g,
  },
  typescript: {
    keywords: /\b(const|let|var|function|return|if|else|for|while|do|switch|case|break|continue|new|this|typeof|instanceof|in|of|import|export|default|class|extends|super|try|catch|finally|throw|async|await|yield|delete|void|null|undefined|true|false|type|interface|enum|namespace|declare|abstract|readonly|override|as|is|keyof|infer|never|unknown|any|satisfies)\b/g,
    builtins: /\b(console|Math|JSON|Array|Object|String|Number|Boolean|Promise|Map|Set|Date|Error|fetch|Record|Partial|Required|Pick|Omit|Exclude|Extract|ReturnType|Parameters|Awaited)\b/g,
    strings: /(`(?:[^`\\]|\\.)*`|"(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*')/g,
    comments: /(\/\/.*$|\/\*[\s\S]*?\*\/)/gm,
    numbers: /\b(\d+\.?\d*)\b/g,
    decorators: /(@\w+)/g,
    template: /(\$\{[^}]+\})/g,
  },
  go: {
    keywords: /\b(func|package|import|var|const|type|struct|interface|map|chan|go|defer|select|return|if|else|for|range|switch|case|break|continue|goto|fallthrough|nil|true|false|make|new|len|cap|append|copy|delete|close|panic|recover|error|string|int|int8|int16|int32|int64|uint|float32|float64|bool|byte|rune|any)\b/g,
    builtins: /\b(fmt|os|io|net|http|json|sync|time|math|strings|strconv|errors|log|bufio|bytes|context|reflect|sort)\b/g,
    strings: /(`[^`]*`|"(?:[^"\\]|\\.)*")/g,
    comments: /(\/\/.*$|\/\*[\s\S]*?\*\/)/gm,
    numbers: /\b(\d+\.?\d*)\b/g,
    functions: /\b(\w+)(?=\s*\()/g,
  },
  kotlin: {
    keywords: /\b(fun|val|var|class|object|interface|data|sealed|enum|companion|return|if|else|when|for|while|do|break|continue|try|catch|finally|throw|null|true|false|import|package|is|as|in|out|by|init|constructor|override|open|abstract|final|private|protected|public|internal|suspend|reified|inline|infix|operator|tailrec|vararg)\b/g,
    builtins: /\b(String|Int|Long|Double|Float|Boolean|Char|Byte|Short|List|MutableList|Map|MutableMap|Set|MutableSet|Array|Pair|Triple|Unit|Any|Nothing|println|print|readLine|listOf|mapOf|setOf|mutableListOf|mutableMapOf|emptyList|arrayOf|let|run|apply|also|with|takeIf|TODO|error|check|require)\b/g,
    strings: /("(?:[^"\\]|\\.)*")/g,
    comments: /(\/\/.*$|\/\*[\s\S]*?\*\/)/gm,
    numbers: /\b(\d+\.?\d*[fFLl]?)\b/g,
    functions: /\b(\w+)(?=\s*[({])/g,
  },
  rust: {
    keywords: /\b(fn|let|mut|const|static|struct|enum|trait|impl|use|mod|pub|return|if|else|match|for|while|loop|break|continue|in|as|where|type|unsafe|async|await|move|ref|dyn|self|Self|super|crate|extern|true|false)\b/g,
    builtins: /\b(String|str|Vec|HashMap|HashSet|Option|Result|Box|Rc|Arc|Mutex|i8|i16|i32|i64|i128|u8|u16|u32|u64|u128|f32|f64|usize|isize|bool|char|Some|None|Ok|Err|println|panic|todo|unwrap|expect|clone|len|push|pop|insert|remove|get|iter|map|filter|collect)\b/g,
    strings: /("(?:[^"\\]|\\.)*")/g,
    comments: /(\/\/.*$|\/\*[\s\S]*?\*\/)/gm,
    numbers: /\b(\d+\.?\d*(?:_\d+)*(?:u8|u16|u32|u64|i8|i16|i32|i64|f32|f64|usize)?)\b/g,
    macros: /(\w+!)/g,
    functions: /\b(\w+)(?=\s*[({])/g,
  },
}

const COLORS = {
  keyword:   '#C678DD',
  builtin:   '#E5C07B',
  string:    '#98C379',
  comment:   '#5C6370',
  number:    '#D19A66',
  function:  '#61AFEF',
  tag:       '#E06C75',
  attribute: '#D19A66',
  special:   '#56B6C2',
  operator:  '#ABB2BF',
  decorator: '#E5C07B',
  selector:  '#E06C75',
  property:  '#61AFEF',
  atRule:    '#C678DD',
  color:     '#D19A66',
  entity:    '#56B6C2',
  template:  '#56B6C2',
  arrow:     '#C678DD',
}

function highlight(code, lang) {
  if (!code) return ''
  let html = code
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')

  const rules = THEMES[lang]
  if (!rules) return html

  const ranges = []

  function addRanges(pattern, colorKey, italic = false) {
    if (!pattern) return
    pattern.lastIndex = 0
    let m
    while ((m = pattern.exec(html)) !== null) {
      ranges.push({
        start: m.index,
        end: m.index + m[0].length,
        text: m[0],
        color: COLORS[colorKey],
        italic,
      })
    }
  }

  if (lang === 'python') {
    addRanges(rules.comments,   'comment', true)
    addRanges(rules.strings,    'string')
    addRanges(rules.decorators, 'decorator')
    addRanges(rules.keywords,   'keyword')
    addRanges(rules.builtins,   'builtin')
    addRanges(rules.selfParam,  'special')
    addRanges(rules.numbers,    'number')
    addRanges(rules.functions,  'function')
  } else if (lang === 'javascript') {
    addRanges(rules.comments,   'comment', true)
    addRanges(rules.strings,    'string')
    addRanges(rules.template,   'special')
    addRanges(rules.keywords,   'keyword')
    addRanges(rules.builtins,   'builtin')
    addRanges(rules.numbers,    'number')
    addRanges(rules.arrows,     'arrow')
    addRanges(rules.functions,  'function')
  } else if (lang === 'html') {
    addRanges(rules.comments,   'comment', true)
    addRanges(rules.doctype,    'keyword')
    addRanges(rules.strings,    'string')
    addRanges(rules.entities,   'entity')
    addRanges(rules.tags,       'tag')
  } else if (lang === 'css') {
    addRanges(rules.comments,   'comment', true)
    addRanges(rules.strings,    'string')
    addRanges(rules.atRules,    'atRule')
    addRanges(rules.colors,     'color')
    addRanges(rules.numbers,    'number')
    addRanges(rules.properties, 'property')
    addRanges(rules.selectors,  'selector')
  } else if (lang === 'bash' || lang === 'git') {
    addRanges(rules.comments,   'comment', true)
    addRanges(rules.strings,    'string')
    addRanges(rules.flags,      'special')
    addRanges(rules.keywords,   'keyword')
    addRanges(rules.numbers,    'number')
    if (rules.sha) addRanges(rules.sha, 'number')
  } else if (lang === 'sql') {
    addRanges(rules.comments,   'comment', true)
    addRanges(rules.strings,    'string')
    addRanges(rules.functions,  'builtin')
    addRanges(rules.keywords,   'keyword')
    addRanges(rules.numbers,    'number')
  } else if (lang === 'java') {
    addRanges(rules.comments,   'comment', true)
    addRanges(rules.strings,    'string')
    addRanges(rules.annotations,'decorator')
    addRanges(rules.keywords,   'keyword')
    addRanges(rules.builtins,   'builtin')
    addRanges(rules.numbers,    'number')
    addRanges(rules.functions,  'function')
  } else if (lang === 'php') {
    addRanges(rules.comments,   'comment', true)
    addRanges(rules.strings,    'string')
    addRanges(rules.keywords,   'keyword')
    addRanges(rules.builtins,   'builtin')
    addRanges(rules.variables,  'special')
    addRanges(rules.numbers,    'number')
    addRanges(rules.functions,  'function')
  } else if (lang === 'cpp') {
    addRanges(rules.comments,   'comment', true)
    addRanges(rules.strings,    'string')
    addRanges(rules.preprocessor,'decorator')
    addRanges(rules.keywords,   'keyword')
    addRanges(rules.builtins,   'builtin')
    addRanges(rules.numbers,    'number')
    addRanges(rules.functions,  'function')
  } else if (lang === 'typescript') {
    addRanges(rules.comments,   'comment', true)
    addRanges(rules.strings,    'string')
    addRanges(rules.template,   'special')
    addRanges(rules.decorators, 'decorator')
    addRanges(rules.keywords,   'keyword')
    addRanges(rules.builtins,   'builtin')
    addRanges(rules.numbers,    'number')
  } else if (lang === 'go') {
    addRanges(rules.comments,   'comment', true)
    addRanges(rules.strings,    'string')
    addRanges(rules.keywords,   'keyword')
    addRanges(rules.builtins,   'builtin')
    addRanges(rules.numbers,    'number')
    addRanges(rules.functions,  'function')
  } else if (lang === 'kotlin') {
    addRanges(rules.comments,   'comment', true)
    addRanges(rules.strings,    'string')
    addRanges(rules.keywords,   'keyword')
    addRanges(rules.builtins,   'builtin')
    addRanges(rules.numbers,    'number')
    addRanges(rules.functions,  'function')
  } else if (lang === 'rust') {
    addRanges(rules.comments,   'comment', true)
    addRanges(rules.strings,    'string')
    addRanges(rules.macros,     'builtin')
    addRanges(rules.keywords,   'keyword')
    addRanges(rules.builtins,   'builtin')
    addRanges(rules.numbers,    'number')
    addRanges(rules.functions,  'function')
  }

  ranges.sort((a, b) => a.start - b.start)
  const clean = []
  let last = 0
  for (const r of ranges) {
    if (r.start >= last) { clean.push(r); last = r.end }
  }

  let result = ''
  let pos = 0
  for (const r of clean) {
    result += html.slice(pos, r.start)
    const style = `color:${r.color}${r.italic ? ';font-style:italic' : ''}`
    result += `<span style="${style}">${html.slice(r.start, r.end)}</span>`
    pos = r.end
  }
  result += html.slice(pos)
  return result
}

export default function CodeEditor({
  value = '',
  onChange,
  lang = 'javascript',
  readOnly = false,
  minHeight = 280,
  fileName,
}) {
  const taRef = useRef(null)
  const hlRef = useRef(null)

  const highlighted = highlight(value, lang)

  const syncScroll = useCallback(() => {
    if (taRef.current && hlRef.current) {
      hlRef.current.scrollTop = taRef.current.scrollTop
      hlRef.current.scrollLeft = taRef.current.scrollLeft
    }
  }, [])

  const handleKeyDown = (e) => {
    if (e.key === 'Tab') {
      e.preventDefault()
      const ta = taRef.current
      const s = ta.selectionStart
      const end = ta.selectionEnd
      const next = value.substring(0, s) + '    ' + value.substring(end)
      onChange?.(next)
      requestAnimationFrame(() => {
        ta.selectionStart = ta.selectionEnd = s + 4
      })
    }
  }

  const langLabels = {
    python: 'Python', javascript: 'JavaScript', html: 'HTML',
    css: 'CSS', sql: 'SQL', typescript: 'TypeScript',
    bash: 'Bash', git: 'Git', java: 'Java', php: 'PHP',
    cpp: 'C++', go: 'Go', kotlin: 'Kotlin', rust: 'Rust',
  }

  const fileNames = {
    python: 'main.py', javascript: 'script.js', html: 'index.html', 
    bash: 'terminal.sh', git: 'commands.sh', java: 'Main.java', 
    php: 'index.php', cpp: 'main.cpp', go: 'main.go', 
    kotlin: 'Main.kt', rust: 'main.rs', typescript: 'index.ts',
    css: 'style.css', sql: 'query.sql',
  }

  const dotColor = {
    python: '#3B82F6', javascript: '#EAB308', html: '#F97316', 
    bash: '#22C55E', git: '#EA580C', java: '#F97316', 
    php: '#818CF8', cpp: '#60A5FA', go: '#34D399', 
    kotlin: '#A78BFA', rust: '#FB923C', typescript: '#3B82F6',
    css: '#8B5CF6', sql: '#06B6D4',
  }

  return (
    <div className="flex flex-col h-full" style={{ background: '#1E1E1E' }}>
      <div className="flex items-center gap-0 flex-shrink-0" style={{ background: '#2D2D30', borderBottom: '1px solid #3C3C3C' }}>
        <div className="flex items-center gap-1.5 px-3 py-2.5 border-r border-[#3C3C3C]">
          <div className="w-3 h-3 rounded-full bg-[#FF5F57] hover:brightness-110 cursor-default" />
          <div className="w-3 h-3 rounded-full bg-[#FFBD2E] hover:brightness-110 cursor-default" />
          <div className="w-3 h-3 rounded-full bg-[#28CA41] hover:brightness-110 cursor-default" />
        </div>
        <div className="flex items-center gap-2 px-4 py-2.5 text-xs" style={{ background: '#1E1E1E', borderRight: '1px solid #3C3C3C' }}>
          <div className="w-2.5 h-2.5 rounded-sm flex-shrink-0" style={{ background: dotColor[lang] || '#888' }} />
          <span style={{ color: '#CCCCCC', fontFamily: 'var(--font-jetbrains, monospace)' }}>
            {fileName || fileNames[lang] || 'code.txt'}
          </span>
        </div>
        <div className="ml-auto flex items-center gap-2 px-3">
          <span className="text-[10px] px-1.5 py-0.5 rounded" style={{ background: '#3C3C3C', color: '#888', fontFamily: 'monospace' }}>
            {langLabels[lang] || lang}
          </span>
        </div>
      </div>

      <div className="flex flex-1 overflow-hidden relative" style={{ minHeight }}>
        <div
          className="flex-shrink-0 select-none overflow-hidden"
          style={{
            width: '48px',
            background: '#1E1E1E',
            borderRight: '1px solid #2A2A2A',
            paddingTop: '12px',
          }}>
          {value.split('\n').map((_, i) => (
            <div key={i}
              style={{
                height: '21px', lineHeight: '21px',
                textAlign: 'right', paddingRight: '10px',
                color: '#3D3D3D',
                fontSize: '12px',
                fontFamily: '"JetBrains Mono", "Fira Code", monospace',
              }}>
              {i + 1}
            </div>
          ))}
        </div>

        <div className="flex-1 relative overflow-hidden">
          <div
            ref={hlRef}
            aria-hidden="true"
            style={{
              position: 'absolute', inset: 0,
              padding: '12px 16px',
              overflowX: 'auto', overflowY: 'auto',
              whiteSpace: 'pre',
              fontFamily: '"JetBrains Mono", "Fira Code", "Consolas", monospace',
              fontSize: '13px', lineHeight: '21px',
              color: '#ABB2BF',
              pointerEvents: 'none',
              background: 'transparent',
              userSelect: 'none',
              tabSize: 4,
            }}
            dangerouslySetInnerHTML={{ __html: highlighted + '\n' }}
          />

          <textarea
            ref={taRef}
            value={value}
            onChange={e => { onChange?.(e.target.value) }}
            onKeyDown={handleKeyDown}
            onScroll={syncScroll}
            readOnly={readOnly}
            spellCheck={false}
            autoCorrect="off"
            autoCapitalize="off"
            autoComplete="off"
            style={{
              position: 'absolute', inset: 0,
              width: '100%', height: '100%',
              padding: '12px 16px',
              overflowX: 'auto', overflowY: 'auto',
              whiteSpace: 'pre',
              fontFamily: '"JetBrains Mono", "Fira Code", "Consolas", monospace',
              fontSize: '13px', lineHeight: '21px',
              color: 'transparent',
              caretColor: '#AEAFAD',
              background: 'transparent',
              border: 'none',
              outline: 'none',
              resize: 'none',
              tabSize: 4,
            }}
          />
        </div>
      </div>

      <div className="flex items-center px-3 py-1 flex-shrink-0"
        style={{ background: '#007ACC', minHeight: '22px' }}>
        <span style={{ color: 'rgba(255,255,255,0.8)', fontSize: '11px', fontFamily: 'var(--font-jetbrains, monospace)' }}>
          {langLabels[lang] || lang}
        </span>
        <span style={{ color: 'rgba(255,255,255,0.5)', fontSize: '11px', marginLeft: '12px' }}>
          Ln {value.split('\n').length}, Col {value.length}
        </span>
        <span style={{ color: 'rgba(255,255,255,0.5)', fontSize: '11px', marginLeft: 'auto' }}>
          UTF-8
        </span>
      </div>
    </div>
  )
}