'use client'
import { useState, useEffect } from 'react'
import { generateCertificateCanvas, downloadCertificateAsPNG, createCertificatePreview } from '@/lib/certificateGenerator'
import toast from 'react-hot-toast'

export default function CertificatePreview({ cert, userName, quizScore, onClose }) {
  const [preview, setPreview] = useState(null)
  const [loading, setLoading] = useState(true)
  const [downloading, setDownloading] = useState(false)

  useEffect(() => {
    const generatePreview = async () => {
      try {
        const canvas = await generateCertificateCanvas(cert, userName)
        const previewUrl = createCertificatePreview(canvas)
        setPreview(previewUrl)
        // Store canvas for download
        window._certCanvas = canvas
      } catch (error) {
        console.error('Error generating preview:', error)
        toast.error('Gagal membuat preview sertifikat')
      } finally {
        setLoading(false)
      }
    }

    generatePreview()
  }, [cert, userName])

  const handleDownloadPNG = () => {
    if (!window._certCanvas) {
      toast.error('Canvas tidak tersedia')
      return
    }
    setDownloading(true)
    try {
      downloadCertificateAsPNG(window._certCanvas, cert.certId)
      toast.success('Sertifikat berhasil diunduh! 🎉')
    } catch (error) {
      toast.error('Gagal mengunduh sertifikat')
    } finally {
      setDownloading(false)
    }
  }

  const handlePrint = () => {
    window.print()
  }

  const handleShare = async () => {
    const shareUrl = `${window.location.origin}/verify/${cert.certId}`
    try {
      if (navigator.share) {
        await navigator.share({
          title: 'CodeBook Certificate',
          text: `Saya telah menyelesaikan ${cert.courseName} di CodeBook!`,
          url: shareUrl,
        })
      } else {
        // Fallback: copy to clipboard
        await navigator.clipboard.writeText(shareUrl)
        toast.success('Link disalin ke clipboard! 📋')
      }
    } catch (error) {
      if (error.name !== 'AbortError') {
        toast.error('Gagal berbagi sertifikat')
      }
    }
  }

  return (
    <div className="fixed inset-0 bg-black/70 dark:bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white dark:bg-[#0f172a] rounded-2xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="sticky top-0 bg-gradient-to-r from-violet-600 to-purple-600 dark:from-violet-600 dark:to-purple-600 px-6 py-4 flex items-center justify-between z-10">
          <div>
            <h2 className="text-2xl font-bold text-white">🎓 Sertifikat Anda</h2>
            <p className="text-violet-100 text-sm mt-1">ID: {cert.certId}</p>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg hover:bg-white/20 transition-colors"
            aria-label="Close"
          >
            <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Content */}
        <div className="p-6">
          {loading ? (
            <div className="flex items-center justify-center py-12">
              <div className="text-center">
                <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-violet-600"></div>
                <p className="mt-4 text-gray-600 dark:text-slate-400">Membuat sertifikat...</p>
              </div>
            </div>
          ) : preview ? (
            <div className="space-y-6">
              {/* Certificate Preview */}
              <div className="bg-gray-100 dark:bg-[#1e293b] rounded-xl overflow-hidden border-2 border-gray-200 dark:border-white/[0.06]">
                <img src={preview} alt="Certificate" className="w-full h-auto" />
              </div>

              {/* Certificate Details */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="bg-violet-50 dark:bg-violet-600/10 rounded-lg p-4 border border-violet-200 dark:border-violet-500/20">
                  <p className="text-xs font-semibold text-gray-600 dark:text-slate-400 uppercase">Kursus</p>
                  <p className="text-sm font-bold text-gray-900 dark:text-white mt-1 truncate">{cert.courseName}</p>
                </div>
                <div className="bg-green-50 dark:bg-green-600/10 rounded-lg p-4 border border-green-200 dark:border-green-500/20">
                  <p className="text-xs font-semibold text-gray-600 dark:text-slate-400 uppercase">Nilai Quiz</p>
                  <p className="text-sm font-bold text-green-600 dark:text-green-400 mt-1">{quizScore}%</p>
                </div>
                <div className="bg-blue-50 dark:bg-blue-600/10 rounded-lg p-4 border border-blue-200 dark:border-blue-500/20">
                  <p className="text-xs font-semibold text-gray-600 dark:text-slate-400 uppercase">Diterbitkan</p>
                  <p className="text-sm font-bold text-blue-600 dark:text-blue-400 mt-1">
                    {new Date(cert.issuedAt).toLocaleDateString('id-ID', { month: 'short', day: 'numeric' })}
                  </p>
                </div>
                <div className="bg-purple-50 dark:bg-purple-600/10 rounded-lg p-4 border border-purple-200 dark:border-purple-500/20">
                  <p className="text-xs font-semibold text-gray-600 dark:text-slate-400 uppercase">Status</p>
                  <p className="text-sm font-bold text-purple-600 dark:text-purple-400 mt-1">✓ Terverifikasi</p>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                <button
                  onClick={handleDownloadPNG}
                  disabled={downloading}
                  className="flex items-center justify-center gap-2 px-4 py-3 bg-violet-600 hover:bg-violet-500 text-white font-semibold rounded-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                  </svg>
                  <span className="hidden sm:inline">Unduh PNG</span>
                  <span className="sm:hidden">Unduh</span>
                </button>

                <button
                  onClick={handlePrint}
                  className="flex items-center justify-center gap-2 px-4 py-3 bg-blue-600 hover:bg-blue-500 text-white font-semibold rounded-lg transition-all"
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z" />
                  </svg>
                  <span className="hidden sm:inline">Cetak</span>
                  <span className="sm:hidden">Cetak</span>
                </button>

                <button
                  onClick={handleShare}
                  className="flex items-center justify-center gap-2 px-4 py-3 bg-green-600 hover:bg-green-500 text-white font-semibold rounded-lg transition-all"
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C9.589 12.938 10 12.052 10 11c0-1.657-1.343-3-3-3s-3 1.343-3 3 1.343 3 3 3c.064 0 .128-.001.192-.003.243.962.807 1.85 1.684 2.342m0 0a9.968 9.968 0 00-5.416-2.286m0 0a9.986 9.986 0 013.541 6.019M15.341 7.657c.961.243 1.84.807 2.342 1.684m0 0a9.968 9.968 0 010 5.416m0 0a9.986 9.986 0 01-6.019-3.541" />
                  </svg>
                  <span className="hidden sm:inline">Bagikan</span>
                  <span className="sm:hidden">Bagikan</span>
                </button>

                <button
                  onClick={() => {
                    const link = document.createElement('a')
                    link.href = `${window.location.origin}/verify/${cert.certId}`
                    link.target = '_blank'
                    link.click()
                  }}
                  className="flex items-center justify-center gap-2 px-4 py-3 bg-gray-600 dark:bg-gray-700 hover:bg-gray-500 dark:hover:bg-gray-600 text-white font-semibold rounded-lg transition-all"
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                  </svg>
                  <span className="hidden sm:inline">Verifikasi</span>
                  <span className="sm:hidden">Verif</span>
                </button>
              </div>

              {/* Info Box */}
              <div className="bg-blue-50 dark:bg-blue-600/10 border border-blue-200 dark:border-blue-500/20 rounded-lg p-4">
                <div className="flex gap-3">
                  <svg className="w-5 h-5 text-blue-600 dark:text-blue-400 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M18 5v8a2 2 0 01-2 2h-5l-5 4v-4H4a2 2 0 01-2-2V5a2 2 0 012-2h12a2 2 0 012 2zm-11-1a1 1 0 11-2 0 1 1 0 012 0z" clipRule="evenodd" />
                  </svg>
                  <div>
                    <p className="font-semibold text-blue-900 dark:text-blue-100">Sertifikat Anda Terverifikasi</p>
                    <p className="text-sm text-blue-800 dark:text-blue-200 mt-1">
                      Sertifikat ini dapat diverifikasi di {window.location.origin}/verify/{cert.certId}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="text-center py-12">
              <p className="text-gray-600 dark:text-slate-400">Gagal membuat sertifikat</p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
