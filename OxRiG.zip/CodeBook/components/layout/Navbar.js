'use client'
import { useState, useEffect, useRef } from 'react'
import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'
import toast from 'react-hot-toast'
import {
  LogoCB, IconMenu, IconClose, IconSearch, IconBook, IconMap,
  IconZap, IconBrain, IconTarget, IconTrophy, IconChat,
  IconShield, IconCertificate, IconGraduate, IconDashboard,
  IconVerify, IconLogout, IconChevronDown,
} from '@/components/ui/Icons'

const NAV = [
  { href: '/workshop',    label: 'Workshop',      Icon: IconGraduate },
  { href: '/materi',      label: 'Materi',         Icon: IconBook },
  { href: '/path',        label: 'Learning Path',  Icon: IconMap },
  { href: '/latihan',     label: 'Latihan',        Icon: IconZap },
  { href: '/quiz',        label: 'Quiz',           Icon: IconBrain },
  { href: '/tantangan',   label: 'Tantangan',      Icon: IconTarget },
  { href: '/leaderboard', label: 'Leaderboard',    Icon: IconTrophy },
  { href: '/forum',       label: 'Forum',          Icon: IconChat },
  { href: '/chat',        label: 'Chat',           Icon: IconChat },
  { href: '/sertifikat',  label: 'Sertifikat',     Icon: IconCertificate },
  { href: '/debugging',   label: 'Debug Guide',    Icon: IconShield },
]

export default function Navbar() {
  const [user, setUser] = useState(null)
  const [scrolled, setScrolled] = useState(false)
  const [open, setOpen] = useState(false)
  const [searchVal, setSearchVal] = useState('')
  const sideRef = useRef(null)
  const pathname = usePathname()
  const router = useRouter()

  useEffect(() => {
    const s = localStorage.getItem('cb_user')
    if (s) setUser(JSON.parse(s))
    const onScroll = () => setScrolled(window.scrollY > 10)
    window.addEventListener('scroll', onScroll)
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  useEffect(() => {
    const h = (e) => { if (sideRef.current && !sideRef.current.contains(e.target)) setOpen(false) }
    if (open) document.addEventListener('mousedown', h)
    return () => document.removeEventListener('mousedown', h)
  }, [open])

  useEffect(() => { setOpen(false) }, [pathname])

  useEffect(() => {
    document.body.style.overflow = open ? 'hidden' : ''
    return () => { document.body.style.overflow = '' }
  }, [open])

  const logout = async () => {
    try { await fetch('/api/auth/logout', { method: 'POST' }) } catch {}
    localStorage.removeItem('cb_user')
    setUser(null)
    toast.success('Sampai jumpa!')
    router.push('/')
  }

  const active = (href) => pathname === href || pathname.startsWith(href + '/')
  const handleSearch = (e) => { e.preventDefault(); if (searchVal.trim()) router.push(`/materi?q=${encodeURIComponent(searchVal)}`) }
  const { level, icon: levelIcon } = getLevelInfo(user?.xp || 0)

  return (
    <>
      <nav className={`fixed top-0 inset-x-0 z-40 transition-all duration-300 ${scrolled ? 'bg-[#020617]/95 backdrop-blur-xl border-b border-white/[0.06] shadow-2xl shadow-black/30' : 'bg-transparent'}`}>
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center gap-3">

          {/* Hamburger */}
          <button onClick={() => setOpen(true)} className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-white/[0.06] transition-all active:scale-95 flex-shrink-0" aria-label="Open menu">
            <IconMenu size={20} />
          </button>

          {/* Logo */}
          <Link href="/" className="flex items-center gap-2.5 flex-shrink-0 group">
            <LogoCB size={32} className="group-hover:opacity-90 transition-opacity" />
            <span className="font-black text-lg tracking-tight text-white hidden sm:block">
              Code<span className="text-violet-400">Book</span>
            </span>
          </Link>

          {/* Search */}
          <form onSubmit={handleSearch} className="hidden md:flex flex-1 max-w-xs mx-4">
            <div className="relative w-full">
              <IconSearch size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
              <input value={searchVal} onChange={e => setSearchVal(e.target.value)}
                placeholder="Cari materi..."
                className="w-full pl-9 pr-4 py-2 bg-white/[0.05] border border-white/[0.08] rounded-xl text-sm text-slate-300 placeholder-slate-600 focus:outline-none focus:border-violet-500/50 focus:bg-white/[0.08] transition-all" />
            </div>
          </form>

          {/* Desktop nav */}
          <div className="hidden lg:flex items-center gap-0.5 flex-1">
            {NAV.slice(0, 5).map(({ href, label, Icon }) => (
              <Link key={href} href={href}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-semibold transition-all duration-200 ${active(href) ? 'text-violet-300 bg-violet-500/10' : 'text-slate-400 hover:text-slate-200 hover:bg-white/[0.05]'}`}>
                <Icon size={15} />
                {label}
              </Link>
            ))}
          </div>

          {/* Right */}
          <div className="flex items-center gap-2 ml-auto">
            {user ? (
              <Link href="/dashboard" className={`flex items-center gap-2 px-3 py-1.5 rounded-xl hover:bg-white/[0.05] transition-all ${active('/dashboard') ? 'bg-violet-500/10' : ''}`}>
                <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-violet-500 to-purple-700 flex items-center justify-center text-white font-black text-xs flex-shrink-0">
                  {user.name?.[0]?.toUpperCase()}
                </div>
                <div className="hidden sm:block text-left">
                  <p className="text-xs font-bold text-white leading-tight">{user.name?.split(' ')[0]}</p>
                  <p className="text-[10px] text-slate-500">{levelIcon} {level}</p>
                </div>
              </Link>
            ) : (
              <div className="flex items-center gap-2">
                <Link href="/login" className="hidden sm:block px-4 py-1.5 rounded-lg text-sm text-slate-400 hover:text-white transition-colors">Masuk</Link>
                <Link href="/register" className="px-4 py-1.5 rounded-lg text-sm font-black bg-violet-600 hover:bg-violet-500 text-white transition-all shadow-sm shadow-violet-500/30">Daftar</Link>
              </div>
            )}
          </div>
        </div>
      </nav>

      {/* Overlay */}
      <div className={`fixed inset-0 bg-black/70 backdrop-blur-sm z-50 transition-all duration-300 ${open ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'}`} />

      {/* Sidebar */}
      <aside ref={sideRef}
        className={`fixed top-0 left-0 h-full w-72 z-50 flex flex-col bg-[#0a0f1e] border-r border-white/[0.06] transition-transform duration-300 ease-out ${open ? 'translate-x-0' : '-translate-x-full'}`}>

        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-white/[0.06]">
          <Link href="/" className="flex items-center gap-2.5">
            <LogoCB size={34} />
            <span className="font-black text-xl text-white">Code<span className="text-violet-400">Book</span></span>
          </Link>
          <button onClick={() => setOpen(false)} className="p-2 rounded-xl text-slate-500 hover:text-white hover:bg-white/[0.06] transition-all">
            <IconClose size={18} />
          </button>
        </div>

        {/* Search mobile */}
        <form onSubmit={handleSearch} className="px-4 pt-4">
          <div className="relative">
            <IconSearch size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-600" />
            <input value={searchVal} onChange={e => setSearchVal(e.target.value)} placeholder="Cari materi..."
              className="w-full pl-9 pr-4 py-2.5 bg-white/[0.04] border border-white/[0.08] rounded-xl text-sm text-slate-300 placeholder-slate-600 focus:outline-none focus:border-violet-500/40 transition-all" />
          </div>
        </form>

        {/* User card */}
        {user && (
          <div className="mx-4 mt-4">
            <Link href="/dashboard" className="flex items-center gap-3 p-3.5 rounded-xl bg-violet-600/10 border border-violet-500/20 hover:bg-violet-600/15 transition-all">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-violet-500 to-purple-700 flex items-center justify-center text-white font-black flex-shrink-0">
                {user.name?.[0]?.toUpperCase()}
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-bold text-white text-sm truncate">{user.name}</p>
                <p className="text-xs text-slate-500 mt-0.5">{levelIcon} {level} • {user.xp || 0} XP</p>
              </div>
            </Link>
          </div>
        )}

        {/* Nav */}
        <div className="flex-1 overflow-y-auto py-4 px-3 space-y-0.5">
          <p className="text-[10px] font-black text-slate-600 uppercase tracking-widest px-3 pb-2">Menu Utama</p>
          {NAV.map(({ href, label, Icon }) => (
            <Link key={href} href={href}
              className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-semibold transition-all ${active(href) ? 'bg-violet-600/15 text-violet-300 border border-violet-500/20' : 'text-slate-400 hover:text-white hover:bg-white/[0.05]'}`}>
              <Icon size={17} className="flex-shrink-0" />
              {label}
              {active(href) && <span className="ml-auto w-1.5 h-1.5 rounded-full bg-violet-400" />}
            </Link>
          ))}

          {user && (
            <>
              <div className="my-3 border-t border-white/[0.06]" />
              <p className="text-[10px] font-black text-slate-600 uppercase tracking-widest px-3 pb-2 pt-1">Akun</p>
              <Link href="/dashboard"
                className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-semibold transition-all ${active('/dashboard') ? 'bg-violet-600/15 text-violet-300 border border-violet-500/20' : 'text-slate-400 hover:text-white hover:bg-white/[0.05]'}`}>
                <IconDashboard size={17} className="flex-shrink-0" />
                Dashboard
              </Link>
            </>
          )}

          <div className="my-3 border-t border-white/[0.06]" />
          <Link href="/verify/CB-XXXX"
            className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-semibold text-slate-400 hover:text-white hover:bg-white/[0.05] transition-all">
            <IconVerify size={17} className="flex-shrink-0" />
            Verifikasi Sertifikat
          </Link>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-white/[0.06]">
          {user ? (
            <button onClick={logout}
              className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl text-sm font-semibold text-red-400 hover:text-red-300 hover:bg-red-500/10 border border-red-500/10 hover:border-red-500/25 transition-all">
              <IconLogout size={16} />
              Keluar
            </button>
          ) : (
            <div className="grid grid-cols-2 gap-2">
              <Link href="/login" className="text-center py-2.5 rounded-xl text-sm font-semibold text-slate-400 border border-white/[0.08] hover:text-white hover:border-white/20 transition-all">Masuk</Link>
              <Link href="/register" className="text-center py-2.5 rounded-xl text-sm font-black bg-violet-600 hover:bg-violet-500 text-white transition-all">Daftar</Link>
            </div>
          )}
          <p className="text-center text-xs text-slate-700 mt-3">CodeBook © 2024</p>
        </div>
      </aside>
    </>
  )
}

function getLevelInfo(xp = 0) {
  if (xp < 500) return { level: 'Beginner', icon: '▲' }
  if (xp < 1500) return { level: 'Intermediate', icon: '◆' }
  if (xp < 3500) return { level: 'Pro', icon: '★' }
  return { level: 'Master', icon: '✦' }
}
