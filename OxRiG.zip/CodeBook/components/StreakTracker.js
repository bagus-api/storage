'use client'
import { useState, useEffect } from 'react'
import { getStreakData, calculateLevel, getXPProgress, ACHIEVEMENTS } from '@/lib/gamification'
import toast from 'react-hot-toast'

export default function StreakTracker({ user, onStreakUpdate }) {
  const [streakData, setStreakData] = useState(null)
  const [levelInfo, setLevelInfo] = useState(null)
  const [xpProgress, setXPProgress] = useState(null)

  useEffect(() => {
    if (user) {
      const streak = getStreakData(user)
      setStreakData(streak)
      
      const level = calculateLevel(user.xp || 0)
      setLevelInfo(level)
      
      const progress = getXPProgress(user.xp || 0)
      setXPProgress(progress)
    }
  }, [user])

  if (!user || !streakData || !levelInfo || !xpProgress) return null

  return (
    <div className="space-y-4">
      {/* Streak Card */}
      <div className="bg-gradient-to-br from-orange-500/10 to-red-500/10 border border-orange-500/20 rounded-xl p-4">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-xs font-semibold text-orange-600 dark:text-orange-400 uppercase tracking-wide">Daily Streak</p>
            <div className="flex items-center gap-2 mt-2">
              <span className="text-3xl font-bold text-orange-600 dark:text-orange-400">{streakData.currentStreak}</span>
              <span className="text-2xl">🔥</span>
            </div>
            <p className="text-xs text-gray-600 dark:text-slate-400 mt-1">Best: {streakData.bestStreak} hari</p>
          </div>
          <div className="text-right">
            <div className="text-4xl mb-2">
              {streakData.wasActiveToday ? '✅' : '⏳'}
            </div>
            <p className="text-xs text-gray-600 dark:text-slate-400">
              {streakData.wasActiveToday ? 'Aktif hari ini' : 'Lanjutkan belajar'}
            </p>
          </div>
        </div>
      </div>

      {/* Level & XP Progress */}
      <div className="bg-gradient-to-br from-violet-500/10 to-purple-500/10 border border-violet-500/20 rounded-xl p-4">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-3">
            <span className="text-3xl">{levelInfo.icon}</span>
            <div>
              <p className="text-xs font-semibold text-violet-600 dark:text-violet-400 uppercase tracking-wide">Level</p>
              <p className="text-lg font-bold text-gray-900 dark:text-white">{levelInfo.level}</p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-2xl font-bold text-violet-600 dark:text-violet-400">{user.xp || 0}</p>
            <p className="text-xs text-gray-600 dark:text-slate-400">XP</p>
          </div>
        </div>

        {/* XP Progress Bar */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="text-gray-600 dark:text-slate-400">{xpProgress.current} / {xpProgress.next}</span>
            <span className="text-gray-600 dark:text-slate-400">{Math.round(xpProgress.percentage)}%</span>
          </div>
          <div className="w-full h-2 bg-gray-200 dark:bg-white/[0.06] rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-violet-500 to-purple-500 transition-all duration-300"
              style={{ width: `${xpProgress.percentage}%` }}
            />
          </div>
          <p className="text-xs text-gray-600 dark:text-slate-400">
            {xpProgress.next - xpProgress.current} XP hingga {xpProgress.nextLevel}
          </p>
        </div>
      </div>

      {/* Recent Achievements */}
      {user.achievements && user.achievements.length > 0 && (
        <div className="bg-gradient-to-br from-yellow-500/10 to-amber-500/10 border border-yellow-500/20 rounded-xl p-4">
          <p className="text-xs font-semibold text-yellow-600 dark:text-yellow-400 uppercase tracking-wide mb-3">Pencapaian Terbaru</p>
          <div className="grid grid-cols-3 gap-2">
            {user.achievements.slice(-3).map((achId) => {
              const ach = Object.values(ACHIEVEMENTS).find(a => a.id === achId)
              return ach ? (
                <div
                  key={achId}
                  className="flex flex-col items-center justify-center p-2 bg-white/50 dark:bg-white/[0.05] rounded-lg border border-yellow-500/10 hover:border-yellow-500/30 transition-all"
                  title={ach.description}
                >
                  <span className="text-2xl mb-1">{ach.icon}</span>
                  <p className="text-[10px] font-semibold text-gray-900 dark:text-white text-center leading-tight">{ach.name}</p>
                </div>
              ) : null
            })}
          </div>
        </div>
      )}

      {/* Motivational Message */}
      <div className="bg-gradient-to-br from-blue-500/10 to-cyan-500/10 border border-blue-500/20 rounded-xl p-4 text-center">
        <p className="text-sm font-semibold text-gray-900 dark:text-white mb-1">
          {streakData.currentStreak >= 7 ? '🎉 Luar biasa! Kamu sangat konsisten!' : '💪 Terus semangat belajar!'}
        </p>
        <p className="text-xs text-gray-600 dark:text-slate-400">
          {streakData.wasActiveToday 
            ? 'Kembali lagi besok untuk melanjutkan streak!' 
            : 'Mulai belajar sekarang untuk mempertahankan streak!'}
        </p>
      </div>
    </div>
  )
}
