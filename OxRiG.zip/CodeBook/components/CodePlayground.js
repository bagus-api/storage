'use client'
import { useState, useEffect, useRef } from 'react'
import Editor from '@monaco-editor/react'
import toast from 'react-hot-toast'

export default function CodePlayground({ language = 'html', initialCode = '', onSave }) {
  const [code, setCode] = useState(initialCode)
  const [output, setOutput] = useState('')
  const [isRunning, setIsRunning] = useState(false)
  const [error, setError] = useState('')
  const [theme, setTheme] = useState('dark')
  const iframeRef = useRef(null)
  const [showPreview, setShowPreview] = useState(true)

  // Detect theme from document
  useEffect(() => {
    const isDark = document.documentElement.classList.contains('dark')
    setTheme(isDark ? 'vs-dark' : 'vs-light')

    // Listen for theme changes
    const observer = new MutationObserver(() => {
      const isDark = document.documentElement.classList.contains('dark')
      setTheme(isDark ? 'vs-dark' : 'vs-light')
    })

    observer.observe(document.documentElement, { attributes: true, attributeFilter: ['class'] })
    return () => observer.disconnect()
  }, [])

  const runCode = () => {
    setIsRunning(true)
    setError('')

    try {
      if (language === 'html') {
        // For HTML, directly render in iframe
        if (iframeRef.current) {
          const doc = iframeRef.current.contentDocument
          doc.open()
          doc.write(code)
          doc.close()
        }
        setOutput('✓ HTML rendered successfully')
      } else if (language === 'javascript') {
        // For JavaScript, execute in console context
        const logs = []
        const originalLog = console.log
        console.log = (...args) => {
          logs.push(args.map(arg => {
            if (typeof arg === 'object') return JSON.stringify(arg, null, 2)
            return String(arg)
          }).join(' '))
          originalLog(...args)
        }

        try {
          // eslint-disable-next-line no-eval
          eval(code)
          setOutput(logs.length > 0 ? logs.join('\n') : '✓ Code executed successfully')
        } catch (e) {
          setError(`Error: ${e.message}`)
          setOutput('')
        }

        console.log = originalLog
      } else if (language === 'css') {
        // For CSS, show preview with sample HTML
        const htmlWithCSS = `
          <!DOCTYPE html>
          <html>
          <head>
            <style>
              ${code}
            </style>
          </head>
          <body style="margin: 0; padding: 20px; background: #f5f5f5; font-family: Arial, sans-serif;">
            <div class="container">
              <h1>CSS Preview</h1>
              <p>Your CSS is now active. Edit the code to see changes in real-time.</p>
              <div class="box">Sample Box</div>
              <button>Sample Button</button>
            </div>
          </body>
          </html>
        `
        if (iframeRef.current) {
          const doc = iframeRef.current.contentDocument
          doc.open()
          doc.write(htmlWithCSS)
          doc.close()
        }
        setOutput('✓ CSS rendered successfully')
      }
    } catch (err) {
      setError(`Error: ${err.message}`)
      setOutput('')
    } finally {
      setIsRunning(false)
    }
  }

  const resetCode = () => {
    setCode(initialCode)
    setOutput('')
    setError('')
    toast.success('Code reset to initial state')
  }

  const copyCode = () => {
    navigator.clipboard.writeText(code)
    toast.success('Code copied to clipboard!')
  }

  const downloadCode = () => {
    const element = document.createElement('a')
    const file = new Blob([code], { type: 'text/plain' })
    element.href = URL.createObjectURL(file)
    element.download = `code.${language === 'html' ? 'html' : language === 'css' ? 'css' : 'js'}`
    document.body.appendChild(element)
    element.click()
    document.body.removeChild(element)
    toast.success('Code downloaded!')
  }

  const getLanguageLabel = () => {
    const labels = {
      html: '🌐 HTML',
      css: '🎨 CSS',
      javascript: '⚙️ JavaScript',
    }
    return labels[language] || language
  }

  return (
    <div className="w-full h-full flex flex-col bg-white dark:bg-[#1e1e1e] rounded-xl border border-gray-200 dark:border-white/[0.06] overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-gray-200 dark:border-white/[0.06] bg-gray-50 dark:bg-[#252526]">
        <div className="flex items-center gap-3">
          <span className="text-sm font-semibold text-gray-900 dark:text-white">{getLanguageLabel()}</span>
          <span className="text-xs text-gray-500 dark:text-slate-500">Playground</span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={copyCode}
            className="p-2 rounded-lg text-gray-600 dark:text-slate-400 hover:text-gray-900 dark:hover:text-white hover:bg-gray-200 dark:hover:bg-white/[0.1] transition-all"
            title="Copy code"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
            </svg>
          </button>

          <button
            onClick={downloadCode}
            className="p-2 rounded-lg text-gray-600 dark:text-slate-400 hover:text-gray-900 dark:hover:text-white hover:bg-gray-200 dark:hover:bg-white/[0.1] transition-all"
            title="Download code"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
            </svg>
          </button>

          <button
            onClick={resetCode}
            className="p-2 rounded-lg text-gray-600 dark:text-slate-400 hover:text-gray-900 dark:hover:text-white hover:bg-gray-200 dark:hover:bg-white/[0.1] transition-all"
            title="Reset code"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
            </svg>
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex overflow-hidden">
        {/* Editor */}
        <div className="flex-1 flex flex-col border-r border-gray-200 dark:border-white/[0.06]">
          <Editor
            height="100%"
            language={language}
            value={code}
            onChange={(value) => setCode(value || '')}
            theme={theme}
            options={{
              minimap: { enabled: false },
              fontSize: 13,
              fontFamily: "'JetBrains Mono', monospace",
              scrollBeyondLastLine: false,
              wordWrap: 'on',
              tabSize: 2,
              automaticLayout: true,
            }}
          />
        </div>

        {/* Preview/Output */}
        {showPreview && (
          <div className="flex-1 flex flex-col bg-white dark:bg-[#1e1e1e] border-l border-gray-200 dark:border-white/[0.06]">
            {/* Preview Controls */}
            <div className="flex items-center justify-between px-4 py-3 border-b border-gray-200 dark:border-white/[0.06] bg-gray-50 dark:bg-[#252526]">
              <span className="text-xs font-semibold text-gray-900 dark:text-white">
                {language === 'html' ? '👁️ Preview' : '📤 Output'}
              </span>
              <button
                onClick={runCode}
                disabled={isRunning}
                className="px-3 py-1.5 rounded-lg bg-violet-600 hover:bg-violet-500 text-white text-xs font-semibold transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
              >
                {isRunning ? (
                  <>
                    <span className="inline-block animate-spin">⚙️</span>
                    Running...
                  </>
                ) : (
                  <>
                    ▶️ Run
                  </>
                )}
              </button>
            </div>

            {/* Preview Content */}
            <div className="flex-1 overflow-auto">
              {language === 'html' ? (
                <iframe
                  ref={iframeRef}
                  className="w-full h-full border-0"
                  title="HTML Preview"
                  sandbox="allow-scripts"
                />
              ) : (
                <div className="p-4">
                  {error ? (
                    <div className="p-3 rounded-lg bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/20">
                      <p className="text-xs font-semibold text-red-700 dark:text-red-400 mb-2">❌ Error</p>
                      <pre className="text-xs text-red-600 dark:text-red-300 overflow-auto font-mono whitespace-pre-wrap break-words">
                        {error}
                      </pre>
                    </div>
                  ) : output ? (
                    <div className="p-3 rounded-lg bg-green-50 dark:bg-green-500/10 border border-green-200 dark:border-green-500/20">
                      <p className="text-xs font-semibold text-green-700 dark:text-green-400 mb-2">✓ Output</p>
                      <pre className="text-xs text-green-600 dark:text-green-300 overflow-auto font-mono whitespace-pre-wrap break-words">
                        {output}
                      </pre>
                    </div>
                  ) : (
                    <div className="flex items-center justify-center h-full text-gray-500 dark:text-slate-500 text-sm">
                      Click "Run" to execute code
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="px-4 py-2 border-t border-gray-200 dark:border-white/[0.06] bg-gray-50 dark:bg-[#252526] flex items-center justify-between text-xs text-gray-600 dark:text-slate-400">
        <span>{code.length} characters</span>
        <button
          onClick={() => setShowPreview(!showPreview)}
          className="text-violet-600 dark:text-violet-400 hover:text-violet-700 dark:hover:text-violet-300 font-semibold"
        >
          {showPreview ? '← Hide Preview' : 'Show Preview →'}
        </button>
      </div>
    </div>
  )
}
