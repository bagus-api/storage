/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: 'class',
  content: ['./app/**/*.{js,jsx}','./components/**/*.{js,jsx}'],
  theme: {
    extend: {
      fontFamily: {
        sans: ['Plus Jakarta Sans', 'sans-serif'],
        mono: ['JetBrains Mono', 'monospace'],
      },
      colors: {
        brand: { DEFAULT:'#7c3aed', light:'#8b5cf6', dark:'#6d28d9', pale:'#ede9fe' },
        surface: { DEFAULT:'#0f172a', 2:'#1e293b', 3:'#334155' },
      },
      animation: {
        'fade-up': 'fadeUp 0.5s ease forwards',
        'fade-in': 'fadeIn 0.4s ease forwards',
        shimmer: 'shimmer 1.5s infinite',
        'slide-left': 'slideInLeft 0.25s ease',
        'bounce-slow': 'bounce 3s infinite',
      },
    },
  },
  plugins: [],
}
