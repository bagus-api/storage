# CodeBook 📚

Platform belajar coding fullstack modern — HTML, CSS, JavaScript, Python, Backend, dan Cybersecurity.

## Tech Stack

- **Frontend**: Next.js 14 (App Router), Tailwind CSS
- **Backend**: Next.js API Routes (Serverless)
- **Database**: MongoDB Atlas (Mongoose)
- **Auth**: JWT + bcryptjs
- **Editor**: Monaco Editor
- **Notif**: React Hot Toast

## Fitur

- 🔐 Auth (JWT + MongoDB)
- 📚 6 Materi dengan chapter
- ⚡ Code Editor (JS, HTML, Python)
- 🧠 Quiz interaktif dengan nilai otomatis
- 📜 Generate & download sertifikat (PNG)
- 🔍 Verifikasi sertifikat via ID
- 👑 Sistem XP + 4 Level (Beginner → Master)
- 🏷️ 7 Badge koleksi
- 🔥 Daily streak login
- 📊 Dashboard progress

## Install & Jalankan

```bash
# 1. Install dependencies
npm install

# 2. Buat .env.local
cp .env.local.example .env.local
# Edit MONGODB_URI dan JWT_SECRET

# 3. Jalankan development server
npm run dev
```

Buka [http://localhost:3000](http://localhost:3000)

## Environment Variables

```env
MONGODB_URI=mongodb+srv://user:pass@cluster.mongodb.net/codebook
JWT_SECRET=random_string_yang_panjang_dan_aman
NEXT_PUBLIC_BASE_URL=http://localhost:3000
```

## Deploy ke Vercel

1. Push ke GitHub
2. Import repo di [vercel.com](https://vercel.com)
3. Set Environment Variables di dashboard Vercel:
   - `MONGODB_URI`
   - `JWT_SECRET`
   - `NEXT_PUBLIC_BASE_URL` (URL produksi kamu)
4. Deploy!

## Struktur Folder

```
codebook/
├── app/
│   ├── api/            # API Routes
│   ├── dashboard/
│   ├── latihan/
│   ├── login/
│   ├── materi/[slug]/
│   ├── quiz/[slug]/
│   ├── register/
│   ├── sertifikat/
│   └── verify/[id]/
├── components/
│   ├── layout/         # Navbar
│   └── ui/             # Skeleton, ProgressBar, Badge
├── data/               # Materi & Quiz data
├── lib/                # mongodb, auth, utils
├── models/             # Mongoose models
└── public/
```

## Developer

Built with ❤️ by CodeBook Team
