// ============================================================
// DEBUGGING GUIDE — Error Types & How to Fix Them
// ============================================================

export const DEBUGGING_TOPICS = [
  // ─── JAVASCRIPT ───────────────────────────────────────────
  {
    id: 'js-errors',
    lang: 'javascript',
    title: 'JavaScript Error Guide',
    icon: 'js',
    color: '#EAB308',
    desc: 'Pahami dan atasi semua jenis error JavaScript — dari SyntaxError hingga async bugs.',
    errors: [
      {
        id: 'js-1',
        name: 'ReferenceError: x is not defined',
        category: 'ReferenceError',
        severity: 'error',
        buggyCode: `// BUG: Menggunakan variabel sebelum dideklarasikan
console.log(namaSiswa)   // ReferenceError!

function sapa() {
  return pesan   // ReferenceError! 'pesan' tidak ada di scope ini
}

let pesan = "Halo"`,
        fixedCode: `// FIX: Deklarasikan variabel sebelum digunakan
let namaSiswa = "Budi"
console.log(namaSiswa)   // "Budi"

// Atau pindahkan ke scope yang benar
let pesan = "Halo"

function sapa() {
  return pesan   // Sekarang bisa akses karena di scope yang sama
}`,
        explanation: 'ReferenceError terjadi ketika kamu menggunakan variabel yang belum dideklarasikan atau di luar scope. Selalu deklarasikan variabel dengan `const`/`let` sebelum menggunakannya.',
        tips: ['Gunakan `const` untuk nilai tetap, `let` untuk yang berubah', 'Hindari `var` — punya scoping yang membingungkan (function scope, bukan block scope)', 'ESLint bisa otomatis deteksi variabel yang tidak dideklarasikan'],
      },
      {
        id: 'js-2',
        name: 'TypeError: Cannot read properties of undefined',
        category: 'TypeError',
        severity: 'error',
        buggyCode: `// BUG: Mengakses property dari nilai undefined/null
const user = null
console.log(user.nama)   // TypeError: Cannot read properties of null

// BUG: Array kosong diakses index yang tidak ada
const data = []
console.log(data[0].id)  // TypeError: undefined.id

// BUG: Async belum selesai
async function getUser() {
  const res = await fetch('/api/user')
  return res.json()
}
const user2 = getUser()  // ini Promise, bukan data!
console.log(user2.nama)  // TypeError`,
        fixedCode: `// FIX 1: Optional chaining (?.)
const user = null
console.log(user?.nama)       // undefined (tidak error)
console.log(user?.alamat?.kota)  // undefined (chain aman)

// FIX 2: Nullish coalescing (??)
const nama = user?.nama ?? "Guest"
console.log(nama)  // "Guest"

// FIX 3: Check sebelum akses
const data = []
if (data.length > 0) {
  console.log(data[0].id)
}

// FIX 4: Await yang benar
async function main() {
  const user2 = await getUser()  // await!
  console.log(user2?.nama)
}`,
        explanation: 'TypeError paling umum di JavaScript. Terjadi saat kamu mencoba mengakses property dari `null` atau `undefined`. Gunakan optional chaining `?.` dan nullish coalescing `??` untuk handle ini dengan aman.',
        tips: ['Gunakan `?.` untuk optional chaining: `obj?.prop?.subprop`', 'Gunakan `??` sebagai fallback: `nilai ?? "default"`', 'Selalu `await` fungsi async sebelum menggunakan hasilnya', 'TypeScript bisa mencegah error ini dengan type checking'],
      },
      {
        id: 'js-3',
        name: 'Infinite Loop',
        category: 'Logic Error',
        severity: 'warning',
        buggyCode: `// BUG: Kondisi loop tidak pernah false
let i = 0
while (i < 10) {
  console.log(i)
  // Lupa i++ ! Loop jalan selamanya
}

// BUG: Recursive tanpa base case
function faktorial(n) {
  return n * faktorial(n - 1)  // Tidak ada base case!
}`,
        fixedCode: `// FIX 1: Pastikan kondisi terminasi
let i = 0
while (i < 10) {
  console.log(i)
  i++   // WAJIB ada! Atau gunakan for loop yang lebih aman
}

// Lebih baik pakai for loop
for (let i = 0; i < 10; i++) {
  console.log(i)
}

// FIX 2: Recursive dengan base case
function faktorial(n) {
  if (n <= 1) return 1  // Base case!
  return n * faktorial(n - 1)
}

console.log(faktorial(5))  // 120`,
        explanation: 'Infinite loop menyebabkan browser/Node.js hang. Selalu pastikan ada kondisi terminasi yang pasti akan terpenuhi.',
        tips: ['`for` loop lebih aman dari `while` untuk iterasi yang jelas jumlahnya', 'Selalu ada base case di recursive function', 'Gunakan `console.log` untuk debug nilai loop counter', 'Set timeout untuk deteksi infinite loop: `setTimeout(() => process.exit(), 5000)`'],
      },
      {
        id: 'js-4',
        name: 'Async/Await tidak ditunggu',
        category: 'Async Bug',
        severity: 'error',
        buggyCode: `// BUG: Lupa await
async function fetchUser(id) {
  const res = await fetch(\`/api/users/\${id}\`)
  return res.json()
}

// Lupa await!
const user = fetchUser(1)  // ini Promise object, bukan data
console.log(user.nama)    // undefined — Promise tidak punya .nama

// BUG: forEach tidak menunggu async
const ids = [1, 2, 3]
ids.forEach(async (id) => {
  const user = await fetchUser(id)  // forEach tidak await ini!
  console.log(user)
})
console.log("Selesai!")  // Ini muncul SEBELUM fetch selesai`,
        fixedCode: `// FIX 1: Selalu await
async function main() {
  const user = await fetchUser(1)  // await!
  console.log(user.nama)  // data yang benar
}

// FIX 2: Gunakan for...of untuk async loop
async function loadAll() {
  const ids = [1, 2, 3]
  
  // Sequential (satu per satu)
  for (const id of ids) {
    const user = await fetchUser(id)
    console.log(user)
  }
  
  // Parallel (semua sekaligus, lebih cepat)
  const users = await Promise.all(ids.map(id => fetchUser(id)))
  console.log(users)
  
  console.log("Benar-benar selesai!")
}`,
        explanation: 'Async bug sangat umum dan susah di-debug. Ingat: `async function` selalu return Promise. Kamu HARUS `await` atau `.then()` untuk mendapat nilai sebenarnya.',
        tips: ['Selalu `await` fungsi async di dalam `async function`', 'Gunakan `for...of` bukan `forEach` untuk loop async', 'Gunakan `Promise.all()` untuk parallel execution', 'TypeScript bisa deteksi Promise yang tidak di-await'],
      },
    ],
  },

  // ─── PYTHON ────────────────────────────────────────────────
  {
    id: 'python-errors',
    lang: 'python',
    title: 'Python Error Guide',
    icon: 'py',
    color: '#3B82F6',
    desc: 'Debug semua jenis error Python — IndentationError, TypeError, logic error, dan lainnya.',
    errors: [
      {
        id: 'py-1',
        name: 'IndentationError: unexpected indent',
        category: 'IndentationError',
        severity: 'error',
        buggyCode: `# BUG: Indentasi tidak konsisten
def hitung(a, b):
  hasil = a + b  # 2 spasi
    return hasil   # IndentationError! 4 spasi tiba-tiba

# BUG: Tab vs Spasi dicampur
if True:
	print("tab")  # tab
    print("spasi")  # spasi - ERROR!`,
        fixedCode: `# FIX: Konsisten gunakan 4 spasi
def hitung(a, b):
    hasil = a + b   # 4 spasi
    return hasil    # 4 spasi konsisten

# FIX: Gunakan spasi saja (standar PEP8)
if True:
    print("konsisten")   # 4 spasi
    print("semua spasi") # 4 spasi`,
        explanation: 'Python menggunakan indentasi untuk menandai blok kode — bukan kurung kurawal seperti bahasa lain. Selalu gunakan 4 spasi (bukan tab) secara konsisten.',
        tips: ['Set editor untuk convert tab ke 4 spasi', 'Gunakan autopep8 atau black formatter', 'PEP8 adalah standar style guide Python', 'Jalankan `python -m py_compile file.py` untuk cek syntax'],
      },
      {
        id: 'py-2',
        name: 'TypeError: unsupported operand type',
        category: 'TypeError',
        severity: 'error',
        buggyCode: `# BUG: Operasi pada tipe data yang salah
umur = input("Umurmu: ")
tahun_lahir = 2024 - umur  # TypeError! input() return string

# BUG: Gabungkan string dan int
nama = "Budi"
umur = 17
print("Halo " + nama + " umur " + umur)  # TypeError!

# BUG: List berisi tipe berbeda dihitung
nilai = [80, 90, "85", 70]
rata = sum(nilai) / len(nilai)  # TypeError! "85" bukan int`,
        fixedCode: `# FIX 1: Convert tipe data
umur = int(input("Umurmu: "))  # Convert ke int
tahun_lahir = 2024 - umur  # OK!

# FIX 2: f-string atau str()
nama = "Budi"
umur = 17
print(f"Halo {nama} umur {umur}")  # f-string (cara modern)
print("Halo " + nama + " umur " + str(umur))  # str() conversion

# FIX 3: Pastikan semua elemen numerik
nilai = [80, 90, 85, 70]  # Hapus string "85"
# Atau convert semua ke float:
nilai_clean = [float(n) for n in nilai]
rata = sum(nilai_clean) / len(nilai_clean)`,
        explanation: 'Python tidak otomatis convert tipe data. Kamu harus eksplisit menggunakan int(), float(), str() untuk konversi.',
        tips: ['Gunakan f-string untuk format string modern: f"Halo {nama}"', 'input() selalu return string — selalu convert jika perlu angka', 'type() dan isinstance() untuk cek tipe data saat runtime', 'Gunakan type hints di Python 3.5+ untuk dokumentasi dan linting'],
      },
      {
        id: 'py-3',
        name: 'IndexError & KeyError',
        category: 'IndexError',
        severity: 'error',
        buggyCode: `# BUG: IndexError - index di luar range
nilai = [80, 90, 85]
print(nilai[3])    # IndexError! index 3 tidak ada (max 2)
print(nilai[-4])   # IndexError! index negatif terlalu kecil

# BUG: KeyError - key tidak ada di dict
siswa = {"nama": "Budi", "umur": 17}
print(siswa["email"])   # KeyError! "email" tidak ada
print(siswa["NAMA"])    # KeyError! case-sensitive!`,
        fixedCode: `# FIX 1: Cek panjang atau gunakan try/except
nilai = [80, 90, 85]

# Cara 1: cek index
if len(nilai) > 3:
    print(nilai[3])

# Cara 2: try/except
try:
    print(nilai[3])
except IndexError:
    print("Index tidak valid")

# Cara 3: .get() untuk dict
siswa = {"nama": "Budi", "umur": 17}
email = siswa.get("email", "Tidak ada")  # Default value
print(email)  # "Tidak ada" (tidak error)

# Cara 4: cek dulu
if "email" in siswa:
    print(siswa["email"])

# Cara 5: defaultdict
from collections import defaultdict
data = defaultdict(list)
data["nilai"].append(85)  # Tidak error meski "nilai" belum ada`,
        explanation: 'IndexError dan KeyError terjadi saat mengakses elemen yang tidak ada. Gunakan .get() untuk dict dan cek panjang untuk list, atau tangkap dengan try/except.',
        tips: ['dict.get(key, default) lebih aman dari dict[key]', 'Gunakan `in` untuk cek keberadaan key: `if key in dict`', 'Gunakan try/except untuk handle error secara graceful', 'enumerate() untuk loop dengan index yang aman'],
      },
    ],
  },

  // ─── JAVA ──────────────────────────────────────────────────
  {
    id: 'java-errors',
    lang: 'java',
    title: 'Java Error Guide',
    icon: 'java',
    color: '#F97316',
    desc: 'Debug NullPointerException, ClassCastException, ArrayIndexOutOfBoundsException, dan lainnya.',
    errors: [
      {
        id: 'java-1',
        name: 'NullPointerException (NPE)',
        category: 'RuntimeException',
        severity: 'error',
        buggyCode: `// BUG: Mengakses method/field dari null object
String nama = null;
System.out.println(nama.length());  // NullPointerException!

// BUG: Return null tanpa check
public Siswa findSiswa(String nim) {
    // ... search logic
    return null;  // Tidak ketemu
}

Siswa s = findSiswa("123");
System.out.println(s.getNama());  // NPE jika tidak ketemu!`,
        fixedCode: `// FIX 1: Null check
String nama = null;
if (nama != null) {
    System.out.println(nama.length());
}
// Atau Objects.requireNonNull
Objects.requireNonNull(nama, "nama tidak boleh null");

// FIX 2: Gunakan Optional (Java 8+)
public Optional<Siswa> findSiswa(String nim) {
    // ... search logic
    return Optional.empty();  // Bukan null!
}

Optional<Siswa> hasil = findSiswa("123");
hasil.ifPresent(s -> System.out.println(s.getNama()));
// Atau
String namaSiswa = hasil.map(Siswa::getNama).orElse("Tidak ditemukan");

// FIX 3: String comparison yang benar
String a = "hello";
// JANGAN: a == "hello" (compare reference)
// LAKUKAN:
if ("hello".equals(a)) {  // Null-safe: literal dulu
    System.out.println("Sama");
}`,
        explanation: 'NullPointerException adalah error paling umum di Java. Hindari dengan menggunakan Optional<T> untuk nilai yang mungkin null, dan selalu cek null sebelum mengakses object.',
        tips: ['Gunakan Optional<T> sebagai return type daripada null', '"hello".equals(var) lebih aman dari var.equals("hello")', 'Annotasi @NonNull dan @Nullable membantu IDE mendeteksi NPE', 'Java 14+ punya helpful NullPointerException dengan detail lokasi null'],
      },
      {
        id: 'java-2',
        name: 'ArrayIndexOutOfBoundsException',
        category: 'RuntimeException',
        severity: 'error',
        buggyCode: `// BUG: Index di luar range array
int[] nilai = {80, 90, 85};
System.out.println(nilai[3]);   // ArrayIndexOutOfBoundsException!
// Index valid: 0, 1, 2 (length-1)

// BUG: Off-by-one error
for (int i = 0; i <= nilai.length; i++) {  // <= harusnya <
    System.out.println(nilai[i]);  // Error di iterasi terakhir
}`,
        fixedCode: `// FIX 1: Cek bounds
int[] nilai = {80, 90, 85};
int targetIndex = 3;
if (targetIndex < nilai.length) {
    System.out.println(nilai[targetIndex]);
}

// FIX 2: Enhanced for loop (tidak bisa ArrayIndexOutOfBounds)
for (int n : nilai) {
    System.out.println(n);
}

// FIX 3: Perbaiki kondisi loop
for (int i = 0; i < nilai.length; i++) {  // < bukan <=
    System.out.println(nilai[i]);
}

// FIX 4: Gunakan ArrayList yang lebih fleksibel
List<Integer> nilaiList = new ArrayList<>(Arrays.asList(80, 90, 85));
nilaiList.get(0);  // Tetap bisa IndexOutOfBoundsException, tapi lebih informatif`,
        explanation: 'ArrayIndexOutOfBoundsException terjadi saat mengakses index di luar range [0, length-1]. Off-by-one error (pakai <= bukan <) adalah penyebab paling umum.',
        tips: ['Gunakan enhanced for-each loop bila tidak perlu index', 'Index valid: 0 sampai array.length - 1', 'Pertimbangkan ArrayList/List<T> daripada array primitif', 'Selalu cek `index < array.length` sebelum akses'],
      },
    ],
  },

  // ─── PHP ───────────────────────────────────────────────────
  {
    id: 'php-errors',
    lang: 'php',
    title: 'PHP Error Guide',
    icon: 'php',
    color: '#818CF8',
    desc: 'Debug PHP errors — Undefined variable, SQL injection prevention, session errors.',
    errors: [
      {
        id: 'php-1',
        name: 'Undefined variable & Notice',
        category: 'Notice/Warning',
        severity: 'warning',
        buggyCode: `<?php
// BUG: Variable belum diset tapi langsung dipakai
echo $nama;   // Notice: Undefined variable

// BUG: Array key tidak ada
$siswa = ["nama" => "Budi"];
echo $siswa["email"];  // Notice: Undefined index

// BUG: Undefined variable di kondisi
if ($isLogin) {  // Notice + mungkin logic error
    echo "Logged in";
}
?>`,
        fixedCode: `<?php
// FIX 1: Cek isset() sebelum pakai
if (isset($nama)) {
    echo $nama;
} else {
    echo "Nama belum diset";
}

// FIX 2: Null coalescing operator (??)
$nama = $nama ?? "Guest";  // Gunakan "Guest" jika $nama undefined
echo $siswa["email"] ?? "Email tidak ada";

// FIX 3: Inisialisasi variabel
$isLogin = false;  // Selalu inisialisasi
if ($isLogin) {
    echo "Logged in";
}

// FIX 4: Error reporting yang tepat untuk development
error_reporting(E_ALL);  // Tampilkan semua error
ini_set('display_errors', '1');  // Hanya di development!
?>`,
        explanation: 'PHP Notice adalah peringatan bukan error fatal, tapi harus diperbaiki. Gunakan isset(), empty(), atau ?? untuk handle variabel yang mungkin tidak ada.',
        tips: ['`isset($var)` cek apakah variabel ada dan bukan null', '`empty($var)` cek apakah variabel kosong/falsy', '`$var ?? "default"` adalah null coalescing (PHP 7+)', 'Aktifkan error_reporting(E_ALL) saat development'],
      },
      {
        id: 'php-2',
        name: 'SQL Injection via PHP',
        category: 'Security Bug',
        severity: 'critical',
        buggyCode: `<?php
// BERBAHAYA: String concatenation langsung ke SQL
$username = $_POST['username'];  // Input dari user
$password = $_POST['password'];

// Payload: username = "admin' --"
$sql = "SELECT * FROM users 
        WHERE username = '$username'      
        AND password = '$password'";
// Query jadi: WHERE username = 'admin' --' AND password = '...'
// -- adalah komentar SQL, password check ter-bypass!

$result = mysqli_query($conn, $sql);  // BAHAYA!
?>`,
        fixedCode: `<?php
// FIX 1: Prepared Statement dengan PDO (DIREKOMENDASIKAN)
$pdo = new PDO("mysql:host=localhost;dbname=mydb", $user, $pass);
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? AND password = ?");
$stmt->execute([$username, $hashedPassword]);  // Parameter dipisah!
$user = $stmt->fetch();

// FIX 2: Prepared Statement dengan MySQLi
$stmt = $conn->prepare("SELECT * FROM users WHERE username = ? AND password = ?");
$stmt->bind_param("ss", $username, $hashedPassword);
$stmt->execute();

// FIX 3: Hash password dengan password_hash()
// JANGAN simpan password plain text!
$hashedPassword = password_hash($password, PASSWORD_BCRYPT);
$isValid = password_verify($inputPassword, $hashedPassword);
?>`,
        explanation: 'SQL Injection adalah celah keamanan KRITIS. Input user TIDAK BOLEH langsung masuk ke query SQL. Selalu gunakan Prepared Statement / Parameterized Query.',
        tips: ['SELALU gunakan PDO atau MySQLi prepared statements', 'JANGAN pernah simpan password plain text — gunakan password_hash()', 'Validasi dan sanitasi semua input user', 'Gunakan htmlspecialchars() untuk output ke HTML'],
      },
    ],
  },

  // ─── C++ ───────────────────────────────────────────────────
  {
    id: 'cpp-errors',
    lang: 'cpp',
    title: 'C++ Error & Memory Guide',
    icon: 'cpp',
    color: '#60A5FA',
    desc: 'Debug segmentation fault, memory leak, undefined behavior, dan common C++ pitfalls.',
    errors: [
      {
        id: 'cpp-1',
        name: 'Segmentation Fault (Dangling Pointer)',
        category: 'Memory Error',
        severity: 'error',
        buggyCode: `// BUG: Dangling pointer - mengakses memori yang sudah dibebaskan
#include <iostream>
using namespace std;

int* createNumber() {
    int num = 42;     // Local variable di stack
    return &num;      // BAHAYA: return alamat local variable!
}   // num dihancurkan di sini!

int main() {
    int* ptr = createNumber();
    cout << *ptr;   // Undefined behavior! Memori tidak valid

    // BUG: Double free
    int* p = new int(10);
    delete p;   // OK
    delete p;   // BUG: Double free! Crash atau corruption
    
    return 0;
}`,
        fixedCode: `// FIX 1: Return by value, bukan pointer ke local
#include <iostream>
#include <memory>
using namespace std;

int createNumber() {
    int num = 42;
    return num;   // Return nilai, bukan pointer
}

// FIX 2: Gunakan smart pointer (C++11+)
unique_ptr<int> createNumberSafe() {
    return make_unique<int>(42);  // Auto-delete saat keluar scope
}

int main() {
    int num = createNumber();     // Safe: copy nilai
    cout << num;   // OK!
    
    // Smart pointer - auto memory management
    auto ptr = createNumberSafe();
    cout << *ptr;   // OK!
    // delete otomatis saat ptr keluar scope
    
    // FIX 3: Set ke nullptr setelah delete
    int* p = new int(10);
    delete p;
    p = nullptr;    // Prevent dangling pointer
    // delete p;    // Sekarang aman: delete nullptr = no-op
    
    return 0;
}`,
        explanation: 'Segmentation fault di C++ sering disebabkan pointer yang tidak valid. Gunakan smart pointers (unique_ptr, shared_ptr) sebagai pengganti raw new/delete.',
        tips: ['Gunakan unique_ptr/shared_ptr bukan raw pointer', 'Set pointer ke nullptr setelah delete', 'Jangan return pointer/reference ke local variable', 'Gunakan Valgrind atau AddressSanitizer untuk deteksi memory errors'],
      },
      {
        id: 'cpp-2',
        name: 'Memory Leak',
        category: 'Memory Error',
        severity: 'warning',
        buggyCode: `// BUG: Memory leak - new tanpa delete
#include <iostream>
using namespace std;

void fungsiLeak() {
    int* arr = new int[1000];  // Alokasi heap
    // ... proses data ...
    // Lupa delete[] arr;  -- MEMORY LEAK!
}   // arr keluar scope, pointer hilang, memori bocor!

class MyClass {
    int* data;
public:
    MyClass() { data = new int[100]; }
    // Lupa destructor! Memory leak setiap kali object dibuat
};`,
        fixedCode: `// FIX 1: Selalu delete setelah new
#include <iostream>
#include <memory>
#include <vector>
using namespace std;

void fungsiAman() {
    // Cara 1: Manual delete
    int* arr = new int[1000];
    // ... proses ...
    delete[] arr;  // WAJIB!
    
    // Cara 2 (LEBIH BAIK): Smart pointer
    auto arr2 = make_unique<int[]>(1000);
    // Auto delete saat keluar scope
    
    // Cara 3 (TERBAIK): Gunakan vector
    vector<int> arr3(1000);  // No manual memory management!
}

class MyClassFixed {
    vector<int> data;   // Gunakan vector, bukan pointer!
public:
    MyClassFixed() : data(100) {}
    // Destructor otomatis dari vector
    
    // Atau jika perlu raw pointer:
    ~MyClassFixed() { delete[] rawData; }  // RULE OF THREE/FIVE
private:
    int* rawData = nullptr;
};`,
        explanation: 'Memory leak terjadi ketika memori yang dialokasikan dengan `new` tidak pernah di-`delete`. Gunakan RAII (Resource Acquisition Is Initialization) dengan smart pointers atau containers.',
        tips: ['Preferensikan vector/array/string atas raw pointer', 'Gunakan unique_ptr untuk ownership tunggal, shared_ptr untuk shared', 'RAII: resource dikelola dalam constructor/destructor', 'Jalankan dengan AddressSanitizer: g++ -fsanitize=address'],
      },
    ],
  },

  // ─── SQL ───────────────────────────────────────────────────
  {
    id: 'sql-errors',
    lang: 'sql',
    title: 'SQL Error Guide',
    icon: 'sql',
    color: '#06B6D4',
    desc: 'Debug SQL errors — syntax errors, JOIN issues, N+1 query problem, dan optimasi.',
    errors: [
      {
        id: 'sql-1',
        name: 'Ambiguous column name in JOIN',
        category: 'Syntax Error',
        severity: 'error',
        buggyCode: `-- BUG: Kolom nama ada di KEDUA tabel, ambigu!
SELECT nama, email, total
FROM users
JOIN orders ON users.id = orders.user_id
-- Error: Column 'nama' is ambiguous
-- (users.nama atau orders.nama?)`,
        fixedCode: `-- FIX: Spesifikasikan tabel atau pakai alias
SELECT 
    u.nama,           -- Eksplisit dari tabel users
    u.email,
    o.total,
    o.created_at
FROM users u           -- Alias singkat
JOIN orders o ON u.id = o.user_id
ORDER BY o.created_at DESC;

-- Praktik terbaik: SELALU gunakan alias tabel saat JOIN
SELECT 
    u.id AS user_id,
    u.nama AS nama_user,
    COUNT(o.id) AS total_order,
    SUM(o.total) AS total_belanja
FROM users u
LEFT JOIN orders o ON u.id = o.user_id
GROUP BY u.id, u.nama;`,
        explanation: 'Ambiguous column error terjadi ketika kolom dengan nama sama ada di beberapa tabel yang di-JOIN. Selalu gunakan alias tabel (u, o, p, dll) untuk kejelasan.',
        tips: ['Selalu gunakan alias tabel saat melakukan JOIN', 'Gunakan AS untuk nama kolom yang deskriptif', 'Spesifikasikan semua kolom yang diambil (hindari SELECT *)', 'Gunakan EXPLAIN untuk analisis performa query'],
      },
      {
        id: 'sql-2',
        name: 'N+1 Query Problem',
        category: 'Performance Bug',
        severity: 'warning',
        buggyCode: `-- BUG: N+1 - 1 query untuk list + N query untuk setiap item

-- Query 1: Ambil semua orders (misal 100 rows)
SELECT * FROM orders;

-- Kemudian untuk SETIAP order, query lagi:
-- Query 2: SELECT * FROM users WHERE id = 1
-- Query 3: SELECT * FROM users WHERE id = 2
-- ... (100 kali!)

-- Di kode aplikasi:
-- orders.forEach(order => {
--   const user = db.query("SELECT * FROM users WHERE id = ?", order.userId)
-- })
-- Total: 101 queries!`,
        fixedCode: `-- FIX: Gunakan JOIN untuk ambil semua data sekaligus (1 query)
SELECT 
    o.id AS order_id,
    o.total,
    o.created_at,
    u.nama AS nama_user,
    u.email
FROM orders o
JOIN users u ON o.user_id = u.id
ORDER BY o.created_at DESC;
-- Hanya 1 query!

-- FIX: Atau IN untuk batch load
SELECT * FROM users 
WHERE id IN (
    SELECT DISTINCT user_id FROM orders
);

-- FIX dengan aggregasi:
SELECT 
    u.nama,
    COUNT(o.id) AS jumlah_order,
    SUM(o.total) AS total_belanja
FROM users u
LEFT JOIN orders o ON u.id = o.user_id
GROUP BY u.id, u.nama;`,
        explanation: 'N+1 adalah masalah performa paling umum. Satu query untuk list, kemudian query lagi untuk setiap item. Solusi: JOIN atau batch loading.',
        tips: ['Gunakan JOIN untuk fetch related data sekaligus', 'Gunakan EXPLAIN ANALYZE untuk melihat execution plan', 'Index kolom yang sering dipakai di WHERE dan JOIN', 'ORM seperti Hibernate/Eloquent punya lazy vs eager loading'],
      },
    ],
  },

  // ─── GENERAL ────────────────────────────────────────────────
  {
    id: 'general-errors',
    lang: 'general',
    title: 'Debugging Methodology',
    icon: 'bug',
    color: '#8B5CF6',
    desc: 'Teknik debugging universal yang berlaku untuk semua bahasa pemrograman.',
    errors: [
      {
        id: 'gen-1',
        name: 'Cara Membaca Error Message',
        category: 'Technique',
        severity: 'info',
        buggyCode: `// Contoh error message JavaScript:
// TypeError: Cannot read properties of undefined (reading 'nama')
//     at getUserName (app.js:15:20)
//     at processRequest (app.js:8:5)
//     at main (app.js:3:1)

// Cara baca:
// 1. TypeError      → Jenis error
// 2. Cannot read... → Deskripsi masalah
// 3. app.js:15:20   → File, baris, kolom`,
        fixedCode: `// LANGKAH DEBUGGING SISTEMATIS:

// 1. BACA ERROR MESSAGE dengan teliti
//    - Jenis error (TypeError, ReferenceError, dll)
//    - Deskripsi masalah
//    - Stack trace: file + baris

// 2. REPRODUKSI error
//    - Buat test case minimal yang reproduce bug

// 3. ISOLASI masalah
console.log("checkpoint 1")  // Print sebelum bug
// ... kode yang diduga bermasalah ...
console.log("checkpoint 2")  // Print setelah bug

// 4. HIPOTESIS & TEST
// Buat dugaan, test, evaluasi, ulangi

// 5. GUNAKAN DEBUGGER
// Browser: F12 → Sources → Breakpoint
// VS Code: F5 → Debug mode
// Python: import pdb; pdb.set_trace()
// Java: jdb atau IDE debugger

// 6. RUBBER DUCK DEBUGGING
// Jelaskan kode kamu ke rubber duck (atau seseorang)
// Sering kali menjelaskan membuat kamu temukan bug sendiri!`,
        explanation: 'Debugging adalah skill yang bisa dipelajari. Pendekatan sistematis jauh lebih efektif daripada random trial-and-error.',
        tips: ['Baca error message sampai habis — semua info ada di sana', 'Stack trace menunjukkan urutan function call yang mengarah ke error', 'Buat reproduksi minimal — isolasi kode yang bermasalah', 'Rubber duck debugging: jelaskan kode ke siapapun/apapun'],
      },
      {
        id: 'gen-2',
        name: 'Git Bisect — Debug Regresi',
        category: 'Technique',
        severity: 'info',
        buggyCode: `# MASALAH: Bug muncul tapi tidak tahu commit mana yang menyebabkannya
# Misalnya: 500 commits lalu semuanya OK, sekarang ada bug

# Cara manual: cek satu per satu (500 commit = lama banget!)
git checkout abc123
# test...
git checkout def456
# test...
# ... ini tidak efisien`,
        fixedCode: `# FIX: Git Bisect - Binary Search untuk cari commit yang introduce bug

# 1. Mulai bisect
git bisect start

# 2. Tandai commit saat ini sebagai "bad" (ada bug)
git bisect bad

# 3. Tandai commit lama yang diketahui "good" (tidak ada bug)
git bisect good v1.0.0  # tag atau commit hash

# Git otomatis checkout ke commit tengah
# 4. Test apakah bug ada
# Jika bug ada:
git bisect bad
# Jika bug tidak ada:
git bisect good
# Ulangi sampai Git menemukan commit yang introduce bug

# Git akan tampilkan:
# "abc123 is the first bad commit"
# commit abc123
# Author: Budi <budi@email.com>
# feat: tambah validasi form

# 5. Selesai
git bisect reset  # Kembali ke HEAD normal

# Bonus: Otomatis dengan script
git bisect run npm test  # Git otomatis bisect pakai test`,
        explanation: 'Git bisect menggunakan binary search untuk menemukan commit yang menyebabkan bug. Dari 1000 commit, hanya butuh ~10 kali test!',
        tips: ['git bisect sangat berguna untuk regresi (bug yang tiba-tiba muncul)', 'Log(2, n) langkah — 1000 commit hanya perlu ~10 test', 'Bisa otomatis dengan script: git bisect run ./test.sh', 'Selalu commit dengan pesan yang jelas untuk memudahkan bisect'],
      },
    ],
  },
]

export function getDebuggingTopic(id) {
  return DEBUGGING_TOPICS.find(t => t.id === id)
}
