// ============================================================
// SECURITY CHALLENGES & LABS — CodeBook
// ============================================================

export const CHALLENGES = [
  {
    id: 'xss-basic',
    title: 'XSS Dasar: Alert Box Injection',
    category: 'xss',
    difficulty: 'Mudah',
    xp: 100,
    description: 'Temukan cara untuk menjalankan JavaScript alert() melalui input form.',
    objective: 'Masukkan payload XSS yang akan menampilkan alert("Hacked!")',
    hint: 'Coba gunakan tag <script> atau event handler seperti onerror',
    solution: '<img src=x onerror="alert(\'Hacked!\')">',
    explanation: `
## Apa itu XSS (Cross-Site Scripting)?

XSS adalah kerentanan keamanan yang memungkinkan attacker menjalankan JavaScript arbitrary di browser user. Ada 3 jenis:

1. **Stored XSS**: Payload disimpan di database dan dijalankan untuk semua user
2. **Reflected XSS**: Payload dikirim via URL dan dijalankan di browser user
3. **DOM-based XSS**: Manipulasi DOM client-side yang tidak aman

## Cara Mencegah XSS:

- **Input Validation**: Validasi semua input dari user
- **Output Encoding**: Encode output sebelum ditampilkan (HTML entities)
- **Content Security Policy (CSP)**: Set header CSP untuk restrict script execution
- **Use Framework Security**: React, Vue, Angular otomatis escape output
- **Sanitize HTML**: Gunakan library seperti DOMPurify

## Contoh Encoding:
\`\`\`javascript
// Tidak aman
document.innerHTML = userInput

// Aman - React otomatis escape
<div>{userInput}</div>

// Aman - Manual encoding
const encoded = userInput
  .replace(/&/g, '&amp;')
  .replace(/</g, '&lt;')
  .replace(/>/g, '&gt;')
  .replace(/"/g, '&quot;')
  .replace(/'/g, '&#x27;')
\`\`\`
    `,
    testCode: `
function testXSS(payload) {
  const div = document.createElement('div');
  div.innerHTML = payload;
  const scripts = div.querySelectorAll('script');
  const events = div.querySelectorAll('[onerror], [onload], [onclick]');
  return scripts.length > 0 || events.length > 0;
}
    `,
  },
  {
    id: 'xss-img-src',
    title: 'XSS via Image Tag',
    category: 'xss',
    difficulty: 'Mudah',
    xp: 100,
    description: 'Gunakan tag img dengan event handler untuk XSS.',
    objective: 'Buat payload XSS menggunakan tag <img>',
    hint: 'Tag img memiliki event onerror yang bisa dijalankan ketika gambar gagal load',
    solution: '<img src="invalid" onerror="alert(\'XSS via img\')">',
    explanation: `
## Event Handler XSS

Banyak HTML tag memiliki event handler yang bisa dimanfaatkan:

- **onerror**: Dijalankan ketika resource gagal load
- **onload**: Dijalankan ketika resource berhasil load
- **onclick**: Dijalankan ketika element diklik
- **onmouseover**: Dijalankan saat mouse hover
- **onfocus**: Dijalankan saat element fokus

## Contoh Payload:
\`\`\`html
<img src=x onerror="alert('XSS')">
<svg onload="alert('XSS')">
<body onload="alert('XSS')">
<input onfocus="alert('XSS')" autofocus>
<marquee onstart="alert('XSS')">
\`\`\`

## Pencegahan:
- Jangan gunakan innerHTML untuk user input
- Gunakan textContent atau innerText
- Sanitize semua HTML input
- Gunakan library seperti DOMPurify
    `,
    testCode: `
function testImgXSS(payload) {
  return payload.includes('<img') && payload.includes('onerror');
}
    `,
  },
  {
    id: 'xss-svg',
    title: 'XSS via SVG Tag',
    category: 'xss',
    difficulty: 'Sedang',
    xp: 150,
    description: 'Exploit SVG tag untuk menjalankan JavaScript.',
    objective: 'Buat payload XSS menggunakan SVG',
    hint: 'SVG adalah format vector yang bisa berisi JavaScript',
    solution: '<svg onload="alert(\'XSS via SVG\')"></svg>',
    explanation: `
## SVG XSS

SVG (Scalable Vector Graphics) adalah format XML yang bisa berisi JavaScript. Ini membuat SVG menjadi vektor serangan XSS yang powerful.

## Contoh Payload SVG:
\`\`\`html
<svg onload="alert('XSS')"></svg>
<svg><script>alert('XSS')</script></svg>
<svg><animate onbegin="alert('XSS')" attributeName="x" dur="1s" />
\`\`\`

## Mengapa SVG Berbahaya?

1. SVG adalah XML yang valid dan bisa berisi script
2. Browser mengeksekusi script di SVG seperti HTML biasa
3. SVG bisa di-embed dalam berbagai cara (img, object, embed, iframe)
4. Filter XSS sering lupa untuk SVG

## Pencegahan:
- Gunakan CSP untuk restrict inline scripts
- Sanitize SVG input dengan hati-hati
- Gunakan library khusus untuk sanitize SVG
- Pertimbangkan untuk disable SVG upload jika tidak perlu
    `,
    testCode: `
function testSVGXSS(payload) {
  return payload.includes('<svg') && payload.includes('onload');
}
    `,
  },
  {
    id: 'sql-injection',
    title: 'SQL Injection Dasar',
    category: 'sqli',
    difficulty: 'Sedang',
    xp: 150,
    description: 'Bypass login dengan SQL injection.',
    objective: 'Masukkan payload SQL yang bypass autentikasi',
    hint: 'Coba gunakan OR 1=1 untuk membuat query selalu true',
    solution: "admin' OR '1'='1",
    explanation: `
## SQL Injection

SQL Injection adalah kerentanan yang memungkinkan attacker memanipulasi SQL query.

## Contoh Query Rentan:
\`\`\`sql
SELECT * FROM users WHERE username = 'input' AND password = 'input'
\`\`\`

## Payload SQL Injection:
\`\`\`sql
admin' OR '1'='1
admin' --
admin' /*
\`\`\`

## Pencegahan:
- Gunakan Prepared Statements / Parameterized Queries
- Input Validation dan Whitelist
- Escape special characters
- Gunakan ORM (Mongoose, Sequelize)
- Principle of Least Privilege di database

## Contoh Aman:
\`\`\`javascript
// Tidak aman
db.query(\`SELECT * FROM users WHERE username = '\${username}'\`)

// Aman - Prepared Statement
db.query('SELECT * FROM users WHERE username = ?', [username])

// Aman - ORM
User.findOne({ username: username })
\`\`\`
    `,
    testCode: `
function testSQLi(payload) {
  return payload.includes("'") && (payload.includes('OR') || payload.includes('--'));
}
    `,
  },
  {
    id: 'nosql-injection',
    title: 'NoSQL Injection: MongoDB',
    category: 'nosql',
    difficulty: 'Sedang',
    xp: 150,
    description: 'Bypass MongoDB query dengan NoSQL injection.',
    objective: 'Buat payload NoSQL injection untuk MongoDB',
    hint: 'MongoDB queries bisa berisi object. Coba gunakan {$ne: null}',
    solution: '{"$ne": null}',
    explanation: `
## NoSQL Injection

NoSQL Injection adalah kerentanan di database NoSQL seperti MongoDB, yang memungkinkan attacker memanipulasi query.

## Contoh Query Rentan:
\`\`\`javascript
db.users.find({ username: req.body.username })
\`\`\`

Jika attacker mengirim:
\`\`\`json
{"username": {"$ne": null}}
\`\`\`

Query menjadi:
\`\`\`javascript
db.users.find({ username: {$ne: null} })
\`\`\`

Ini akan return semua user karena semua username tidak null!

## Pencegahan:
- Validasi input type (harus string, bukan object)
- Sanitize input dengan library seperti mongo-sanitize
- Gunakan schema validation (Mongoose)
- Whitelist operator yang diizinkan

## Contoh Aman:
\`\`\`javascript
// Tidak aman
db.users.find({ username: req.body.username })

// Aman - Validasi type
if (typeof req.body.username !== 'string') throw Error('Invalid')
db.users.find({ username: req.body.username })

// Aman - Sanitize
const sanitize = (obj) => JSON.parse(JSON.stringify(obj))
db.users.find(sanitize({ username: req.body.username }))
\`\`\`
    `,
    testCode: `
function testNoSQLi(payload) {
  try {
    const obj = JSON.parse(payload);
    return Object.keys(obj).some(k => k.startsWith('$'));
  } catch {
    return false;
  }
}
    `,
  },
  {
    id: 'csrf-token',
    title: 'CSRF: Token Bypass',
    category: 'csrf',
    difficulty: 'Sulit',
    xp: 200,
    description: 'Pahami dan bypass CSRF protection.',
    objective: 'Jelaskan bagaimana CSRF attack bekerja',
    hint: 'CSRF attack membutuhkan user untuk visit malicious site sambil logged in',
    solution: 'Attacker membuat form di situs lain yang auto-submit ke target site',
    explanation: `
## CSRF (Cross-Site Request Forgery)

CSRF adalah attack dimana attacker membuat user melakukan action tanpa consent mereka.

## Contoh Attack:
1. User login ke bank.com
2. User visit malicious.com (tanpa logout)
3. malicious.com memiliki hidden form yang transfer uang
4. Form auto-submit ke bank.com
5. Bank process request karena user sudah authenticated

## Pencegahan:
- **CSRF Token**: Generate unique token untuk setiap form
- **SameSite Cookie**: Set cookie flag SameSite=Strict
- **Double Submit Cookie**: Kirim token di cookie dan body
- **Referer Check**: Validasi Referer header
- **Origin Check**: Validasi Origin header

## Implementasi CSRF Token:
\`\`\`html
<form method="POST" action="/transfer">
  <input type="hidden" name="csrf_token" value="random_token_here">
  <input type="text" name="amount">
  <button type="submit">Transfer</button>
</form>
\`\`\`

\`\`\`javascript
// Server-side validation
if (req.body.csrf_token !== req.session.csrf_token) {
  return res.status(403).json({ error: 'CSRF token invalid' });
}
\`\`\`
    `,
    testCode: `
function testCSRF(answer) {
  return answer.toLowerCase().includes('form') && answer.toLowerCase().includes('auto');
}
    `,
  },
]

export const CHALLENGE_CATEGORIES = [
  { id: 'xss', label: 'XSS (Cross-Site Scripting)', icon: '🔴', color: 'from-red-500 to-pink-600' },
  { id: 'sqli', label: 'SQL Injection', icon: '🔵', color: 'from-blue-500 to-cyan-600' },
  { id: 'nosql', label: 'NoSQL Injection', icon: '🟢', color: 'from-emerald-500 to-teal-600' },
  { id: 'csrf', label: 'CSRF', icon: '🟡', color: 'from-yellow-500 to-orange-600' },
]
