export const MATERI_LIST = [
  // ==================== EXISTING ====================
  {
    slug: 'html-fundamentals',
    title: 'HTML Fundamentals',
    category: 'Programming',
    icon: '🏷️',
    color: 'from-orange-500 to-red-500',
    level: 'Beginner',
    duration: '3 jam',
    xp: 150,
    badgeId: 'complete_html',
    description: 'Pelajari dasar-dasar HTML untuk membangun struktur halaman web.',
    chapters: [
      {
        id: 'html-1',
        title: 'Pengenalan HTML',
        content: `# Pengenalan HTML

HTML (HyperText Markup Language) adalah bahasa markup standar untuk membuat halaman web.

## Struktur Dasar HTML

\`\`\`html
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Halaman Pertamaku</title>
</head>
<body>
  <h1>Hello, World!</h1>
  <p>Ini adalah paragraf pertamaku.</p>
</body>
</html>
\`\`\`

## Penjelasan Komponen

- **DOCTYPE** — Mendeklarasikan tipe dokumen HTML5
- **html** — Elemen root dari halaman
- **head** — Berisi meta informasi
- **body** — Konten yang ditampilkan di browser

## Tag HTML Dasar

| Tag | Fungsi |
|-----|--------|
| h1–h6 | Heading |
| p | Paragraf |
| a | Link |
| img | Gambar |
| div | Container block |
| span | Container inline |`,
      },
      {
        id: 'html-2',
        title: 'Form & Input',
        content: `# Form & Input HTML

Form adalah cara utama pengguna berinteraksi dengan website.

## Struktur Form

\`\`\`html
<form action="/submit" method="POST">
  <input type="text" name="nama" required>
  <input type="email" name="email" required>
  <input type="password" name="password">
  <button type="submit">Kirim</button>
</form>
\`\`\`

## Jenis Input

- **text** — Teks biasa
- **email** — Validasi format email
- **password** — Teks tersembunyi
- **number** — Angka saja
- **checkbox** — Pilihan ya/tidak
- **radio** — Pilih satu opsi
- **file** — Upload file`,
      },
    ],
  },
  {
    slug: 'css-mastery',
    title: 'CSS Mastery',
    category: 'Programming',
    icon: '🎨',
    color: 'from-blue-500 to-cyan-500',
    level: 'Beginner',
    duration: '4 jam',
    xp: 200,
    badgeId: 'complete_css',
    description: 'Kuasai CSS untuk styling website yang indah dan responsif.',
    chapters: [
      {
        id: 'css-1',
        title: 'CSS Fundamentals',
        content: `# CSS Fundamentals

CSS (Cascading Style Sheets) untuk mendeskripsikan tampilan dokumen HTML.

## Sintaks

\`\`\`css
body {
  font-family: 'Sora', sans-serif;
  background-color: #0a0b14;
  color: #e2e8f0;
}
\`\`\`

## Flexbox

\`\`\`css
.container {
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 1rem;
}
\`\`\`

## Grid

\`\`\`css
.grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 1.5rem;
}
\`\`\`

## Responsive Design

\`\`\`css
/* Mobile first */
.card { width: 100%; }

@media (min-width: 768px) {
  .card { width: 48%; }
}

@media (min-width: 1024px) {
  .card { width: 32%; }
}
\`\`\``,
      },
    ],
  },
  {
    slug: 'javascript-essentials',
    title: 'JavaScript Essentials',
    category: 'Programming',
    icon: '⚡',
    color: 'from-yellow-500 to-orange-500',
    level: 'Beginner',
    duration: '6 jam',
    xp: 300,
    badgeId: 'complete_js',
    description: 'Pelajari JavaScript dari dasar hingga konsep modern ES6+.',
    chapters: [
      {
        id: 'js-1',
        title: 'Variabel & Tipe Data',
        content: `# Variabel & Tipe Data

\`\`\`javascript
const nama = "CodeBook"   // immutable
let score = 0             // mutable

// Tipe data
const teks = "Hello"
const angka = 42
const bool = true
const arr = [1, 2, 3]
const obj = { nama: 'Budi', xp: 1500 }
\`\`\``,
      },
      {
        id: 'js-2',
        title: 'Fungsi & Arrow Function',
        content: `# Fungsi di JavaScript

\`\`\`javascript
// Arrow function
const sapa = (nama) => \`Halo, \${nama}!\`

// Higher-order functions
const angka = [1, 2, 3, 4, 5]
const kuadrat = angka.map(n => n * n)
const genap = angka.filter(n => n % 2 === 0)
const total = angka.reduce((acc, n) => acc + n, 0)
\`\`\`

## Async/Await

\`\`\`javascript
async function fetchData(url) {
  try {
    const res = await fetch(url)
    const data = await res.json()
    return data
  } catch (error) {
    console.error('Error:', error)
  }
}
\`\`\``,
      },
    ],
  },
  {
    slug: 'python-basics',
    title: 'Python Basics',
    category: 'Programming',
    icon: '🐍',
    color: 'from-green-500 to-teal-500',
    level: 'Beginner',
    duration: '5 jam',
    xp: 250,
    badgeId: null,
    description: 'Belajar Python dari nol — sintaks bersih, mudah dipahami.',
    chapters: [
      {
        id: 'py-1',
        title: 'Sintaks Python & Variabel',
        content: `# Python: Sintaks & Variabel

\`\`\`python
nama = "CodeBook"
tahun = 2024
print(f"Platform: {nama}, Tahun: {tahun}")

# List & Dict
bahasa = ['Python', 'JavaScript', 'Go']
user = { 'nama': 'Budi', 'xp': 1500 }

# Loop
for lang in bahasa:
    print(f"  - {lang}")
\`\`\`

## Fungsi Python

\`\`\`python
def hitung_level(xp):
    if xp < 500: return "Beginner"
    elif xp < 1500: return "Intermediate"
    elif xp < 3500: return "Pro"
    return "Master"

level = hitung_level(1500)
print(f"Level: {level}")
\`\`\``,
      },
    ],
  },
  {
    slug: 'backend-api',
    title: 'Backend & REST API',
    category: 'Web Development',
    icon: '⚙️',
    color: 'from-purple-500 to-indigo-500',
    level: 'Intermediate',
    duration: '8 jam',
    xp: 400,
    badgeId: null,
    description: 'Bangun REST API dengan Node.js, Express, dan MongoDB.',
    chapters: [
      {
        id: 'api-1',
        title: 'REST API Fundamentals',
        content: `# REST API Fundamentals

## HTTP Methods

| Method | Fungsi |
|--------|--------|
| GET | Ambil data |
| POST | Buat data |
| PUT | Update data |
| DELETE | Hapus data |

## Express.js

\`\`\`javascript
const express = require('express')
const app = express()
app.use(express.json())

app.get('/api/users', async (req, res) => {
  const users = await User.find().select('-password')
  res.json({ success: true, data: users })
})

app.post('/api/users', async (req, res) => {
  const { nama, email, password } = req.body
  const hashed = await bcrypt.hash(password, 12)
  const user = await User.create({ nama, email, password: hashed })
  res.status(201).json({ success: true, data: user })
})

app.listen(3000)
\`\`\``,
      },
    ],
  },
  {
    slug: 'cybersecurity-fundamentals',
    title: 'Cybersecurity Fundamentals',
    category: 'Cybersecurity',
    icon: '🛡️',
    color: 'from-red-500 to-pink-500',
    level: 'Intermediate',
    duration: '10 jam',
    xp: 500,
    badgeId: null,
    description: 'Pelajari keamanan web: OWASP Top 10, secure coding, dan best practices.',
    chapters: [
      {
        id: 'sec-1',
        title: 'Pengenalan Cybersecurity',
        content: `# Pengenalan Cybersecurity

## CIA Triad
- **Confidentiality** — Data hanya diakses pihak berwenang
- **Integrity** — Data tidak dimodifikasi secara tidak sah
- **Availability** — Sistem tersedia saat dibutuhkan

## Jenis Ancaman
- **Phishing** — Social engineering via email/link palsu
- **Malware** — Software berbahaya
- **Brute Force** — Menebak password sistematis
- **MitM** — Mencegat komunikasi`,
      },
      {
        id: 'sec-2',
        title: 'OWASP Top 10',
        content: `# OWASP Top 10

## SQL Injection

\`\`\`javascript
// BERBAHAYA
const q = "SELECT * FROM users WHERE email = '" + email + "'"

// AMAN - parameterized
const user = await User.findOne({ email: sanitizedEmail })
\`\`\`

## XSS

\`\`\`javascript
// BERBAHAYA
document.innerHTML = userInput

// AMAN
element.textContent = userInput
\`\`\`

## Secure Cookie

\`\`\`javascript
res.cookie('session', token, {
  httpOnly: true,
  secure: true,
  sameSite: 'strict'
})
\`\`\``,
      },
      {
        id: 'sec-3',
        title: 'Secure Coding',
        content: `# Secure Coding Practices

## Password Hashing

\`\`\`javascript
const hashed = await bcrypt.hash(password, 12)
const valid = await bcrypt.compare(input, hashed)
\`\`\`

## JWT Security

\`\`\`javascript
const token = jwt.sign(
  { userId: user._id },
  process.env.JWT_SECRET,
  { expiresIn: '7d' }
)
\`\`\`

## Input Validation

\`\`\`javascript
if (!email.includes('@')) throw new Error('Email invalid')
if (password.length < 8) throw new Error('Password terlalu pendek')
\`\`\``,
      },
    ],
  },

  // ==================== NEW MATERI ====================

  // 1. React.js
  {
    slug: 'react-fundamentals',
    title: 'React.js Fundamentals',
    category: 'Web Development',
    icon: '⚛️',
    color: 'from-cyan-400 to-blue-500',
    level: 'Intermediate',
    duration: '8 jam',
    xp: 400,
    badgeId: 'complete_react',
    description: 'Kuasai React.js — library UI paling populer di dunia.',
    chapters: [
      {
        id: 'react-1',
        title: 'Pengenalan React & JSX',
        content: `# Pengenalan React.js

React adalah library JavaScript untuk membangun UI yang dikembangkan oleh Meta. React menggunakan pendekatan **component-based** — UI dipecah jadi komponen-komponen kecil yang reusable.

## Mengapa React?

- **Component reusable** — tulis sekali, pakai berkali-kali
- **Virtual DOM** — update UI super cepat
- **Ekosistem besar** — ribuan library pendukung
- **Job market** — skill paling dicari developer

## JSX — JavaScript + HTML

JSX adalah sintaks extension yang memungkinkan kamu menulis HTML di dalam JavaScript.

\`\`\`jsx
// Komponen React paling sederhana
function Salam({ nama }) {
  return (
    <div className="card">
      <h1>Halo, {nama}!</h1>
      <p>Selamat datang di CodeBook.</p>
    </div>
  )
}

// Penggunaan
function App() {
  return <Salam nama="Budi" />
}
\`\`\`

## Rules JSX

\`\`\`jsx
// ✅ Harus ada satu root element
function Good() {
  return (
    <div>
      <h1>Judul</h1>
      <p>Paragraf</p>
    </div>
  )
}

// ✅ Atau pakai Fragment
function AlsoGood() {
  return (
    <>
      <h1>Judul</h1>
      <p>Paragraf</p>
    </>
  )
}

// ❌ Ini error — dua root element
function Bad() {
  return (
    <h1>Judul</h1>
    <p>Paragraf</p>
  )
}
\`\`\`

## Ekspresi di JSX

\`\`\`jsx
const nama = "CodeBook"
const xp = 1500
const isLogin = true

function Info() {
  return (
    <div>
      <h1>{nama}</h1>
      <p>XP: {xp * 2}</p>
      {isLogin && <span>✓ Login</span>}
      {isLogin ? <span>Online</span> : <span>Offline</span>}
    </div>
  )
}
\`\`\``,
      },
      {
        id: 'react-2',
        title: 'useState & useEffect',
        content: `# React Hooks: useState & useEffect

Hooks adalah fungsi spesial yang memungkinkan kamu menggunakan state dan fitur React lainnya di function component.

## useState — Menyimpan Data

\`\`\`jsx
import { useState } from 'react'

function Counter() {
  const [count, setCount] = useState(0)  // nilai awal = 0

  return (
    <div>
      <p>Count: {count}</p>
      <button onClick={() => setCount(count + 1)}>+</button>
      <button onClick={() => setCount(count - 1)}>-</button>
      <button onClick={() => setCount(0)}>Reset</button>
    </div>
  )
}
\`\`\`

## useState dengan Object

\`\`\`jsx
function Form() {
  const [form, setForm] = useState({
    nama: '',
    email: '',
  })

  const handleChange = (e) => {
    setForm(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }))
  }

  return (
    <form>
      <input name="nama" value={form.nama} onChange={handleChange} />
      <input name="email" value={form.email} onChange={handleChange} />
      <p>Halo, {form.nama}!</p>
    </form>
  )
}
\`\`\`

## useEffect — Side Effects

\`\`\`jsx
import { useState, useEffect } from 'react'

function UserProfile({ userId }) {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Dijalankan setelah component render
    fetch(\`/api/users/\${userId}\`)
      .then(r => r.json())
      .then(data => {
        setUser(data)
        setLoading(false)
      })
  }, [userId])  // dependency array — re-run kalau userId berubah

  if (loading) return <p>Loading...</p>
  return <h1>Halo, {user.nama}!</h1>
}
\`\`\`

## useEffect Cleanup

\`\`\`jsx
useEffect(() => {
  const timer = setInterval(() => {
    console.log('tick')
  }, 1000)

  // Cleanup — dijalankan saat component unmount
  return () => clearInterval(timer)
}, [])
\`\`\``,
      },
      {
        id: 'react-3',
        title: 'Props & Component Pattern',
        content: `# Props & Component Pattern

## Props — Data Antar Komponen

Props (properties) adalah cara mengirim data dari parent ke child component.

\`\`\`jsx
// Child component menerima props
function KartuMateri({ title, icon, xp, level, onClick }) {
  return (
    <div className="card" onClick={onClick}>
      <span>{icon}</span>
      <h3>{title}</h3>
      <p>Level: {level}</p>
      <span>+{xp} XP</span>
    </div>
  )
}

// Parent mengirim props
function DaftarMateri() {
  const materi = [
    { title: 'HTML', icon: '🏷️', xp: 150, level: 'Beginner' },
    { title: 'React', icon: '⚛️', xp: 400, level: 'Intermediate' },
  ]

  return (
    <div>
      {materi.map((m, i) => (
        <KartuMateri
          key={i}
          {...m}
          onClick={() => console.log('Dipilih:', m.title)}
        />
      ))}
    </div>
  )
}
\`\`\`

## Default Props

\`\`\`jsx
function Button({ label = 'Klik', color = 'blue', disabled = false }) {
  return (
    <button
      style={{ background: color }}
      disabled={disabled}
    >
      {label}
    </button>
  )
}
\`\`\`

## Children Props

\`\`\`jsx
function Card({ title, children }) {
  return (
    <div className="card">
      <h2>{title}</h2>
      <div>{children}</div>
    </div>
  )
}

// Penggunaan
function App() {
  return (
    <Card title="Info">
      <p>Ini adalah konten di dalam card.</p>
      <button>Klik</button>
    </Card>
  )
}
\`\`\``,
      },
    ],
  },

  // 2. Node.js & Express
  {
    slug: 'nodejs-express',
    title: 'Node.js & Express',
    category: 'Web Development',
    icon: '🟢',
    color: 'from-green-600 to-emerald-500',
    level: 'Intermediate',
    duration: '7 jam',
    xp: 380,
    badgeId: null,
    description: 'Bangun server-side application dengan Node.js dan Express dari nol.',
    chapters: [
      {
        id: 'node-1',
        title: 'Pengenalan Node.js',
        content: `# Pengenalan Node.js

Node.js adalah runtime JavaScript yang berjalan di server — bukan di browser. Dibuat tahun 2009 oleh Ryan Dahl, sekarang dipakai oleh Netflix, LinkedIn, Uber, dan lainnya.

## Kenapa Node.js?

- **JavaScript di server** — satu bahasa untuk frontend & backend
- **Non-blocking I/O** — handle ribuan request sekaligus
- **NPM** — 2 juta+ package tersedia
- **Fast** — dibangun di atas V8 engine Chrome

## Cara Kerja Node.js

\`\`\`
Browser Request
      ↓
   Node.js (Event Loop)
      ↓
   Proses request (non-blocking)
      ↓
   Response balik ke browser
\`\`\`

## Node.js Dasar

\`\`\`javascript
// hello.js
console.log("Hello dari Node.js!")

// Jalankan: node hello.js

// Baca file
const fs = require('fs')
fs.readFile('data.txt', 'utf8', (err, data) => {
  if (err) throw err
  console.log(data)
})

// Atau pakai async/await
const data = await fs.promises.readFile('data.txt', 'utf8')
console.log(data)
\`\`\`

## NPM — Node Package Manager

\`\`\`bash
# Init project baru
npm init -y

# Install package
npm install express mongoose bcryptjs

# Install dev dependency
npm install --save-dev nodemon

# Jalankan script
npm run dev
\`\`\`

## Module System

\`\`\`javascript
// CommonJS (lama)
const express = require('express')
module.exports = { namaFungsi }

// ES Modules (modern)
import express from 'express'
export { namaFungsi }
export default namaFungsi
\`\`\``,
      },
      {
        id: 'node-2',
        title: 'Express.js Server',
        content: `# Express.js Server

Express adalah framework minimalis untuk Node.js yang mempermudah pembuatan web server dan API.

## Setup Dasar

\`\`\`javascript
const express = require('express')
const app = express()

// Middleware untuk parse JSON
app.use(express.json())
// Middleware untuk parse URL-encoded
app.use(express.urlencoded({ extended: true }))

// Basic route
app.get('/', (req, res) => {
  res.json({ message: 'CodeBook API berjalan!' })
})

app.listen(3000, () => {
  console.log('Server di http://localhost:3000')
})
\`\`\`

## Routing

\`\`\`javascript
// GET — ambil semua user
app.get('/api/users', async (req, res) => {
  const users = await User.find()
  res.json(users)
})

// GET — ambil satu user by ID
app.get('/api/users/:id', async (req, res) => {
  const { id } = req.params
  const user = await User.findById(id)
  if (!user) return res.status(404).json({ error: 'Not found' })
  res.json(user)
})

// POST — buat user baru
app.post('/api/users', async (req, res) => {
  const { nama, email } = req.body
  const user = await User.create({ nama, email })
  res.status(201).json(user)
})

// PUT — update user
app.put('/api/users/:id', async (req, res) => {
  const user = await User.findByIdAndUpdate(
    req.params.id,
    req.body,
    { new: true }
  )
  res.json(user)
})

// DELETE — hapus user
app.delete('/api/users/:id', async (req, res) => {
  await User.findByIdAndDelete(req.params.id)
  res.json({ message: 'Berhasil dihapus' })
})
\`\`\`

## Middleware

\`\`\`javascript
// Middleware adalah fungsi yang dijalankan sebelum route handler

// Logger middleware
app.use((req, res, next) => {
  console.log(\`\${req.method} \${req.url} - \${new Date().toISOString()}\`)
  next() // lanjut ke middleware/route berikutnya
})

// Auth middleware
function isAuth(req, res, next) {
  const token = req.headers.authorization?.split(' ')[1]
  if (!token) return res.status(401).json({ error: 'Unauthorized' })
  
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET)
    req.user = decoded
    next()
  } catch {
    res.status(401).json({ error: 'Token tidak valid' })
  }
}

// Pakai middleware di route tertentu
app.get('/api/profile', isAuth, (req, res) => {
  res.json({ user: req.user })
})
\`\`\``,
      },
    ],
  },

  // 3. Git & Version Control
  {
    slug: 'git-version-control',
    title: 'Git & Version Control',
    category: 'Programming',
    icon: '🌿',
    color: 'from-orange-600 to-yellow-500',
    level: 'Beginner',
    duration: '4 jam',
    xp: 200,
    badgeId: 'complete_git',
    description: 'Wajib dikuasai semua developer — kelola kode dengan Git dan GitHub.',
    chapters: [
      {
        id: 'git-1',
        title: 'Git Dasar',
        content: `# Git & Version Control

Git adalah sistem version control terdistribusi yang melacak perubahan kode. Dibuat oleh Linus Torvalds (creator Linux) tahun 2005.

## Kenapa Git Penting?

- **Riwayat perubahan** — lihat siapa ubah apa dan kapan
- **Kolaborasi** — banyak developer kerja di proyek yang sama
- **Backup** — kode aman di cloud (GitHub, GitLab)
- **Rollback** — balik ke versi sebelumnya kapan saja

## Instalasi & Konfigurasi

\`\`\`bash
# Cek versi
git --version

# Konfigurasi identitas (wajib pertama kali)
git config --global user.name "Nama Kamu"
git config --global user.email "email@example.com"

# Lihat konfigurasi
git config --list
\`\`\`

## Workflow Dasar Git

\`\`\`bash
# 1. Init repository baru
git init

# 2. Cek status file
git status

# 3. Tambah file ke staging area
git add namafile.js        # file spesifik
git add .                  # semua file

# 4. Commit — simpan snapshot
git commit -m "feat: tambah halaman login"

# 5. Lihat riwayat commit
git log
git log --oneline          # format ringkas
\`\`\`

## Area di Git

\`\`\`
Working Directory → Staging Area → Repository
      (edit)           (git add)    (git commit)
\`\`\`

## .gitignore

\`\`\`bash
# File .gitignore — file yang tidak di-track Git

node_modules/
.env
.env.local
.next/
dist/
*.log
.DS_Store
\`\`\``,
      },
      {
        id: 'git-2',
        title: 'Branching & GitHub',
        content: `# Branching & GitHub

## Branching — Kerja Paralel

Branch memungkinkan kamu mengembangkan fitur tanpa mengganggu kode utama.

\`\`\`bash
# Lihat semua branch
git branch

# Buat branch baru
git branch fitur-login

# Pindah ke branch
git checkout fitur-login

# Buat & langsung pindah (shortcut)
git checkout -b fitur-register

# Merge branch ke main
git checkout main
git merge fitur-login

# Hapus branch setelah merge
git branch -d fitur-login
\`\`\`

## Strategy Branching

\`\`\`
main          ──●──────────────────●── (production)
                 \                /
feature/login    ●──●──●──●──●──●
\`\`\`

## GitHub — Remote Repository

\`\`\`bash
# Hubungkan ke GitHub
git remote add origin https://github.com/username/repo.git

# Push pertama kali
git push -u origin main

# Push selanjutnya
git push

# Pull perubahan dari remote
git pull

# Clone repo orang lain
git clone https://github.com/username/repo.git
\`\`\`

## Pesan Commit yang Baik

\`\`\`bash
# Format: type: deskripsi singkat

git commit -m "feat: tambah sistem login JWT"
git commit -m "fix: perbaiki bug token expired"
git commit -m "docs: update README cara deploy"
git commit -m "style: rapikan formatting kode"
git commit -m "refactor: pecah komponen NavBar"

# Types: feat, fix, docs, style, refactor, test, chore
\`\`\`

## Merge Conflict

\`\`\`bash
# Kalau ada conflict saat merge:
git merge fitur-baru
# Auto-merging file.js
# CONFLICT (content): Merge conflict in file.js

# Buka file, edit bagian conflict:
# <<<<<<< HEAD
# kode di main
# =======
# kode di branch baru
# >>>>>>> fitur-baru

# Setelah resolve:
git add file.js
git commit -m "fix: resolve merge conflict"
\`\`\``,
      },
    ],
  },

  // 4. Database SQL vs NoSQL
  {
    slug: 'database-fundamentals',
    title: 'Database Fundamentals',
    category: 'Web Development',
    icon: '🗄️',
    color: 'from-blue-600 to-violet-500',
    level: 'Intermediate',
    duration: '6 jam',
    xp: 320,
    badgeId: null,
    description: 'Pahami SQL vs NoSQL, desain database yang baik, dan query optimasi.',
    chapters: [
      {
        id: 'db-1',
        title: 'SQL vs NoSQL',
        content: `# SQL vs NoSQL

Dua paradigma besar dalam database — pilih yang tepat sesuai kebutuhan proyekmu.

## SQL (Relational Database)

Data disimpan dalam tabel dengan baris dan kolom. Hubungan antar tabel menggunakan JOIN.

**Contoh:** MySQL, PostgreSQL, SQLite, MariaDB

\`\`\`sql
-- Buat tabel
CREATE TABLE users (
  id INT PRIMARY KEY AUTO_INCREMENT,
  nama VARCHAR(100) NOT NULL,
  email VARCHAR(100) UNIQUE NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert data
INSERT INTO users (nama, email)
VALUES ('Budi', 'budi@example.com');

-- Select data
SELECT * FROM users WHERE email = 'budi@example.com';

-- Update
UPDATE users SET nama = 'Budi Santoso' WHERE id = 1;

-- Delete
DELETE FROM users WHERE id = 1;
\`\`\`

## NoSQL (Non-Relational Database)

Data disimpan dalam format fleksibel — dokumen JSON, key-value, graph, dll.

**Contoh:** MongoDB, Redis, Cassandra, Firebase

\`\`\`javascript
// MongoDB — dokumen JSON
{
  _id: ObjectId("..."),
  nama: "Budi",
  email: "budi@example.com",
  xp: 1500,
  badges: ["first_login", "complete_html"],
  createdAt: ISODate("2024-01-01")
}
\`\`\`

## Kapan Pakai SQL vs NoSQL?

| Kriteria | SQL | NoSQL |
|----------|-----|-------|
| Struktur data | Tetap/terstruktur | Fleksibel/berubah |
| Relasi kompleks | ✅ Lebih baik | ❌ Kurang ideal |
| Scale horizontal | ❌ Sulit | ✅ Mudah |
| Konsistensi | ✅ ACID | ❌ Eventual |
| Kecepatan dev | ❌ Lebih lambat | ✅ Lebih cepat |

**Pakai SQL:** aplikasi keuangan, e-commerce, data terstruktur
**Pakai NoSQL:** real-time app, content platform, data fleksibel`,
      },
      {
        id: 'db-2',
        title: 'MongoDB dengan Mongoose',
        content: `# MongoDB dengan Mongoose

Mongoose adalah ODM (Object Data Modeling) library untuk MongoDB di Node.js.

## Setup Koneksi

\`\`\`javascript
const mongoose = require('mongoose')

mongoose.connect(process.env.MONGODB_URI)
  .then(() => console.log('MongoDB terhubung!'))
  .catch(err => console.error('Error:', err))
\`\`\`

## Schema & Model

\`\`\`javascript
const userSchema = new mongoose.Schema({
  nama: {
    type: String,
    required: [true, 'Nama wajib diisi'],
    trim: true,
    minlength: 2
  },
  email: {
    type: String,
    required: true,
    unique: true,
    lowercase: true
  },
  password: { type: String, required: true },
  xp: { type: Number, default: 0 },
  badges: [{ type: String }],
  createdAt: { type: Date, default: Date.now }
})

const User = mongoose.model('User', userSchema)
module.exports = User
\`\`\`

## CRUD Operations

\`\`\`javascript
// CREATE
const user = await User.create({
  nama: 'Budi',
  email: 'budi@example.com',
  password: hashedPassword
})

// READ — semua
const users = await User.find()
const users = await User.find({ xp: { $gte: 500 } }) // filter
const users = await User.find().select('-password')    // exclude field

// READ — satu
const user = await User.findById(id)
const user = await User.findOne({ email: 'budi@example.com' })

// UPDATE
const updated = await User.findByIdAndUpdate(
  id,
  { $inc: { xp: 100 }, $push: { badges: 'new_badge' } },
  { new: true } // return dokumen baru
)

// DELETE
await User.findByIdAndDelete(id)
\`\`\`

## Query Operators

\`\`\`javascript
// Comparison
{ xp: { $gt: 500 } }    // greater than
{ xp: { $lt: 1500 } }   // less than
{ xp: { $gte: 500 } }   // greater than or equal
{ level: { $in: ['Pro', 'Master'] } }

// Logical
{ $and: [{ xp: { $gte: 500 } }, { xp: { $lt: 1500 } }] }
{ $or: [{ level: 'Pro' }, { level: 'Master' }] }

// Array
{ badges: { $exists: true, $ne: [] } }
{ badges: { $elemMatch: { $eq: 'first_login' } } }
\`\`\``,
      },
    ],
  },

  // 5. TypeScript Basics
  {
    slug: 'typescript-basics',
    title: 'TypeScript Basics',
    category: 'Programming',
    icon: '🔷',
    color: 'from-blue-500 to-blue-700',
    level: 'Intermediate',
    duration: '5 jam',
    xp: 300,
    badgeId: null,
    description: 'Tambahkan type safety ke JavaScript — TypeScript untuk developer modern.',
    chapters: [
      {
        id: 'ts-1',
        title: 'Pengenalan TypeScript',
        content: `# Pengenalan TypeScript

TypeScript adalah superset JavaScript yang menambahkan sistem tipe statis. Dibuat oleh Microsoft, sekarang dipakai oleh hampir semua perusahaan besar.

## Kenapa TypeScript?

- **Deteksi error lebih awal** — sebelum runtime
- **Autocomplete lebih baik** — IDE tahu tipe data
- **Kode lebih mudah dibaca** — tipe sebagai dokumentasi
- **Refactoring lebih aman** — IDE bantu ubah kode

## Tipe Data Dasar

\`\`\`typescript
// Primitive types
let nama: string = "CodeBook"
let umur: number = 5
let aktif: boolean = true
let apapun: any = "bisa apa saja"  // hindari any!

// Array
let angka: number[] = [1, 2, 3]
let kata: Array<string> = ["a", "b", "c"]

// Tuple
let pasangan: [string, number] = ["nama", 42]

// Union type — bisa salah satu
let id: string | number = "abc123"
id = 456  // juga valid

// Literal type
let arah: "kiri" | "kanan" | "lurus" = "kiri"
\`\`\`

## Interface & Type

\`\`\`typescript
// Interface — mendefinisikan bentuk object
interface User {
  id: string
  nama: string
  email: string
  xp?: number          // optional dengan ?
  readonly createdAt: Date  // tidak bisa diubah
}

// Type alias
type Level = "Beginner" | "Intermediate" | "Pro" | "Master"

type UserWithLevel = User & {
  level: Level
}

// Penggunaan
const user: User = {
  id: "123",
  nama: "Budi",
  email: "budi@example.com",
  xp: 1500,
  createdAt: new Date()
}
\`\`\`

## Fungsi dengan TypeScript

\`\`\`typescript
// Parameter dan return type
function tambah(a: number, b: number): number {
  return a + b
}

// Arrow function
const kali = (a: number, b: number): number => a * b

// Optional & default parameter
function sapa(nama: string, salam: string = "Halo"): string {
  return \`\${salam}, \${nama}!\`
}

// Generic function
function identitas<T>(nilai: T): T {
  return nilai
}

const angka = identitas<number>(42)
const teks = identitas<string>("hello")
\`\`\``,
      },
    ],
  },

  // 6. Docker
  {
    slug: 'docker-deployment',
    title: 'Docker & Deployment',
    category: 'Web Development',
    icon: '🐳',
    color: 'from-blue-400 to-cyan-600',
    level: 'Advanced',
    duration: '6 jam',
    xp: 450,
    badgeId: null,
    description: 'Containerize aplikasi dengan Docker dan deploy ke VPS.',
    chapters: [
      {
        id: 'docker-1',
        title: 'Pengenalan Docker',
        content: `# Pengenalan Docker

Docker adalah platform untuk mengemas, mendistribusikan, dan menjalankan aplikasi dalam container.

## Apa itu Container?

Container adalah unit standar software yang mengemas kode dan semua dependensinya, sehingga aplikasi berjalan konsisten di environment manapun.

\`\`\`
┌─────────────────────────────────────┐
│           Host OS (Linux)            │
├──────────────┬──────────────────────┤
│  Container A │    Container B       │
│  Node.js App │    Python App        │
│  + deps      │    + deps            │
└──────────────┴──────────────────────┘
\`\`\`

## Docker vs VM

| | Docker | Virtual Machine |
|--|--------|-----------------|
| Boot time | Detik | Menit |
| Size | MB | GB |
| Performance | Native | Overhead |
| Isolation | Process | Full OS |

## Perintah Docker Dasar

\`\`\`bash
# Pull image dari Docker Hub
docker pull node:18-alpine

# Lihat image yang ada
docker images

# Jalankan container
docker run -p 3000:3000 nama-image

# Lihat container yang berjalan
docker ps

# Stop container
docker stop container-id

# Remove container
docker rm container-id

# Lihat logs
docker logs container-id
\`\`\`

## Dockerfile

\`\`\`dockerfile
# Base image
FROM node:18-alpine

# Working directory
WORKDIR /app

# Copy package files
COPY package*.json ./

# Install dependencies
RUN npm install --production

# Copy source code
COPY . .

# Build (untuk Next.js)
RUN npm run build

# Expose port
EXPOSE 3000

# Jalankan aplikasi
CMD ["npm", "start"]
\`\`\`

## Build & Run

\`\`\`bash
# Build image
docker build -t codebook-app .

# Jalankan dengan environment variables
docker run -p 3000:3000 \\
  -e MONGODB_URI=... \\
  -e JWT_SECRET=... \\
  codebook-app
\`\`\``,
      },
      {
        id: 'docker-2',
        title: 'Docker Compose & Deploy VPS',
        content: `# Docker Compose & Deploy ke VPS

## Docker Compose

Docker Compose memungkinkan kamu menjalankan multi-container app dengan satu perintah.

\`\`\`yaml
# docker-compose.yml
version: '3.8'

services:
  app:
    build: .
    ports:
      - "3000:3000"
    environment:
      - MONGODB_URI=mongodb://mongo:27017/codebook
      - JWT_SECRET=supersecret
    depends_on:
      - mongo
    restart: unless-stopped

  mongo:
    image: mongo:6
    volumes:
      - mongo_data:/data/db
    restart: unless-stopped

volumes:
  mongo_data:
\`\`\`

\`\`\`bash
# Jalankan semua services
docker-compose up -d

# Stop semua
docker-compose down

# Lihat logs
docker-compose logs -f app
\`\`\`

## Deploy ke VPS (Ubuntu)

\`\`\`bash
# 1. Install Docker di VPS
curl -fsSL https://get.docker.com | sh

# 2. Install Docker Compose
sudo apt install docker-compose -y

# 3. Clone repo kamu
git clone https://github.com/username/codebook.git
cd codebook

# 4. Buat .env file
nano .env

# 5. Jalankan
docker-compose up -d

# 6. Setup Nginx sebagai reverse proxy
sudo apt install nginx -y

# /etc/nginx/sites-available/codebook
server {
    listen 80;
    server_name domain.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}

# 7. SSL dengan Certbot
sudo apt install certbot python3-certbot-nginx -y
sudo certbot --nginx -d domain.com
\`\`\``,
      },
    ],
  },

  // 7. Linux & Terminal
  {
    slug: 'linux-terminal',
    title: 'Linux & Terminal',
    category: 'Programming',
    icon: '🖥️',
    color: 'from-gray-600 to-gray-800',
    level: 'Beginner',
    duration: '4 jam',
    xp: 220,
    badgeId: null,
    description: 'Kuasai Linux dan terminal — skill wajib setiap developer.',
    chapters: [
      {
        id: 'linux-1',
        title: 'Command Dasar Linux',
        content: `# Linux & Terminal

Terminal adalah antarmuka teks untuk berinteraksi dengan sistem operasi. Setiap developer wajib bisa menggunakannya.

## Navigasi File System

\`\`\`bash
# Lihat direktori sekarang
pwd

# List isi direktori
ls
ls -la        # termasuk hidden file + detail
ls -lh        # ukuran human-readable

# Pindah direktori
cd /home/user
cd ..         # naik satu level
cd ~          # ke home directory
cd -          # kembali ke direktori sebelumnya

# Buat direktori
mkdir nama-folder
mkdir -p parent/child/grandchild  # buat nested

# Hapus
rm file.txt
rm -rf folder/    # hapus folder + isinya (hati-hati!)

# Copy & Move
cp file.txt /tujuan/
cp -r folder/ /tujuan/
mv file.txt /tujuan/           # move
mv lama.txt baru.txt           # rename
\`\`\`

## Baca & Edit File

\`\`\`bash
# Tampilkan isi file
cat file.txt
less file.txt    # bisa scroll
head -n 20 file.txt  # 20 baris pertama
tail -n 20 file.txt  # 20 baris terakhir
tail -f log.txt      # live update (monitor log)

# Edit file
nano file.txt    # editor simple
vim file.txt     # editor advanced

# Cari teks dalam file
grep "kata" file.txt
grep -r "kata" ./folder/   # recursive
grep -i "kata" file.txt    # case-insensitive
\`\`\`

## Process Management

\`\`\`bash
# Lihat proses yang berjalan
ps aux
top          # real-time
htop         # lebih bagus (install dulu)

# Kill proses
kill 1234         # by PID
kill -9 1234      # force kill
pkill nama-proses

# Background job
node server.js &    # jalankan di background
nohup node server.js &  # tetap jalan setelah logout

# PM2 untuk production
npm install -g pm2
pm2 start server.js --name "app"
pm2 list
pm2 logs app
pm2 restart app
pm2 stop app
\`\`\``,
      },
      {
        id: 'linux-2',
        title: 'SSH, Permission & Cron',
        content: `# SSH, Permission & Cron Job

## SSH — Remote Access

\`\`\`bash
# Connect ke server
ssh user@ip-server
ssh user@ip-server -p 2222  # port custom

# Generate SSH key
ssh-keygen -t rsa -b 4096 -C "email@example.com"

# Copy public key ke server
ssh-copy-id user@ip-server

# SSH config (biar praktis)
# ~/.ssh/config
Host myserver
  HostName 192.168.1.100
  User ubuntu
  IdentityFile ~/.ssh/id_rsa

# Sekarang tinggal: ssh myserver
\`\`\`

## File Permission

\`\`\`bash
# Format: rwxrwxrwx (owner/group/others)
ls -la
# -rw-r--r-- 1 user group 1234 Jan 1 file.txt

# chmod — ubah permission
chmod 755 file.sh     # rwxr-xr-x
chmod 644 file.txt    # rw-r--r--
chmod +x script.sh    # tambah execute

# Tabel permission
# 4 = read (r)
# 2 = write (w)
# 1 = execute (x)
# 7 = rwx, 6 = rw-, 5 = r-x, 4 = r--

# chown — ubah owner
chown user:group file.txt
chown -R user:group folder/
\`\`\`

## Cron Job — Scheduled Task

\`\`\`bash
# Edit cron jobs
crontab -e

# Format: menit jam hari bulan hari-minggu perintah
# * = semua nilai

# Contoh cron jobs:
# Setiap menit
* * * * * /path/to/script.sh

# Setiap jam pada menit 0
0 * * * * /path/to/script.sh

# Setiap hari jam 2 pagi
0 2 * * * /path/to/backup.sh

# Setiap Senin jam 9 pagi
0 9 * * 1 /path/to/report.sh

# Setiap 5 menit
*/5 * * * * /path/to/cek.sh

# Lihat cron jobs
crontab -l
\`\`\``,
      },
    ],
  },

  // 8. System Design
  {
    slug: 'system-design',
    title: 'System Design',
    category: 'Web Development',
    icon: '🏗️',
    color: 'from-violet-500 to-purple-700',
    level: 'Advanced',
    duration: '8 jam',
    xp: 500,
    badgeId: null,
    description: 'Desain sistem yang scalable — load balancing, caching, microservices.',
    chapters: [
      {
        id: 'sys-1',
        title: 'Scalability & Architecture',
        content: `# System Design Fundamentals

System design adalah proses mendefinisikan arsitektur, komponen, dan interface sistem untuk memenuhi requirement tertentu.

## Monolith vs Microservices

### Monolith
Semua fitur dalam satu aplikasi.

\`\`\`
┌─────────────────────────────┐
│        Monolith App         │
│  ┌──────┐ ┌──────┐ ┌─────┐ │
│  │ Auth │ │Posts │ │Chat │ │
│  └──────┘ └──────┘ └─────┘ │
│         One Database        │
└─────────────────────────────┘
\`\`\`

✅ Mudah develop & deploy awal
✅ Tidak ada network latency antar service
❌ Sulit scale bagian tertentu
❌ Satu error bisa crash semua

### Microservices
Setiap fitur jadi service terpisah.

\`\`\`
Client
  ↓
API Gateway
  ├── Auth Service    → Auth DB
  ├── Post Service    → Post DB
  └── Chat Service    → Chat DB
\`\`\`

✅ Scale per service
✅ Deploy independen
❌ Kompleks — network calls, distributed tracing
❌ Tidak cocok untuk tim kecil

## Load Balancing

Mendistribusikan traffic ke beberapa server.

\`\`\`
                   ┌─── Server 1
Client → Load     ├─── Server 2
         Balancer └─── Server 3

Algoritma:
- Round Robin — bergantian urut
- Least Connections — ke server paling sedikit koneksi
- IP Hash — client yang sama selalu ke server yang sama
\`\`\`

## Horizontal vs Vertical Scaling

\`\`\`
Vertical (Scale Up):        Horizontal (Scale Out):
Server kecil → besar        Tambah server baru

     ▲                       □ □ □
     █  →  ████              → tambah □ □
     ▼
Mahal, ada batas            Murah, bisa terus tambah
\`\`\``,
      },
      {
        id: 'sys-2',
        title: 'Caching & Database Optimization',
        content: `# Caching & Database Optimization

## Caching dengan Redis

Cache menyimpan data yang sering diakses di memori (RAM), jauh lebih cepat dari database.

\`\`\`javascript
const redis = require('redis')
const client = redis.createClient()

// Middleware caching
async function cacheMiddleware(req, res, next) {
  const key = \`cache:\${req.url}\`
  
  // Cek cache dulu
  const cached = await client.get(key)
  if (cached) {
    return res.json(JSON.parse(cached))
  }
  
  // Override res.json untuk simpan ke cache
  const originalJson = res.json.bind(res)
  res.json = async (data) => {
    await client.setEx(key, 3600, JSON.stringify(data)) // TTL 1 jam
    return originalJson(data)
  }
  
  next()
}

// Penggunaan
app.get('/api/materi', cacheMiddleware, getMaterHandler)
\`\`\`

## Database Indexing

Index membuat query lebih cepat dengan membuat "daftar isi" di database.

\`\`\`javascript
// MongoDB — buat index
userSchema.index({ email: 1 })           // single field
userSchema.index({ email: 1, nama: 1 })  // compound
userSchema.index({ xp: -1 })             // descending

// Tanpa index: scan semua dokumen O(n)
// Dengan index: langsung ke dokumen O(log n)
\`\`\`

## CDN — Content Delivery Network

\`\`\`
Tanpa CDN:
User (Indonesia) → Server (US) → 300ms latency

Dengan CDN:
User (Indonesia) → CDN Node (Singapore) → 20ms latency

CDN populer: Cloudflare, AWS CloudFront, Vercel Edge Network
\`\`\`

## Rate Limiting

\`\`\`javascript
const rateLimit = require('express-rate-limit')

// Batasi 100 request per 15 menit per IP
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100,
  message: { error: 'Terlalu banyak request, coba lagi nanti' },
  standardHeaders: true,
})

// Lebih ketat untuk login
const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 5,
  message: { error: 'Terlalu banyak percobaan login' },
})

app.use('/api/', limiter)
app.use('/api/auth/login', loginLimiter)
\`\`\``,
      },
    ],
  },

  // 9. Clean Code
  {
    slug: 'clean-code',
    title: 'Clean Code & Best Practices',
    category: 'Programming',
    icon: '✨',
    color: 'from-emerald-400 to-green-600',
    level: 'Intermediate',
    duration: '5 jam',
    xp: 280,
    badgeId: null,
    description: 'Tulis kode yang bersih, mudah dibaca, dan mudah di-maintain.',
    chapters: [
      {
        id: 'clean-1',
        title: 'Prinsip Clean Code',
        content: `# Clean Code & Best Practices

Clean Code adalah kode yang mudah dibaca, dipahami, dan dimodifikasi oleh developer lain (termasuk kamu sendiri 6 bulan ke depan).

## Penamaan yang Bermakna

\`\`\`javascript
// ❌ Tidak jelas
const d = new Date()
const arr = users.filter(u => u.a > 18)
function calc(x, y) { return x * y * 0.1 }

// ✅ Jelas dan deskriptif
const currentDate = new Date()
const adultUsers = users.filter(user => user.age > 18)
function calculateTax(price, quantity) { return price * quantity * 0.1 }
\`\`\`

## Fungsi Kecil & Satu Tujuan

\`\`\`javascript
// ❌ Fungsi terlalu besar, banyak tujuan
async function handleUser(req, res) {
  const { email, password, nama } = req.body
  if (!email || !password || !nama) return res.status(400).json({ error: '...' })
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  if (!emailRegex.test(email)) return res.status(400).json({ error: '...' })
  const existing = await User.findOne({ email })
  if (existing) return res.status(409).json({ error: '...' })
  const hashed = await bcrypt.hash(password, 12)
  const user = await User.create({ nama, email, password: hashed })
  const token = jwt.sign({ userId: user._id }, process.env.JWT_SECRET)
  res.json({ user, token })
}

// ✅ Dipecah jadi fungsi kecil
function validateRegisterInput(data) {
  const { email, password, nama } = data
  if (!email || !password || !nama) throw new Error('Semua field wajib diisi')
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new Error('Email tidak valid')
  if (password.length < 6) throw new Error('Password minimal 6 karakter')
}

async function checkEmailUnique(email) {
  const existing = await User.findOne({ email })
  if (existing) throw new Error('Email sudah terdaftar')
}

async function createUserWithToken(userData) {
  const hashed = await bcrypt.hash(userData.password, 12)
  const user = await User.create({ ...userData, password: hashed })
  const token = jwt.sign({ userId: user._id }, process.env.JWT_SECRET)
  return { user, token }
}

async function handleRegister(req, res) {
  try {
    validateRegisterInput(req.body)
    await checkEmailUnique(req.body.email)
    const result = await createUserWithToken(req.body)
    res.status(201).json(result)
  } catch (error) {
    res.status(400).json({ error: error.message })
  }
}
\`\`\`

## SOLID Principles

**S — Single Responsibility**
Satu class/fungsi, satu tanggung jawab.

**O — Open/Closed**
Terbuka untuk extension, tertutup untuk modifikasi.

**D — Don't Repeat Yourself (DRY)**

\`\`\`javascript
// ❌ Duplikasi kode
function validateEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)
}
// ... di tempat lain
if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(userEmail)) { ... }

// ✅ Tulis sekali, pakai berulang
const isValidEmail = (email) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)
\`\`\``,
      },
    ],
  },

  // 10. Penetration Testing (edukatif)
  {
    slug: 'pentest-basics',
    title: 'Penetration Testing Basics',
    category: 'Cybersecurity',
    icon: '🔓',
    color: 'from-red-600 to-orange-600',
    level: 'Advanced',
    duration: '10 jam',
    xp: 600,
    badgeId: null,
    description: 'Ethical hacking & bug bounty — pelajari cara berpikir seperti hacker untuk defend sistem. (LEGAL & EDUKATIF)',
    chapters: [
      {
        id: 'pt-1',
        title: 'Ethical Hacking & Reconnaissance',
        content: `# Penetration Testing Basics

⚠️ **DISCLAIMER:** Materi ini sepenuhnya untuk tujuan edukasi dan defensive security. Penggunaan teknik ini tanpa izin tertulis adalah ILEGAL. Selalu dapatkan izin sebelum melakukan testing.

## Apa itu Penetration Testing?

Penetration testing (pentest) adalah proses mensimulasikan serangan siber terhadap sistem dengan izin pemiliknya, untuk menemukan kerentanan sebelum hacker jahat menemukannya.

## Tahapan Pentest (PTES)

\`\`\`
1. Reconnaissance (pengumpulan informasi)
2. Scanning & Enumeration
3. Exploitation
4. Post-Exploitation
5. Reporting
\`\`\`

## Reconnaissance — Passive

Mengumpulkan informasi tanpa berinteraksi langsung dengan target.

\`\`\`bash
# WHOIS — informasi domain
whois example.com

# DNS lookup
nslookup example.com
dig example.com ANY

# Subdomain enumeration (passive)
# Tools: Shodan, Censys, DNSdumpster

# Google Dorking — cari informasi via Google
site:example.com                    # semua halaman domain
site:example.com filetype:pdf       # cari PDF
inurl:admin site:example.com        # cari halaman admin
intitle:"index of" site:example.com # cari directory listing
\`\`\`

## Reconnaissance — Active

Berinteraksi langsung dengan target (hanya dengan izin!).

\`\`\`bash
# Port scanning dengan nmap
nmap -sV 192.168.1.1          # scan service version
nmap -p 1-1000 192.168.1.1   # scan port 1-1000
nmap -sC 192.168.1.1          # default scripts

# Output nmap
# PORT     STATE SERVICE  VERSION
# 22/tcp   open  ssh      OpenSSH 8.9
# 80/tcp   open  http     nginx 1.18
# 3306/tcp open  mysql    MySQL 8.0
\`\`\`

## Bug Bounty Mindset

\`\`\`
Target → Recon → Vulnerability → PoC → Report → Reward

Platform Bug Bounty:
- HackerOne
- Bugcrowd  
- Intigriti
- Open Bug Bounty

Scope yang biasa dicari:
- XSS (Cross-Site Scripting)
- IDOR (Insecure Direct Object Reference)
- SQL Injection
- Authentication bypass
- Information disclosure
\`\`\``,
      },
      {
        id: 'pt-2',
        title: 'Web App Vulnerabilities',
        content: `# Web Application Vulnerabilities

## IDOR — Insecure Direct Object Reference

Salah satu bug paling sering ditemukan di bug bounty.

\`\`\`
// Contoh IDOR:
GET /api/user/profile/123    ← user kamu
GET /api/user/profile/124    ← bisa akses data user lain!

// Pencegahan:
// Selalu cek authorization, bukan hanya authentication
app.get('/api/user/profile/:id', isAuth, async (req, res) => {
  const user = await User.findById(req.params.id)
  
  // ❌ Tidak ada pengecekan
  res.json(user)
  
  // ✅ Cek apakah user boleh akses data ini
  if (req.user.id !== req.params.id) {
    return res.status(403).json({ error: 'Forbidden' })
  }
  res.json(user)
})
\`\`\`

## JWT Attack

\`\`\`javascript
// ❌ Algoritma 'none' — JWT tanpa signature
// Header: { "alg": "none", "typ": "JWT" }
// Attacker bisa forge token!

// Pencegahan:
const decoded = jwt.verify(token, secret, {
  algorithms: ['HS256']  // whitelist algoritma yang diizinkan
})

// ❌ JWT secret lemah
const secret = "secret"    // mudah di-brute force

// ✅ Secret kuat
const secret = require('crypto').randomBytes(64).toString('hex')
\`\`\`

## Broken Access Control

\`\`\`javascript
// ❌ Endpoint admin tanpa pengecekan role
app.delete('/api/admin/user/:id', isAuth, deleteUser)

// ✅ Cek role juga
function isAdmin(req, res, next) {
  if (req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Akses ditolak' })
  }
  next()
}

app.delete('/api/admin/user/:id', isAuth, isAdmin, deleteUser)
\`\`\`

## Security Headers Lengkap

\`\`\`javascript
// Gunakan Helmet.js di Express
const helmet = require('helmet')

app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      imgSrc: ["'self'", "data:", "https:"],
    },
  },
  hsts: {
    maxAge: 31536000,
    includeSubDomains: true,
    preload: true
  },
}))
\`\`\``,
      },
    ],
  },

  // 11. Kriptografi
  {
    slug: 'kriptografi',
    title: 'Kriptografi & Enkripsi',
    category: 'Cybersecurity',
    icon: '🔐',
    color: 'from-purple-600 to-pink-600',
    level: 'Intermediate',
    duration: '6 jam',
    xp: 400,
    badgeId: null,
    description: 'Pahami kriptografi modern — enkripsi, hashing, TLS/SSL, dan implementasinya.',
    chapters: [
      {
        id: 'crypto-1',
        title: 'Konsep Kriptografi',
        content: `# Kriptografi & Enkripsi

Kriptografi adalah ilmu mengamankan komunikasi dengan mengubah data menjadi format yang tidak bisa dibaca tanpa kunci rahasia.

## Hashing vs Enkripsi

| | Hashing | Enkripsi |
|--|---------|----------|
| Reversible | ❌ Tidak | ✅ Ya (dengan kunci) |
| Tujuan | Verifikasi integritas | Kerahasiaan data |
| Output | Fixed length | Variabel |
| Contoh | bcrypt, SHA-256 | AES, RSA |

## Hashing

\`\`\`javascript
const crypto = require('crypto')

// SHA-256 (jangan untuk password!)
const hash = crypto
  .createHash('sha256')
  .update('data saya')
  .digest('hex')

console.log(hash)
// 3b9c9f3d... (64 karakter hex, selalu sama untuk input yang sama)

// Gunakan untuk: checksum file, token, tanda tangan data
// JANGAN gunakan untuk: password!
\`\`\`

## Password Hashing dengan bcrypt

\`\`\`javascript
const bcrypt = require('bcryptjs')

// Hash password
async function hashPassword(password) {
  const salt = await bcrypt.genSalt(12)  // cost factor
  return bcrypt.hash(password, salt)
}

// Verifikasi
async function checkPassword(input, hash) {
  return bcrypt.compare(input, hash)
}

// Kenapa bcrypt, bukan SHA-256?
// - bcrypt by design lambat (melawan brute force)
// - Setiap hash punya salt unik (melawan rainbow table)
// - Cost factor bisa dinaikkan seiring waktu
\`\`\`

## Symmetric vs Asymmetric Encryption

### Symmetric (AES)
Satu kunci untuk enkripsi dan dekripsi.

\`\`\`javascript
const crypto = require('crypto')

const KEY = crypto.randomBytes(32)  // 256-bit key
const IV = crypto.randomBytes(16)   // initialization vector

// Enkripsi
function encrypt(text) {
  const cipher = crypto.createCipheriv('aes-256-cbc', KEY, IV)
  let encrypted = cipher.update(text, 'utf8', 'hex')
  encrypted += cipher.final('hex')
  return encrypted
}

// Dekripsi
function decrypt(encrypted) {
  const decipher = crypto.createDecipheriv('aes-256-cbc', KEY, IV)
  let decrypted = decipher.update(encrypted, 'hex', 'utf8')
  decrypted += decipher.final('utf8')
  return decrypted
}

const terenkripsi = encrypt("Data rahasia")
const asli = decrypt(terenkripsi)
\`\`\`

### Asymmetric (RSA)
Dua kunci berbeda — public key untuk enkripsi, private key untuk dekripsi.

\`\`\`
Public Key  → siapapun bisa punya → untuk ENKRIPSI
Private Key → rahasia, hanya pemilik → untuk DEKRIPSI

Analogi:
Public key = gembok terbuka yang kamu bagikan ke semua orang
Private key = kunci gembok yang kamu simpan sendiri

Dipakai di: HTTPS, SSH, JWT (RS256), SSL Certificate
\`\`\``,
      },
      {
        id: 'crypto-2',
        title: 'TLS/SSL & HTTPS',
        content: `# TLS/SSL & HTTPS

## Apa itu TLS/SSL?

TLS (Transport Layer Security) adalah protokol kriptografi yang mengamankan komunikasi di internet. HTTPS = HTTP + TLS.

## Cara Kerja TLS Handshake

\`\`\`
Client                          Server
  |                               |
  |── ClientHello ──────────────→ |  (versi TLS, cipher suites)
  |← ServerHello ─────────────── |  (pilih cipher, kirim sertifikat)
  |← Certificate ─────────────── |  (public key server)
  |                               |
  | [Client verifikasi sertifikat] |
  |                               |
  |── PreMasterSecret (encrypted) → |  (enkripsi dengan public key server)
  |                               |
  | [Kedua sisi generate session key dari PreMasterSecret]
  |                               |
  |── Finished ─────────────────→ |
  |← Finished ─────────────────── |
  |                               |
  |═══════ Encrypted Data ════════|  (pakai symmetric session key)
\`\`\`

## SSL Certificate

\`\`\`bash
# Cek sertifikat SSL sebuah website
openssl s_client -connect example.com:443 -showcerts

# Generate self-signed cert (untuk development)
openssl req -x509 -newkey rsa:4096 \\
  -keyout key.pem -out cert.pem \\
  -days 365 -nodes

# Free SSL dengan Let's Encrypt (production)
sudo certbot --nginx -d domain.com
\`\`\`

## HTTPS di Node.js

\`\`\`javascript
const https = require('https')
const fs = require('fs')
const express = require('express')

const app = express()

const options = {
  key: fs.readFileSync('key.pem'),
  cert: fs.readFileSync('cert.pem')
}

https.createServer(options, app).listen(443, () => {
  console.log('HTTPS Server berjalan di port 443')
})

// Redirect HTTP ke HTTPS
const http = require('http')
http.createServer((req, res) => {
  res.writeHead(301, { Location: 'https://' + req.headers.host + req.url })
  res.end()
}).listen(80)
\`\`\``,
      },
    ],
  },
]

