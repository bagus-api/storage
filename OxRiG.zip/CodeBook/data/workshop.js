// ============================================================
// WORKSHOP DATA — Step-by-step interactive coding exercises
// Like freeCodeCamp, tapi Bahasa Indonesia
// ============================================================

export const WORKSHOPS = [
  // ================================================================
  // 1. PYTHON FUNDAMENTAL
  // ================================================================
  {
    id: 'python-dasar',
    title: 'Python Dasar: Variabel & Tipe Data',
    category: 'Programming',
    slug: 'python-dasar',
    icon: '🐍',
    lang: 'python',
    color: 'from-green-500 to-teal-500',
    level: 'Beginner',
    xp: 200,
    desc: 'Belajar Python dari nol — variabel, tipe data, input/output, dan kondisi.',
    steps: [
      {
        id: 1,
        title: 'Membuat Variabel String',
        instruction: `## Langkah 1: Variabel String

Dalam Python, **variabel** adalah tempat menyimpan data. Cara membuat variabel sangat sederhana:

\`\`\`python
bahasa = 'Python'
\`\`\`

Di contoh atas, variabel \`bahasa\` menyimpan nilai string \`'Python'\`. String adalah teks yang diapit tanda kutip satu \`' '\` atau dua \`" "\`.

**Tugasmu:** Buat variabel bernama \`nama\` dan isi dengan namamu (pakai tanda kutip).`,
        starterCode: `# Buat variabel nama di sini
`,
        check: {
          type: 'contains',
          patterns: ["nama =", "nama="],
          mustContainString: true,
          errorMsg: 'Pastikan kamu membuat variabel bernama \`nama\` dan mengisinya dengan string (teks dengan tanda kutip).',
        },
        hint: 'Contoh: nama = \'Budi\' atau nama = "Siti"',
        successMsg: 'Bagus! Kamu berhasil membuat variabel string pertamamu! 🎉',
      },
      {
        id: 2,
        title: 'Menampilkan Output dengan print()',
        instruction: `## Langkah 2: Fungsi print()

Untuk menampilkan nilai variabel ke layar, gunakan fungsi \`print()\`:

\`\`\`python
nama = 'Budi'
print(nama)  # Output: Budi
\`\`\`

\`print()\` adalah fungsi bawaan Python yang menampilkan teks ke terminal.

**Tugasmu:** Tampilkan variabel \`nama\` menggunakan \`print()\`.`,
        starterCode: `nama = 'Alice'
# Tampilkan variabel nama di sini
`,
        check: {
          type: 'contains',
          patterns: ['print(nama)'],
          errorMsg: 'Gunakan print(nama) untuk menampilkan variabel nama.',
        },
        hint: 'Tulis print(nama) di baris berikutnya',
        successMsg: 'Mantap! print() adalah fungsi yang akan sering kamu pakai! ✅',
      },
      {
        id: 3,
        title: 'Variabel Integer (Angka Bulat)',
        instruction: `## Langkah 3: Tipe Data Integer

Integer adalah bilangan bulat tanpa tanda kutip:

\`\`\`python
umur = 17
nilai = 100
\`\`\`

Berbeda dari string, integer **tidak** diapit tanda kutip.

**Tugasmu:** Buat dua variabel:
- \`umur\` dengan nilai angka usiamu
- \`nilai\` dengan nilai angka berapa saja`,
        starterCode: `nama = 'Alice'
# Buat variabel umur dan nilai di sini
`,
        check: {
          type: 'contains',
          patterns: ['umur =', 'nilai ='],
          errorMsg: 'Buat variabel \`umur\` dan \`nilai\` dengan nilai angka (tanpa tanda kutip).',
        },
        hint: 'Contoh: umur = 17 dan nilai = 95',
        successMsg: 'Hebat! Integer tidak butuh tanda kutip karena bukan teks. 🔢',
      },
      {
        id: 4,
        title: 'Tipe Data Float (Desimal)',
        instruction: `## Langkah 4: Float — Angka Desimal

Float adalah angka dengan koma/desimal:

\`\`\`python
tinggi = 165.5
berat = 60.8
rata_rata = 87.5
\`\`\`

Python menggunakan titik \`.\` bukan koma untuk desimal.

**Tugasmu:** Buat variabel \`rata_rata\` dengan nilai desimal (misalnya nilai rata-ratamu).`,
        starterCode: `nama = 'Alice'
umur = 17
# Buat variabel rata_rata bertipe float
`,
        check: {
          type: 'contains',
          patterns: ['rata_rata =', 'rata_rata='],
          mustHaveDot: true,
          errorMsg: 'Buat variabel \`rata_rata\` dengan nilai desimal menggunakan titik, contoh: 87.5',
        },
        hint: 'Contoh: rata_rata = 87.5',
        successMsg: 'Float dipakai untuk angka dengan desimal. Ingat, pakai titik bukan koma! 🎯',
      },
      {
        id: 5,
        title: 'Tipe Data Boolean',
        instruction: `## Langkah 5: Boolean — True atau False

Boolean hanya punya dua nilai: \`True\` atau \`False\` (huruf kapital!):

\`\`\`python
lulus = True
absen = False
aktif = True
\`\`\`

Boolean sering dipakai untuk kondisi — ya/tidak, benar/salah.

**Tugasmu:** Buat variabel \`lulus\` dengan nilai \`True\`.`,
        starterCode: `nama = 'Alice'
umur = 17
rata_rata = 87.5
# Buat variabel lulus bertipe boolean
`,
        check: {
          type: 'contains',
          patterns: ['lulus = True', 'lulus=True'],
          errorMsg: 'Buat variabel \`lulus\` dengan nilai True (huruf T kapital, tanpa tanda kutip).',
        },
        hint: 'Tulis: lulus = True (perhatikan huruf kapital T)',
        successMsg: 'Boolean hanya True atau False — perhatikan huruf kapital! ✅',
      },
      {
        id: 6,
        title: 'Fungsi type() — Cek Tipe Data',
        instruction: `## Langkah 6: Mengecek Tipe Data

Gunakan \`type()\` untuk melihat tipe data sebuah variabel:

\`\`\`python
nama = 'Budi'
print(type(nama))   # <class 'str'>
print(type(17))     # <class 'int'>
print(type(87.5))   # <class 'float'>
print(type(True))   # <class 'bool'>
\`\`\`

**Tugasmu:** Tampilkan tipe data dari variabel \`nama\`, \`umur\`, \`rata_rata\`, dan \`lulus\` menggunakan \`type()\`.`,
        starterCode: `nama = 'Alice'
umur = 17
rata_rata = 87.5
lulus = True
# Tampilkan type() untuk setiap variabel
`,
        check: {
          type: 'contains',
          patterns: ['type(nama)', 'type(umur)', 'type(rata_rata)', 'type(lulus)'],
          errorMsg: 'Tampilkan type() untuk semua variabel: nama, umur, rata_rata, dan lulus.',
        },
        hint: 'Contoh: print(type(nama)) untuk setiap variabel',
        successMsg: 'type() sangat berguna untuk debug saat kamu tidak yakin tipe datanya! 🔍',
      },
      {
        id: 7,
        title: 'F-String — Format Teks Modern',
        instruction: `## Langkah 7: F-String

F-String adalah cara modern Python untuk menggabungkan variabel ke dalam string:

\`\`\`python
nama = 'Budi'
umur = 17
print(f'Nama saya {nama}, umur {umur} tahun')
# Output: Nama saya Budi, umur 17 tahun
\`\`\`

Perhatikan huruf \`f\` sebelum tanda kutip dan variabel di dalam \`{}\`.

**Tugasmu:** Buat f-string yang menampilkan: "Halo, nama saya [nama] dan saya berumur [umur] tahun."`,
        starterCode: `nama = 'Alice'
umur = 17
# Buat f-string yang menampilkan nama dan umur
`,
        check: {
          type: 'contains',
          patterns: ["f'", 'f"'],
          mustContain: ['{nama}', '{umur}'],
          errorMsg: 'Gunakan f-string dengan format: print(f\'...{nama}...{umur}...\')',
        },
        hint: 'Contoh: print(f\'Halo, nama saya {nama} dan saya berumur {umur} tahun.\')',
        successMsg: 'F-string adalah cara paling modern dan rapi untuk format teks di Python! 🚀',
      },
      {
        id: 8,
        title: 'Operasi Aritmatika',
        instruction: `## Langkah 8: Operasi Matematika

Python bisa dipakai sebagai kalkulator:

| Operator | Fungsi | Contoh |
|----------|--------|--------|
| \`+\` | Penjumlahan | 5 + 3 = 8 |
| \`-\` | Pengurangan | 10 - 4 = 6 |
| \`*\` | Perkalian | 3 * 4 = 12 |
| \`/\` | Pembagian | 10 / 2 = 5.0 |
| \`//\` | Pembagian bulat | 10 // 3 = 3 |
| \`%\` | Sisa bagi | 10 % 3 = 1 |
| \`**\` | Pangkat | 2 ** 3 = 8 |

**Tugasmu:** Buat variabel \`total\` yang merupakan hasil dari \`nilai_1 + nilai_2\`, lalu tampilkan hasilnya.`,
        starterCode: `nilai_1 = 80
nilai_2 = 90
# Buat variabel total = nilai_1 + nilai_2
# Tampilkan total
`,
        check: {
          type: 'contains',
          patterns: ['total =', 'total='],
          mustContain: ['nilai_1 + nilai_2', 'nilai_1+nilai_2'],
          errorMsg: 'Buat variabel \`total\` yang menghitung nilai_1 + nilai_2, lalu print(total).',
        },
        hint: 'total = nilai_1 + nilai_2 kemudian print(total)',
        successMsg: 'Python bisa melakukan semua operasi matematika. Sangat berguna! ➕',
      },
      {
        id: 9,
        title: 'Input dari Pengguna',
        instruction: `## Langkah 9: Fungsi input()

Gunakan \`input()\` untuk meminta data dari pengguna:

\`\`\`python
nama = input('Masukkan namamu: ')
print(f'Halo, {nama}!')
\`\`\`

Perhatian: \`input()\` **selalu mengembalikan string**, meskipun pengguna mengetik angka.

\`\`\`python
angka = input('Masukkan angka: ')
print(type(angka))  # <class 'str'>, bukan int!
\`\`\`

**Tugasmu:** Buat program yang meminta input nama pengguna dan menyapanya.`,
        starterCode: `# Minta input nama dari pengguna
# Tampilkan sapaan menggunakan f-string
`,
        check: {
          type: 'contains',
          patterns: ['input('],
          mustContain: ['print('],
          errorMsg: 'Gunakan input() untuk meminta nama, lalu print() untuk menyapa.',
        },
        hint: 'nama = input("Masukkan namamu: ") lalu print(f"Halo, {nama}!")',
        successMsg: 'input() membuat program interaktif! Ingat hasilnya selalu string. 🙋',
      },
      {
        id: 10,
        title: 'Konversi Tipe Data',
        instruction: `## Langkah 10: Konversi Tipe Data

Karena \`input()\` selalu string, kita perlu konversi jika ingin operasi matematika:

\`\`\`python
# str → int
umur = int(input('Umurmu: '))

# str → float  
tinggi = float(input('Tinggimu: '))

# int → str
angka = 42
teks = str(angka)  # '42'
\`\`\`

**Tugasmu:** Buat program yang:
1. Minta input dua angka dari pengguna (konversi ke int)
2. Tampilkan hasil penjumlahannya`,
        starterCode: `# Minta dua angka dari pengguna, konversi ke int
# Hitung dan tampilkan jumlahnya
`,
        check: {
          type: 'contains',
          patterns: ['int(input('],
          errorMsg: 'Gunakan int(input(...)) untuk mengkonversi input string ke integer.',
        },
        hint: 'a = int(input("Angka 1: ")) lalu b = int(input("Angka 2: ")) lalu print(a + b)',
        successMsg: 'Konversi tipe data sangat penting! int(), float(), str() adalah yang paling sering dipakai. 🔄',
      },
      {
        id: 11,
        title: 'Kondisi if-elif-else',
        instruction: `## Langkah 11: Percabangan if-elif-else

Kondisi membuat program bisa mengambil keputusan:

\`\`\`python
nilai = 85

if nilai >= 90:
    print('A - Sangat Baik')
elif nilai >= 75:
    print('B - Baik')
elif nilai >= 60:
    print('C - Cukup')
else:
    print('D - Perlu Belajar Lagi')
\`\`\`

Perhatikan: Python menggunakan **indentasi** (spasi 4) untuk blok kode!

**Tugasmu:** Buat program yang menentukan kategori BMI:
- BMI < 18.5 → "Kurus"
- BMI 18.5–24.9 → "Normal"
- BMI >= 25 → "Gemuk"`,
        starterCode: `bmi = 22.5  # Coba ubah nilainya
# Buat kondisi if-elif-else untuk kategori BMI
`,
        check: {
          type: 'contains',
          patterns: ['if ', 'elif ', 'else:'],
          errorMsg: 'Buat struktur if-elif-else untuk mengecek nilai BMI.',
        },
        hint: 'if bmi < 18.5: lalu elif bmi <= 24.9: lalu else:',
        successMsg: 'if-elif-else adalah pondasi logika program! Sekarang program bisa berpikir. 🧠',
      },
      {
        id: 12,
        title: 'Perulangan for',
        instruction: `## Langkah 12: Perulangan for

Loop \`for\` digunakan untuk mengulang sesuatu beberapa kali:

\`\`\`python
# Loop range
for i in range(5):
    print(i)  # 0, 1, 2, 3, 4

# Loop list
buah = ['apel', 'mangga', 'jeruk']
for b in buah:
    print(b)
\`\`\`

\`range(5)\` menghasilkan angka 0 sampai 4.

**Tugasmu:** Buat loop yang mencetak tabel perkalian 3 (dari 1 sampai 10).`,
        starterCode: `# Buat tabel perkalian 3 menggunakan for loop
# Output: 3 x 1 = 3, 3 x 2 = 6, dst sampai 3 x 10 = 30
`,
        check: {
          type: 'contains',
          patterns: ['for ', 'range('],
          mustContain: ['print('],
          errorMsg: 'Gunakan for loop dengan range() untuk membuat tabel perkalian.',
        },
        hint: 'for i in range(1, 11): lalu print(f"3 x {i} = {3*i}")',
        successMsg: 'For loop menghemat penulisan kode yang berulang! Sangat powerful. 🔁',
      },
      {
        id: 13,
        title: 'List — Kumpulan Data',
        instruction: `## Langkah 13: List

List adalah kumpulan data dalam satu variabel:

\`\`\`python
nilai = [85, 90, 78, 92, 88]

# Akses elemen (index mulai dari 0)
print(nilai[0])   # 85 (pertama)
print(nilai[-1])  # 88 (terakhir)

# Tambah elemen
nilai.append(95)

# Panjang list
print(len(nilai))  # 6
\`\`\`

**Tugasmu:** Buat list \`mata_pelajaran\` berisi 5 mata pelajaran, lalu tampilkan panjangnya dan elemen pertama dan terakhirnya.`,
        starterCode: `# Buat list mata_pelajaran dengan 5 mata pelajaran
# Tampilkan: panjang list, elemen pertama, elemen terakhir
`,
        check: {
          type: 'contains',
          patterns: ['mata_pelajaran =', 'mata_pelajaran='],
          mustContain: ['len(', 'print('],
          errorMsg: 'Buat list \`mata_pelajaran\` dengan 5 elemen, lalu gunakan len() dan print untuk menampilkannya.',
        },
        hint: 'mata_pelajaran = ["Matematika", "Fisika", ...] lalu print(len(mata_pelajaran))',
        successMsg: 'List sangat berguna untuk menyimpan banyak data sekaligus! 📝',
      },
      {
        id: 14,
        title: 'Fungsi def',
        instruction: `## Langkah 14: Membuat Fungsi

Fungsi adalah blok kode yang bisa dipakai berkali-kali:

\`\`\`python
def sapa(nama):
    print(f'Halo, {nama}! Selamat datang di Python.')

# Memanggil fungsi
sapa('Budi')   # Halo, Budi! Selamat datang di Python.
sapa('Siti')   # Halo, Siti! Selamat datang di Python.
\`\`\`

**Tugasmu:** Buat fungsi \`hitung_rata_rata\` yang menerima parameter \`list_nilai\` dan mengembalikan rata-ratanya menggunakan \`sum()\` dan \`len()\`.`,
        starterCode: `# Buat fungsi hitung_rata_rata(list_nilai)
# yang mengembalikan rata-rata dari list

# Test fungsi:
nilai = [80, 85, 90, 78, 92]
# Panggil fungsi dan tampilkan hasilnya
`,
        check: {
          type: 'contains',
          patterns: ['def hitung_rata_rata('],
          mustContain: ['return ', 'sum(', 'len('],
          errorMsg: 'Buat fungsi \`def hitung_rata_rata(list_nilai):\` yang menggunakan sum() dan len() lalu return hasilnya.',
        },
        hint: 'def hitung_rata_rata(list_nilai): lalu return sum(list_nilai) / len(list_nilai)',
        successMsg: 'Luar biasa! Fungsi membuat kode reusable dan terorganisir. Ini inti dari programming! 🏆',
      },
      {
        id: 15,
        title: 'Raport Nilai Final',
        instruction: `## Langkah 15: Program Raport Lengkap 🎓

Sekarang gabungkan semua yang sudah kamu pelajari! Buat program raport yang:

1. Menyimpan nama siswa dan daftar nilai dalam variabel
2. Menghitung rata-rata nilai
3. Menentukan grade: A (≥90), B (≥75), C (≥60), D (<60)
4. Menampilkan raport lengkap menggunakan f-string

Contoh output:
\`\`\`
=== RAPORT NILAI ===
Nama  : Alice
Nilai : [85, 90, 78, 92, 88]
Rata2 : 86.6
Grade : B - Baik
===================
\`\`\`

**Tugasmu:** Buat program raport lengkap!`,
        starterCode: `# Program Raport Lengkap
# Gunakan semua konsep: variabel, list, fungsi, kondisi, f-string

nama = 'Alice'
nilai = [85, 90, 78, 92, 88]

# Hitung rata-rata

# Tentukan grade

# Tampilkan raport
`,
        check: {
          type: 'contains',
          patterns: ['nama', 'nilai'],
          mustContain: ['print(', 'if ', 'sum('],
          errorMsg: 'Program harus menggunakan variabel nama & nilai, menghitung rata-rata, menentukan grade dengan if, dan menampilkan raport.',
        },
        hint: 'Gabungkan: sum(nilai)/len(nilai) untuk rata-rata, if/elif untuk grade, f-string untuk tampilan',
        successMsg: '🎉🎉🎉 SELAMAT! Kamu telah menyelesaikan Workshop Python Dasar! Kamu sudah belajar variabel, tipe data, input/output, kondisi, loop, list, dan fungsi!',
        isFinal: true,
      },
    ],
  },

  // ================================================================
  // 2. JAVASCRIPT FUNDAMENTAL
  // ================================================================
  {
    id: 'javascript-dasar',
    title: 'JavaScript Dasar: Dari Nol ke ES6',
    category: 'Programming',
    slug: 'javascript-dasar',
    icon: '⚡',
    lang: 'javascript',
    color: 'from-yellow-500 to-orange-500',
    level: 'Beginner',
    xp: 200,
    desc: 'Kuasai JavaScript modern dari variabel, fungsi, array, hingga ES6 async/await.',
    steps: [
      {
        id: 1,
        title: 'Deklarasi Variabel dengan const',
        instruction: `## Langkah 1: const — Variabel Tetap

Di JavaScript modern, gunakan \`const\` untuk variabel yang nilainya tidak berubah:

\`\`\`javascript
const nama = 'CodeBook'
const tahun = 2024
\`\`\`

\`const\` = **const**ant, nilainya tidak bisa diubah setelah deklarasi.

**Tugasmu:** Buat variabel \`nama\` menggunakan \`const\` dan isi dengan namamu.`,
        starterCode: `// Buat variabel nama menggunakan const
`,
        check: {
          type: 'contains',
          patterns: ['const nama'],
          errorMsg: 'Gunakan \`const nama = "..."\` untuk membuat variabel nama.',
        },
        hint: 'const nama = "NamaKamu"',
        successMsg: 'const adalah pilihan default di JavaScript modern. Gunakan const kecuali perlu diubah! ✅',
      },
      {
        id: 2,
        title: 'Deklarasi Variabel dengan let',
        instruction: `## Langkah 2: let — Variabel yang Bisa Berubah

Gunakan \`let\` ketika nilai variabel perlu diubah:

\`\`\`javascript
let skor = 0
skor = 100  // Bisa diubah!
skor += 50  // Sekarang 150
\`\`\`

Hindari \`var\` — sudah ketinggalan zaman dan punya bug tersembunyi.

**Tugasmu:** Buat variabel \`skor\` dengan \`let\` bernilai 0, lalu ubah nilainya menjadi 100.`,
        starterCode: `const nama = 'Alice'
// Buat variabel skor dengan let, nilai 0
// Lalu ubah nilainya menjadi 100
`,
        check: {
          type: 'contains',
          patterns: ['let skor'],
          mustContain: ['skor = 100', 'skor=100'],
          errorMsg: 'Gunakan \`let skor = 0\` lalu ubah dengan \`skor = 100\`.',
        },
        hint: 'let skor = 0 lalu skor = 100 di baris berikutnya',
        successMsg: 'let untuk yang bisa berubah, const untuk yang tetap. Mudah kan? 🔄',
      },
      {
        id: 3,
        title: 'Template Literal',
        instruction: `## Langkah 3: Template Literal

Template literal menggunakan backtick \` \` untuk format string dengan variabel:

\`\`\`javascript
const nama = 'Budi'
const umur = 17
console.log(\`Halo, saya \${nama} berumur \${umur} tahun\`)
// Output: Halo, saya Budi berumur 17 tahun
\`\`\`

Variabel disisipkan menggunakan \`\${...}\`.

**Tugasmu:** Buat template literal yang menampilkan "Selamat datang, [nama]! Skormu adalah [skor] poin."`,
        starterCode: `const nama = 'Alice'
let skor = 100
// Buat template literal dan tampilkan dengan console.log
`,
        check: {
          type: 'contains',
          patterns: ['`'],
          mustContain: ['${nama}', '${skor}', 'console.log'],
          errorMsg: 'Gunakan backtick dan ${nama} ${skor} dalam template literal.',
        },
        hint: 'console.log(\`Selamat datang, ${nama}! Skormu ${skor} poin.\`)',
        successMsg: 'Template literal jauh lebih rapi dari penggabungan string dengan +! 🚀',
      },
      {
        id: 4,
        title: 'Arrow Function',
        instruction: `## Langkah 4: Arrow Function

Arrow function adalah cara modern menulis fungsi di JavaScript:

\`\`\`javascript
// Cara lama
function tambah(a, b) {
  return a + b
}

// Arrow function (modern & ringkas)
const tambah = (a, b) => a + b

// Dengan body block
const sapa = (nama) => {
  const pesan = \`Halo, \${nama}!\`
  return pesan
}
\`\`\`

**Tugasmu:** Buat arrow function \`kali\` yang menerima dua parameter dan mengembalikan hasil perkaliannya.`,
        starterCode: `// Buat arrow function bernama 'kali'
// yang menerima parameter a dan b
// dan mengembalikan a * b

// Test:
console.log(kali(3, 4))  // Harus output: 12
console.log(kali(5, 7))  // Harus output: 35
`,
        check: {
          type: 'contains',
          patterns: ['const kali =', 'const kali='],
          mustContain: ['=>'],
          errorMsg: 'Buat \`const kali = (a, b) => ...\` sebagai arrow function.',
        },
        hint: 'const kali = (a, b) => a * b',
        successMsg: 'Arrow function lebih ringkas dan ini standar di kode JavaScript modern! ⚡',
      },
      {
        id: 5,
        title: 'Array & Method Dasar',
        instruction: `## Langkah 5: Array

Array menyimpan banyak data dalam satu variabel:

\`\`\`javascript
const bahasa = ['JavaScript', 'Python', 'Go']

console.log(bahasa[0])        // JavaScript
console.log(bahasa.length)    // 3
bahasa.push('Rust')           // Tambah di akhir
console.log(bahasa.includes('Python'))  // true
\`\`\`

**Tugasmu:** Buat array \`nilai\` berisi 5 angka, lalu:
- Tampilkan elemen pertama
- Tampilkan panjang array
- Tambahkan angka baru dengan push()`,
        starterCode: `// Buat array nilai dengan 5 angka
// Tampilkan elemen pertama, panjang array
// Tambahkan satu angka dengan push()
`,
        check: {
          type: 'contains',
          patterns: ['const nilai', 'let nilai'],
          mustContain: ['push(', 'console.log'],
          errorMsg: 'Buat array \`nilai\`, tampilkan elemen pertama & length, lalu gunakan push().',
        },
        hint: 'const nilai = [80, 85, 90, 78, 92] lalu console.log(nilai[0]) dan nilai.push(95)',
        successMsg: 'Array adalah struktur data paling sering dipakai di JavaScript! 📦',
      },
      {
        id: 6,
        title: 'Array.map() — Transformasi Data',
        instruction: `## Langkah 6: Array.map()

\`map()\` membuat array baru dengan mentransformasi setiap elemen:

\`\`\`javascript
const angka = [1, 2, 3, 4, 5]

// Kuadratkan setiap angka
const kuadrat = angka.map(n => n * n)
console.log(kuadrat)  // [1, 4, 9, 16, 25]

// Konversi ke string
const teks = angka.map(n => \`Angka \${n}\`)
\`\`\`

**Tugasmu:** Gunakan \`map()\` pada array \`nilai\` untuk menambahkan 5 poin ke setiap nilai (bonus nilai).`,
        starterCode: `const nilai = [80, 85, 90, 78, 92]
// Buat array nilaiBonus menggunakan map()
// setiap nilai ditambah 5

console.log(nilaiBonus)  // [85, 90, 95, 83, 97]
`,
        check: {
          type: 'contains',
          patterns: ['map('],
          mustContain: ['+ 5', '+5'],
          errorMsg: 'Gunakan nilai.map(n => n + 5) untuk menambah 5 ke setiap nilai.',
        },
        hint: 'const nilaiBonus = nilai.map(n => n + 5)',
        successMsg: 'map() tidak mengubah array asli, ia membuat array baru. Ini penting! 🗺️',
      },
      {
        id: 7,
        title: 'Array.filter() — Menyaring Data',
        instruction: `## Langkah 7: Array.filter()

\`filter()\` menyaring elemen array berdasarkan kondisi:

\`\`\`javascript
const angka = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

// Saring hanya angka genap
const genap = angka.filter(n => n % 2 === 0)
console.log(genap)  // [2, 4, 6, 8, 10]

// Saring nilai >= 75
const lulus = [65, 75, 80, 55, 90].filter(n => n >= 75)
console.log(lulus)  // [75, 80, 90]
\`\`\`

**Tugasmu:** Filter array \`nilai\` untuk mendapatkan hanya nilai yang >= 85.`,
        starterCode: `const nilai = [80, 85, 90, 78, 92, 70, 88]
// Buat array nilaiTinggi menggunakan filter()
// hanya nilai >= 85

console.log(nilaiTinggi)  // [85, 90, 92, 88]
`,
        check: {
          type: 'contains',
          patterns: ['filter('],
          mustContain: ['>= 85', '>=85'],
          errorMsg: 'Gunakan nilai.filter(n => n >= 85) untuk menyaring nilai tinggi.',
        },
        hint: 'const nilaiTinggi = nilai.filter(n => n >= 85)',
        successMsg: 'filter() sangat powerful untuk menyaring data! Kombinasikan dengan map() untuk hasil terbaik. 🔍',
      },
      {
        id: 8,
        title: 'Array.reduce() — Akumulasi',
        instruction: `## Langkah 8: Array.reduce()

\`reduce()\` mengakumulasi array menjadi satu nilai:

\`\`\`javascript
const angka = [1, 2, 3, 4, 5]

// Jumlahkan semua
const total = angka.reduce((akumulasi, n) => akumulasi + n, 0)
console.log(total)  // 15

// Cari nilai maksimum
const maks = angka.reduce((max, n) => n > max ? n : max, 0)
\`\`\`

**Tugasmu:** Gunakan \`reduce()\` untuk menghitung total semua nilai dalam array, lalu hitung rata-ratanya.`,
        starterCode: `const nilai = [80, 85, 90, 78, 92]
// Hitung total menggunakan reduce()
// Hitung rata-rata = total / nilai.length

console.log('Total:', total)
console.log('Rata-rata:', rataRata)
`,
        check: {
          type: 'contains',
          patterns: ['reduce('],
          mustContain: ['nilai.length'],
          errorMsg: 'Gunakan reduce() untuk total, lalu bagi dengan nilai.length untuk rata-rata.',
        },
        hint: 'const total = nilai.reduce((acc, n) => acc + n, 0) lalu const rataRata = total / nilai.length',
        successMsg: 'reduce() adalah yang paling powerful tapi butuh latihan. Sekarang kamu paham! 💪',
      },
      {
        id: 9,
        title: 'Object — Struktur Data',
        instruction: `## Langkah 9: Object

Object menyimpan data dalam pasangan key-value:

\`\`\`javascript
const siswa = {
  nama: 'Budi',
  umur: 17,
  nilai: [85, 90, 78],
  aktif: true
}

// Akses property
console.log(siswa.nama)        // Budi
console.log(siswa['umur'])     // 17

// Tambah/ubah property
siswa.kelas = 'XI IPA'
\`\`\`

**Tugasmu:** Buat object \`siswa\` dengan property: nama, kelas, nilai (array), dan aktif (boolean). Lalu tampilkan namanya.`,
        starterCode: `// Buat object siswa dengan property:
// nama (string), kelas (string), nilai (array 3 angka), aktif (boolean)
// Tampilkan nama siswa
`,
        check: {
          type: 'contains',
          patterns: ['const siswa', 'let siswa'],
          mustContain: ['nama:', 'console.log'],
          errorMsg: 'Buat object \`siswa\` dengan property nama, kelas, nilai, dan aktif. Tampilkan siswa.nama.',
        },
        hint: 'const siswa = { nama: "Budi", kelas: "XI", nilai: [85, 90, 78], aktif: true }',
        successMsg: 'Object adalah cara utama menyimpan data terstruktur di JavaScript! 🏗️',
      },
      {
        id: 10,
        title: 'Destructuring Assignment',
        instruction: `## Langkah 10: Destructuring

Destructuring memungkinkan "membongkar" nilai dari array/object:

\`\`\`javascript
// Object destructuring
const { nama, umur, kelas } = siswa
console.log(nama)   // Nilai dari siswa.nama

// Array destructuring
const [pertama, kedua, ...sisa] = [10, 20, 30, 40, 50]
console.log(pertama)  // 10
console.log(sisa)     // [30, 40, 50]

// Di parameter fungsi
const tampilkan = ({ nama, kelas }) => {
  console.log(\`\${nama} - Kelas \${kelas}\`)
}
\`\`\`

**Tugasmu:** Gunakan destructuring untuk mengambil \`nama\` dan \`kelas\` dari object siswa, lalu tampilkan keduanya.`,
        starterCode: `const siswa = {
  nama: 'Alice',
  kelas: 'XI IPA',
  nilai: [85, 90, 78],
  aktif: true
}
// Gunakan destructuring untuk ambil nama dan kelas
// Tampilkan keduanya
`,
        check: {
          type: 'contains',
          patterns: ['const { ', 'const {'],
          mustContain: ['nama', 'kelas'],
          errorMsg: 'Gunakan destructuring: const { nama, kelas } = siswa',
        },
        hint: 'const { nama, kelas } = siswa lalu console.log(nama, kelas)',
        successMsg: 'Destructuring membuat kode lebih ringkas dan mudah dibaca! Ini ES6 yang wajib dikuasai. 🎯',
      },
      {
        id: 11,
        title: 'Spread Operator',
        instruction: `## Langkah 11: Spread Operator (...)

Spread operator "menyebarkan" elemen array atau object:

\`\`\`javascript
// Gabungkan array
const a = [1, 2, 3]
const b = [4, 5, 6]
const gabungan = [...a, ...b]  // [1, 2, 3, 4, 5, 6]

// Clone array (bukan reference!)
const original = [1, 2, 3]
const klon = [...original]

// Gabungkan object
const dasar = { nama: 'Budi', umur: 17 }
const lengkap = { ...dasar, kelas: 'XI', aktif: true }
\`\`\`

**Tugasmu:** Gabungkan dua array nilai menjadi satu menggunakan spread operator.`,
        starterCode: `const nilaiUTS = [80, 85, 78]
const nilaiUAS = [90, 92, 88]
// Gabungkan kedua array menggunakan spread operator
// Simpan ke variabel semuaNilai

console.log(semuaNilai)  // [80, 85, 78, 90, 92, 88]
`,
        check: {
          type: 'contains',
          patterns: ['...nilaiUTS', '...nilaiUAS'],
          errorMsg: 'Gunakan spread: const semuaNilai = [...nilaiUTS, ...nilaiUAS]',
        },
        hint: 'const semuaNilai = [...nilaiUTS, ...nilaiUAS]',
        successMsg: 'Spread operator sangat berguna untuk menggabungkan data tanpa mutasi! 🌟',
      },
      {
        id: 12,
        title: 'Promise — Asynchronous Dasar',
        instruction: `## Langkah 12: Promise

Promise merepresentasikan operasi yang belum selesai (asynchronous):

\`\`\`javascript
const ambilData = new Promise((resolve, reject) => {
  const berhasil = true
  
  if (berhasil) {
    resolve('Data berhasil diambil!')
  } else {
    reject('Terjadi kesalahan!')
  }
})

ambilData
  .then(hasil => console.log(hasil))
  .catch(error => console.log(error))
\`\`\`

**Tugasmu:** Buat Promise bernama \`cekLogin\` yang resolve dengan pesan sukses jika \`isLogin = true\`.`,
        starterCode: `const isLogin = true

// Buat Promise cekLogin
// Jika isLogin true: resolve('Login berhasil!')
// Jika false: reject('Belum login!')

// Panggil dengan .then() dan .catch()
`,
        check: {
          type: 'contains',
          patterns: ['new Promise('],
          mustContain: ['resolve(', 'reject(', '.then('],
          errorMsg: 'Buat new Promise dengan resolve dan reject, lalu panggil dengan .then() dan .catch().',
        },
        hint: 'const cekLogin = new Promise((resolve, reject) => { if (isLogin) resolve("Login berhasil!") else reject("Belum login!") })',
        successMsg: 'Promise adalah pondasi async JavaScript! Langkah selanjutnya adalah async/await. 🔮',
      },
      {
        id: 13,
        title: 'Async/Await',
        instruction: `## Langkah 13: Async/Await

Async/await adalah cara lebih mudah menulis kode asynchronous:

\`\`\`javascript
// Simulasi fetch data (menunggu 1 detik)
const ambilUser = () => new Promise(resolve => {
  setTimeout(() => resolve({ nama: 'Budi', xp: 1500 }), 1000)
})

// Dengan async/await
async function tampilkanUser() {
  try {
    const user = await ambilUser()  // Tunggu hasilnya
    console.log(\`User: \${user.nama}, XP: \${user.xp}\`)
  } catch (error) {
    console.log('Error:', error)
  }
}

tampilkanUser()
\`\`\`

**Tugasmu:** Buat async function \`hitungTotal\` yang menggunakan await untuk menunggu hasil fungsi async, lalu tampilkan hasilnya.`,
        starterCode: `// Fungsi yang mensimulasikan operasi async
const hitungAsync = (a, b) => new Promise(resolve => {
  setTimeout(() => resolve(a + b), 500)
})

// Buat async function hitungTotal
// yang menggunakan await hitungAsync(10, 20)
// dan menampilkan hasilnya
`,
        check: {
          type: 'contains',
          patterns: ['async function', 'async ()'],
          mustContain: ['await'],
          errorMsg: 'Buat async function yang menggunakan await untuk menunggu hasil hitungAsync.',
        },
        hint: 'async function hitungTotal() { const hasil = await hitungAsync(10, 20); console.log(hasil) }',
        successMsg: 'Async/await membuat kode async terlihat seperti synchronous. Ini standar modern! ⚡',
      },
      {
        id: 14,
        title: 'Error Handling — try/catch',
        instruction: `## Langkah 14: Penanganan Error

try/catch menangkap error agar program tidak crash:

\`\`\`javascript
function bagi(a, b) {
  if (b === 0) {
    throw new Error('Tidak bisa bagi dengan nol!')
  }
  return a / b
}

try {
  console.log(bagi(10, 2))   // 5
  console.log(bagi(10, 0))   // Error!
} catch (error) {
  console.log('Error:', error.message)
} finally {
  console.log('Selalu dijalankan')
}
\`\`\`

**Tugasmu:** Buat fungsi \`parseJSON\` yang mencoba parse string JSON. Jika gagal, tangkap errornya dan tampilkan pesan yang ramah.`,
        starterCode: `function parseJSON(jsonString) {
  // Gunakan try/catch untuk JSON.parse(jsonString)
  // Jika berhasil: return hasilnya
  // Jika error: return null dan tampilkan pesan error
}

console.log(parseJSON('{"nama":"Budi"}'))  // { nama: 'Budi' }
console.log(parseJSON('ini bukan json'))   // null + pesan error
`,
        check: {
          type: 'contains',
          patterns: ['try {', 'try{'],
          mustContain: ['catch', 'JSON.parse('],
          errorMsg: 'Gunakan try { JSON.parse(jsonString) } catch (error) { ... } dalam fungsi parseJSON.',
        },
        hint: 'try { return JSON.parse(jsonString) } catch (e) { console.log("Error:", e.message); return null }',
        successMsg: 'Error handling membuat aplikasimu robust! Selalu tangkap error yang mungkin terjadi. 🛡️',
      },
      {
        id: 15,
        title: 'Program Akhir: Sistem Nilai Siswa',
        instruction: `## Langkah 15: Sistem Nilai Lengkap 🏆

Gabungkan semua konsep JavaScript yang sudah dipelajari! Buat sistem nilai siswa yang:

1. Punya array \`siswa\` berisi beberapa object siswa dengan nama dan array nilai
2. Fungsi \`hitungRata\` menggunakan reduce() untuk hitung rata-rata
3. Fungsi \`tentukanGrade\` menggunakan kondisi untuk grade A/B/C/D
4. Gunakan map() untuk memproses semua siswa
5. Tampilkan laporan lengkap menggunakan template literal

Contoh output:
\`\`\`
📊 LAPORAN NILAI KELAS
======================
✅ Alice   | Rata: 88.0 | Grade: B
✅ Budi    | Rata: 92.0 | Grade: A  
⚠️  Charlie | Rata: 65.0 | Grade: C
======================
\`\`\``,
        starterCode: `const siswa = [
  { nama: 'Alice', nilai: [85, 90, 88, 87, 90] },
  { nama: 'Budi', nilai: [92, 95, 88, 94, 91] },
  { nama: 'Charlie', nilai: [65, 70, 60, 68, 62] },
]

// Buat fungsi hitungRata menggunakan reduce()
// Buat fungsi tentukanGrade
// Proses semua siswa dengan map()
// Tampilkan laporan
`,
        check: {
          type: 'contains',
          patterns: ['reduce(', 'map('],
          mustContain: ['console.log', 'Grade'],
          errorMsg: 'Gunakan reduce() untuk rata-rata, map() untuk proses semua siswa, dan tampilkan laporan.',
        },
        hint: 'Gabungkan: reduce untuk rata-rata, if/else untuk grade, map untuk proses semua, template literal untuk tampilan',
        successMsg: '🎊🎊🎊 LUAR BIASA! Kamu telah menyelesaikan Workshop JavaScript Modern! Kamu menguasai const/let, arrow function, array methods, object, destructuring, spread, async/await, dan error handling!',
        isFinal: true,
      },
    ],
  },

  // ================================================================
  // 3. HTML & CSS WORKSHOP
  // ================================================================
  {
    id: 'html-css-dasar',
    title: 'HTML & CSS: Bangun Halaman Web',
    category: 'Frontend',
    slug: 'html-css-dasar',
    icon: '🏷️',
    lang: 'html',
    color: 'from-orange-500 to-red-500',
    level: 'Beginner',
    xp: 150,
    desc: 'Belajar membangun halaman web dari nol dengan HTML5 dan CSS3 modern.',
    steps: [
      {
        id: 1,
        title: 'Struktur Dasar HTML',
        instruction: `## Langkah 1: Kerangka HTML5

Setiap halaman HTML harus punya struktur dasar:

\`\`\`html
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Judul Halaman</title>
</head>
<body>
  <!-- Konten di sini -->
</body>
</html>
\`\`\`

**Tugasmu:** Buat struktur HTML5 lengkap dengan judul "Profil Saya".`,
        starterCode: `<!-- Buat struktur HTML5 lengkap di sini -->
`,
        check: {
          type: 'contains',
          patterns: ['<!DOCTYPE html>', '<!doctype html>'],
          mustContain: ['<html', '<head>', '<body>', '<title>'],
          errorMsg: 'Buat struktur lengkap: DOCTYPE, html, head dengan title, dan body.',
        },
        hint: 'Mulai dengan <!DOCTYPE html> lalu <html lang="id"><head>...<title>Profil Saya</title></head><body></body></html>',
        successMsg: 'Kerangka HTML5 ini adalah fondasi setiap halaman web modern! 🏗️',
      },
      {
        id: 2,
        title: 'Heading & Paragraf',
        instruction: `## Langkah 2: Heading dan Paragraf

Tag heading dari h1 (terbesar) sampai h6 (terkecil):

\`\`\`html
<h1>Judul Utama</h1>
<h2>Sub Judul</h2>
<h3>Sub-sub Judul</h3>

<p>Ini adalah sebuah paragraf. Teks bisa panjang.</p>
<p>Paragraf kedua dimulai di sini.</p>
\`\`\`

**Tugasmu:** Di dalam \`<body>\`, tambahkan:
- \`<h1>\` dengan namamu
- \`<h2>\` dengan profesimu/cita-citamu
- \`<p>\` dengan deskripsi singkat tentangmu`,
        starterCode: `<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Profil Saya</title>
</head>
<body>
  <!-- Tambahkan h1, h2, dan p di sini -->
</body>
</html>`,
        check: {
          type: 'contains',
          patterns: ['<h1>', '<h1 '],
          mustContain: ['<h2>', '<p>'],
          errorMsg: 'Tambahkan tag <h1>, <h2>, dan <p> di dalam body.',
        },
        hint: '<h1>Nama Kamu</h1><h2>Frontend Developer</h2><p>Deskripsi singkat...</p>',
        successMsg: 'Heading dan paragraf adalah elemen teks paling dasar di HTML! 📝',
      },
      {
        id: 3,
        title: 'Link dan Gambar',
        instruction: `## Langkah 3: Link dan Gambar

\`\`\`html
<!-- Link -->
<a href="https://google.com" target="_blank">Kunjungi Google</a>

<!-- Gambar -->
<img src="foto.jpg" alt="Foto Profil" width="200">

<!-- Link gambar -->
<a href="https://github.com">
  <img src="github-logo.png" alt="GitHub">
</a>
\`\`\`

- \`href\` = URL tujuan
- \`target="_blank"\` = buka di tab baru
- \`alt\` = teks alternatif (wajib untuk aksesibilitas)

**Tugasmu:** Tambahkan link ke website favoritmu dan gambar profil (boleh pakai URL gambar dari internet).`,
        starterCode: `<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Profil Saya</title>
</head>
<body>
  <h1>Nama Saya</h1>
  <p>Deskripsi saya.</p>
  <!-- Tambahkan link dan gambar di sini -->
</body>
</html>`,
        check: {
          type: 'contains',
          patterns: ['<a href=', '<a href ='],
          mustContain: ['<img', 'alt='],
          errorMsg: 'Tambahkan tag <a href="..."> untuk link dan <img src="..." alt="..."> untuk gambar.',
        },
        hint: '<a href="https://github.com" target="_blank">GitHub</a> dan <img src="https://via.placeholder.com/150" alt="Foto">',
        successMsg: 'Link dan gambar adalah elemen kunci dalam navigasi web! 🔗',
      },
      {
        id: 4,
        title: 'List — Ordered & Unordered',
        instruction: `## Langkah 4: Daftar List

\`\`\`html
<!-- Unordered list (bullet) -->
<ul>
  <li>JavaScript</li>
  <li>Python</li>
  <li>CSS</li>
</ul>

<!-- Ordered list (nomor) -->
<ol>
  <li>Belajar HTML</li>
  <li>Belajar CSS</li>
  <li>Belajar JavaScript</li>
</ol>
\`\`\`

**Tugasmu:** Tambahkan dua list:
1. Unordered list berisi skill-mu (minimal 3)
2. Ordered list berisi rencanamu belajar (minimal 3 langkah)`,
        starterCode: `<!DOCTYPE html>
<html lang="id">
<head><meta charset="UTF-8"><title>Profil Saya</title></head>
<body>
  <h1>Nama Saya</h1>
  <h2>Skill Saya:</h2>
  <!-- Buat unordered list skill -->
  
  <h2>Rencana Belajar:</h2>
  <!-- Buat ordered list rencana -->
</body>
</html>`,
        check: {
          type: 'contains',
          patterns: ['<ul>', '<ul '],
          mustContain: ['<ol>', '<li>'],
          errorMsg: 'Buat <ul> dengan <li> untuk skill, dan <ol> dengan <li> untuk rencana.',
        },
        hint: '<ul><li>HTML</li><li>CSS</li><li>JavaScript</li></ul>',
        successMsg: 'List sangat berguna untuk menampilkan informasi terstruktur! 📋',
      },
      {
        id: 5,
        title: 'CSS Inline vs Internal',
        instruction: `## Langkah 5: Menambahkan CSS

Ada 3 cara menambahkan CSS:

\`\`\`html
<!-- 1. Inline (langsung di elemen - tidak disarankan) -->
<h1 style="color: blue; font-size: 32px;">Judul</h1>

<!-- 2. Internal (di dalam <style> tag) -->
<head>
  <style>
    h1 { color: #7c3aed; font-size: 2rem; }
    p { color: #666; line-height: 1.6; }
  </style>
</head>

<!-- 3. External (file .css terpisah - best practice) -->
<link rel="stylesheet" href="style.css">
\`\`\`

**Tugasmu:** Tambahkan \`<style>\` di dalam \`<head>\` dan buat style untuk:
- \`body\`: background-color dan font-family
- \`h1\`: color dan font-size
- \`p\`: color dan line-height`,
        starterCode: `<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Profil Saya</title>
  <!-- Tambahkan <style> di sini -->
</head>
<body>
  <h1>Nama Saya</h1>
  <p>Ini adalah deskripsi saya.</p>
</body>
</html>`,
        check: {
          type: 'contains',
          patterns: ['<style>'],
          mustContain: ['body', 'h1', 'color'],
          errorMsg: 'Tambahkan <style> di dalam <head> dengan styling untuk body, h1, dan p.',
        },
        hint: '<style>body { background-color: #f5f5f5; font-family: Arial; } h1 { color: #7c3aed; }</style>',
        successMsg: 'CSS internal bagus untuk halaman tunggal. Gunakan file terpisah untuk proyek besar! 🎨',
      },
      {
        id: 6,
        title: 'CSS Flexbox',
        instruction: `## Langkah 6: Flexbox — Layout Modern

Flexbox membuat penataan layout jadi mudah:

\`\`\`css
.container {
  display: flex;
  justify-content: center;    /* horizontal: flex-start, center, flex-end, space-between */
  align-items: center;        /* vertical: flex-start, center, flex-end */
  gap: 16px;                  /* jarak antar elemen */
  flex-wrap: wrap;            /* pindah baris jika muat */
}
\`\`\`

**Tugasmu:** Buat navigation bar menggunakan flexbox dengan logo di kiri dan 3 menu di kanan.`,
        starterCode: `<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Profil Saya</title>
  <style>
    /* Styling untuk nav */
    nav {
      /* Tambahkan display: flex dan property lainnya */
    }
    .logo { font-weight: bold; font-size: 20px; }
    .menu { display: flex; gap: 20px; list-style: none; }
  </style>
</head>
<body>
  <nav>
    <div class="logo">CodeBook</div>
    <ul class="menu">
      <li>Beranda</li>
      <li>Tentang</li>
      <li>Kontak</li>
    </ul>
  </nav>
</body>
</html>`,
        check: {
          type: 'contains',
          patterns: ['display: flex', 'display:flex'],
          mustContain: ['justify-content', 'nav'],
          errorMsg: 'Tambahkan display: flex dan justify-content ke dalam CSS nav.',
        },
        hint: 'nav { display: flex; justify-content: space-between; align-items: center; padding: 16px; }',
        successMsg: 'Flexbox adalah cara paling umum untuk layout di web modern! Kuasai ini dan kamu sudah setengah jalan. 💪',
      },
      {
        id: 7,
        title: 'CSS Grid',
        instruction: `## Langkah 7: CSS Grid — Layout Dua Dimensi

Grid memungkinkan layout dengan baris DAN kolom:

\`\`\`css
.grid-container {
  display: grid;
  grid-template-columns: repeat(3, 1fr);  /* 3 kolom sama lebar */
  gap: 20px;
}

/* Responsive: 1 kolom di mobile */
@media (max-width: 768px) {
  .grid-container {
    grid-template-columns: 1fr;
  }
}
\`\`\`

**Tugasmu:** Buat grid 3 kolom untuk menampilkan 6 kartu skill.`,
        starterCode: `<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Skill Grid</title>
  <style>
    /* Buat CSS Grid 3 kolom */
    .grid { /* ... */ }
    .card {
      background: #f0f0f0;
      padding: 20px;
      border-radius: 8px;
      text-align: center;
    }
  </style>
</head>
<body>
  <div class="grid">
    <div class="card">HTML</div>
    <div class="card">CSS</div>
    <div class="card">JavaScript</div>
    <div class="card">Python</div>
    <div class="card">React</div>
    <div class="card">Node.js</div>
  </div>
</body>
</html>`,
        check: {
          type: 'contains',
          patterns: ['display: grid', 'display:grid'],
          mustContain: ['grid-template-columns'],
          errorMsg: 'Tambahkan display: grid dan grid-template-columns ke class .grid',
        },
        hint: '.grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; }',
        successMsg: 'CSS Grid + Flexbox = combo sempurna untuk layout apapun! 🏆',
      },
      {
        id: 8,
        title: 'Form HTML5',
        instruction: `## Langkah 8: Form yang Accessible

\`\`\`html
<form>
  <div class="form-group">
    <label for="email">Email:</label>
    <input type="email" id="email" name="email" 
           placeholder="kamu@example.com" required>
  </div>
  
  <div class="form-group">
    <label for="pesan">Pesan:</label>
    <textarea id="pesan" name="pesan" rows="4" required></textarea>
  </div>
  
  <button type="submit">Kirim</button>
</form>
\`\`\`

**Tugasmu:** Buat form kontak dengan field: nama, email, subjek, pesan, dan tombol kirim. Tambahkan CSS untuk styling.`,
        starterCode: `<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Form Kontak</title>
  <style>
    /* Styling form */
    .form-group { margin-bottom: 16px; }
    label { display: block; margin-bottom: 4px; font-weight: bold; }
    input, textarea { width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px; }
  </style>
</head>
<body>
  <h1>Hubungi Saya</h1>
  <form>
    <!-- Tambahkan field nama, email, subjek, pesan, dan button -->
  </form>
</body>
</html>`,
        check: {
          type: 'contains',
          patterns: ['<input', '<input '],
          mustContain: ['<textarea', '<button', 'type="email"'],
          errorMsg: 'Buat form dengan input untuk nama, email (type="email"), textarea untuk pesan, dan button submit.',
        },
        hint: 'Tambahkan input name, input email, input subjek, textarea pesan, dan button type="submit"',
        successMsg: 'Form yang baik harus accessible dengan label yang benar. Kamu sudah melakukannya! 📋',
      },
      {
        id: 9,
        title: 'CSS Variables & Tema',
        instruction: `## Langkah 9: CSS Custom Properties (Variables)

CSS Variables memungkinkan tema yang konsisten:

\`\`\`css
:root {
  --warna-utama: #7c3aed;
  --warna-teks: #1f2937;
  --warna-bg: #f9fafb;
  --font-utama: 'Arial', sans-serif;
  --border-radius: 8px;
}

h1 { color: var(--warna-utama); }
body { background: var(--warna-bg); font-family: var(--font-utama); }
.card { border-radius: var(--border-radius); }
\`\`\`

**Tugasmu:** Buat sistem warna menggunakan CSS variables dan terapkan ke setidaknya 4 elemen berbeda.`,
        starterCode: `<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>CSS Variables</title>
  <style>
    :root {
      /* Definisikan variabel warna di sini */
    }
    /* Gunakan var() untuk styling elemen */
    body { }
    h1 { }
    .card { }
    button { }
  </style>
</head>
<body>
  <h1>Judul dengan CSS Variables</h1>
  <div class="card">
    <p>Kartu dengan styling variabel</p>
    <button>Tombol</button>
  </div>
</body>
</html>`,
        check: {
          type: 'contains',
          patterns: [':root {', ':root{'],
          mustContain: ['var(--', '--'],
          errorMsg: 'Definisikan variabel CSS di :root { } lalu gunakan var(--nama-variabel) untuk styling.',
        },
        hint: ':root { --warna: #7c3aed; } lalu h1 { color: var(--warna); }',
        successMsg: 'CSS Variables membuat desain konsisten dan mudah diubah! Ini standar modern. 🎨',
      },
      {
        id: 10,
        title: 'Responsive Design & Media Query',
        instruction: `## Langkah 10: Responsive Design

Website harus tampil baik di semua ukuran layar:

\`\`\`css
/* Mobile first approach */
.container {
  width: 100%;
  padding: 16px;
}

/* Tablet: 768px ke atas */
@media (min-width: 768px) {
  .container {
    max-width: 768px;
    margin: 0 auto;
  }
}

/* Desktop: 1024px ke atas */  
@media (min-width: 1024px) {
  .container {
    max-width: 1200px;
  }
}
\`\`\`

**Tugasmu:** Buat layout yang berubah dari 1 kolom (mobile) menjadi 3 kolom (desktop) menggunakan media query.`,
        starterCode: `<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Responsive</title>
  <style>
    .grid {
      /* Default: 1 kolom untuk mobile */
    }
    /* Media query untuk tablet (min 768px): 2 kolom */
    /* Media query untuk desktop (min 1024px): 3 kolom */
    .card { background: #e0e7ff; padding: 20px; margin: 8px 0; border-radius: 8px; }
  </style>
</head>
<body>
  <div class="grid">
    <div class="card">Kartu 1</div>
    <div class="card">Kartu 2</div>
    <div class="card">Kartu 3</div>
    <div class="card">Kartu 4</div>
    <div class="card">Kartu 5</div>
    <div class="card">Kartu 6</div>
  </div>
</body>
</html>`,
        check: {
          type: 'contains',
          patterns: ['@media'],
          mustContain: ['min-width', 'grid-template-columns'],
          errorMsg: 'Tambahkan @media query untuk tablet dan desktop dengan grid-template-columns yang berbeda.',
        },
        hint: '@media (min-width: 768px) { .grid { display: grid; grid-template-columns: repeat(2, 1fr); } }',
        successMsg: 'Responsive design adalah syarat wajib website modern! Kamu hampir jadi web developer. 📱💻',
        isFinal: false,
      },
    ],
  },

  // ================================================================
  // 4. SQL FUNDAMENTALS
  // ================================================================
  {
    id: 'sql-dasar',
    title: 'SQL: Query Database dari Nol',
    slug: 'sql-dasar',
    icon: '📊',
    lang: 'sql',
    category: 'Database',
    color: 'from-cyan-500 to-blue-500',
    level: 'Beginner',
    xp: 180,
    desc: 'Kuasai SQL dari SELECT dasar hingga JOIN, agregasi, dan subquery.',
    steps: [
      {
        id: 1,
        title: 'SELECT Dasar',
        instruction: `## Langkah 1: Perintah SELECT

SQL (Structured Query Language) digunakan untuk berinteraksi dengan database relasional.

Perintah paling dasar adalah SELECT:

\`\`\`sql
-- Ambil semua kolom dan semua baris
SELECT * FROM users;

-- Ambil kolom tertentu saja
SELECT nama, email FROM users;
\`\`\`

Tanda \`*\` berarti "semua kolom". Titik koma \`;\` mengakhiri perintah.

**Tugasmu:** Tulis query untuk mengambil semua data dari tabel \`products\`.`,
        starterCode: `-- Ambil semua data dari tabel products
`,
        check: { type: 'contains', patterns: ['SELECT', 'select'], mustContain: ['FROM', 'from', 'products'], errorMsg: 'Gunakan SELECT * FROM products; untuk mengambil semua data.' },
        hint: 'SELECT * FROM products;',
        successMsg: 'SELECT adalah perintah paling sering dipakai di SQL! ✅',
      },
      {
        id: 2,
        title: 'WHERE — Filter Data',
        instruction: `## Langkah 2: Filter dengan WHERE

WHERE digunakan untuk menyaring baris berdasarkan kondisi:

\`\`\`sql
-- Filter user bernama 'Budi'
SELECT * FROM users WHERE nama = 'Budi';

-- Filter harga di atas 100000
SELECT * FROM products WHERE harga > 100000;

-- Multiple kondisi
SELECT * FROM products 
WHERE harga > 50000 AND stok > 0;
\`\`\`

**Tugasmu:** Ambil semua produk dengan kategori = 'Elektronik'.`,
        starterCode: `-- Ambil produk dengan kategori Elektronik
`,
        check: { type: 'contains', patterns: ['WHERE', 'where'], mustContain: ['kategori', 'Elektronik'], errorMsg: 'Gunakan WHERE kategori = \'Elektronik\'' },
        hint: "SELECT * FROM products WHERE kategori = 'Elektronik';",
        successMsg: 'WHERE adalah filter paling penting di SQL! 🔍',
      },
      {
        id: 3,
        title: 'ORDER BY — Urutkan Hasil',
        instruction: `## Langkah 3: Mengurutkan dengan ORDER BY

\`\`\`sql
-- Urutkan dari harga termurah
SELECT * FROM products ORDER BY harga ASC;

-- Urutkan dari harga termahal
SELECT * FROM products ORDER BY harga DESC;

-- Urutkan by nama, lalu by harga
SELECT * FROM products ORDER BY nama ASC, harga DESC;
\`\`\`

\`ASC\` = ascending (naik), \`DESC\` = descending (turun)

**Tugasmu:** Ambil semua user, urutkan berdasarkan nama (A-Z).`,
        starterCode: `-- Ambil semua user diurutkan by nama ascending
`,
        check: { type: 'contains', patterns: ['ORDER BY', 'order by'], mustContain: ['nama', 'ASC', 'asc'], errorMsg: 'Gunakan ORDER BY nama ASC untuk urutan A-Z.' },
        hint: 'SELECT * FROM users ORDER BY nama ASC;',
        successMsg: 'ORDER BY membuat hasil mudah dibaca! ↑↓',
      },
      {
        id: 4,
        title: 'LIMIT & OFFSET — Paginasi',
        instruction: `## Langkah 4: LIMIT dan OFFSET

\`\`\`sql
-- Ambil 10 baris pertama
SELECT * FROM products LIMIT 10;

-- Skip 10, ambil 10 berikutnya (halaman 2)
SELECT * FROM products LIMIT 10 OFFSET 10;

-- Kombinasi dengan ORDER BY
SELECT * FROM products 
ORDER BY created_at DESC 
LIMIT 5;  -- 5 produk terbaru
\`\`\`

**Tugasmu:** Ambil 5 produk termahal.`,
        starterCode: `-- Ambil 5 produk dengan harga tertinggi
`,
        check: { type: 'contains', patterns: ['LIMIT', 'limit'], mustContain: ['ORDER BY', 'order by', 'DESC', 'desc'], errorMsg: 'Gunakan ORDER BY harga DESC LIMIT 5' },
        hint: 'SELECT * FROM products ORDER BY harga DESC LIMIT 5;',
        successMsg: 'LIMIT + ORDER BY = pattern paling umum untuk menampilkan data! 📄',
      },
      {
        id: 5,
        title: 'Fungsi Agregasi',
        instruction: `## Langkah 5: COUNT, SUM, AVG, MIN, MAX

Fungsi agregasi menghitung nilai dari banyak baris:

\`\`\`sql
SELECT COUNT(*) FROM users;          -- Hitung jumlah baris
SELECT COUNT(email) FROM users;      -- Hitung non-NULL email

SELECT SUM(harga) FROM orders;       -- Total harga
SELECT AVG(harga) FROM products;     -- Rata-rata harga
SELECT MIN(harga) FROM products;     -- Harga termurah
SELECT MAX(harga) FROM products;     -- Harga termahal
\`\`\`

**Tugasmu:** Hitung jumlah total produk, harga rata-rata, dan harga termahal dalam satu query.`,
        starterCode: `-- Hitung COUNT, AVG harga, dan MAX harga dari products
`,
        check: { type: 'contains', patterns: ['COUNT', 'count'], mustContain: ['AVG', 'avg', 'MAX', 'max'], errorMsg: 'Gunakan SELECT COUNT(*), AVG(harga), MAX(harga) FROM products;' },
        hint: 'SELECT COUNT(*), AVG(harga), MAX(harga) FROM products;',
        successMsg: 'Fungsi agregasi sangat powerful untuk analisis data! 📊',
      },
      {
        id: 6,
        title: 'GROUP BY — Kelompokkan Data',
        instruction: `## Langkah 6: GROUP BY

GROUP BY mengelompokkan baris berdasarkan nilai kolom:

\`\`\`sql
-- Hitung jumlah produk per kategori
SELECT kategori, COUNT(*) AS jumlah
FROM products
GROUP BY kategori;

-- Total penjualan per user
SELECT user_id, SUM(total) AS total_belanja
FROM orders
GROUP BY user_id
ORDER BY total_belanja DESC;
\`\`\`

\`AS\` memberi alias/nama pada kolom hasil.

**Tugasmu:** Hitung jumlah user per kota, urutkan dari kota dengan user terbanyak.`,
        starterCode: `-- Hitung jumlah user per kota, urutkan terbanyak dulu
`,
        check: { type: 'contains', patterns: ['GROUP BY', 'group by'], mustContain: ['COUNT', 'count', 'kota'], errorMsg: 'Gunakan GROUP BY kota dengan COUNT(*) dan ORDER BY COUNT(*) DESC' },
        hint: 'SELECT kota, COUNT(*) AS jumlah FROM users GROUP BY kota ORDER BY jumlah DESC;',
        successMsg: 'GROUP BY adalah kunci analisis data per kategori! 🗂️',
      },
      {
        id: 7,
        title: 'HAVING — Filter Setelah GROUP BY',
        instruction: `## Langkah 7: HAVING

HAVING memfilter hasil GROUP BY (WHERE tidak bisa dipakai setelah GROUP BY):

\`\`\`sql
-- Hanya tampilkan kategori dengan lebih dari 5 produk
SELECT kategori, COUNT(*) AS jumlah
FROM products
GROUP BY kategori
HAVING COUNT(*) > 5;

-- Perbedaan WHERE vs HAVING:
-- WHERE memfilter baris SEBELUM group
-- HAVING memfilter SETELAH group
\`\`\`

**Tugasmu:** Tampilkan user yang total belanjaannya lebih dari 500000.`,
        starterCode: `-- Tampilkan user_id dengan SUM(total) > 500000
`,
        check: { type: 'contains', patterns: ['HAVING', 'having'], mustContain: ['GROUP BY', 'group by', 'SUM', 'sum'], errorMsg: 'Gunakan GROUP BY user_id HAVING SUM(total) > 500000' },
        hint: 'SELECT user_id, SUM(total) AS total FROM orders GROUP BY user_id HAVING SUM(total) > 500000;',
        successMsg: 'HAVING = WHERE tapi untuk hasil agregasi! Penting banget ini. 🎯',
      },
      {
        id: 8,
        title: 'INNER JOIN — Gabungkan Tabel',
        instruction: `## Langkah 8: JOIN

JOIN menggabungkan dua tabel berdasarkan kolom yang berhubungan:

\`\`\`sql
-- Tabel: orders (id, user_id, total)
-- Tabel: users (id, nama, email)

-- INNER JOIN: ambil baris yang match di KEDUA tabel
SELECT users.nama, orders.total, orders.created_at
FROM orders
INNER JOIN users ON orders.user_id = users.id;

-- Bisa pakai alias untuk ringkas
SELECT u.nama, o.total
FROM orders o
JOIN users u ON o.user_id = u.id;
\`\`\`

**Tugasmu:** Gabungkan tabel \`products\` dan \`categories\` untuk menampilkan nama produk beserta nama kategorinya.`,
        starterCode: `-- JOIN products dengan categories
-- Tampilkan nama produk dan nama kategori
`,
        check: { type: 'contains', patterns: ['JOIN', 'join'], mustContain: ['ON', 'on', 'products', 'categories'], errorMsg: 'Gunakan JOIN ... ON untuk menghubungkan products dan categories.' },
        hint: 'SELECT p.nama, c.nama AS kategori FROM products p JOIN categories c ON p.category_id = c.id;',
        successMsg: 'JOIN adalah fitur paling powerful di SQL relasional! 🔗',
      },
      {
        id: 9,
        title: 'LEFT JOIN — Semua Data Kiri',
        instruction: `## Langkah 9: LEFT JOIN vs INNER JOIN

\`\`\`sql
-- INNER JOIN: hanya baris yang match kedua tabel
-- LEFT JOIN: semua baris kiri + yang match kanan (NULL jika tidak match)

-- Semua user, termasuk yang belum pernah order
SELECT u.nama, COUNT(o.id) AS jumlah_order
FROM users u
LEFT JOIN orders o ON u.id = o.user_id
GROUP BY u.id, u.nama;

-- User yang BELUM pernah order
SELECT u.nama
FROM users u
LEFT JOIN orders o ON u.id = o.user_id
WHERE o.id IS NULL;
\`\`\`

**Tugasmu:** Tampilkan semua produk beserta total order-nya (termasuk produk yang belum pernah dipesan, tampilkan 0).`,
        starterCode: `-- LEFT JOIN products dengan order_items
-- Tampilkan nama produk dan COUNT order (termasuk yang 0)
`,
        check: { type: 'contains', patterns: ['LEFT JOIN', 'left join'], mustContain: ['products'], errorMsg: 'Gunakan LEFT JOIN agar produk tanpa order tetap tampil.' },
        hint: 'SELECT p.nama, COUNT(oi.id) AS total_order FROM products p LEFT JOIN order_items oi ON p.id = oi.product_id GROUP BY p.id, p.nama;',
        successMsg: 'LEFT JOIN memastikan data kiri tidak hilang! Sering dipakai di laporan. 📋',
      },
      {
        id: 10,
        title: 'INSERT, UPDATE, DELETE',
        instruction: `## Langkah 10: Manipulasi Data

\`\`\`sql
-- INSERT — tambah data baru
INSERT INTO users (nama, email, kota)
VALUES ('Budi', 'budi@email.com', 'Jakarta');

-- INSERT multiple rows
INSERT INTO products (nama, harga) VALUES
  ('Laptop', 15000000),
  ('Mouse', 150000);

-- UPDATE — ubah data
UPDATE users
SET kota = 'Bandung', aktif = true
WHERE id = 5;

-- DELETE — hapus data (HATI-HATI!)
DELETE FROM users WHERE id = 5;
DELETE FROM orders WHERE created_at < '2023-01-01';
\`\`\`

**Tugasmu:** Tulis query INSERT untuk menambahkan produk baru dengan nama, harga, dan kategori.`,
        starterCode: `-- INSERT produk baru ke tabel products
-- dengan kolom: nama, harga, kategori
`,
        check: { type: 'contains', patterns: ['INSERT INTO', 'insert into'], mustContain: ['VALUES', 'values'], errorMsg: 'Gunakan INSERT INTO products (nama, harga, kategori) VALUES (...)' },
        hint: "INSERT INTO products (nama, harga, kategori) VALUES ('Headphone', 500000, 'Elektronik');",
        successMsg: 'INSERT, UPDATE, DELETE = CRUD di SQL! Handle dengan hati-hati terutama DELETE. ⚠️',
      },
      {
        id: 11,
        title: 'Subquery',
        instruction: `## Langkah 11: Subquery

Query di dalam query:

\`\`\`sql
-- Produk dengan harga di atas rata-rata
SELECT nama, harga
FROM products
WHERE harga > (SELECT AVG(harga) FROM products);

-- User yang pernah order produk kategori 'Elektronik'
SELECT DISTINCT u.nama
FROM users u
WHERE u.id IN (
  SELECT o.user_id FROM orders o
  JOIN order_items oi ON o.id = oi.order_id
  JOIN products p ON oi.product_id = p.id
  WHERE p.kategori = 'Elektronik'
);
\`\`\`

**Tugasmu:** Ambil semua produk dengan harga di atas rata-rata harga semua produk.`,
        starterCode: `-- Produk dengan harga di atas rata-rata
-- Gunakan subquery dengan AVG
`,
        check: { type: 'contains', patterns: ['SELECT AVG', 'select avg'], mustContain: ['WHERE', 'harga'], errorMsg: 'Gunakan WHERE harga > (SELECT AVG(harga) FROM products)' },
        hint: 'SELECT nama, harga FROM products WHERE harga > (SELECT AVG(harga) FROM products);',
        successMsg: 'Subquery membuat SQL sangat ekspresif! Bisa nested berkali-kali. 🧩',
      },
      {
        id: 12,
        title: 'CREATE TABLE & Tipe Data',
        instruction: `## Langkah 12: Membuat Tabel

\`\`\`sql
CREATE TABLE users (
  id          INT PRIMARY KEY AUTO_INCREMENT,
  nama        VARCHAR(100) NOT NULL,
  email       VARCHAR(200) UNIQUE NOT NULL,
  password    VARCHAR(255) NOT NULL,
  umur        INT,
  saldo       DECIMAL(15, 2) DEFAULT 0,
  aktif       BOOLEAN DEFAULT TRUE,
  created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tipe data umum:
-- INT, BIGINT          angka bulat
-- DECIMAL(p,s)         desimal presisi
-- VARCHAR(n)           teks variabel
-- TEXT                 teks panjang
-- BOOLEAN              true/false
-- DATE, TIMESTAMP      tanggal/waktu
\`\`\`

**Tugasmu:** Buat tabel \`products\` dengan kolom: id, nama, harga, stok, kategori, dan created_at.`,
        starterCode: `-- Buat tabel products
-- Kolom: id, nama, harga, stok, kategori, created_at
`,
        check: { type: 'contains', patterns: ['CREATE TABLE', 'create table'], mustContain: ['nama', 'harga', 'PRIMARY KEY', 'primary key'], errorMsg: 'Gunakan CREATE TABLE products dengan semua kolom yang dibutuhkan.' },
        hint: 'CREATE TABLE products (id INT PRIMARY KEY AUTO_INCREMENT, nama VARCHAR(200) NOT NULL, harga DECIMAL(15,2), stok INT DEFAULT 0, kategori VARCHAR(100), created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);',
        successMsg: 'Schema design yang baik = fondasi database yang kuat! 🏗️',
      },
      {
        id: 13,
        title: 'INDEX — Percepat Query',
        instruction: `## Langkah 13: INDEX untuk Performa

Tanpa index, database scan semua baris (lambat).
Dengan index, langsung loncat ke data yang dicari (cepat).

\`\`\`sql
-- Buat index pada kolom email (sering di-WHERE)
CREATE INDEX idx_users_email ON users(email);

-- Unique index (tidak boleh duplikat)
CREATE UNIQUE INDEX idx_users_email_unique ON users(email);

-- Composite index (kombinasi kolom)
CREATE INDEX idx_orders_user_date ON orders(user_id, created_at);

-- Lihat index yang ada
SHOW INDEX FROM users;

-- Hapus index
DROP INDEX idx_users_email ON users;
\`\`\`

**Tugasmu:** Buat index pada kolom \`email\` di tabel \`users\`.`,
        starterCode: `-- Buat index pada kolom email tabel users
`,
        check: { type: 'contains', patterns: ['CREATE INDEX', 'create index'], mustContain: ['email', 'users'], errorMsg: 'Gunakan CREATE INDEX nama_index ON users(email)' },
        hint: 'CREATE INDEX idx_users_email ON users(email);',
        successMsg: 'Index yang tepat bisa percepat query 100x lebih cepat! ⚡',
      },
      {
        id: 14,
        title: 'TRANSACTION',
        instruction: `## Langkah 14: Transaction — All or Nothing

Transaction memastikan sekelompok operasi berhasil semua atau gagal semua:

\`\`\`sql
-- Contoh: Transfer saldo antar user
BEGIN TRANSACTION;

UPDATE accounts SET saldo = saldo - 100000 WHERE user_id = 1;
UPDATE accounts SET saldo = saldo + 100000 WHERE user_id = 2;

-- Jika keduanya berhasil:
COMMIT;

-- Jika ada error (rollback semua):
ROLLBACK;
\`\`\`

Tanpa transaction: jika UPDATE pertama berhasil tapi kedua gagal, saldo hilang!

**Tugasmu:** Tulis transaction untuk mengurangi stok produk dan menambah catatan order sekaligus.`,
        starterCode: `-- Transaction: kurangi stok dan tambah order
-- Harus COMMIT di akhir
`,
        check: { type: 'contains', patterns: ['BEGIN', 'begin', 'START TRANSACTION', 'start transaction'], mustContain: ['COMMIT', 'commit'], errorMsg: 'Gunakan BEGIN TRANSACTION ... COMMIT untuk membungkus operasi.' },
        hint: 'BEGIN; UPDATE products SET stok = stok - 1 WHERE id = 5; INSERT INTO orders ... ; COMMIT;',
        successMsg: 'Transaction adalah ACID compliance — fondasi keandalan database! 🔒',
        isFinal: true,
      },
    ],
  },

  // ================================================================
  // 5. GIT & VERSION CONTROL
  // ================================================================
  {
    id: 'git-dasar',
    title: 'Git: Version Control dari Nol',
    slug: 'git-dasar',
    icon: '🔀',
    lang: 'git',
    category: 'Tools',
    color: 'from-orange-600 to-red-500',
    level: 'Beginner',
    xp: 150,
    desc: 'Kuasai Git dari init, commit, branching, merge, hingga workflow tim profesional.',
    steps: [
      {
        id: 1,
        title: 'git init & git status',
        instruction: `## Langkah 1: Inisialisasi Repository

Git tracking perubahan file di dalam sebuah repository.

\`\`\`bash
# Buat repository baru
git init

# Cek status file (tracked/untracked/modified)
git status

# Output contoh:
# On branch main
# Untracked files:
#   index.html
#   style.css
\`\`\`

**Tugasmu:** Tulis perintah untuk menginisialisasi repository baru DAN mengecek statusnya.`,
        starterCode: `# Tulis dua perintah git di sini:
# 1. Inisialisasi repository baru
# 2. Cek status repository
`,
        check: { type: 'contains', patterns: ['git init'], mustContain: ['git status'], errorMsg: 'Tulis git init dan git status.' },
        hint: 'git init\ngit status',
        successMsg: 'git init membuat folder .git yang menyimpan semua history! ✅',
      },
      {
        id: 2,
        title: 'git add — Stage Changes',
        instruction: `## Langkah 2: Staging Area

Sebelum commit, file harus di-"stage" dulu:

\`\`\`bash
# Tambah satu file ke staging
git add index.html

# Tambah beberapa file
git add index.html style.css

# Tambah SEMUA file yang berubah
git add .

# Tambah semua file dengan ekstensi .js
git add *.js

# Cek apa yang sudah di-stage
git status
\`\`\`

**Tugasmu:** Tulis perintah untuk menstage semua perubahan sekaligus.`,
        starterCode: `# Stage semua perubahan sekaligus
`,
        check: { type: 'contains', patterns: ['git add .', 'git add -A'], errorMsg: 'Gunakan git add . untuk stage semua perubahan.' },
        hint: 'git add .',
        successMsg: 'Staging area memungkinkan kamu memilih perubahan mana yang masuk satu commit! 📦',
      },
      {
        id: 3,
        title: 'git commit — Simpan Snapshot',
        instruction: `## Langkah 3: Commit

Commit menyimpan snapshot permanent dari staging area:

\`\`\`bash
# Commit dengan pesan
git commit -m "feat: tambah halaman login"

# Stage + commit sekaligus (hanya untuk file yang sudah tracked)
git commit -am "fix: perbaiki bug tombol submit"

# Format pesan commit yang baik (Conventional Commits):
git commit -m "feat: ..."     # fitur baru
git commit -m "fix: ..."      # bug fix
git commit -m "docs: ..."     # dokumentasi
git commit -m "style: ..."    # formatting
git commit -m "refactor: ..."  # refactoring
git commit -m "test: ..."     # test
\`\`\`

**Tugasmu:** Tulis perintah untuk commit dengan pesan "feat: halaman awal website".`,
        starterCode: `# Commit dengan pesan feat: halaman awal website
`,
        check: { type: 'contains', patterns: ['git commit'], mustContain: ['feat:', '-m'], errorMsg: 'Gunakan git commit -m "feat: halaman awal website"' },
        hint: 'git commit -m "feat: halaman awal website"',
        successMsg: 'Commit = titik balik yang bisa kamu kembali kapan saja! 📸',
      },
      {
        id: 4,
        title: 'git log — Lihat History',
        instruction: `## Langkah 4: Melihat History

\`\`\`bash
# Lihat semua commit
git log

# Format ringkas (satu baris per commit)
git log --oneline

# Log dengan graph (visual branch)
git log --oneline --graph --all

# Lihat commit terakhir
git log -1

# Cari commit by author
git log --author="Budi"

# Cari commit by kata kunci di pesan
git log --grep="fix"
\`\`\`

**Tugasmu:** Tulis perintah untuk melihat log dalam format ringkas (oneline) dengan graph.`,
        starterCode: `# Tampilkan log ringkas dengan graph
`,
        check: { type: 'contains', patterns: ['git log'], mustContain: ['--oneline', '--graph'], errorMsg: 'Gunakan git log --oneline --graph --all' },
        hint: 'git log --oneline --graph --all',
        successMsg: 'git log adalah cara melihat "filmstrip" perjalanan proyekmu! 🎬',
      },
      {
        id: 5,
        title: 'git branch — Kelola Branch',
        instruction: `## Langkah 5: Branch

Branch memungkinkan pengembangan paralel tanpa mengganggu kode utama:

\`\`\`bash
# Lihat semua branch
git branch

# Buat branch baru
git branch fitur-login

# Pindah ke branch
git checkout fitur-login
# atau cara modern:
git switch fitur-login

# Buat + langsung pindah (shortcut)
git checkout -b fitur-register
git switch -c fitur-register   # cara modern

# Hapus branch
git branch -d fitur-selesai    # hapus jika sudah merge
git branch -D fitur-abandoned  # force delete
\`\`\`

**Tugasmu:** Tulis perintah untuk membuat branch bernama "fitur-dashboard" sekaligus langsung pindah ke sana.`,
        starterCode: `# Buat dan langsung pindah ke branch fitur-dashboard
`,
        check: { type: 'contains', patterns: ['git checkout -b', 'git switch -c'], mustContain: ['fitur-dashboard'], errorMsg: 'Gunakan git checkout -b fitur-dashboard atau git switch -c fitur-dashboard' },
        hint: 'git checkout -b fitur-dashboard',
        successMsg: 'Branch adalah superpower Git! Kerjakan fitur baru tanpa takut merusak main. 🌿',
      },
      {
        id: 6,
        title: 'git merge — Gabungkan Branch',
        instruction: `## Langkah 6: Merge

Merge menggabungkan perubahan dari satu branch ke branch lain:

\`\`\`bash
# Pastikan kamu di branch tujuan (main)
git checkout main

# Merge branch fitur ke main
git merge fitur-login

# Jika ada conflict, edit file yang conflict lalu:
git add file-yang-conflict.js
git commit -m "fix: resolve merge conflict"

# Setelah merge, hapus branch
git branch -d fitur-login
\`\`\`

**Tugasmu:** Tulis urutan perintah: pindah ke main, lalu merge branch "fitur-dashboard".`,
        starterCode: `# 1. Pindah ke branch main
# 2. Merge branch fitur-dashboard ke main
`,
        check: { type: 'contains', patterns: ['git checkout main', 'git switch main'], mustContain: ['git merge', 'fitur-dashboard'], errorMsg: 'Tulis git checkout main lalu git merge fitur-dashboard' },
        hint: 'git checkout main\ngit merge fitur-dashboard',
        successMsg: 'Merge = menyatukan kerja keras tim! Pahami conflict resolution dengan baik. 🔀',
      },
      {
        id: 7,
        title: 'git remote & push',
        instruction: `## Langkah 7: Remote Repository

Remote adalah copy repository di server (GitHub, GitLab, dll):

\`\`\`bash
# Hubungkan ke remote (GitHub)
git remote add origin https://github.com/user/repo.git

# Lihat remote yang ada
git remote -v

# Push branch ke remote (pertama kali)
git push -u origin main

# Push selanjutnya
git push

# Push branch baru
git push origin fitur-login

# Pull perubahan dari remote
git pull
\`\`\`

**Tugasmu:** Tulis perintah untuk menambahkan remote bernama "origin" dengan URL GitHub, lalu push ke main.`,
        starterCode: `# Tambahkan remote origin dengan URL GitHub
# Lalu push ke branch main
`,
        check: { type: 'contains', patterns: ['git remote add'], mustContain: ['git push', 'origin', 'main'], errorMsg: 'Gunakan git remote add origin <url> lalu git push -u origin main' },
        hint: 'git remote add origin https://github.com/user/repo.git\ngit push -u origin main',
        successMsg: 'GitHub/GitLab = backup kode + kolaborasi tim! Wajib pakai. ☁️',
      },
      {
        id: 8,
        title: 'git stash — Simpan Sementara',
        instruction: `## Langkah 8: Git Stash

Stash menyimpan perubahan sementara tanpa commit (berguna saat perlu switch branch cepat):

\`\`\`bash
# Simpan semua perubahan ke stash
git stash

# Simpan dengan nama
git stash save "WIP: form validasi"

# Lihat daftar stash
git stash list

# Ambil kembali stash terakhir
git stash pop

# Ambil stash tertentu
git stash apply stash@{2}

# Hapus stash
git stash drop stash@{0}
git stash clear  # hapus semua
\`\`\`

**Tugasmu:** Tulis perintah untuk menyimpan perubahan ke stash dengan nama "WIP: perbaikan bug login".`,
        starterCode: `# Simpan perubahan ke stash dengan nama "WIP: perbaikan bug login"
`,
        check: { type: 'contains', patterns: ['git stash'], mustContain: ['WIP'], errorMsg: 'Gunakan git stash save "WIP: perbaikan bug login"' },
        hint: 'git stash save "WIP: perbaikan bug login"',
        successMsg: 'Stash = laci sementara untuk perubahan yang belum siap di-commit! 🗄️',
      },
      {
        id: 9,
        title: '.gitignore',
        instruction: `## Langkah 9: .gitignore

File .gitignore memberitahu Git file/folder mana yang TIDAK perlu di-track:

\`\`\`bash
# File .gitignore untuk proyek Node.js/Next.js

# Dependencies
node_modules/

# Environment variables (SANGAT PENTING - jangan commit ini!)
.env
.env.local
.env.production

# Build output
.next/
dist/
build/
out/

# OS files
.DS_Store
Thumbs.db

# Logs
*.log
npm-debug.log*

# Editor
.vscode/
.idea/
\`\`\`

**Tugasmu:** Tulis isi .gitignore untuk proyek Node.js: exclude node_modules, .env, .next, dan *.log.`,
        starterCode: `# Tulis isi .gitignore untuk proyek Node.js
# Minimal: node_modules, .env, .next, dan file log
`,
        check: { type: 'contains', patterns: ['node_modules'], mustContain: ['.env', '.next', '.log', '*.log'], errorMsg: 'Pastikan .gitignore berisi node_modules/, .env, .next/, dan *.log' },
        hint: 'node_modules/\n.env\n.env.local\n.next/\n*.log',
        successMsg: 'Jangan pernah commit .env ke Git! Itu risiko keamanan besar. 🔐',
      },
      {
        id: 10,
        title: 'Git Workflow Tim',
        instruction: `## Langkah 10: Git Flow Profesional

Workflow Git yang umum dipakai tim:

\`\`\`bash
# 1. Update main dulu
git checkout main
git pull origin main

# 2. Buat branch untuk fitur/fix
git checkout -b feat/user-authentication

# 3. Kerjakan, commit rutin
git add .
git commit -m "feat: tambah form login"
git commit -m "feat: tambah JWT validation"

# 4. Push branch ke remote
git push origin feat/user-authentication

# 5. Buat Pull Request di GitHub
# (dilakukan via GitHub UI)

# 6. Setelah PR di-approve & merge, cleanup
git checkout main
git pull
git branch -d feat/user-authentication
\`\`\`

**Tugasmu:** Tulis lengkap perintah untuk: (1) update main, (2) buat branch "fix/bug-login", (3) commit "fix: perbaiki validasi email", (4) push branch.`,
        starterCode: `# Workflow lengkap:
# 1. Update main
# 2. Buat branch fix/bug-login
# 3. Commit
# 4. Push branch
`,
        check: { type: 'contains', patterns: ['git pull'], mustContain: ['fix/bug-login', 'git commit', 'git push'], errorMsg: 'Tulis semua 4 langkah: git pull, checkout -b, commit -m, push' },
        hint: 'git checkout main && git pull\ngit checkout -b fix/bug-login\ngit commit -m "fix: perbaiki validasi email"\ngit push origin fix/bug-login',
        successMsg: '🏆 Selamat! Kamu sekarang bisa berkontribusi ke proyek tim profesional dengan Git!',
        isFinal: true,
      },
    ],
  },

  // ================================================================
  // 6. CSS ADVANCED
  // ================================================================
  {
    id: 'css-lanjutan',
    title: 'CSS Modern: Animasi & Layout Pro',
    slug: 'css-lanjutan',
    icon: '🎨',
    lang: 'css',
    category: 'Frontend',
    color: 'from-purple-500 to-pink-500',
    level: 'Intermediate',
    xp: 180,
    desc: 'Kuasai CSS modern — animasi, custom properties, Grid lanjutan, dan desain responsif.',
    steps: [
      {
        id: 1,
        title: 'CSS Custom Properties (Variables)',
        instruction: `## Langkah 1: CSS Variables

CSS Custom Properties memungkinkan tema yang konsisten:

\`\`\`css
:root {
  --color-primary: #7c3aed;
  --color-text: #1f2937;
  --color-bg: #f9fafb;
  --spacing-md: 1rem;
  --border-radius: 8px;
  --font-sans: 'Plus Jakarta Sans', sans-serif;
}

/* Gunakan dengan var() */
.button {
  background: var(--color-primary);
  padding: var(--spacing-md);
  border-radius: var(--border-radius);
}

/* Override untuk komponen tertentu */
.card {
  --color-primary: #059669;  /* Lokal override */
  background: var(--color-primary);
}
\`\`\`

**Tugasmu:** Buat sistem design token dengan minimal 5 variabel CSS di :root, lalu terapkan ke beberapa elemen.`,
        starterCode: `:root {
  /* Definisikan min 5 variabel: warna utama, bg, teks, spacing, border-radius */
}

.button {
  /* Gunakan var() untuk styling */
}

.card {
  /* Gunakan var() */
}
`,
        check: { type: 'contains', patterns: [':root {', ':root{'], mustContain: ['var(--', '--'], errorMsg: 'Definisikan variabel di :root {} dan gunakan var(--nama) untuk styling.' },
        hint: ':root { --primary: #7c3aed; --bg: #f9fafb; --text: #1f2937; --space: 1rem; --radius: 8px; }',
        successMsg: 'CSS Variables = sistem desain yang konsisten dan mudah diubah! 🎨',
      },
      {
        id: 2,
        title: 'Flexbox Advanced',
        instruction: `## Langkah 2: Flexbox Lanjutan

\`\`\`css
.container {
  display: flex;
  flex-direction: row;       /* row | column | row-reverse | column-reverse */
  justify-content: space-between; /* start | end | center | space-between | space-around */
  align-items: center;        /* start | end | center | stretch | baseline */
  flex-wrap: wrap;            /* nowrap | wrap | wrap-reverse */
  gap: 1rem;                  /* jarak antar item */
}

.item {
  flex: 1;                    /* flex-grow: 1, flex-shrink: 1, flex-basis: 0 */
  flex: 0 0 200px;            /* tidak grow, tidak shrink, lebar 200px */
  order: 2;                   /* ubah urutan visual */
  align-self: flex-start;     /* override align-items untuk item ini */
}
\`\`\`

**Tugasmu:** Buat navbar dengan flexbox: logo di kiri, nav links di tengah, button di kanan. Responsive: kolom di mobile.`,
        starterCode: `.navbar {
  /* Flexbox: logo kiri, nav tengah, btn kanan */
}

.nav-links {
  /* Horizontal list */
}

@media (max-width: 768px) {
  .navbar {
    /* Flex column di mobile */
  }
}
`,
        check: { type: 'contains', patterns: ['display: flex', 'display:flex'], mustContain: ['justify-content', '@media'], errorMsg: 'Buat flexbox navbar dengan media query untuk mobile.' },
        hint: '.navbar { display: flex; justify-content: space-between; align-items: center; }',
        successMsg: 'Flexbox + media query = navbar responsif yang profesional! 💪',
      },
      {
        id: 3,
        title: 'CSS Grid Lanjutan',
        instruction: `## Langkah 3: CSS Grid Advanced

\`\`\`css
.layout {
  display: grid;
  
  /* Template dengan nama area */
  grid-template-areas:
    "header header header"
    "sidebar main   main"
    "footer footer  footer";
  
  grid-template-columns: 250px 1fr 1fr;
  grid-template-rows: 60px 1fr 40px;
  min-height: 100vh;
  gap: 0;
}

.header  { grid-area: header; }
.sidebar { grid-area: sidebar; }
.main    { grid-area: main; }
.footer  { grid-area: footer; }
\`\`\`

**Tugasmu:** Buat layout dashboard dengan CSS Grid: header atas penuh, sidebar kiri, konten kanan, footer bawah penuh.`,
        starterCode: `.dashboard {
  display: grid;
  /* Template areas: header / sidebar + main / footer */
  /* Min height: 100vh */
}

/* Assign grid-area ke setiap elemen */
.header  { }
.sidebar { }
.main    { }
.footer  { }
`,
        check: { type: 'contains', patterns: ['grid-template-areas', 'grid-template-columns'], mustContain: ['grid-area'], errorMsg: 'Gunakan grid-template-areas dan grid-area untuk layout dashboard.' },
        hint: '.dashboard { display: grid; grid-template-areas: "header header" "sidebar main" "footer footer"; grid-template-columns: 250px 1fr; }',
        successMsg: 'Named grid areas membuat layout kompleks jadi sangat mudah dibaca! 🏗️',
      },
      {
        id: 4,
        title: 'CSS Transitions',
        instruction: `## Langkah 4: Transisi Smooth

\`\`\`css
.button {
  background: #7c3aed;
  padding: 10px 20px;
  border-radius: 8px;
  
  /* Transition: property duration timing-function delay */
  transition: background 0.3s ease;
  
  /* Atau multiple properties */
  transition: background 0.3s ease, transform 0.2s ease, box-shadow 0.3s ease;
  
  /* Semua property */
  transition: all 0.3s ease;
}

.button:hover {
  background: #5b21b6;
  transform: translateY(-2px);
  box-shadow: 0 8px 20px rgba(124, 58, 237, 0.4);
}
\`\`\`

**Tugasmu:** Buat card dengan transisi smooth pada hover: scale sedikit membesar, shadow muncul, border berubah warna.`,
        starterCode: `.card {
  background: #0f172a;
  border: 1px solid rgba(255,255,255,0.06);
  border-radius: 16px;
  padding: 24px;
  /* Tambahkan transition */
}

.card:hover {
  /* Tambahkan efek hover dengan transform, box-shadow, border */
}
`,
        check: { type: 'contains', patterns: ['transition:'], mustContain: ['.card:hover', 'transform'], errorMsg: 'Tambahkan transition ke .card dan efek transform di .card:hover' },
        hint: '.card { transition: all 0.3s ease; } .card:hover { transform: translateY(-4px) scale(1.02); box-shadow: 0 20px 40px rgba(0,0,0,0.3); border-color: rgba(124,58,237,0.4); }',
        successMsg: 'Transisi yang halus membuat UI terasa premium dan profesional! ✨',
      },
      {
        id: 5,
        title: 'CSS Keyframe Animations',
        instruction: `## Langkah 5: Animasi Keyframe

\`\`\`css
/* Definisikan animasi */
@keyframes fadeInUp {
  from {
    opacity: 0;
    transform: translateY(20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

@keyframes pulse {
  0%, 100% { transform: scale(1); }
  50%       { transform: scale(1.1); }
}

/* Pakai animasi */
.hero-title {
  animation: fadeInUp 0.6s ease forwards;
}

.badge {
  animation: pulse 2s ease-in-out infinite;
}
\`\`\`

**Tugasmu:** Buat animasi "shimmer" loading skeleton (efek kilat berjalan dari kiri ke kanan).`,
        starterCode: `/* Animasi shimmer untuk loading skeleton */
@keyframes shimmer {
  /* Dari posisi -200% ke 200% */
}

.skeleton {
  background: /* gradient dengan shimmer */;
  background-size: 200% 100%;
  animation: /* pakai shimmer, 1.5s, infinite */;
  border-radius: 6px;
  height: 16px;
}
`,
        check: { type: 'contains', patterns: ['@keyframes shimmer', '@keyframes'], mustContain: ['animation:', 'infinite', 'background'], errorMsg: 'Buat @keyframes shimmer dengan pergerakan gradient dan animation infinite.' },
        hint: '@keyframes shimmer { 0% { background-position: 200% 0; } 100% { background-position: -200% 0; } } .skeleton { background: linear-gradient(90deg, #1e293b 25%, #334155 50%, #1e293b 75%); background-size: 200% 100%; animation: shimmer 1.5s infinite; }',
        successMsg: 'Skeleton loading membuat UX terasa lebih cepat walau data belum ada! ⚡',
      },
      {
        id: 6,
        title: 'CSS Pseudo-elements',
        instruction: `## Langkah 6: ::before & ::after

Pseudo-elements membuat elemen dekoratif tanpa tambah HTML:

\`\`\`css
/* Garis dekoratif di bawah heading */
.section-title {
  position: relative;
  display: inline-block;
}

.section-title::after {
  content: '';           /* WAJIB ada */
  position: absolute;
  bottom: -4px;
  left: 0;
  width: 100%;
  height: 3px;
  background: linear-gradient(90deg, #7c3aed, #06b6d4);
  border-radius: 2px;
}

/* Custom list marker */
li::before {
  content: '→';
  color: #7c3aed;
  font-weight: bold;
  margin-right: 8px;
}
\`\`\`

**Tugasmu:** Buat tombol dengan efek "loading spinner" menggunakan ::after pseudo-element dan CSS animation.`,
        starterCode: `.btn-loading {
  position: relative;
  padding: 10px 40px 10px 16px;
}

.btn-loading::after {
  content: '';
  position: absolute;
  /* Spinner: border, border-radius, animasi rotate */
}

@keyframes spin {
  /* 0deg ke 360deg */
}
`,
        check: { type: 'contains', patterns: ['::after', '::before'], mustContain: ['@keyframes', 'border-radius'], errorMsg: 'Buat ::after dengan animasi spin menggunakan border dan @keyframes.' },
        hint: '.btn-loading::after { content:""; position:absolute; right:12px; top:50%; width:14px; height:14px; border:2px solid rgba(255,255,255,0.3); border-top-color:white; border-radius:50%; transform:translateY(-50%); animation:spin 0.8s linear infinite; }',
        successMsg: 'Pseudo-elements mengurangi div soup di HTML! Desain bersih. 🎨',
      },
      {
        id: 7,
        title: 'Container Queries (Modern CSS)',
        instruction: `## Langkah 7: Container Queries

Container Queries (CSS baru 2023) — responsive berdasarkan container, bukan viewport:

\`\`\`css
/* Definisikan container */
.card-wrapper {
  container-type: inline-size;
  container-name: card;
}

/* Kondisi berdasarkan ukuran container */
@container card (min-width: 400px) {
  .card {
    display: flex;
    gap: 16px;
  }
  .card-image {
    width: 120px;
    flex-shrink: 0;
  }
}

@container (max-width: 300px) {
  .card-title {
    font-size: 0.875rem;
  }
}
\`\`\`

**Tugasmu:** Buat card wrapper dengan container query: di atas 450px tampil horizontal, di bawah tampil vertikal.`,
        starterCode: `.card-wrapper {
  /* Jadikan ini container */
}

.card {
  /* Default: vertical layout */
}

@container (min-width: 450px) {
  .card {
    /* Horizontal layout saat container >= 450px */
  }
}
`,
        check: { type: 'contains', patterns: ['container-type', '@container'], mustContain: ['min-width'], errorMsg: 'Gunakan container-type dan @container (min-width: 450px) untuk container query.' },
        hint: '.card-wrapper { container-type: inline-size; } @container (min-width: 450px) { .card { display: flex; gap: 16px; } }',
        successMsg: 'Container Queries lebih powerful dari media queries untuk component-based design! 🔮',
        isFinal: true,
      },
    ],
  },

  // ================================================================
  // 7. NODE.JS BACKEND
  // ================================================================
  {
    id: 'nodejs-backend',
    title: 'Node.js: Build REST API Lengkap',
    slug: 'nodejs-backend',
    icon: '🟢',
    lang: 'javascript',
    category: 'Backend',
    color: 'from-green-500 to-emerald-600',
    level: 'Intermediate',
    xp: 220,
    desc: 'Bangun REST API production-ready dengan Node.js, Express, JWT auth, dan MongoDB.',
    steps: [
      {
        id: 1,
        title: 'Setup Express Server',
        instruction: `## Langkah 1: Setup Express.js

\`\`\`javascript
const express = require('express')
const app = express()

// Middleware untuk parse JSON body
app.use(express.json())
app.use(express.urlencoded({ extended: true }))

// Basic route
app.get('/', (req, res) => {
  res.json({ message: 'API berjalan!', version: '1.0' })
})

// Start server
const PORT = process.env.PORT || 3000
app.listen(PORT, () => {
  console.log(\`Server berjalan di http://localhost:\${PORT}\`)
})
\`\`\`

**Tugasmu:** Buat setup Express server lengkap dengan middleware JSON dan route GET / yang mengembalikan JSON dengan pesan selamat datang.`,
        starterCode: `const express = require('express')
const app = express()

// Tambahkan middleware untuk parse JSON

// Buat route GET / yang return JSON { message: 'Selamat datang di API' }

// Start server di port 3000
`,
        check: { type: 'contains', patterns: ['express()'], mustContain: ['express.json()', 'app.get(', 'app.listen('], errorMsg: 'Buat app = express(), gunakan app.use(express.json()), buat route GET /, dan app.listen(3000).' },
        hint: "const app = express(); app.use(express.json()); app.get('/', (req, res) => res.json({message:'Selamat datang'})); app.listen(3000);",
        successMsg: 'Express server siap! Ini fondasi semua backend JavaScript. 🟢',
      },
      {
        id: 2,
        title: 'REST Routes CRUD',
        instruction: `## Langkah 2: Semua HTTP Methods

\`\`\`javascript
// Data sementara (nantinya dari database)
let products = [
  { id: 1, nama: 'Laptop', harga: 15000000 },
  { id: 2, nama: 'Mouse', harga: 150000 },
]

// GET /products — ambil semua
app.get('/products', (req, res) => {
  res.json({ success: true, data: products })
})

// GET /products/:id — ambil satu
app.get('/products/:id', (req, res) => {
  const product = products.find(p => p.id === parseInt(req.params.id))
  if (!product) return res.status(404).json({ error: 'Tidak ditemukan' })
  res.json({ success: true, data: product })
})

// POST /products — buat baru
app.post('/products', (req, res) => {
  const { nama, harga } = req.body
  const product = { id: products.length + 1, nama, harga }
  products.push(product)
  res.status(201).json({ success: true, data: product })
})
\`\`\`

**Tugasmu:** Buat route PUT /products/:id untuk mengupdate produk berdasarkan ID.`,
        starterCode: `let products = [
  { id: 1, nama: 'Laptop', harga: 15000000 },
]

// Buat route PUT /products/:id
// Cari product by id, update nama dan/atau harga dari req.body
// Return product yang sudah diupdate
`,
        check: { type: 'contains', patterns: ['app.put(', "app.put('"], mustContain: ['req.params.id', 'req.body', 'res.json('], errorMsg: "Buat app.put('/products/:id', ...) yang mengupdate produk." },
        hint: "app.put('/products/:id', (req, res) => { const idx = products.findIndex(p => p.id === parseInt(req.params.id)); if(idx === -1) return res.status(404).json({error:'Not found'}); products[idx] = {...products[idx], ...req.body}; res.json({success:true, data:products[idx]}); })",
        successMsg: 'CRUD lengkap: GET, POST, PUT, DELETE = 4 operasi dasar REST API! ⚙️',
      },
      {
        id: 3,
        title: 'Middleware Custom',
        instruction: `## Langkah 3: Middleware

Middleware adalah fungsi yang dijalankan sebelum route handler:

\`\`\`javascript
// Logger middleware
const logger = (req, res, next) => {
  const waktu = new Date().toISOString()
  console.log(\`[\${waktu}] \${req.method} \${req.url}\`)
  next()  // Lanjut ke middleware/route berikutnya
}

app.use(logger)  // Pakai untuk semua route

// Auth middleware
const isAuth = (req, res, next) => {
  const token = req.headers.authorization?.split(' ')[1]
  if (!token) {
    return res.status(401).json({ error: 'Token tidak ada' })
  }
  // Verifikasi token...
  req.user = { id: 1, nama: 'Budi' }  // Attach ke request
  next()
}

// Pakai hanya untuk route tertentu
app.get('/profile', isAuth, (req, res) => {
  res.json({ user: req.user })
})
\`\`\`

**Tugasmu:** Buat middleware \`validateProduct\` yang memvalidasi request body POST: nama wajib ada, harga harus angka positif.`,
        starterCode: `// Buat middleware validateProduct
// Cek: req.body.nama harus ada (minimal 3 karakter)
//       req.body.harga harus angka > 0
// Jika invalid: return 400 dengan pesan error
// Jika valid: panggil next()

// Pakai di route POST /products
`,
        check: { type: 'contains', patterns: ['const validateProduct', 'function validateProduct'], mustContain: ['next()', 'res.status(400)'], errorMsg: 'Buat function middleware validateProduct yang memanggil next() jika valid atau return 400 jika tidak valid.' },
        hint: "const validateProduct = (req, res, next) => { const {nama, harga} = req.body; if(!nama || nama.length < 3) return res.status(400).json({error:'Nama minimal 3 karakter'}); if(!harga || harga <= 0) return res.status(400).json({error:'Harga harus positif'}); next() }",
        successMsg: 'Middleware membuat validasi, auth, dan logging menjadi reusable! 🔧',
      },
      {
        id: 4,
        title: 'Error Handling',
        instruction: `## Langkah 4: Global Error Handler

\`\`\`javascript
// Error handler khusus (4 parameter)
app.use((err, req, res, next) => {
  console.error(err.stack)
  res.status(err.status || 500).json({
    error: err.message || 'Internal Server Error',
    ...(process.env.NODE_ENV === 'development' && { stack: err.stack })
  })
})

// 404 handler
app.use((req, res) => {
  res.status(404).json({ error: \`Route \${req.url} tidak ditemukan\` })
})

// Gunakan try/catch di async route
app.get('/users', async (req, res, next) => {
  try {
    const users = await User.find()
    res.json(users)
  } catch (err) {
    next(err)  // Teruskan ke error handler
  }
})
\`\`\`

**Tugasmu:** Buat global error handler dan 404 handler untuk Express app.`,
        starterCode: `const express = require('express')
const app = express()
app.use(express.json())

// Route contoh
app.get('/users', (req, res) => { res.json([{id:1}]) })

// Tambahkan 404 handler di sini

// Tambahkan global error handler (4 parameter) di sini
`,
        check: { type: 'contains', patterns: ['(err, req, res, next)'], mustContain: ['status(404)', '500'], errorMsg: 'Buat error handler dengan 4 parameter (err, req, res, next) dan 404 handler.' },
        hint: "app.use((req,res)=>res.status(404).json({error:'Not found'})); app.use((err,req,res,next)=>res.status(err.status||500).json({error:err.message}))",
        successMsg: 'Error handling yang baik = API yang profesional dan tidak crash! 🛡️',
      },
      {
        id: 5,
        title: 'JWT Authentication',
        instruction: `## Langkah 5: JWT Auth

\`\`\`javascript
const jwt = require('jsonwebtoken')
const bcrypt = require('bcryptjs')

// Register
app.post('/auth/register', async (req, res) => {
  const { nama, email, password } = req.body
  
  // Hash password sebelum simpan
  const hashedPassword = await bcrypt.hash(password, 12)
  
  // Simpan ke DB (contoh in-memory)
  const user = { id: Date.now(), nama, email, password: hashedPassword }
  
  // Buat token
  const token = jwt.sign(
    { userId: user.id, email: user.email },
    process.env.JWT_SECRET,
    { expiresIn: '7d' }
  )
  
  res.status(201).json({ user: { id: user.id, nama, email }, token })
})
\`\`\`

**Tugasmu:** Buat route POST /auth/login yang: verifikasi email+password, buat JWT token, return user + token.`,
        starterCode: `const jwt = require('jsonwebtoken')
const bcrypt = require('bcryptjs')

const users = [
  { id: 1, email: 'budi@test.com', password: '$2b$12$...' } // hashed
]

// POST /auth/login
// 1. Cari user by email
// 2. Verifikasi password dengan bcrypt.compare
// 3. Buat JWT token
// 4. Return { user, token }
app.post('/auth/login', async (req, res) => {
  // Tulis di sini
})
`,
        check: { type: 'contains', patterns: ['bcrypt.compare(', 'jwt.sign('], mustContain: ['res.json(', 'token'], errorMsg: 'Gunakan bcrypt.compare untuk verifikasi password dan jwt.sign untuk buat token.' },
        hint: "const { email, password } = req.body; const user = users.find(u => u.email === email); if(!user || !await bcrypt.compare(password, user.password)) return res.status(401).json({error:'Invalid'}); const token = jwt.sign({userId:user.id}, process.env.JWT_SECRET, {expiresIn:'7d'}); res.json({user, token})",
        successMsg: 'JWT auth adalah standar industri untuk REST API! Keamanan terjamin. 🔐',
        isFinal: true,
      },
    ],
  },

  // ================================================================
  // 8. REACT.JS WORKSHOP
  // ================================================================
  {
    id: 'react-dasar',
    title: 'React.js: Component & Hooks Modern',
    slug: 'react-dasar',
    icon: '⚛️',
    lang: 'javascript',
    category: 'Frontend',
    color: 'from-sky-400 to-cyan-500',
    level: 'Intermediate',
    xp: 220,
    desc: 'Pelajari React.js dari component dasar, useState, useEffect, hingga custom hooks.',
    steps: [
      {
        id: 1,
        title: 'Komponen Pertama',
        instruction: `## Langkah 1: Function Component

React membangun UI dari komponen-komponen kecil yang reusable:

\`\`\`jsx
// Komponen sederhana
function Salam({ nama }) {
  return (
    <div className="card">
      <h1>Halo, {nama}!</h1>
      <p>Selamat datang di React.</p>
    </div>
  )
}

// Penggunaan
function App() {
  return (
    <div>
      <Salam nama="Budi" />
      <Salam nama="Siti" />
    </div>
  )
}

export default App
\`\`\`

**Tugasmu:** Buat komponen \`KartuProfil\` yang menerima props \`nama\`, \`jabatan\`, dan \`xp\`, lalu render semuanya.`,
        starterCode: `// Buat komponen KartuProfil
// Props: nama (string), jabatan (string), xp (number)
// Render semuanya dalam sebuah div

function KartuProfil({ nama, jabatan, xp }) {
  // return JSX di sini
}

// Contoh penggunaan:
// <KartuProfil nama="Budi" jabatan="Frontend Dev" xp={1500} />
`,
        check: { type: 'contains', patterns: ['function KartuProfil', 'const KartuProfil'], mustContain: ['return (', 'nama', 'jabatan', 'xp'], errorMsg: 'Buat function KartuProfil yang me-render nama, jabatan, dan xp.' },
        hint: 'function KartuProfil({ nama, jabatan, xp }) { return (<div><h2>{nama}</h2><p>{jabatan}</p><span>{xp} XP</span></div>) }',
        successMsg: 'Komponen React = blok bangunan UI yang reusable! ⚛️',
      },
      {
        id: 2,
        title: 'useState — Interaktivitas',
        instruction: `## Langkah 2: useState

useState menyimpan state (data yang bisa berubah) di komponen:

\`\`\`jsx
import { useState } from 'react'

function Counter() {
  const [count, setCount] = useState(0)  // [nilai, setter]

  return (
    <div>
      <p>Count: {count}</p>
      <button onClick={() => setCount(count + 1)}>+1</button>
      <button onClick={() => setCount(count - 1)}>-1</button>
      <button onClick={() => setCount(0)}>Reset</button>
    </div>
  )
}
\`\`\`

**Tugasmu:** Buat komponen \`TodoInput\` dengan state \`teks\` yang diperbarui setiap pengguna mengetik di input, dan tombol untuk clear.`,
        starterCode: `import { useState } from 'react'

function TodoInput() {
  // Buat state 'teks' dengan nilai awal string kosong
  
  return (
    <div>
      <input
        value={/* state teks */}
        onChange={/* update state */}
        placeholder="Ketik todo..."
      />
      <p>Kamu mengetik: {/* tampilkan teks */}</p>
      <button onClick={/* set teks ke '' */}>Clear</button>
    </div>
  )
}
`,
        check: { type: 'contains', patterns: ['useState('], mustContain: ['onChange', 'onClick', 'setTeks', 'setText'], errorMsg: 'Buat const [teks, setTeks] = useState("") dan hubungkan ke input onChange dan button onClick.' },
        hint: "const [teks, setTeks] = useState(''); onChange={e => setTeks(e.target.value)} onClick={() => setTeks('')}",
        successMsg: 'useState membuat komponen React menjadi interaktif! 🎮',
      },
      {
        id: 3,
        title: 'useEffect — Data Fetching',
        instruction: `## Langkah 3: useEffect

useEffect menjalankan kode setelah render (side effects):

\`\`\`jsx
import { useState, useEffect } from 'react'

function UserProfile({ userId }) {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    setLoading(true)
    fetch(\`https://jsonplaceholder.typicode.com/users/\${userId}\`)
      .then(r => r.json())
      .then(data => { setUser(data); setLoading(false) })
      .catch(err => { setError(err.message); setLoading(false) })
  }, [userId])  // re-run jika userId berubah

  if (loading) return <p>Loading...</p>
  if (error)   return <p>Error: {error}</p>
  return <h2>{user?.name}</h2>
}
\`\`\`

**Tugasmu:** Buat komponen \`PostList\` yang fetch dari https://jsonplaceholder.typicode.com/posts?_limit=5 dan tampilkan judul setiap post.`,
        starterCode: `import { useState, useEffect } from 'react'

function PostList() {
  const [posts, setPosts] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Fetch posts dari jsonplaceholder, limit 5
    // Set posts dan loading
  }, [])  // dependency array kosong = run sekali saat mount

  if (loading) return <p>Loading posts...</p>

  return (
    <ul>
      {/* Map posts dan tampilkan title */}
    </ul>
  )
}
`,
        check: { type: 'contains', patterns: ['useEffect('], mustContain: ['fetch(', 'setPosts(', 'setLoading('], errorMsg: 'Di dalam useEffect, fetch data lalu setPosts dengan hasilnya dan setLoading(false).' },
        hint: "useEffect(() => { fetch('https://jsonplaceholder.typicode.com/posts?_limit=5').then(r=>r.json()).then(data=>{setPosts(data);setLoading(false)}) }, [])",
        successMsg: 'useEffect + fetch = pattern paling umum di React untuk load data! 📡',
      },
      {
        id: 4,
        title: 'Event Handling & Forms',
        instruction: `## Langkah 4: Controlled Form

\`\`\`jsx
import { useState } from 'react'

function LoginForm() {
  const [form, setForm] = useState({ email: '', password: '' })
  const [errors, setErrors] = useState({})

  const handleChange = (e) => {
    const { name, value } = e.target
    setForm(prev => ({ ...prev, [name]: value }))
  }

  const handleSubmit = (e) => {
    e.preventDefault()  // Prevent reload halaman
    
    // Validasi
    const newErrors = {}
    if (!form.email.includes('@')) newErrors.email = 'Email tidak valid'
    if (form.password.length < 6) newErrors.password = 'Min 6 karakter'
    
    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors); return
    }
    
    console.log('Submit:', form)
  }

  return (
    <form onSubmit={handleSubmit}>
      <input name="email" value={form.email} onChange={handleChange} />
      {errors.email && <span className="error">{errors.email}</span>}
      <button type="submit">Login</button>
    </form>
  )
}
\`\`\`

**Tugasmu:** Buat form registrasi dengan state untuk nama, email, password. Validasi: semua wajib diisi, password min 6 karakter.`,
        starterCode: `import { useState } from 'react'

function RegisterForm() {
  const [form, setForm] = useState({ nama: '', email: '', password: '' })
  const [errors, setErrors] = useState({})

  const handleChange = (e) => {
    // Update state form berdasarkan name dan value
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    // Validasi semua field wajib diisi, password min 6 char
    // Jika valid, console.log(form)
  }

  return (
    <form onSubmit={handleSubmit}>
      {/* Input nama, email, password */}
      {/* Tampilkan errors */}
      <button type="submit">Daftar</button>
    </form>
  )
}
`,
        check: { type: 'contains', patterns: ['handleSubmit', 'handleChange'], mustContain: ['e.preventDefault()', 'setForm', 'setErrors'], errorMsg: 'Buat handleChange untuk update form state, handleSubmit dengan preventDefault dan validasi.' },
        hint: "const handleChange = (e) => { setForm(p => ({...p, [e.target.name]: e.target.value})) }; handleSubmit: e.preventDefault(), validasi, setErrors",
        successMsg: 'Controlled form + validasi = pattern standar form di React! 📝',
      },
      {
        id: 5,
        title: 'Custom Hook',
        instruction: `## Langkah 5: Custom Hooks

Custom hooks mengekstrak logika yang bisa di-reuse:

\`\`\`jsx
// Custom hook useFetch
function useFetch(url) {
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    if (!url) return
    setLoading(true)
    setError(null)
    
    fetch(url)
      .then(r => {
        if (!r.ok) throw new Error(\`HTTP \${r.status}\`)
        return r.json()
      })
      .then(data => { setData(data); setLoading(false) })
      .catch(err => { setError(err.message); setLoading(false) })
  }, [url])

  return { data, loading, error }
}

// Pakai di komponen apapun!
function Posts() {
  const { data, loading, error } = useFetch('/api/posts')
  if (loading) return <p>Loading...</p>
  return <ul>{data?.map(p => <li key={p.id}>{p.title}</li>)}</ul>
}
\`\`\`

**Tugasmu:** Buat custom hook \`useLocalStorage(key, defaultValue)\` yang sync state ke localStorage.`,
        starterCode: `import { useState, useEffect } from 'react'

function useLocalStorage(key, defaultValue) {
  // 1. Init state: ambil dari localStorage jika ada, else defaultValue
  const [value, setValue] = useState(() => {
    // Coba ambil dari localStorage
    // Return defaultValue jika tidak ada
  })

  // 2. Sync ke localStorage setiap value berubah
  useEffect(() => {
    // localStorage.setItem(key, JSON.stringify(value))
  }, [key, value])

  return [value, setValue]
}

// Contoh penggunaan:
// const [nama, setNama] = useLocalStorage('nama', 'Guest')
`,
        check: { type: 'contains', patterns: ['function useLocalStorage', 'const useLocalStorage'], mustContain: ['localStorage', 'useState(', 'useEffect('], errorMsg: 'Buat useLocalStorage dengan useState (init dari localStorage) dan useEffect (sync ke localStorage).' },
        hint: "const [value, setValue] = useState(() => { try { const item = localStorage.getItem(key); return item ? JSON.parse(item) : defaultValue } catch { return defaultValue } }); useEffect(() => { localStorage.setItem(key, JSON.stringify(value)) }, [key, value]); return [value, setValue]",
        successMsg: '🎊 Custom hook mengubah logika menjadi reusable! Ini pattern terpenting di React modern!',
        isFinal: true,
      },
    ],
  },

  // ================================================================
  // 9. JAVA FUNDAMENTAL
  // ================================================================
  {
    id: 'java-dasar',
    title: 'Java: OOP & Pemrograman Objek',
    slug: 'java-dasar',
    icon: '☕',
    lang: 'java',
    category: 'Programming',
    color: 'from-orange-500 to-red-600',
    level: 'Intermediate',
    xp: 220,
    desc: 'Belajar Java dari variabel, OOP, inheritance, interface, hingga collections.',
    steps: [
      {
        id: 1,
        title: 'Hello World & Variabel',
        instruction: `## Langkah 1: Hello World Java

Java adalah bahasa strongly-typed. Setiap variabel WAJIB dideklarasikan tipe datanya:

\`\`\`java
public class Main {
    public static void main(String[] args) {
        // Tipe data primitif
        int umur = 17;
        double nilai = 87.5;
        boolean lulus = true;
        char grade = 'A';
        
        // String (bukan primitif, ini objek)
        String nama = "Budi";
        
        // Output
        System.out.println("Halo, " + nama + "!");
        System.out.printf("Umur: %d, Nilai: %.1f%n", umur, nilai);
    }
}
\`\`\`

**Tugasmu:** Buat class Main dengan method main, deklarasikan variabel nama (String), umur (int), dan nilaiRata (double), lalu cetak ketiganya.`,
        starterCode: `public class Main {
    public static void main(String[] args) {
        // Deklarasikan: nama (String), umur (int), nilaiRata (double)
        
        // Cetak ketiga variabel
    }
}`,
        check: { type: 'contains', patterns: ['String nama'], mustContain: ['int umur', 'double', 'System.out.println'], errorMsg: 'Deklarasikan String nama, int umur, double nilaiRata, lalu System.out.println.' },
        hint: 'String nama = "Alice"; int umur = 17; double nilaiRata = 88.5; System.out.println(nama + " " + umur + " " + nilaiRata);',
        successMsg: 'Java strongly-typed — tipe data wajib dideklarasikan eksplisit! ☕',
      },
      {
        id: 2,
        title: 'Class & Object',
        instruction: `## Langkah 2: Class dan Object

Class adalah blueprint, object adalah instance-nya:

\`\`\`java
public class Siswa {
    // Field (atribut)
    String nama;
    int umur;
    double[] nilai;
    
    // Constructor
    public Siswa(String nama, int umur) {
        this.nama = nama;
        this.umur = umur;
        this.nilai = new double[]{};
    }
    
    // Method
    public double hitungRata() {
        double total = 0;
        for (double n : nilai) total += n;
        return nilai.length > 0 ? total / nilai.length : 0;
    }
    
    public String toString() {
        return nama + " (umur " + umur + ")";
    }
}

// Penggunaan
Siswa s = new Siswa("Budi", 17);
System.out.println(s);
\`\`\`

**Tugasmu:** Buat class \`Buku\` dengan field judul (String), penulis (String), harga (double). Buat constructor dan method \`getInfo()\` yang return String deskripsi buku.`,
        starterCode: `public class Buku {
    // Deklarasikan field: judul, penulis, harga
    
    // Constructor
    
    // Method getInfo() - return String deskripsi
    
    public static void main(String[] args) {
        Buku b = new Buku("Clean Code", "Robert Martin", 150000);
        System.out.println(b.getInfo());
    }
}`,
        check: { type: 'contains', patterns: ['class Buku'], mustContain: ['String judul', 'String penulis', 'double harga', 'getInfo'], errorMsg: 'Buat class Buku dengan field String judul, String penulis, double harga, dan method getInfo().' },
        hint: 'public Buku(String judul, String penulis, double harga) { this.judul=judul; this.penulis=penulis; this.harga=harga; } public String getInfo() { return judul + " by " + penulis + " - Rp" + harga; }',
        successMsg: 'OOP adalah inti Java! Class, object, field, method — ini fondasi segalanya. ☕',
      },
      {
        id: 3,
        title: 'Inheritance & Override',
        instruction: `## Langkah 3: Inheritance

Inheritance memungkinkan class mewarisi sifat class lain:

\`\`\`java
// Parent class
public class Hewan {
    String nama;
    
    public Hewan(String nama) {
        this.nama = nama;
    }
    
    public void bersuara() {
        System.out.println(nama + " bersuara...");
    }
    
    public String toString() {
        return "Hewan: " + nama;
    }
}

// Child class
public class Anjing extends Hewan {
    String ras;
    
    public Anjing(String nama, String ras) {
        super(nama);  // Panggil constructor parent
        this.ras = ras;
    }
    
    @Override
    public void bersuara() {
        System.out.println(nama + " berkata: Guk guk!");
    }
}
\`\`\`

**Tugasmu:** Buat class \`Kendaraan\` dengan field merk dan kecepatan, lalu class \`Mobil extends Kendaraan\` dengan field jumlahPintu dan override method \`info()\`.`,
        starterCode: `public class Kendaraan {
    String merk;
    int kecepatan;
    
    public Kendaraan(String merk, int kecepatan) {
        this.merk = merk;
        this.kecepatan = kecepatan;
    }
    
    public String info() {
        return merk + " - " + kecepatan + " km/h";
    }
}

// Buat class Mobil extends Kendaraan
// Tambah field: int jumlahPintu
// Override method info() - tambahkan jumlahPintu`,
        check: { type: 'contains', patterns: ['extends Kendaraan'], mustContain: ['@Override', 'super(', 'jumlahPintu'], errorMsg: 'Buat class Mobil extends Kendaraan dengan @Override method info() dan super() di constructor.' },
        hint: 'class Mobil extends Kendaraan { int jumlahPintu; public Mobil(String merk, int kecepatan, int pintu) { super(merk, kecepatan); this.jumlahPintu = pintu; } @Override public String info() { return super.info() + " - " + jumlahPintu + " pintu"; } }',
        successMsg: 'Inheritance + @Override = polimorfisme Java! Kode jadi DRY dan extensible. ☕',
      },
      {
        id: 4,
        title: 'Interface',
        instruction: `## Langkah 4: Interface

Interface mendefinisikan kontrak yang harus dipenuhi class:

\`\`\`java
// Interface = kontrak perilaku
public interface Drawable {
    void draw();           // abstract method (wajib diimplementasi)
    default void show() {  // default method (boleh tidak di-override)
        System.out.println("Menampilkan: " + getClass().getSimpleName());
    }
}

public interface Resizable {
    void resize(double factor);
}

// Class bisa implement multiple interface
public class Circle implements Drawable, Resizable {
    double radius;
    
    @Override
    public void draw() {
        System.out.println("Menggambar lingkaran r=" + radius);
    }
    
    @Override
    public void resize(double factor) {
        this.radius *= factor;
    }
}
\`\`\`

**Tugasmu:** Buat interface \`Shapeable\` dengan method \`luas()\` dan \`keliling()\`. Implementasi di class \`Persegi\` dengan field sisi.`,
        starterCode: `// Buat interface Shapeable
// dengan method: double luas() dan double keliling()

// Implementasi di class Persegi implements Shapeable
// Field: double sisi

public class Main {
    public static void main(String[] args) {
        Persegi p = new Persegi(5.0);
        System.out.println("Luas: " + p.luas());
        System.out.println("Keliling: " + p.keliling());
    }
}`,
        check: { type: 'contains', patterns: ['interface Shapeable'], mustContain: ['implements Shapeable', 'luas()', 'keliling()'], errorMsg: 'Buat interface Shapeable lalu class Persegi implements Shapeable dengan kedua method.' },
        hint: 'interface Shapeable { double luas(); double keliling(); } class Persegi implements Shapeable { double sisi; public Persegi(double s) { sisi=s; } public double luas() { return sisi*sisi; } public double keliling() { return 4*sisi; } }',
        successMsg: 'Interface = kontrak yang fleksibel! Java bisa implement banyak interface. ☕',
      },
      {
        id: 5,
        title: 'ArrayList & Collections',
        instruction: `## Langkah 5: ArrayList dan Collections

\`\`\`java
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

List<String> bahasa = new ArrayList<>();

// Tambah elemen
bahasa.add("Java");
bahasa.add("Python");
bahasa.add("Go");

// Akses
System.out.println(bahasa.get(0));  // Java
System.out.println(bahasa.size());  // 3

// Loop
for (String b : bahasa) {
    System.out.println(b);
}

// Sort
Collections.sort(bahasa);

// Remove
bahasa.remove("Go");

// Stream (Java 8+)
bahasa.stream()
    .filter(b -> b.startsWith("J"))
    .forEach(System.out::println);
\`\`\`

**Tugasmu:** Buat ArrayList angka berisi 5 Integer, hitung totalnya dengan stream, lalu sort dan tampilkan.`,
        starterCode: `import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        List<Integer> angka = new ArrayList<>();
        // Tambahkan 5 angka
        
        // Hitung total dengan stream().mapToInt().sum()
        
        // Sort ascending
        
        // Tampilkan semua
    }
}`,
        check: { type: 'contains', patterns: ['ArrayList<'], mustContain: ['stream()', 'Collections.sort(', '.add('], errorMsg: 'Gunakan ArrayList, stream().mapToInt().sum() untuk total, Collections.sort() untuk sort.' },
        hint: 'angka.add(10); angka.add(5); ... int total = angka.stream().mapToInt(Integer::intValue).sum(); Collections.sort(angka); angka.forEach(System.out::println);',
        successMsg: 'Java Collections + Stream API = powerful data processing! ☕',
        isFinal: true,
      },
    ],
  },

  // ================================================================
  // 10. PHP WORKSHOP
  // ================================================================
  {
    id: 'php-dasar',
    title: 'PHP: Web Backend dari Nol',
    slug: 'php-dasar',
    icon: '🐘',
    lang: 'php',
    category: 'Backend',
    color: 'from-indigo-500 to-violet-600',
    level: 'Beginner',
    xp: 180,
    desc: 'Belajar PHP dari sintaks dasar, array, fungsi, OOP, hingga koneksi ke database.',
    steps: [
      {
        id: 1,
        title: 'Variabel & Output PHP',
        instruction: `## Langkah 1: PHP Dasar

PHP diawali dengan tag \`<?php\` dan variabel selalu diawali \`$\`:

\`\`\`php
<?php
$nama = "Budi";
$umur = 17;
$nilai = 88.5;
$lulus = true;

// Output
echo "Halo, $nama!\n";
echo "Umur: " . $umur . " tahun\n";
printf("Nilai: %.1f\n", $nilai);

// var_dump untuk debug
var_dump($lulus);  // bool(true)
var_dump($nilai);  // float(88.5)
?>
\`\`\`

**Tugasmu:** Buat variabel $nama, $kota, dan $saldo (float), lalu tampilkan ketiganya dengan echo.`,
        starterCode: `<?php
// Buat variabel $nama (string), $kota (string), $saldo (float)

// Tampilkan ketiganya dengan echo

?>`,
        check: { type: 'contains', patterns: ['$nama'], mustContain: ['$kota', '$saldo', 'echo'], errorMsg: 'Buat $nama, $kota, $saldo lalu echo ketiga variabel tersebut.' },
        hint: '$nama = "Budi"; $kota = "Jakarta"; $saldo = 1500000.50; echo "Nama: $nama, Kota: $kota, Saldo: $saldo";',
        successMsg: 'PHP variabel selalu diawali $ — mudah dibedakan dari teks biasa! 🐘',
      },
      {
        id: 2,
        title: 'Array PHP',
        instruction: `## Langkah 2: Array di PHP

PHP punya array yang fleksibel — bisa indexed, associative, atau multidimensional:

\`\`\`php
<?php
// Indexed array
$buah = ["apel", "mangga", "jeruk"];
echo $buah[0];  // apel
echo count($buah);  // 3

// Associative array (seperti object JS)
$siswa = [
    "nama" => "Budi",
    "umur" => 17,
    "nilai" => 88.5,
];
echo $siswa["nama"];  // Budi

// Tambah elemen
$buah[] = "anggur";  // push ke akhir
$siswa["kelas"] = "XI IPA";  // tambah key baru

// Loop
foreach ($buah as $b) {
    echo $b . "\n";
}

foreach ($siswa as $key => $val) {
    echo "$key: $val\n";
}
?>
\`\`\`

**Tugasmu:** Buat associative array \$produk dengan key: nama, harga, stok. Lalu tampilkan setiap key-value dengan foreach.`,
        starterCode: `<?php
// Buat associative array $produk
// Key: nama (string), harga (float), stok (int)

// Tampilkan setiap key-value dengan foreach

?>`,
        check: { type: 'contains', patterns: ['$produk = [', '$produk=['], mustContain: ['=>', 'foreach'], errorMsg: 'Buat $produk = ["nama" => "...", "harga" => ..., "stok" => ...] lalu foreach.' },
        hint: '$produk = ["nama" => "Laptop", "harga" => 15000000, "stok" => 5]; foreach ($produk as $k => $v) { echo "$k: $v\n"; }',
        successMsg: 'Array PHP sangat fleksibel — bisa indexed dan associative sekaligus! 🐘',
      },
      {
        id: 3,
        title: 'Fungsi PHP',
        instruction: `## Langkah 3: Function di PHP

\`\`\`php
<?php
// Function dasar
function sapa($nama, $salam = "Halo") {
    return "$salam, $nama!";
}

echo sapa("Budi");          // Halo, Budi!
echo sapa("Siti", "Selamat pagi");  // Selamat pagi, Siti!

// Arrow function (PHP 7.4+)
$kali = fn($a, $b) => $a * $b;
echo $kali(3, 4);  // 12

// Built-in string functions
$teks = "  Hello World  ";
echo trim($teks);           // "Hello World"
echo strtoupper($teks);     // "  HELLO WORLD  "
echo str_replace("World", "PHP", $teks);  // "  Hello PHP  "
echo strlen(trim($teks));   // 11
?>
\`\`\`

**Tugasmu:** Buat function \`hitungDiskon($harga, $persen)\` yang mengembalikan harga setelah diskon, lalu test dengan beberapa nilai.`,
        starterCode: `<?php
// Buat function hitungDiskon($harga, $persen)
// Return: harga - (harga * persen / 100)

// Test:
// echo hitungDiskon(100000, 20);  // 80000
// echo hitungDiskon(500000, 10);  // 450000

?>`,
        check: { type: 'contains', patterns: ['function hitungDiskon('], mustContain: ['return', '$harga', '$persen'], errorMsg: 'Buat function hitungDiskon($harga, $persen) { return $harga - ($harga * $persen / 100); }' },
        hint: 'function hitungDiskon($harga, $persen) { return $harga - ($harga * $persen / 100); }',
        successMsg: 'Function PHP mendukung default parameter — sama seperti JavaScript modern! 🐘',
      },
      {
        id: 4,
        title: 'Class & OOP PHP',
        instruction: `## Langkah 4: OOP di PHP

\`\`\`php
<?php
class Produk {
    private string $nama;
    private float $harga;
    private int $stok;
    
    public function __construct(string $nama, float $harga, int $stok = 0) {
        $this->nama  = $nama;
        $this->harga = $harga;
        $this->stok  = $stok;
    }
    
    // Getter
    public function getNama(): string  { return $this->nama; }
    public function getHarga(): float  { return $this->harga; }
    
    // Method
    public function beli(int $jumlah): bool {
        if ($this->stok < $jumlah) return false;
        $this->stok -= $jumlah;
        return true;
    }
    
    public function __toString(): string {
        return "{$this->nama} - Rp{$this->harga} (stok: {$this->stok})";
    }
}

$p = new Produk("Laptop", 15000000, 10);
echo $p;            // Laptop - Rp15000000 (stok: 10)
$p->beli(3);
echo $p;            // ... (stok: 7)
?>
\`\`\`

**Tugasmu:** Buat class \`BankAccount\` dengan field balance (private), method deposit(), withdraw() (return false jika balance kurang), dan getBalance().`,
        starterCode: `<?php
class BankAccount {
    private float $balance;
    
    public function __construct(float $initialBalance = 0) {
        $this->balance = $initialBalance;
    }
    
    // Buat method deposit($amount)
    
    // Buat method withdraw($amount) - return false jika tidak cukup
    
    // Buat method getBalance() - return balance saat ini
}

$acc = new BankAccount(100000);
$acc->deposit(50000);   // balance = 150000
$acc->withdraw(30000);  // balance = 120000
echo $acc->getBalance(); // 120000
?>`,
        check: { type: 'contains', patterns: ['function deposit(', 'function withdraw('], mustContain: ['$this->balance', 'function getBalance('], errorMsg: 'Buat method deposit, withdraw (dengan cek saldo), dan getBalance.' },
        hint: 'public function deposit($a) { $this->balance += $a; } public function withdraw($a) { if ($a > $this->balance) return false; $this->balance -= $a; return true; } public function getBalance() { return $this->balance; }',
        successMsg: 'OOP PHP modern pakai type hints dan visibility modifier — mirip Java! 🐘',
        isFinal: true,
      },
    ],
  },

  // ================================================================
  // 11. C++ WORKSHOP
  // ================================================================
  {
    id: 'cpp-dasar',
    title: 'C++: Pemrograman Sistem & Algoritma',
    slug: 'cpp-dasar',
    icon: '⚙️',
    lang: 'cpp',
    category: 'Programming',
    color: 'from-blue-600 to-blue-800',
    level: 'Intermediate',
    xp: 250,
    desc: 'Kuasai C++ dari pointer, struct, OOP, STL, hingga algoritma dan memori management.',
    steps: [
      {
        id: 1,
        title: 'Hello World & Tipe Data',
        instruction: `## Langkah 1: C++ Dasar

C++ adalah bahasa low-level yang cepat, dipakai di game engine, OS, embedded system:

\`\`\`cpp
#include <iostream>
#include <string>
using namespace std;

int main() {
    // Tipe data
    int    umur    = 17;
    double nilai   = 88.5;
    bool   lulus   = true;
    char   grade   = 'A';
    string nama    = "Budi";
    
    // Output
    cout << "Halo, " << nama << "!" << endl;
    cout << "Umur: " << umur << " tahun" << endl;
    printf("Nilai: %.1f\n", nilai);
    
    return 0;
}
\`\`\`

**Tugasmu:** Buat program C++ yang mendeklarasikan string nama, int umur, double ipk, lalu tampilkan ketiganya dengan cout.`,
        starterCode: `#include <iostream>
#include <string>
using namespace std;

int main() {
    // Deklarasikan: string nama, int umur, double ipk
    
    // Tampilkan dengan cout
    
    return 0;
}`,
        check: { type: 'contains', patterns: ['string nama', 'string  nama'], mustContain: ['int umur', 'double ipk', 'cout'], errorMsg: 'Deklarasikan string nama, int umur, double ipk lalu cout ketiganya.' },
        hint: 'string nama = "Budi"; int umur = 17; double ipk = 3.85; cout << nama << " " << umur << " " << ipk << endl;',
        successMsg: 'C++ = kecepatan C + OOP! Dipakai di Unreal Engine, Chrome V8, MySQL. ⚡',
      },
      {
        id: 2,
        title: 'Pointer & Reference',
        instruction: `## Langkah 2: Pointer — Fitur Unik C++

Pointer menyimpan ALAMAT memori variabel, bukan nilainya:

\`\`\`cpp
#include <iostream>
using namespace std;

int main() {
    int x = 42;
    
    int* ptr = &x;     // ptr = alamat memori x
    
    cout << x;         // 42       (nilai)
    cout << &x;        // 0x7fff.. (alamat)
    cout << ptr;       // 0x7fff.. (alamat yang disimpan ptr)
    cout << *ptr;      // 42       (dereferencing = ambil nilai)
    
    *ptr = 100;        // ubah nilai x melalui pointer
    cout << x;         // 100
    
    // Reference (alias)
    int& ref = x;
    ref = 200;         // sama seperti x = 200
    cout << x;         // 200
    
    return 0;
}
\`\`\`

**Tugasmu:** Buat fungsi \`swap\` yang menukar nilai dua variabel menggunakan pointer (bukan return value).`,
        starterCode: `#include <iostream>
using namespace std;

// Buat fungsi swap yang menerima dua pointer int
// dan menukar nilai yang ditunjuk

void swap(int* a, int* b) {
    // Tukar *a dan *b menggunakan temporary variable
}

int main() {
    int x = 10, y = 20;
    swap(&x, &y);
    cout << "x=" << x << " y=" << y << endl;  // x=20 y=10
    return 0;
}`,
        check: { type: 'contains', patterns: ['void swap(int*', 'void swap( int*'], mustContain: ['*a', '*b', 'int temp'], errorMsg: 'Di dalam swap, gunakan int temp = *a; *a = *b; *b = temp;' },
        hint: 'void swap(int* a, int* b) { int temp = *a; *a = *b; *b = temp; }',
        successMsg: 'Pointer adalah konsep paling penting di C/C++! Pahami ini, pahami memory. 🧠',
      },
      {
        id: 3,
        title: 'Struct & Class C++',
        instruction: `## Langkah 3: Struct dan Class

\`\`\`cpp
#include <iostream>
#include <string>
using namespace std;

// Struct (default public)
struct Point {
    double x, y;
    
    double distanceTo(Point other) {
        double dx = x - other.x;
        double dy = y - other.y;
        return sqrt(dx*dx + dy*dy);
    }
};

// Class (default private)
class Siswa {
private:
    string nama;
    int umur;
    
public:
    Siswa(string n, int u) : nama(n), umur(u) {}
    
    string getNama() const { return nama; }
    int getUmur() const { return umur; }
    
    void tampilkan() const {
        cout << nama << " (" << umur << " tahun)" << endl;
    }
};
\`\`\`

**Tugasmu:** Buat struct \`Mahasiswa\` dengan field nim (string), nama (string), ipk (double), dan method \`tampilkan()\`.`,
        starterCode: `#include <iostream>
#include <string>
using namespace std;

// Buat struct Mahasiswa dengan field nim, nama, ipk
// dan method tampilkan()

int main() {
    Mahasiswa m;
    m.nim = "2024001";
    m.nama = "Budi Santoso";
    m.ipk = 3.85;
    m.tampilkan();
    // Output: [2024001] Budi Santoso - IPK: 3.85
    return 0;
}`,
        check: { type: 'contains', patterns: ['struct Mahasiswa'], mustContain: ['string nim', 'string nama', 'double ipk', 'tampilkan'], errorMsg: 'Buat struct Mahasiswa dengan string nim, string nama, double ipk, dan void tampilkan().' },
        hint: 'struct Mahasiswa { string nim; string nama; double ipk; void tampilkan() { cout << "[" << nim << "] " << nama << " - IPK: " << ipk << endl; } };',
        successMsg: 'C++ struct dan class hampir sama — bedanya hanya default access modifier! ⚡',
      },
      {
        id: 4,
        title: 'STL: Vector & Algorithm',
        instruction: `## Langkah 4: STL — Standard Template Library

STL menyediakan data structure dan algoritma siap pakai:

\`\`\`cpp
#include <iostream>
#include <vector>
#include <algorithm>
#include <numeric>
using namespace std;

int main() {
    vector<int> angka = {64, 34, 25, 12, 22};
    
    // Sort ascending
    sort(angka.begin(), angka.end());
    
    // Sort descending
    sort(angka.begin(), angka.end(), greater<int>());
    
    // Total
    int total = accumulate(angka.begin(), angka.end(), 0);
    
    // Find
    auto it = find(angka.begin(), angka.end(), 25);
    if (it != angka.end()) cout << "Ketemu di index " << (it - angka.begin());
    
    // Lambda sort
    vector<string> kata = {"banana", "apple", "cherry"};
    sort(kata.begin(), kata.end(), [](const string& a, const string& b) {
        return a.length() < b.length();
    });
    
    return 0;
}
\`\`\`

**Tugasmu:** Buat vector nilai berisi 6 double, hitung rata-rata dengan accumulate, sort ascending, lalu tampilkan semua.`,
        starterCode: `#include <iostream>
#include <vector>
#include <algorithm>
#include <numeric>
using namespace std;

int main() {
    vector<double> nilai = {85.0, 72.5, 90.0, 68.0, 88.5, 76.0};
    
    // Hitung rata-rata dengan accumulate
    
    // Sort ascending
    
    // Tampilkan semua nilai dan rata-rata
    
    return 0;
}`,
        check: { type: 'contains', patterns: ['accumulate('], mustContain: ['sort(', 'begin()', 'cout'], errorMsg: 'Gunakan accumulate() untuk total, sort() untuk urutan, lalu cout.' },
        hint: 'double total = accumulate(nilai.begin(), nilai.end(), 0.0); double rata = total/nilai.size(); sort(nilai.begin(), nilai.end()); for(double n: nilai) cout << n << " "; cout << "\nRata: " << rata;',
        successMsg: 'STL adalah kekuatan terbesar C++! sort(), find(), accumulate() sudah dioptimasi. ⚡',
        isFinal: true,
      },
    ],
  },

  // ================================================================
  // 12. GO WORKSHOP
  // ================================================================
  {
    id: 'go-dasar',
    title: 'Go: Backend yang Cepat & Concurrent',
    slug: 'go-dasar',
    icon: '🔵',
    lang: 'go',
    category: 'Backend',
    color: 'from-cyan-500 to-teal-600',
    level: 'Intermediate',
    xp: 220,
    desc: 'Belajar Go dari sintaks, goroutine, channel, hingga build REST API performant.',
    steps: [
      {
        id: 1,
        title: 'Hello World & Variabel Go',
        instruction: `## Langkah 1: Go — Simple & Fast

Go (Golang) dibuat Google. Terkenal karena cepat, sederhana, dan concurrency built-in:

\`\`\`go
package main

import (
    "fmt"
    "strings"
)

func main() {
    // Deklarasi variabel
    nama := "Budi"          // short declaration (type inference)
    var umur int = 17        // explicit type
    var nilai float64 = 88.5
    
    // Multiple assignment
    x, y := 10, 20
    
    // Swap
    x, y = y, x
    
    fmt.Println("Halo,", nama)
    fmt.Printf("Umur: %d, Nilai: %.1f\n", umur, nilai)
    fmt.Printf("x=%d, y=%d\n", x, y)
    
    upper := strings.ToUpper(nama)
    fmt.Println(upper)
}
\`\`\`

**Tugasmu:** Buat program Go dengan variabel nama (string), umur (int), gaji (float64) menggunakan := lalu fmt.Printf semuanya.`,
        starterCode: `package main

import "fmt"

func main() {
    // Deklarasikan nama, umur, gaji menggunakan :=
    
    // Tampilkan dengan fmt.Printf
}`,
        check: { type: 'contains', patterns: ['nama :='], mustContain: ['umur :=', 'gaji :=', 'fmt.Printf'], errorMsg: 'Gunakan := untuk deklarasi nama, umur, gaji lalu fmt.Printf.' },
        hint: 'nama := "Budi"; umur := 17; gaji := 5000000.0; fmt.Printf("Nama: %s, Umur: %d, Gaji: %.0f\n", nama, umur, gaji)',
        successMsg: 'Go := adalah cara paling idiomatik untuk deklarasi variabel! 🔵',
      },
      {
        id: 2,
        title: 'Function & Multiple Return',
        instruction: `## Langkah 2: Function Go

Go mendukung multiple return values — fitur yang sangat berguna untuk error handling:

\`\`\`go
package main

import (
    "errors"
    "fmt"
)

// Function dengan multiple return
func bagi(a, b float64) (float64, error) {
    if b == 0 {
        return 0, errors.New("tidak bisa bagi dengan nol")
    }
    return a / b, nil
}

// Named return values
func minMax(arr []int) (min, max int) {
    min, max = arr[0], arr[0]
    for _, v := range arr {
        if v < min { min = v }
        if v > max { max = v }
    }
    return  // naked return
}

func main() {
    hasil, err := bagi(10, 3)
    if err != nil {
        fmt.Println("Error:", err)
    } else {
        fmt.Printf("10/3 = %.2f\n", hasil)
    }
    
    min, max := minMax([]int{3,1,4,1,5,9,2,6})
    fmt.Printf("Min=%d, Max=%d\n", min, max)
}
\`\`\`

**Tugasmu:** Buat function \`hitungLuas(panjang, lebar float64) (float64, error)\` yang return error jika panjang atau lebar <= 0.`,
        starterCode: `package main

import (
    "errors"
    "fmt"
)

// Buat function hitungLuas(panjang, lebar float64) (float64, error)
// Return error jika panjang <= 0 atau lebar <= 0

func main() {
    luas, err := hitungLuas(5.0, 3.0)
    if err != nil {
        fmt.Println("Error:", err)
    } else {
        fmt.Printf("Luas: %.2f\n", luas)
    }
    
    _, err2 := hitungLuas(-1, 3)
    fmt.Println(err2)
}`,
        check: { type: 'contains', patterns: ['func hitungLuas('], mustContain: ['errors.New(', 'return', 'float64, error'], errorMsg: 'Buat func hitungLuas(panjang, lebar float64) (float64, error) dengan error check.' },
        hint: 'func hitungLuas(p, l float64) (float64, error) { if p <= 0 || l <= 0 { return 0, errors.New("nilai harus positif") }; return p * l, nil }',
        successMsg: 'Multiple return + explicit error handling = Go philosophy! Tidak ada exceptions. 🔵',
      },
      {
        id: 3,
        title: 'Goroutine & Channel',
        instruction: `## Langkah 3: Concurrency dengan Goroutine

Goroutine adalah lightweight thread yang sangat murah di Go:

\`\`\`go
package main

import (
    "fmt"
    "sync"
    "time"
)

// Goroutine dasar
func worker(id int, wg *sync.WaitGroup) {
    defer wg.Done()
    fmt.Printf("Worker %d mulai\n", id)
    time.Sleep(100 * time.Millisecond)
    fmt.Printf("Worker %d selesai\n", id)
}

// Channel untuk komunikasi antar goroutine
func generate(ch chan<- int, n int) {
    for i := 0; i < n; i++ {
        ch <- i * i  // kirim ke channel
    }
    close(ch)
}

func main() {
    // WaitGroup
    var wg sync.WaitGroup
    for i := 1; i <= 3; i++ {
        wg.Add(1)
        go worker(i, &wg)
    }
    wg.Wait()
    
    // Channel
    ch := make(chan int, 5)
    go generate(ch, 5)
    for v := range ch {
        fmt.Println(v)  // 0, 1, 4, 9, 16
    }
}
\`\`\`

**Tugasmu:** Buat channel int, jalankan goroutine yang mengirim bilangan prima pertama (2,3,5,7,11), lalu terima dan tampilkan.`,
        starterCode: `package main

import "fmt"

func kirimPrima(ch chan<- int) {
    prima := []int{2, 3, 5, 7, 11}
    // Kirim setiap bilangan prima ke channel
    // Jangan lupa close(ch) di akhir
}

func main() {
    ch := make(chan int, 5)
    go kirimPrima(ch)
    
    // Terima dan tampilkan setiap nilai dari channel
}`,
        check: { type: 'contains', patterns: ['chan int', 'chan<- int'], mustContain: ['go kirimPrima', 'close(ch)', 'range ch'], errorMsg: 'Kirim setiap prima ke channel, close(ch), lalu for v := range ch di main.' },
        hint: 'for _, p := range prima { ch <- p }; close(ch) / for v := range ch { fmt.Println(v) }',
        successMsg: 'Goroutine + Channel = concurrency model paling elegan! Itulah mengapa Go dipakai di cloud. 🔵',
        isFinal: true,
      },
    ],
  },

  // ================================================================
  // 13. TYPESCRIPT WORKSHOP
  // ================================================================
  {
    id: 'typescript-dasar',
    title: 'TypeScript: JavaScript yang Type-Safe',
    slug: 'typescript-dasar',
    icon: '🔷',
    lang: 'typescript',
    category: 'Frontend',
    color: 'from-blue-500 to-blue-700',
    level: 'Intermediate',
    xp: 200,
    desc: 'Kuasai TypeScript dari type annotation, interface, generics, hingga decorators.',
    steps: [
      {
        id: 1,
        title: 'Type Annotation Dasar',
        instruction: `## Langkah 1: TypeScript — JavaScript + Types

TypeScript menambahkan sistem tipe statis ke JavaScript. Error terdeteksi SEBELUM runtime:

\`\`\`typescript
// Type annotation
let nama: string = "Budi"
let umur: number = 17
let lulus: boolean = true
let nilai: number[] = [85, 90, 78]

// Union type
let id: string | number = "abc123"
id = 456  // juga valid

// Literal type
let arah: "kiri" | "kanan" | "lurus" = "kiri"

// Tuple
let koordinat: [number, number] = [10.5, -7.25]

// Optional
let email: string | undefined = undefined

// Type alias
type Nilai = number
type Grade = "A" | "B" | "C" | "D"

const hitungGrade = (n: Nilai): Grade => {
    if (n >= 90) return "A"
    if (n >= 75) return "B"
    if (n >= 60) return "C"
    return "D"
}
\`\`\`

**Tugasmu:** Buat type alias \`Koordinat\` (tuple [number, number]), deklarasikan variabel bertipe Koordinat, dan buat fungsi \`jarak(a: Koordinat, b: Koordinat): number\`.`,
        starterCode: `// Buat type alias Koordinat = [number, number]

// Deklarasikan dua variabel Koordinat

// Buat fungsi jarak(a: Koordinat, b: Koordinat): number
// Rumus: sqrt((x2-x1)^2 + (y2-y1)^2)

// Test:
// const a: Koordinat = [0, 0]
// const b: Koordinat = [3, 4]
// console.log(jarak(a, b))  // 5`,
        check: { type: 'contains', patterns: ['type Koordinat'], mustContain: ['Koordinat', ': number', 'jarak('], errorMsg: 'Buat type Koordinat = [number, number] dan function jarak dengan parameter bertipe Koordinat.' },
        hint: 'type Koordinat = [number, number]; const jarak = (a: Koordinat, b: Koordinat): number => Math.sqrt((b[0]-a[0])**2 + (b[1]-a[1])**2)',
        successMsg: 'Type alias membuat kode TypeScript lebih ekspresif dan self-documenting! 🔷',
      },
      {
        id: 2,
        title: 'Interface & Type Guard',
        instruction: `## Langkah 2: Interface

Interface mendefinisikan bentuk object:

\`\`\`typescript
interface User {
    id: number
    nama: string
    email: string
    umur?: number          // optional
    readonly createdAt: Date  // immutable
}

// Extend interface
interface Admin extends User {
    role: "superadmin" | "moderator"
    permissions: string[]
}

// Type guard
function isAdmin(user: User | Admin): user is Admin {
    return "role" in user
}

// Function dengan interface
function tampilkanUser(user: User): string {
    return user.umur 
        ? \`\${user.nama} (\${user.umur} th)\`
        : user.nama
}
\`\`\`

**Tugasmu:** Buat interface \`Produk\` dengan id, nama, harga, stok (optional). Buat interface \`ProdukDigital extends Produk\` dengan tambahan field downloadUrl. Buat fungsi yang menerima Produk dan return string deskripsi.`,
        starterCode: `// Buat interface Produk
// Field: id (number), nama (string), harga (number), stok? (number)

// Buat interface ProdukDigital extends Produk
// Tambah field: downloadUrl (string)

// Buat function deskripsikan(p: Produk): string
// Return format: "Nama - Rp{harga}"

// Test:
// const laptop: Produk = { id: 1, nama: "Laptop", harga: 15000000, stok: 5 }
// console.log(deskripsikan(laptop))`,
        check: { type: 'contains', patterns: ['interface Produk'], mustContain: ['interface ProdukDigital extends Produk', 'deskripsikan(', ': Produk'], errorMsg: 'Buat interface Produk, ProdukDigital extends Produk, dan function deskripsikan(p: Produk).' },
        hint: 'interface Produk { id: number; nama: string; harga: number; stok?: number } interface ProdukDigital extends Produk { downloadUrl: string } const deskripsikan = (p: Produk): string => `${p.nama} - Rp${p.harga}`',
        successMsg: 'Interface TypeScript = kontrak yang terdokumentasi sendiri! Lebih baik dari JSDoc. 🔷',
      },
      {
        id: 3,
        title: 'Generics',
        instruction: `## Langkah 3: Generics — Code yang Reusable & Type-Safe

Generics membuat fungsi/class bekerja dengan berbagai tipe tanpa kehilangan type safety:

\`\`\`typescript
// Generic function
function identitas<T>(nilai: T): T {
    return nilai
}

identitas<string>("hello")  // return string
identitas<number>(42)       // return number

// Generic Array utility
function pertama<T>(arr: T[]): T | undefined {
    return arr[0]
}

function filter<T>(arr: T[], predicate: (item: T) => boolean): T[] {
    return arr.filter(predicate)
}

// Generic interface
interface ApiResponse<T> {
    data: T
    status: number
    message: string
}

// Penggunaan
const response: ApiResponse<User[]> = {
    data: [{ id: 1, nama: "Budi", email: "budi@email.com", createdAt: new Date() }],
    status: 200,
    message: "OK"
}
\`\`\`

**Tugasmu:** Buat generic function \`groupBy<T>(arr: T[], key: keyof T): Record<string, T[]>\` yang mengelompokkan array berdasarkan key tertentu.`,
        starterCode: `// Buat generic function groupBy
// <T>(arr: T[], key: keyof T): Record<string, T[]>

// Test:
const produk = [
    { kategori: "Elektronik", nama: "Laptop" },
    { kategori: "Buku", nama: "Clean Code" },
    { kategori: "Elektronik", nama: "Mouse" },
]

// const grouped = groupBy(produk, "kategori")
// Expected: { Elektronik: [...], Buku: [...] }`,
        check: { type: 'contains', patterns: ['function groupBy<T>', 'const groupBy = <T>'], mustContain: ['keyof T', 'Record<', 'reduce('], errorMsg: 'Buat function groupBy<T>(arr: T[], key: keyof T): Record<string, T[]> menggunakan reduce.' },
        hint: 'function groupBy<T>(arr: T[], key: keyof T): Record<string, T[]> { return arr.reduce((acc, item) => { const k = String(item[key]); if (!acc[k]) acc[k] = []; acc[k].push(item); return acc }, {} as Record<string, T[]>) }',
        successMsg: 'Generics = abstraksi tertinggi TypeScript! Kode reusable + fully type-safe. 🔷',
        isFinal: true,
      },
    ],
  },
]

export function getWorkshop(id) {
  return WORKSHOPS.find(w => w.id === id || w.slug === id)
}

export function checkAnswer(code, check) {
  if (!check || !code) return { passed: false, msg: 'Kode tidak boleh kosong' }
  const normalized = code.trim()
  if (!normalized) return { passed: false, msg: 'Tulis kode dulu ya!' }

  if (check.type === 'contains') {
    const mainPassed = check.patterns?.some(p => normalized.includes(p)) ?? true

    let mustPassed = true
    if (check.mustContain) {
      for (const p of check.mustContain) {
        const alts = Array.isArray(p) ? p : [p]
        if (!alts.some(alt => normalized.includes(alt))) {
          mustPassed = false
          break
        }
      }
    }

    if (!mainPassed || !mustPassed) {
      return { passed: false, msg: check.errorMsg || 'Kode belum sesuai. Coba lagi!' }
    }

    if (check.mustContainString && !/['"`]/.test(normalized)) {
      return { passed: false, msg: check.errorMsg || 'Pastikan menggunakan tanda kutip untuk string.' }
    }
    if (check.mustHaveDot && !/\d+\.\d+/.test(normalized)) {
      return { passed: false, msg: check.errorMsg || 'Gunakan titik untuk desimal, contoh: 87.5' }
    }

    return { passed: true }
  }

  return { passed: true }
}