import mongoose from 'mongoose'

const ChatMessageSchema = new mongoose.Schema({
  room: { type: String, default: 'general', index: true },
  authorId: { type: String, required: true },
  authorName: { type: String, required: true },
  content: { type: String, required: true, maxlength: 1000 },
  type: { type: String, enum: ['text', 'system'], default: 'text' },
  createdAt: { type: Date, default: Date.now, expires: 604800 }, // auto-delete after 7 days
})

ChatMessageSchema.index({ room: 1, createdAt: -1 })

// This model will be created on the chat connection separately
export const ChatMessageSchema_ = ChatMessageSchema
