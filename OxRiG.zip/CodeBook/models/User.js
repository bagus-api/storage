import mongoose from 'mongoose'

const UserSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true, maxlength: 50 },
  email: { type: String, required: true, unique: true, lowercase: true, maxlength: 320, index: true },
  password: { type: String, required: true },
  xp: { type: Number, default: 0, min: 0 },
  badges: [{ type: String }],
  streak: { type: Number, default: 0 },
  lastLogin: { type: Date },
  completedMateri: [{ type: String }],
  completedQuiz: [{
    quizId: String,
    score: Number,
    passed: { type: Boolean, default: false },
    completedAt: Date,
  }],
  certificates: [{ type: String }],
  createdAt: { type: Date, default: Date.now },
})

// Remove password from JSON output
UserSchema.methods.toJSON = function() {
  const obj = this.toObject()
  delete obj.password
  return obj
}

export default mongoose.models.User || mongoose.model('User', UserSchema)
