import mongoose from 'mongoose'

const ReplySchema = new mongoose.Schema({
  author: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  authorName: { type: String, required: true },
  content: { type: String, required: true, maxlength: 5000 },
  votes: { type: Number, default: 0 },
  isSolution: { type: Boolean, default: false },
  createdAt: { type: Date, default: Date.now },
})

const ThreadSchema = new mongoose.Schema({
  title: { type: String, required: true, trim: true, maxlength: 200 },
  content: { type: String, required: true, maxlength: 10000 },
  author: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  authorName: { type: String, required: true },
  category: {
    type: String,
    enum: ['html-css', 'javascript', 'react', 'backend', 'python', 'cybersecurity', 'database', 'git', 'general'],
    default: 'general'
  },
  tags: [{ type: String, maxlength: 30 }],
  replies: [ReplySchema],
  views: { type: Number, default: 0 },
  votes: { type: Number, default: 0 },
  solved: { type: Boolean, default: false },
  isPinned: { type: Boolean, default: false },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now },
})

ThreadSchema.index({ category: 1, createdAt: -1 })
ThreadSchema.index({ createdAt: -1 })
ThreadSchema.index({ votes: -1 })

export default mongoose.models.Thread || mongoose.model('Thread', ThreadSchema)
