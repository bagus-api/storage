import mongoose from 'mongoose'

const CertificateSchema = new mongoose.Schema({
  certId: { type: String, required: true, unique: true, index: true },
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  userName: { type: String, required: true, trim: true },
  courseName: { type: String, required: true },
  courseSlug: { type: String, required: true },
  quizScore: { type: Number, default: 0 },
  issuedAt: { type: Date, default: Date.now },
  domain: { type: String, default: 'https://www.codebook.zapto.org/' },
})

// Compound index: 1 sertifikat per user per course
CertificateSchema.index({ userId: 1, courseSlug: 1 }, { unique: true })

export default mongoose.models.Certificate || mongoose.model('Certificate', CertificateSchema)
