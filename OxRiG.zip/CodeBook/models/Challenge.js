import mongoose from 'mongoose'

const ChallengeProgressSchema = new mongoose.Schema({
  userId: { type: String, required: true, index: true },
  challengeId: { type: String, required: true },
  solved: { type: Boolean, default: false },
  attempts: { type: Number, default: 0 },
  xpEarned: { type: Number, default: 0 },
  solvedAt: { type: Date },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now },
})

ChallengeProgressSchema.index({ userId: 1, challengeId: 1 }, { unique: true })

export default mongoose.models.ChallengeProgress || mongoose.model('ChallengeProgress', ChallengeProgressSchema)
