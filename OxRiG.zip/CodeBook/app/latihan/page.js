'use client'
import { useState } from 'react'
import dynamic from 'next/dynamic'
import Navbar from '@/components/layout/Navbar'
import toast from 'react-hot-toast'

const MonacoEditor = dynamic(() => import('@monaco-editor/react'), { ssr: false, loading: () => (
  <div className="flex items-center justify-center h-full bg-[#0d0f1a]">
    <div className="text-slate-600 text-sm flex items-center gap-2">
      <svg className="animate-spin w-4 h-4" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" /><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" /></svg>
      Memuat editor...
    </div>
  </div>
)})

const TEMPLATES = {
  javascript: {
    label: 'JavaScript',
    icon: '⚡',
    code: `// Selamat datang di CodeBook Editor!
// Tulis kode JavaScript di sini

function hitung(a, b) {
  return a + b
}

const hasil = hitung(10, 32)
console.log("Hasil:", hasil)

// Coba array & loop
const angka = [1, 2, 3, 4, 5]
const kuadrat = angka.map(n => n * n)
console.log("Kuadrat:", kuadrat)

// Async/Await simulation
const data = { nama: "CodeBook", version: "1.0" }
console.log(JSON.stringify(data, null, 2))
`,
  },
  html: {
    label: 'HTML',
    icon: '🏷️',
    code: `<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Preview HTML</title>
  <style>
    body { 
      font-family: 'Sora', sans-serif; 
      background: #0a0b14; 
      color: #e2e8f0; 
      padding: 2rem; 
    }
    h1 { color: #6171f5; }
    .card {
      background: #0f1117;
      border: 1px solid rgba(97,113,245,0.2);
      border-radius: 12px;
      padding: 1.5rem;
      margin-top: 1rem;
    }
    button {
      background: #6171f5;
      color: white;
      border: none;
      padding: 8px 20px;
      border-radius: 8px;
      cursor: pointer;
      font-size: 14px;
      margin-top: 1rem;
    }
    button:hover { background: #4f52ea; }
  </style>
</head>
<body>
  <h1>Hello dari CodeBook! 🚀</h1>
  <div class="card">
    <h2>Ini adalah card</h2>
    <p>Tulis HTML apa saja dan lihat hasilnya langsung di preview.</p>
    <button onclick="alert('Halo!')">Klik Saya</button>
  </div>
</body>
</html>`,
  },
  python_sim: {
    label: 'Python',
    icon: '🐍',
    code: `# Python Simulator (dijalankan sebagai JavaScript)
# Catatan: Ini adalah simulasi output Python

nama = "CodeBook"
tahun = 2024
print(f"Platform: {nama}")
print(f"Tahun: {tahun}")

# List operations
bahasa = ["Python", "JavaScript", "Go"]
for lang in bahasa:
    print(f"  - {lang}")

# Dictionary
user = {"nama": "Budi", "xp": 1500, "level": "Pro"}
print(f"\\nUser: {user['nama']}")
print(f"XP: {user['xp']}")

# Function
def hitung_level(xp):
    if xp < 500: return "Beginner"
    elif xp < 1500: return "Intermediate"
    elif xp < 3500: return "Pro"
    return "Master"

level = hitung_level(user["xp"])
print(f"Level: {level}")
`,
  },
}

function parsePythonLike(code) {
  const lines = code.split('\n')
  const output = []

  for (const rawLine of lines) {
    const line = rawLine.trim()
    if (!line || line.startsWith('#')) continue

    const printMatch = line.match(/^print\((.+)\)$/)
    if (printMatch) {
      let content = printMatch[1]
      // Handle f-strings
      content = content.replace(/f["'](.+?)["']/, (_, inner) => inner.replace(/\{([^}]+)\}/g, (__, expr) => {
        try { return eval(expr) } catch { return expr }
      }))
      // Clean quotes
      content = content.replace(/^["']|["']$/g, '')
      output.push(content)
    }
  }
  return output.join('\n') || '(tidak ada output)'
}

export default function LatihanPage() {
  const [lang, setLang] = useState('javascript')
  const [code, setCode] = useState(TEMPLATES.javascript.code)
  const [output, setOutput] = useState('')
  const [running, setRunning] = useState(false)
  const [tab, setTab] = useState('output')
  const [htmlPreview, setHtmlPreview] = useState('')

  const handleLangChange = (l) => {
    setLang(l)
    setCode(TEMPLATES[l].code)
    setOutput('')
    setHtmlPreview('')
  }

  const runCode = () => {
    setRunning(true)
    setOutput('')
    setHtmlPreview('')

    setTimeout(() => {
      try {
        if (lang === 'html') {
          setHtmlPreview(code)
          setTab('preview')
          toast.success('HTML dirender! 🎨')
        } else if (lang === 'python_sim') {
          const result = parsePythonLike(code)
          setOutput(result)
          setTab('output')
          toast.success('Python dieksekusi! 🐍')
        } else {
          const logs = []
          const origLog = console.log
          console.log = (...args) => { logs.push(args.map(a => typeof a === 'object' ? JSON.stringify(a, null, 2) : String(a)).join(' ')); origLog(...args) }

          try {
            const fn = new Function(code)
            fn()
          } finally {
            console.log = origLog
          }

          setOutput(logs.length > 0 ? logs.join('\n') : '(tidak ada output)')
          setTab('output')
          toast.success('Kode berhasil dijalankan! ⚡')
        }
      } catch (err) {
        setOutput(`Error: ${err.message}`)
        setTab('output')
        toast.error('Terdapat error dalam kode')
      } finally {
        setRunning(false)
      }
    }, 400)
  }

  return (
    <div className="min-h-screen bg-[#0a0b14]">
      <Navbar />
      <div className="pt-16 h-screen flex flex-col">
        {/* Top bar */}
        <div className="flex items-center gap-3 px-4 py-3 bg-[#0d0f1a] border-b border-white/[0.06] flex-shrink-0">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-[#6171f5] to-purple-600 flex items-center justify-center text-white font-bold text-xs">CB</div>
            <span className="text-sm font-semibold text-white">Latihan Code</span>
          </div>
          <div className="flex gap-1 ml-2">
            {Object.entries(TEMPLATES).map(([key, t]) => (
              <button
                key={key}
                onClick={() => handleLangChange(key)}
                className={`px-3 py-1 rounded-lg text-xs font-medium transition-all flex items-center gap-1.5 ${lang === key ? 'bg-[#6171f5] text-white' : 'text-slate-500 hover:text-slate-300 hover:bg-white/[0.05]'}`}
              >
                <span>{t.icon}</span> {t.label}
              </button>
            ))}
          </div>
          <button
            onClick={runCode}
            disabled={running}
            className="ml-auto flex items-center gap-2 px-4 py-1.5 rounded-lg text-sm font-semibold bg-[#6171f5] hover:bg-[#4f52ea] text-white disabled:opacity-60 transition-all"
          >
            {running ? (
              <><svg className="animate-spin w-3.5 h-3.5" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" /><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" /></svg> Running...</>
            ) : (
              <><span>▶</span> Run</>
            )}
          </button>
        </div>

        {/* Editor + Output */}
        <div className="flex flex-1 min-h-0">
          {/* Editor */}
          <div className="flex-1 min-w-0 border-r border-white/[0.06]">
            <MonacoEditor
              height="100%"
              language={lang === 'python_sim' ? 'python' : lang}
              value={code}
              onChange={(val) => setCode(val || '')}
              theme="vs-dark"
              options={{
                fontSize: 14,
                fontFamily: "'JetBrains Mono', 'Fira Code', monospace",
                lineHeight: 1.7,
                minimap: { enabled: false },
                scrollBeyondLastLine: false,
                padding: { top: 16, bottom: 16 },
                renderLineHighlight: 'all',
                smoothScrolling: true,
                cursorBlinking: 'smooth',
                bracketPairColorization: { enabled: true },
                wordWrap: 'on',
              }}
            />
          </div>

          {/* Output panel */}
          <div className="w-80 lg:w-96 flex flex-col bg-[#0d0f1a] flex-shrink-0">
            <div className="flex border-b border-white/[0.06] flex-shrink-0">
              {['output', 'preview'].map(t => (
                <button
                  key={t}
                  onClick={() => setTab(t)}
                  className={`flex-1 py-2.5 text-xs font-medium transition-colors capitalize ${tab === t ? 'text-[#a5bbff] border-b-2 border-[#6171f5]' : 'text-slate-600 hover:text-slate-400'}`}
                >
                  {t === 'preview' ? '🌐 Preview' : '💻 Output'}
                </button>
              ))}
            </div>

            <div className="flex-1 overflow-auto">
              {tab === 'output' ? (
                <div className="p-4">
                  {output ? (
                    <pre className={`text-xs leading-relaxed font-mono whitespace-pre-wrap ${output.startsWith('Error:') ? 'text-red-400' : 'text-emerald-400'}`}>
                      {output}
                    </pre>
                  ) : (
                    <div className="flex flex-col items-center justify-center h-40 text-slate-700">
                      <span className="text-3xl mb-2">▶</span>
                      <p className="text-xs">Tekan Run untuk menjalankan kode</p>
                    </div>
                  )}
                </div>
              ) : (
                htmlPreview ? (
                  <iframe
                    srcDoc={htmlPreview}
                    className="w-full h-full border-0"
                    title="HTML Preview"
                    sandbox="allow-scripts"
                  />
                ) : (
                  <div className="flex flex-col items-center justify-center h-40 text-slate-700">
                    <span className="text-3xl mb-2">🌐</span>
                    <p className="text-xs">Jalankan HTML untuk melihat preview</p>
                  </div>
                )
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
