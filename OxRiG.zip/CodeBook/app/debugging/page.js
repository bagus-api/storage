'use client'
import { useState } from 'react'
import Link from 'next/link'
import Navbar from '@/components/layout/Navbar'
import { DEBUGGING_TOPICS } from '@/data/debugging'

const LANG_META = {
  javascript: { label: 'JavaScript', bg: 'bg-yellow-500/10', border: 'border-yellow-500/20', text: 'text-yellow-400', dot: '#EAB308' },
  python:     { label: 'Python',     bg: 'bg-blue-500/10',   border: 'border-blue-500/20',   text: 'text-blue-400',   dot: '#3B82F6' },
  java:       { label: 'Java',       bg: 'bg-orange-500/10', border: 'border-orange-500/20', text: 'text-orange-400', dot: '#F97316' },
  php:        { label: 'PHP',        bg: 'bg-violet-500/10', border: 'border-violet-500/20', text: 'text-violet-400', dot: '#818CF8' },
  cpp:        { label: 'C++',        bg: 'bg-blue-600/10',   border: 'border-blue-600/20',   text: 'text-blue-300',   dot: '#60A5FA' },
  sql:        { label: 'SQL',        bg: 'bg-cyan-500/10',   border: 'border-cyan-500/20',   text: 'text-cyan-400',   dot: '#06B6D4' },
  general:    { label: 'General',    bg: 'bg-violet-500/10', border: 'border-violet-500/20', text: 'text-violet-400', dot: '#8B5CF6' },
}

const SEV_META = {
  error:    { label: 'Error',    bg: 'bg-red-500/10',    text: 'text-red-400',    border: 'border-red-500/20' },
  warning:  { label: 'Warning', bg: 'bg-yellow-500/10', text: 'text-yellow-400', border: 'border-yellow-500/20' },
  critical: { label: 'Critical',bg: 'bg-red-700/15',    text: 'text-red-300',    border: 'border-red-700/30' },
  info:     { label: 'Info',    bg: 'bg-blue-500/10',   text: 'text-blue-400',   border: 'border-blue-500/20' },
}

function CodeBlock({ code, lang }) {
  const [copied, setCopied] = useState(false)
  const handleCopy = () => {
    navigator.clipboard.writeText(code)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }
  return (
    <div className="relative rounded-xl overflow-hidden border border-white/[0.08]" style={{ background: '#1E1E1E' }}>
      <div className="flex items-center justify-between px-4 py-2.5 border-b border-white/[0.06]" style={{ background: '#2D2D30' }}>
        <div className="flex items-center gap-1.5">
          <div className="w-2.5 h-2.5 rounded-full bg-[#FF5F57]" />
          <div className="w-2.5 h-2.5 rounded-full bg-[#FFBD2E]" />
          <div className="w-2.5 h-2.5 rounded-full bg-[#28CA41]" />
        </div>
        <button onClick={handleCopy} className="text-xs font-mono transition-colors" style={{ color: copied ? '#28CA41' : '#888' }}>
          {copied ? '✓ Copied' : 'Copy'}
        </button>
      </div>
      <pre className="p-4 overflow-x-auto text-sm leading-relaxed font-mono text-slate-300 whitespace-pre">
        <code>{code}</code>
      </pre>
    </div>
  )
}

function ErrorCard({ error }) {
  const [expanded, setExpanded] = useState(false)
  const sev = SEV_META[error.severity] || SEV_META.info

  return (
    <div className="rounded-2xl border border-white/[0.06] bg-[#0f172a] overflow-hidden">
      <button
        onClick={() => setExpanded(!expanded)}
        className="w-full flex items-center gap-4 p-5 text-left hover:bg-white/[0.02] transition-all"
      >
        <div className={`w-2 h-2 rounded-full flex-shrink-0 ${error.severity === 'error' || error.severity === 'critical' ? 'bg-red-500' : error.severity === 'warning' ? 'bg-yellow-500' : 'bg-blue-500'}`} />
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap mb-1">
            <code className="text-sm font-mono font-bold text-slate-200">{error.name}</code>
            <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md border ${sev.bg} ${sev.text} ${sev.border}`}>
              {error.category}
            </span>
            <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md border ${sev.bg} ${sev.text} ${sev.border}`}>
              {sev.label}
            </span>
          </div>
          <p className="text-xs text-slate-500">{error.explanation.slice(0, 80)}...</p>
        </div>
        <span className="text-slate-600 flex-shrink-0 text-lg">{expanded ? '▲' : '▼'}</span>
      </button>

      {expanded && (
        <div className="border-t border-white/[0.06] p-5 space-y-5">
          {/* Explanation */}
          <div className="p-4 rounded-xl bg-blue-500/5 border border-blue-500/15">
            <p className="text-xs font-bold text-blue-400 mb-1.5">Penjelasan</p>
            <p className="text-sm text-slate-400 leading-relaxed">{error.explanation}</p>
          </div>

          {/* Bug vs Fix side by side */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <div className="w-3 h-3 rounded-full bg-red-500" />
                <p className="text-xs font-black text-red-400 uppercase tracking-wider">Kode Bermasalah (Bug)</p>
              </div>
              <CodeBlock code={error.buggyCode} lang="code" />
            </div>
            <div>
              <div className="flex items-center gap-2 mb-2">
                <div className="w-3 h-3 rounded-full bg-emerald-500" />
                <p className="text-xs font-black text-emerald-400 uppercase tracking-wider">Kode yang Benar (Fix)</p>
              </div>
              <CodeBlock code={error.fixedCode} lang="code" />
            </div>
          </div>

          {/* Tips */}
          <div className="p-4 rounded-xl bg-violet-500/5 border border-violet-500/15">
            <p className="text-xs font-black text-violet-400 mb-3 uppercase tracking-wider">Tips & Best Practice</p>
            <ul className="space-y-2">
              {error.tips.map((tip, i) => (
                <li key={i} className="flex items-start gap-2.5 text-sm text-slate-400">
                  <div className="w-5 h-5 rounded-md bg-violet-500/15 flex items-center justify-center text-violet-400 text-[10px] font-black flex-shrink-0 mt-0.5">{i+1}</div>
                  <span dangerouslySetInnerHTML={{ __html: tip.replace(/`([^`]+)`/g, '<code style="background:#1e293b;padding:1px 5px;border-radius:4px;color:#C678DD;font-family:monospace;font-size:11px">$1</code>') }} />
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}
    </div>
  )
}

export default function DebuggingPage() {
  const [selectedLang, setSelectedLang] = useState('all')
  const langs = ['all', ...DEBUGGING_TOPICS.map(t => t.lang)]

  const filtered = selectedLang === 'all'
    ? DEBUGGING_TOPICS
    : DEBUGGING_TOPICS.filter(t => t.lang === selectedLang)

  const totalErrors = DEBUGGING_TOPICS.reduce((sum, t) => sum + t.errors.length, 0)

  return (
    <div className="min-h-screen bg-[#020617]">
      <Navbar />
      <div className="max-w-6xl mx-auto px-4 py-24">

        {/* Header */}
        <div className="mb-12">
          <div className="flex items-center gap-2 mb-3">
            <div className="w-1 h-6 rounded-full bg-red-500" />
            <p className="text-red-400 text-sm font-black uppercase tracking-widest">Debug & Fix</p>
          </div>
          <h1 className="text-4xl sm:text-5xl font-black text-white leading-tight mb-4">
            Error & Debugging Guide
          </h1>
          <p className="text-slate-500 max-w-xl text-lg leading-relaxed">
            Pahami setiap jenis error, lihat kode yang bermasalah vs yang benar, dan kuasai teknik debugging seperti engineer senior.
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-10">
          {[
            { label: 'Total Error Types', value: totalErrors, color: 'text-red-400' },
            { label: 'Bahasa Covered', value: DEBUGGING_TOPICS.length, color: 'text-violet-400' },
            { label: 'Bug vs Fix Examples', value: totalErrors, color: 'text-emerald-400' },
            { label: 'Tips & Tricks', value: DEBUGGING_TOPICS.reduce((s,t) => s + t.errors.reduce((ss,e) => ss + e.tips.length, 0), 0), color: 'text-blue-400' },
          ].map(s => (
            <div key={s.label} className="p-4 rounded-xl bg-[#0f172a] border border-white/[0.06] text-center">
              <div className={`text-2xl font-black mb-1 ${s.color}`}>{s.value}</div>
              <div className="text-slate-600 text-xs">{s.label}</div>
            </div>
          ))}
        </div>

        {/* Lang filter */}
        <div className="flex gap-2 mb-8 flex-wrap">
          {langs.map(lang => {
            const meta = LANG_META[lang]
            return (
              <button key={lang} onClick={() => setSelectedLang(lang)}
                className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all border ${
                  selectedLang === lang
                    ? `${meta?.bg || 'bg-violet-500/10'} ${meta?.text || 'text-violet-400'} ${meta?.border || 'border-violet-500/20'}`
                    : 'bg-transparent border-white/[0.06] text-slate-500 hover:text-slate-300'
                }`}>
                {lang !== 'all' && <div className="w-1.5 h-1.5 rounded-full" style={{ background: meta?.dot || '#888' }} />}
                {lang === 'all' ? 'Semua' : meta?.label || lang.toUpperCase()}
              </button>
            )
          })}
        </div>

        {/* Error topics */}
        <div className="space-y-8">
          {filtered.map(topic => {
            const meta = LANG_META[topic.lang]
            return (
              <div key={topic.id}>
                {/* Topic header */}
                <div className="flex items-center gap-3 mb-4">
                  <div className={`flex items-center gap-2 px-3 py-1.5 rounded-xl ${meta?.bg} border ${meta?.border}`}>
                    <div className="w-2 h-2 rounded-full" style={{ background: meta?.dot }} />
                    <span className={`text-xs font-black ${meta?.text}`}>{meta?.label || topic.lang.toUpperCase()}</span>
                  </div>
                  <h2 className="font-black text-white text-lg">{topic.title}</h2>
                  <span className="text-xs text-slate-600">{topic.errors.length} error types</span>
                </div>
                <p className="text-slate-500 text-sm mb-4">{topic.desc}</p>

                <div className="space-y-3">
                  {topic.errors.map(err => <ErrorCard key={err.id} error={err} />)}
                </div>
              </div>
            )
          })}
        </div>

        {/* Coming soon */}
        <div className="mt-12 p-5 rounded-2xl border border-dashed border-white/10 text-center">
          <p className="text-slate-600 text-sm">
            🔜 Error guide untuk Kotlin, Rust, Go, dan TypeScript segera hadir!
          </p>
        </div>
      </div>
    </div>
  )
}
