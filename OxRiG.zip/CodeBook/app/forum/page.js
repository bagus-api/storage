'use client'
import { useState, useEffect, useCallback } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import Navbar from '@/components/layout/Navbar'
import toast from 'react-hot-toast'

const CATS = [
  { id: 'all', label: 'Semua', icon: '📋' },
  { id: 'javascript', label: 'JavaScript', icon: '⚡' },
  { id: 'react', label: 'React.js', icon: '⚛️' },
  { id: 'html-css', label: 'HTML & CSS', icon: '🏷️' },
  { id: 'backend', label: 'Backend', icon: '⚙️' },
  { id: 'python', label: 'Python', icon: '🐍' },
  { id: 'database', label: 'Database', icon: '🗄️' },
  { id: 'cybersecurity', label: 'Security', icon: '🛡️' },
  { id: 'git', label: 'Git', icon: '🌿' },
  { id: 'general', label: 'General', icon: '💬' },
]

const SORTS = [
  { key: 'latest', label: '🕐 Terbaru' },
  { key: 'popular', label: '🔥 Populer' },
  { key: 'unsolved', label: '❓ Belum Terjawab' },
]

function timeAgo(date) {
  const s = Math.floor((Date.now() - new Date(date)) / 1000)
  if (s < 60) return `${s}d lalu`
  if (s < 3600) return `${Math.floor(s/60)}m lalu`
  if (s < 86400) return `${Math.floor(s/3600)}j lalu`
  if (s < 604800) return `${Math.floor(s/86400)} hari lalu`
  return new Date(date).toLocaleDateString('id-ID', { day:'numeric', month:'short' })
}

export default function ForumPage() {
  const [threads, setThreads] = useState([])
  const [total, setTotal] = useState(0)
  const [loading, setLoading] = useState(true)
  const [cat, setCat] = useState('all')
  const [sort, setSort] = useState('latest')
  const [search, setSearch] = useState('')
  const [searchInput, setSearchInput] = useState('')
  const [page, setPage] = useState(1)
  const [updatedAt, setUpdatedAt] = useState(null)
  const [showCreate, setShowCreate] = useState(false)
  const [user, setUser] = useState(null)
  const router = useRouter()

  useEffect(() => {
    const s = localStorage.getItem('cb_user')
    if (s) setUser(JSON.parse(s))
  }, [])

  const fetchThreads = useCallback(async (silent = false) => {
    try {
      if (!silent) setLoading(true)
      const params = new URLSearchParams({ cat, sort, page, ...(search && { q: search }) })
      const res = await fetch(`/api/forum/threads?${params}`)
      const data = await res.json()
      if (data.success) {
        setThreads(data.threads)
        setTotal(data.total)
        setUpdatedAt(new Date())
      }
    } catch {}
    finally { setLoading(false) }
  }, [cat, sort, page, search])

  useEffect(() => { setPage(1) }, [cat, sort, search])
  useEffect(() => { fetchThreads() }, [fetchThreads])

  // Realtime poll every 15 seconds
  useEffect(() => {
    const iv = setInterval(() => fetchThreads(true), 15000)
    return () => clearInterval(iv)
  }, [fetchThreads])

  const handleSearch = (e) => {
    e.preventDefault()
    setSearch(searchInput)
  }

  return (
    <div className="min-h-screen bg-[#020617]">
      <Navbar />
      <div className="max-w-6xl mx-auto px-4 py-24">

        {/* Header */}
        <div className="flex items-end justify-between flex-wrap gap-4 mb-8">
          <div>
            <p className="section-label">Komunitas</p>
            <h1 className="section-title">Forum Diskusi</h1>
            <div className="flex items-center gap-2 mt-2 text-xs">
              <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
              <span className="text-slate-600">
                {updatedAt ? `Live • ${updatedAt.toLocaleTimeString('id-ID')}` : 'Memuat...'}
              </span>
              <span className="text-slate-700">•</span>
              <span className="text-slate-600">{total} thread</span>
            </div>
          </div>
          {user ? (
            <button onClick={() => setShowCreate(true)}
              className="btn btn-primary px-5 py-2.5 rounded-xl text-sm">
              ✏️ Buat Thread
            </button>
          ) : (
            <Link href="/login" className="btn btn-primary px-5 py-2.5 rounded-xl text-sm">
              Login untuk Diskusi
            </Link>
          )}
        </div>

        {/* Search + Sort */}
        <div className="flex gap-3 mb-5 flex-wrap">
          <form onSubmit={handleSearch} className="flex-1 min-w-0 relative">
            <svg className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
            </svg>
            <input value={searchInput} onChange={e => setSearchInput(e.target.value)}
              placeholder="Cari pertanyaan atau tag..."
              className="input pl-10 py-2.5 w-full" />
          </form>
          <select value={sort} onChange={e => setSort(e.target.value)}
            className="input py-2.5 w-auto pr-8 cursor-pointer bg-[#0f172a]">
            {SORTS.map(s => <option key={s.key} value={s.key}>{s.label}</option>)}
          </select>
        </div>

        <div className="flex gap-5">
          {/* Category sidebar */}
          <div className="hidden lg:block w-48 flex-shrink-0">
            <p className="text-[10px] font-black text-slate-600 uppercase tracking-widest mb-2 px-2">Kategori</p>
            <nav className="space-y-0.5">
              {CATS.map(c => (
                <button key={c.id} onClick={() => setCat(c.id)}
                  className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-sm font-semibold transition-all text-left ${cat === c.id ? 'bg-violet-600/15 text-violet-300 border border-violet-500/20' : 'text-slate-500 hover:text-slate-200 hover:bg-white/[0.04]'}`}>
                  <span className="text-base">{c.icon}</span>
                  <span className="truncate">{c.label}</span>
                </button>
              ))}
            </nav>
          </div>

          {/* Thread list */}
          <div className="flex-1 min-w-0">
            {/* Mobile cat scroll */}
            <div className="lg:hidden flex gap-2 overflow-x-auto pb-2 mb-4">
              {CATS.map(c => (
                <button key={c.id} onClick={() => setCat(c.id)}
                  className={`flex-shrink-0 flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${cat === c.id ? 'bg-violet-600 text-white' : 'bg-[#0f172a] text-slate-500 border border-white/[0.06]'}`}>
                  {c.icon} {c.label}
                </button>
              ))}
            </div>

            {loading ? (
              <div className="space-y-3">
                {[...Array(6)].map((_, i) => <div key={i} className="skeleton h-24 rounded-2xl" />)}
              </div>
            ) : threads.length === 0 ? (
              <div className="text-center py-20">
                <div className="text-5xl mb-3">💬</div>
                <p className="text-slate-400 font-bold">Belum ada thread</p>
                <p className="text-slate-600 text-sm mt-1">Jadilah yang pertama bertanya!</p>
              </div>
            ) : (
              <div className="space-y-2.5">
                {threads.map(t => (
                  <Link key={t._id} href={`/forum/${t._id}`}
                    className="group block p-4 rounded-2xl bg-[#0f172a] border border-white/[0.06] hover:border-violet-500/25 transition-all hover:bg-[#141f35]">
                    <div className="flex items-start gap-3">
                      {t.isPinned && <span className="text-yellow-500 text-sm mt-0.5 flex-shrink-0">📌</span>}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1.5 flex-wrap">
                          {t.solved && <span className="badge badge-green">✓ Terjawab</span>}
                          <span className="badge badge-purple">
                            {CATS.find(c => c.id === t.category)?.icon} {CATS.find(c => c.id === t.category)?.label || t.category}
                          </span>
                        </div>
                        <h3 className="font-bold text-white text-sm group-hover:text-violet-300 transition-colors leading-relaxed mb-2">
                          {t.title}
                        </h3>
                        <div className="flex items-center gap-3 flex-wrap">
                          {(t.tags || []).slice(0, 4).map(tag => (
                            <span key={tag} className="text-[10px] text-slate-600">#{tag}</span>
                          ))}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 mt-3 pt-3 border-t border-white/[0.04] text-xs text-slate-600 flex-wrap">
                      <span className="font-semibold text-slate-500">@{t.authorName}</span>
                      <span>{timeAgo(t.createdAt)}</span>
                      <span className="ml-auto flex items-center gap-3">
                        <span title="Upvote">👍 {t.votes || 0}</span>
                        <span title="Balasan">💬 {t.replyCount || 0}</span>
                        <span title="Views">👁 {t.views || 0}</span>
                      </span>
                    </div>
                  </Link>
                ))}
              </div>
            )}

            {/* Pagination */}
            {total > 20 && (
              <div className="flex gap-2 justify-center mt-6">
                <button onClick={() => setPage(p => Math.max(1, p-1))} disabled={page === 1}
                  className="px-4 py-2 rounded-xl text-sm bg-[#0f172a] border border-white/[0.06] text-slate-400 disabled:opacity-30 hover:text-white transition-all">
                  ← Prev
                </button>
                <span className="px-4 py-2 text-sm text-slate-500">Hal {page} / {Math.ceil(total/20)}</span>
                <button onClick={() => setPage(p => p+1)} disabled={page >= Math.ceil(total/20)}
                  className="px-4 py-2 rounded-xl text-sm bg-[#0f172a] border border-white/[0.06] text-slate-400 disabled:opacity-30 hover:text-white transition-all">
                  Next →
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Create Thread Modal */}
      {showCreate && <CreateThreadModal user={user} onClose={() => setShowCreate(false)} onCreated={() => { setShowCreate(false); fetchThreads() }} />}
    </div>
  )
}

function CreateThreadModal({ user, onClose, onCreated }) {
  const [form, setForm] = useState({ title: '', content: '', category: 'general', tags: '' })
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!form.title.trim() || !form.content.trim()) { toast.error('Judul dan isi wajib diisi'); return }
    setLoading(true)
    try {
      const tags = form.tags.split(',').map(t => t.trim().toLowerCase()).filter(Boolean).slice(0, 5)
      const res = await fetch('/api/forum/threads', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ ...form, tags }),
      })
      const data = await res.json()
      if (!res.ok) { toast.error(data.error); return }
      toast.success('Thread berhasil dibuat! 🎉')
      onCreated()
    } catch { toast.error('Gagal membuat thread') }
    finally { setLoading(false) }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
      <div className="w-full max-w-lg bg-[#0f172a] border border-white/[0.08] rounded-2xl shadow-2xl">
        <div className="flex items-center justify-between p-5 border-b border-white/[0.06]">
          <h2 className="font-bold text-white">✏️ Buat Thread Baru</h2>
          <button onClick={onClose} className="text-slate-500 hover:text-white transition-colors">✕</button>
        </div>
        <form onSubmit={handleSubmit} className="p-5 space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-400 mb-1.5">Judul Pertanyaan</label>
            <input value={form.title} onChange={e => setForm(p => ({...p, title: e.target.value}))}
              className="input" placeholder="Jelaskan pertanyaanmu secara singkat..." maxLength={200} required />
          </div>
          <div>
            <label className="block text-xs font-bold text-slate-400 mb-1.5">Kategori</label>
            <select value={form.category} onChange={e => setForm(p => ({...p, category: e.target.value}))}
              className="input bg-[#0f172a]">
              {[
                {v:'javascript',l:'⚡ JavaScript'},{v:'react',l:'⚛️ React.js'},
                {v:'html-css',l:'🏷️ HTML & CSS'},{v:'backend',l:'⚙️ Backend'},
                {v:'python',l:'🐍 Python'},{v:'database',l:'🗄️ Database'},
                {v:'cybersecurity',l:'🛡️ Security'},{v:'git',l:'🌿 Git'},
                {v:'general',l:'💬 General'},
              ].map(o => <option key={o.v} value={o.v}>{o.l}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-xs font-bold text-slate-400 mb-1.5">Isi Pertanyaan</label>
            <textarea value={form.content} onChange={e => setForm(p => ({...p, content: e.target.value}))}
              className="input min-h-[120px] resize-none" placeholder="Jelaskan masalahmu secara detail. Sertakan kode jika perlu..."
              maxLength={10000} required />
          </div>
          <div>
            <label className="block text-xs font-bold text-slate-400 mb-1.5">Tags (pisahkan dengan koma)</label>
            <input value={form.tags} onChange={e => setForm(p => ({...p, tags: e.target.value}))}
              className="input" placeholder="contoh: express, cors, api" />
          </div>
          <div className="flex gap-3 pt-2">
            <button type="button" onClick={onClose} className="flex-1 py-2.5 rounded-xl text-sm font-semibold text-slate-400 border border-white/[0.08] hover:text-white transition-all">
              Batal
            </button>
            <button type="submit" disabled={loading} className="flex-1 py-2.5 rounded-xl text-sm font-bold bg-violet-600 hover:bg-violet-500 text-white disabled:opacity-50 transition-all">
              {loading ? 'Posting...' : 'Post Thread'}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
