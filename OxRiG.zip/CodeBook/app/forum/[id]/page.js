'use client'
import { useState, useEffect, useCallback } from 'react'
import { useParams, useRouter } from 'next/navigation'
import Link from 'next/link'
import Navbar from '@/components/layout/Navbar'
import toast from 'react-hot-toast'

function timeAgo(date) {
  const s = Math.floor((Date.now() - new Date(date)) / 1000)
  if (s < 60) return `${s}d lalu`
  if (s < 3600) return `${Math.floor(s/60)}m lalu`
  if (s < 86400) return `${Math.floor(s/3600)}j lalu`
  return `${Math.floor(s/86400)} hari lalu`
}

export default function ThreadDetailPage() {
  const { id } = useParams()
  const [thread, setThread] = useState(null)
  const [loading, setLoading] = useState(true)
  const [reply, setReply] = useState('')
  const [posting, setPosting] = useState(false)
  const [user, setUser] = useState(null)
  const [voting, setVoting] = useState(false)

  useEffect(() => {
    const s = localStorage.getItem('cb_user')
    if (s) setUser(JSON.parse(s))
  }, [])

  const fetchThread = useCallback(async (silent = false) => {
    try {
      if (!silent) setLoading(true)
      const res = await fetch(`/api/forum/thread/${id}`)
      const data = await res.json()
      if (data.success) setThread(data.thread)
    } catch {}
    finally { setLoading(false) }
  }, [id])

  useEffect(() => { fetchThread() }, [fetchThread])

  // Poll every 10 seconds for new replies
  useEffect(() => {
    const iv = setInterval(() => fetchThread(true), 10000)
    return () => clearInterval(iv)
  }, [fetchThread])

  const handleReply = async (e) => {
    e.preventDefault()
    if (!user) { toast.error('Login dulu!'); return }
    if (!reply.trim() || reply.trim().length < 5) { toast.error('Balasan terlalu pendek'); return }
    setPosting(true)
    try {
      const res = await fetch(`/api/forum/thread/${id}/reply`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ content: reply }),
      })
      const data = await res.json()
      if (!res.ok) { toast.error(data.error); return }
      setReply('')
      toast.success('Balasan terkirim! 💬')
      fetchThread(true)
    } catch { toast.error('Gagal kirim balasan') }
    finally { setPosting(false) }
  }

  const handleVote = async (dir) => {
    if (!user) { toast.error('Login dulu!'); return }
    if (voting) return
    setVoting(true)
    try {
      const res = await fetch(`/api/forum/thread/${id}/vote`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ dir }),
      })
      const data = await res.json()
      if (data.success) {
        setThread(p => ({ ...p, votes: data.votes }))
        toast.success(dir === 1 ? '👍 Upvoted!' : '👎 Downvoted')
      }
    } catch {}
    finally { setVoting(false) }
  }

  if (loading) return (
    <div className="min-h-screen bg-[#020617]"><Navbar />
      <div className="max-w-3xl mx-auto px-4 py-24 space-y-4">
        <div className="skeleton h-10 w-3/4 rounded-xl" />
        <div className="skeleton h-48 rounded-2xl" />
        {[1,2].map(i => <div key={i} className="skeleton h-32 rounded-2xl" />)}
      </div>
    </div>
  )

  if (!thread) return (
    <div className="min-h-screen bg-[#020617]"><Navbar />
      <div className="flex items-center justify-center h-[60vh] text-center">
        <div>
          <div className="text-5xl mb-3">🔍</div>
          <p className="text-white font-bold mb-2">Thread tidak ditemukan</p>
          <Link href="/forum" className="text-violet-400 hover:text-violet-300 text-sm">← Kembali ke Forum</Link>
        </div>
      </div>
    </div>
  )

  return (
    <div className="min-h-screen bg-[#020617]">
      <Navbar />
      <div className="max-w-3xl mx-auto px-4 py-24">

        {/* Breadcrumb */}
        <div className="flex items-center gap-2 text-sm text-slate-600 mb-6">
          <Link href="/forum" className="hover:text-violet-400 transition-colors">Forum</Link>
          <span>/</span>
          <span className="text-slate-400 truncate">{thread.title}</span>
        </div>

        {/* Thread */}
        <div className="p-6 rounded-2xl bg-[#0f172a] border border-white/[0.08] mb-4">
          <div className="flex items-start gap-4">
            {/* Vote */}
            <div className="flex flex-col items-center gap-1 flex-shrink-0">
              <button onClick={() => handleVote(1)} disabled={voting}
                className="w-8 h-8 rounded-lg bg-white/[0.04] hover:bg-violet-500/15 hover:text-violet-400 text-slate-500 transition-all flex items-center justify-center text-sm disabled:opacity-50">
                ▲
              </button>
              <span className={`font-black text-sm tabular-nums ${thread.votes > 0 ? 'text-violet-400' : thread.votes < 0 ? 'text-red-400' : 'text-slate-500'}`}>
                {thread.votes || 0}
              </span>
              <button onClick={() => handleVote(-1)} disabled={voting}
                className="w-8 h-8 rounded-lg bg-white/[0.04] hover:bg-red-500/10 hover:text-red-400 text-slate-500 transition-all flex items-center justify-center text-sm disabled:opacity-50">
                ▼
              </button>
            </div>
            {/* Content */}
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-2 flex-wrap">
                {thread.solved && <span className="badge badge-green">✓ Terjawab</span>}
                <span className="badge badge-purple">{thread.category}</span>
                {(thread.tags || []).map(t => <span key={t} className="text-[10px] text-slate-600">#{t}</span>)}
              </div>
              <h1 className="text-xl font-black text-white mb-4 leading-tight">{thread.title}</h1>
              <div className="text-slate-400 text-sm leading-relaxed whitespace-pre-wrap">{thread.content}</div>
              <div className="flex items-center gap-3 mt-4 pt-4 border-t border-white/[0.06] text-xs text-slate-600">
                <div className="w-6 h-6 rounded-lg bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center text-white font-bold text-[10px]">
                  {thread.authorName?.[0]?.toUpperCase()}
                </div>
                <span className="font-semibold text-slate-400">@{thread.authorName}</span>
                <span>•</span>
                <span>{timeAgo(thread.createdAt)}</span>
                <span className="ml-auto">👁 {thread.views} views</span>
              </div>
            </div>
          </div>
        </div>

        {/* Replies */}
        <div className="mb-4">
          <div className="flex items-center gap-2 mb-3">
            <h2 className="font-bold text-white text-sm">{thread.replies?.length || 0} Balasan</h2>
            <div className="flex-1 h-px bg-white/[0.06]" />
            <span className="text-xs text-slate-600 flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
              Live
            </span>
          </div>

          {(thread.replies || []).length === 0 ? (
            <div className="p-8 rounded-2xl bg-[#0f172a] border border-white/[0.06] text-center">
              <div className="text-3xl mb-2">💬</div>
              <p className="text-slate-500 text-sm">Belum ada balasan. Jadilah yang pertama!</p>
            </div>
          ) : (
            <div className="space-y-3">
              {(thread.replies || []).map((r, i) => (
                <div key={r._id || i}
                  className={`p-4 rounded-2xl border transition-all ${r.isSolution ? 'bg-emerald-500/5 border-emerald-500/25' : 'bg-[#0f172a] border-white/[0.06]'}`}>
                  {r.isSolution && (
                    <div className="flex items-center gap-2 mb-3">
                      <span className="badge badge-green">✓ Jawaban Terbaik</span>
                    </div>
                  )}
                  <p className="text-slate-300 text-sm leading-relaxed whitespace-pre-wrap">{r.content}</p>
                  <div className="flex items-center gap-3 mt-3 pt-3 border-t border-white/[0.04] text-xs text-slate-600">
                    <div className="w-5 h-5 rounded bg-[#1e293b] flex items-center justify-center text-white font-bold text-[10px]">
                      {r.authorName?.[0]?.toUpperCase()}
                    </div>
                    <span className="font-semibold text-slate-500">@{r.authorName}</span>
                    <span>{timeAgo(r.createdAt)}</span>
                    <span className="ml-auto">👍 {r.votes || 0}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Reply form */}
        <div className="p-5 rounded-2xl bg-[#0f172a] border border-white/[0.08]">
          <h3 className="font-bold text-white text-sm mb-3">💬 Tulis Balasan</h3>
          {user ? (
            <form onSubmit={handleReply}>
              <textarea value={reply} onChange={e => setReply(e.target.value)}
                placeholder="Tulis jawabanmu di sini... Sertakan kode jika perlu."
                className="input min-h-[100px] resize-none mb-3 w-full" maxLength={5000} />
              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-600">{reply.length}/5000</span>
                <button type="submit" disabled={posting || !reply.trim()}
                  className="btn btn-primary px-5 py-2 rounded-xl text-sm disabled:opacity-50">
                  {posting ? 'Mengirim...' : 'Kirim Balasan →'}
                </button>
              </div>
            </form>
          ) : (
            <div className="text-center py-6">
              <p className="text-slate-500 text-sm mb-3">Login untuk ikut berdiskusi</p>
              <Link href="/login" className="btn btn-primary px-5 py-2 rounded-xl text-sm">Login Sekarang</Link>
            </div>
          )}
        </div>

        <Link href="/forum" className="inline-flex items-center gap-2 mt-6 text-sm text-slate-600 hover:text-violet-400 transition-colors">
          ← Kembali ke Forum
        </Link>
      </div>
    </div>
  )
}
