'use client'
import { useState, useEffect } from 'react'
import Link from 'next/link'
import Navbar from '@/components/layout/Navbar'
import { MATERI_LIST } from '@/data/materi'

const STATS = [
  { n: '17+', label: 'Materi Lengkap', icon: '📚' },
  { n: '200+', label: 'Quiz & Praktek', icon: '🧠' },
  { n: '4 Level', label: 'Sistem XP', icon: '⚡' },
  { n: '100%', label: 'Gratis', icon: '🎁' },
]

const PATHS = [
  { title: 'Frontend Developer', icon: '🎨', steps: ['HTML & CSS', 'JavaScript', 'React.js', 'Next.js'], color: 'from-pink-500 to-rose-500', count: 4 },
  { title: 'Backend Developer', icon: '⚙️', steps: ['Python / Node.js', 'REST API', 'Database', 'Docker'], color: 'from-emerald-500 to-teal-500', count: 4 },
  { title: 'Cybersecurity', icon: '🛡️', steps: ['Keamanan Dasar', 'OWASP Top 10', 'Secure Coding', 'Pentest Basics'], color: 'from-red-500 to-orange-500', count: 4 },
  { title: 'Fullstack Developer', icon: '🚀', steps: ['Frontend', 'Backend', 'Database', 'Deployment'], color: 'from-violet-500 to-purple-600', count: 4 },
]

const TESTIMONIALS = [
  { name: 'Rizky A.', role: 'Frontend Dev', text: 'CodeBook bantu gue ngerti React dari nol. Materinya jelas banget dan ada latihan langsung!', avatar: 'R' },
  { name: 'Siti N.', role: 'Junior Dev', text: 'Platform terbaik buat belajar cybersecurity dalam bahasa Indonesia. Highly recommended!', avatar: 'S' },
  { name: 'Budi S.', role: 'Fullstack Dev', text: 'Quiz 45 soal per topik beneran ngetes pemahaman. Sertifikatnya juga keren untuk portfolio!', avatar: 'B' },
]

const CREDITS = [
  { name: 'SHADOWNEX', role: 'Developer', icon: '👨‍💻', color: 'from-violet-600 to-purple-700', badge: 'Founder' },
  { name: 'HIME', role: 'Bug Hunter', icon: '🐛', color: 'from-red-500 to-rose-600', badge: 'Security' },
  { name: 'CODEXFUAD', role: 'Bug Hunter', icon: '🔍', color: 'from-orange-500 to-red-500', badge: 'Security' },
  { name: 'MRLOLZZ', role: 'Support', icon: '🛠️', color: 'from-blue-500 to-cyan-500', badge: 'Support' },
  { name: '1LH4MZXSEC', role: 'Support', icon: '⚙️', color: 'from-emerald-500 to-teal-500', badge: 'Support' },
  { name: 'RAZOR', role: 'Support', icon: '⚡', color: 'from-violet-500 to-indigo-600', badge: 'Support' },
]

export default function HomePage() {
  const [user, setUser] = useState(null)

  useEffect(() => {
    const s = localStorage.getItem('cb_user')
    if (s) setUser(JSON.parse(s))
  }, [])

  return (
    <div className="min-h-screen bg-[#020617]">
      <Navbar />

      {/* ── HERO ── */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden px-4 bg-grid">
        {/* Blobs */}
        <div className="absolute inset-0 pointer-events-none overflow-hidden">
          <div className="absolute top-1/4 left-1/4 w-[500px] h-[500px] bg-violet-600/10 rounded-full blur-[120px]" />
          <div className="absolute bottom-1/4 right-1/4 w-[400px] h-[400px] bg-cyan-500/8 rounded-full blur-[100px]" />
        </div>

        <div className="relative max-w-5xl mx-auto text-center z-10 pt-16">
          {/* Pill badge */}
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-violet-500/10 border border-violet-500/20 text-violet-300 text-xs font-bold mb-8 animate-fade-in">
            <span className="w-2 h-2 rounded-full bg-violet-400 animate-pulse" />
            Platform Belajar Coding Terlengkap Indonesia
          </div>

          <h1 className="text-5xl sm:text-6xl lg:text-7xl font-black text-white leading-[1.08] mb-6 animate-fade-up">
            Belajar Coding{' '}
            <span className="relative">
              <span className="bg-gradient-to-r from-violet-400 via-purple-400 to-cyan-400 bg-clip-text text-transparent">
                Sampai Jago
              </span>
            </span>
            <br />dari Nol
          </h1>

          <p className="text-slate-400 text-lg sm:text-xl max-w-2xl mx-auto mb-10 leading-relaxed">
            HTML, CSS, JavaScript, Python, React, Backend, Cybersecurity — semua dalam satu platform.
            Dengan quiz 45 soal, latihan praktek, dan sertifikat PDF profesional.
          </p>

          <div className="flex flex-col sm:flex-row gap-3 justify-center mb-16">
            <Link href="/register" className="btn btn-primary text-base px-8 py-3.5 rounded-xl">
              🚀 Mulai Belajar Gratis
            </Link>
            <Link href="/path" className="btn btn-outline text-base px-8 py-3.5 rounded-xl border-white/10 text-slate-300 hover:text-white hover:border-white/20">
              🗺️ Lihat Learning Path
            </Link>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 max-w-2xl mx-auto stagger">
            {STATS.map(s => (
              <div key={s.label} className="p-4 rounded-2xl bg-white/[0.03] border border-white/[0.06] animate-fade-up">
                <div className="text-2xl mb-1.5">{s.icon}</div>
                <div className="text-xl font-black text-white">{s.n}</div>
                <div className="text-xs text-slate-500 mt-0.5">{s.label}</div>
              </div>
            ))}
          </div>

          {/* Scroll hint */}
          <div className="mt-16 flex flex-col items-center text-slate-700 animate-bounce-slow">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M19 9l-7 7-7-7" />
            </svg>
          </div>
        </div>
      </section>

      {/* ── LEARNING PATHS ── */}
      <section className="py-24 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="mb-12">
            <p className="section-label">Learning Path</p>
            <h2 className="section-title">Jalur Belajar Terstruktur</h2>
            <p className="section-desc">Tidak perlu bingung mulai dari mana. Ikuti jalur belajar yang sudah disusun step-by-step.</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {PATHS.map((p, i) => (
              <Link key={i} href="/path" className="group p-5 rounded-2xl bg-[#0f172a] border border-white/[0.06] hover:border-violet-500/30 transition-all hover:-translate-y-1">
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${p.color} flex items-center justify-center text-2xl mb-4 shadow-lg`}>
                  {p.icon}
                </div>
                <h3 className="font-bold text-white mb-3 group-hover:text-violet-300 transition-colors">{p.title}</h3>
                <ol className="space-y-1.5">
                  {p.steps.map((s, j) => (
                    <li key={j} className="flex items-center gap-2 text-xs text-slate-500">
                      <span className="w-4 h-4 rounded-full bg-violet-500/15 text-violet-400 flex items-center justify-center text-[10px] font-bold flex-shrink-0">{j + 1}</span>
                      {s}
                    </li>
                  ))}
                </ol>
                <div className="mt-4 pt-3 border-t border-white/[0.04] text-xs text-violet-400 font-semibold group-hover:text-violet-300">
                  Mulai Path →
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* ── MATERI ── */}
      <section className="py-24 px-4 bg-[#070d1e]">
        <div className="max-w-6xl mx-auto">
          <div className="flex items-end justify-between mb-10 flex-wrap gap-4">
            <div>
              <p className="section-label">Kurikulum</p>
              <h2 className="section-title">17+ Materi Lengkap</h2>
            </div>
            <Link href="/materi" className="text-sm font-semibold text-violet-400 hover:text-violet-300 transition-colors">
              Lihat semua →
            </Link>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {MATERI_LIST.slice(0, 6).map((m, i) => (
              <Link key={m.slug} href={`/materi/${m.slug}`}
                className="group flex gap-4 p-4 rounded-2xl bg-[#0f172a] border border-white/[0.06] hover:border-violet-500/25 transition-all hover:bg-[#141f35]">
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${m.color} flex items-center justify-center text-2xl flex-shrink-0 shadow-lg`}>
                  {m.icon}
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-bold text-white text-sm group-hover:text-violet-300 transition-colors mb-1">{m.title}</h3>
                  <p className="text-slate-500 text-xs leading-relaxed line-clamp-2">{m.description}</p>
                  <div className="flex items-center gap-2 mt-2">
                    <span className="badge badge-purple">{m.level}</span>
                    <span className="text-[10px] text-slate-600">⏱ {m.duration}</span>
                    <span className="text-[10px] text-violet-500 ml-auto font-bold">+{m.xp} XP</span>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* ── HOW IT WORKS ── */}
      <section className="py-24 px-4">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-14">
            <p className="section-label">Cara Kerja</p>
            <h2 className="section-title">Belajar Sampai Sertifikat</h2>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 relative">
            {[
              { step: '01', title: 'Daftar Gratis', desc: 'Buat akun dalam 30 detik. Tidak perlu kartu kredit.', icon: '👤' },
              { step: '02', title: 'Pilih Materi', desc: 'Pilih dari 17+ materi atau ikuti learning path yang sudah tersedia.', icon: '📚' },
              { step: '03', title: 'Kerjakan Quiz', desc: '45 soal + 5 latihan praktek per materi. Nilai min 85% untuk sertifikat.', icon: '🧠' },
              { step: '04', title: 'Dapat Sertifikat', desc: 'Download sertifikat PDF profesional dengan QR verifikasi unik.', icon: '📜' },
            ].map((s, i) => (
              <div key={i} className="relative text-center p-6 rounded-2xl bg-[#0f172a] border border-white/[0.06]">
                <div className="w-12 h-12 rounded-2xl bg-violet-500/10 border border-violet-500/20 flex items-center justify-center text-2xl mx-auto mb-4">{s.icon}</div>
                <div className="text-xs font-black text-violet-500 mb-2 tracking-widest">{s.step}</div>
                <h3 className="font-bold text-white mb-2">{s.title}</h3>
                <p className="text-slate-500 text-xs leading-relaxed">{s.desc}</p>
                {i < 3 && (
                  <div className="hidden sm:block absolute top-1/2 -right-2 text-slate-700 text-lg z-10">→</div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── GAMIFICATION ── */}
      <section className="py-24 px-4 bg-[#070d1e]">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-12">
            <p className="section-label">Gamifikasi</p>
            <h2 className="section-title">Belajar Lebih Seru</h2>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { icon: '⚡', title: 'Sistem XP', desc: 'Dapat XP setiap selesai materi dan quiz' },
              { icon: '👑', title: '4 Level', desc: 'Beginner → Intermediate → Pro → Master' },
              { icon: '🏆', title: 'Leaderboard', desc: 'Bersaing dengan ribuan pelajar lain' },
              { icon: '🔥', title: 'Daily Streak', desc: 'Login tiap hari, pertahankan streak-mu' },
              { icon: '🏅', title: 'Badge Koleksi', desc: '10+ badge unik untuk setiap pencapaian' },
              { icon: '📜', title: 'Sertifikat PDF', desc: 'Sertifikat profesional dengan QR verifikasi' },
              { icon: '💻', title: 'Code Editor', desc: 'Latihan langsung di browser, tanpa install' },
              { icon: '💬', title: 'Forum Diskusi', desc: 'Tanya jawab dengan sesama pelajar' },
            ].map((f, i) => (
              <div key={i} className="p-5 rounded-xl bg-[#0f172a] border border-white/[0.06] hover:border-violet-500/20 transition-all group">
                <div className="text-3xl mb-3">{f.icon}</div>
                <h3 className="font-bold text-white text-sm mb-1 group-hover:text-violet-300 transition-colors">{f.title}</h3>
                <p className="text-slate-500 text-xs leading-relaxed">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── TESTIMONIALS ── */}
      <section className="py-24 px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <p className="section-label">Testimoni</p>
            <h2 className="section-title">Kata Mereka</h2>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {TESTIMONIALS.map((t, i) => (
              <div key={i} className="p-5 rounded-2xl bg-[#0f172a] border border-white/[0.06]">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center text-white font-bold text-sm flex-shrink-0">
                    {t.avatar}
                  </div>
                  <div>
                    <p className="font-bold text-white text-sm">{t.name}</p>
                    <p className="text-xs text-slate-500">{t.role}</p>
                  </div>
                </div>
                <div className="text-yellow-400 text-sm mb-3">★★★★★</div>
                <p className="text-slate-400 text-sm leading-relaxed">"{t.text}"</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA ── */}
      <section className="py-24 px-4">
        <div className="max-w-3xl mx-auto">
          <div className="relative p-10 rounded-3xl overflow-hidden text-center border border-violet-500/20 bg-gradient-to-br from-violet-900/20 to-purple-900/10">
            <div className="absolute inset-0 opacity-10 bg-gradient-to-br from-violet-600 to-purple-600" />
            <div className="relative">
              <div className="text-5xl mb-4">🚀</div>
              <h2 className="text-3xl font-black text-white mb-3">Siap Jadi Developer Pro?</h2>
              <p className="text-slate-400 mb-8">Bergabung sekarang. Gratis, tanpa kartu kredit.</p>
              {user ? (
                <Link href="/dashboard" className="btn btn-primary text-base px-8 py-3.5 rounded-xl">
                  Lanjut Belajar →
                </Link>
              ) : (
                <Link href="/register" className="btn btn-primary text-base px-8 py-3.5 rounded-xl">
                  Daftar Sekarang — Gratis
                </Link>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* ── CREDITS ── */}
      <section className="py-20 px-4 bg-[#070d1e]">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <p className="section-label">Tim</p>
            <h2 className="section-title">Terima Kasih 🙏</h2>
            <p className="section-desc mx-auto text-center">Orang-orang hebat di balik CodeBook.</p>
          </div>

          {/* Developer */}
          <div className="flex justify-center mb-6">
            <div className="relative p-6 rounded-2xl bg-[#0f172a] border border-violet-500/30 text-center w-56 group hover:border-violet-400/50 transition-all">
              <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-violet-600/5 to-purple-600/5 opacity-0 group-hover:opacity-100 transition-opacity" />
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-violet-600 to-purple-700 flex items-center justify-center text-3xl mx-auto mb-3 shadow-xl shadow-violet-500/25">👨‍💻</div>
              <p className="font-black text-white tracking-wide mb-1">SHADOWNEX</p>
              <span className="badge badge-purple">Founder & Developer</span>
              <p className="text-slate-500 text-xs mt-2">Membangun CodeBook dari nol</p>
            </div>
          </div>

          {/* Bug hunters & Support */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
            {CREDITS.filter(c => c.name !== 'SHADOWNEX').map((c, i) => (
              <div key={i} className="p-4 rounded-2xl bg-[#0f172a] border border-white/[0.06] hover:border-white/10 text-center transition-all group">
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${c.color} flex items-center justify-center text-xl mx-auto mb-3 shadow-lg`}>
                  {c.icon}
                </div>
                <p className="font-bold text-white text-xs tracking-wide mb-1">{c.name}</p>
                <span className={`badge text-[10px] ${c.role === 'Bug Hunter' ? 'badge-red' : 'badge-blue'}`}>
                  {c.role}
                </span>
              </div>
            ))}
          </div>

          <div className="mt-8 text-center p-4 rounded-2xl bg-violet-600/5 border border-violet-500/10">
            <p className="text-slate-500 text-sm">💜 Terima kasih telah menjadi bagian dari perjalanan CodeBook untuk komunitas developer Indonesia.</p>
          </div>
        </div>
      </section>

      {/* ── FOOTER ── */}
      <footer className="py-10 px-4 border-t border-white/[0.06]">
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-violet-600 to-purple-700 flex items-center justify-center text-white font-black text-sm">CB</div>
              <div>
                <span className="font-black text-white">Code<span className="text-violet-400">Book</span></span>
                <p className="text-xs text-slate-600 mt-0.5">Platform Belajar Coding Indonesia</p>
              </div>
            </div>
            <div className="flex flex-wrap gap-x-6 gap-y-2 justify-center text-sm text-slate-600">
              {[
                { href: '/workshop', label: 'Workshop' },
            { href: '/materi', label: 'Materi' },
                { href: '/path', label: 'Learning Path' },
                { href: '/quiz', label: 'Quiz' },
                { href: '/leaderboard', label: 'Leaderboard' },
                { href: '/forum', label: 'Forum' },
                { href: '/verify/CB-XXXX', label: 'Verifikasi' },
              ].map(l => (
                <Link key={l.href} href={l.href} className="hover:text-slate-400 transition-colors">{l.label}</Link>
              ))}
            </div>
          </div>
          <div className="mt-8 pt-6 border-t border-white/[0.04] text-center text-xs text-slate-700">
            © 2024 CodeBook — Built with ❤️ by ShadowNex. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  )
}
