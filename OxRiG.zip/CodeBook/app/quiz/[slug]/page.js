'use client'
import { useState, useEffect } from 'react'
import { useParams, useRouter } from 'next/navigation'
import Link from 'next/link'
import Navbar from '@/components/layout/Navbar'
import { QUIZ_DATA } from '@/data/quiz'
import toast from 'react-hot-toast'

export default function QuizDetailPage() {
  const { slug } = useParams()
  const router = useRouter()
  const [answers, setAnswers] = useState({})
  const [submitted, setSubmitted] = useState(false)
  const [score, setScore] = useState(0)
  const [saving, setSaving] = useState(false)
  const [current, setCurrent] = useState(0)
  const [prevBest, setPrevBest] = useState(null)

  const quiz = QUIZ_DATA.find(q => q.slug === slug)

  useEffect(() => {
    const s = localStorage.getItem('cb_user')
    if (s) {
      const u = JSON.parse(s)
      const records = (u.completedQuiz || []).filter(q => q.quizId === quiz?.id)
      const best = records.sort((a,b) => b.score - a.score)[0]
      if (best) setPrevBest(best.score)
    }
  }, [quiz])

  if (!quiz) return (
    <div className="min-h-screen bg-[#020617] flex items-center justify-center">
      <div className="text-center">
        <div className="text-5xl mb-4">🔍</div>
        <p className="text-white font-bold mb-3">Quiz tidak ditemukan</p>
        <Link href="/quiz" className="text-violet-400">← Kembali ke Quiz</Link>
      </div>
    </div>
  )

  const totalQ = quiz.questions.length
  const question = quiz.questions[current]
  const progress = (Object.keys(answers).length / totalQ) * 100
  const passed = score >= quiz.minScore

  const handleAnswer = (qid, idx) => {
    if (submitted) return
    setAnswers(p => ({ ...p, [qid]: idx }))
  }

  const handleSubmit = async () => {
    if (Object.keys(answers).length < totalQ) {
      toast.error(`Jawab semua ${totalQ} soal dulu!`)
      return
    }
    let correct = 0
    quiz.questions.forEach(q => { if (answers[q.id] === q.correct) correct++ })
    const finalScore = Math.round((correct / totalQ) * 100)
    setScore(finalScore)
    setSubmitted(true)

    setSaving(true)
    try {
      const xpEarned = Math.round((finalScore / 100) * quiz.xp)
      const res = await fetch('/api/quiz', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ quizId: quiz.id, score: finalScore, xpEarned, isPerfect: finalScore === 100 }),
      })
      const data = await res.json()
      if (data.success) {
        const stored = localStorage.getItem('cb_user')
        if (stored) {
          const u = JSON.parse(stored)
          localStorage.setItem('cb_user', JSON.stringify({
            ...u, xp: data.user.xp,
            completedQuiz: data.user.completedQuiz,
            badges: data.user.badges,
          }))
        }
        if (finalScore >= quiz.minScore) toast.success(`Lulus! +${xpEarned} XP 🎉 Sekarang bisa tandai materi selesai!`)
        else toast.error(`Nilai ${finalScore}% — perlu ${quiz.minScore}% untuk unlock XP & sertifikat`)
        setPrevBest(prev => prev === null ? finalScore : Math.max(prev, finalScore))
      }
    } catch { toast.error('Gagal menyimpan hasil') }
    finally { setSaving(false) }
  }

  const handleRetry = () => {
    setAnswers({}); setSubmitted(false); setScore(0); setCurrent(0)
  }

  return (
    <div className="min-h-screen bg-[#020617]">
      <Navbar />
      <div className="max-w-2xl mx-auto px-4 py-24">

        {/* Header */}
        <div className="flex items-center gap-3 mb-6">
          <Link href="/quiz" className="p-2 rounded-xl text-slate-600 hover:text-slate-400 hover:bg-white/[0.05] transition-all">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" /></svg>
          </Link>
          <div className="flex-1 min-w-0">
            <h1 className="font-black text-white truncate">{quiz.title}</h1>
            <div className="flex items-center gap-3 text-xs text-slate-600 mt-0.5">
              <span>{totalQ} soal</span>
              <span>•</span>
              <span className="text-yellow-400 font-semibold">Min {quiz.minScore}% → unlock XP & sertifikat</span>
              {prevBest !== null && (
                <><span>•</span>
                <span className={prevBest >= quiz.minScore ? 'text-emerald-400' : 'text-orange-400'}>
                  Terbaik: {prevBest}%
                </span></>
              )}
            </div>
          </div>
        </div>

        {/* Info box */}
        <div className="mb-5 p-3.5 rounded-xl bg-violet-500/8 border border-violet-500/20 flex items-start gap-2.5">
          <span className="text-lg flex-shrink-0">💡</span>
          <p className="text-xs text-violet-300">
            <strong>Perhatian:</strong> Nilai ≥{quiz.minScore}% diperlukan untuk mendapatkan XP, menandai materi selesai, dan mendapatkan sertifikat.
          </p>
        </div>

        {!submitted ? (
          <>
            {/* Progress */}
            <div className="mb-6">
              <div className="flex justify-between text-xs text-slate-600 mb-2">
                <span>Soal {current + 1} dari {totalQ}</span>
                <span className="text-violet-400 font-bold">{Object.keys(answers).length}/{totalQ} dijawab</span>
              </div>
              <div className="w-full h-2 bg-slate-900 rounded-full overflow-hidden">
                <div className="h-full bg-gradient-to-r from-violet-600 to-purple-500 rounded-full transition-all duration-500" style={{ width: `${progress}%` }} />
              </div>
            </div>

            {/* Question */}
            <div className="p-6 rounded-2xl bg-[#0f172a] border border-white/[0.06] mb-4">
              <div className="flex items-start gap-3 mb-5">
                <span className="flex-shrink-0 w-7 h-7 rounded-full bg-violet-600 text-white text-xs font-black flex items-center justify-center">{current+1}</span>
                <p className="text-white font-semibold leading-relaxed text-sm">{question.question}</p>
              </div>
              <div className="space-y-2.5">
                {question.options.map((opt, idx) => (
                  <button key={idx} onClick={() => handleAnswer(question.id, idx)}
                    className={`w-full text-left px-4 py-3 rounded-xl text-sm transition-all border ${
                      answers[question.id] === idx
                        ? 'bg-violet-600/15 border-violet-500/40 text-violet-300'
                        : 'bg-[#1e293b] border-white/[0.06] text-slate-400 hover:border-white/10 hover:text-slate-200'
                    }`}>
                    <span className="inline-flex items-center gap-3">
                      <span className={`w-6 h-6 rounded-full border flex-shrink-0 flex items-center justify-center text-xs font-bold ${answers[question.id] === idx ? 'bg-violet-600 border-violet-600 text-white' : 'border-slate-600 text-slate-600'}`}>
                        {answers[question.id] === idx ? '✓' : String.fromCharCode(65+idx)}
                      </span>
                      {opt}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Navigation */}
            <div className="flex items-center gap-2">
              <button onClick={() => setCurrent(p => Math.max(0, p-1))} disabled={current === 0}
                className="px-4 py-2.5 rounded-xl text-sm text-slate-400 bg-[#0f172a] border border-white/[0.06] disabled:opacity-30 hover:border-white/10 hover:text-slate-200 transition-all disabled:cursor-not-allowed">
                ← Prev
              </button>

              {/* Question dots */}
              <div className="flex-1 flex gap-1 flex-wrap justify-center max-h-16 overflow-y-auto py-0.5" style={{scrollbarWidth:'none'}}>
                {quiz.questions.map((q, i) => (
                  <button key={i} onClick={() => setCurrent(i)}
                    className={`w-6 h-6 rounded text-[10px] font-bold transition-all flex-shrink-0 ${
                      i === current ? 'bg-violet-600 text-white' :
                      answers[q.id] !== undefined ? 'bg-violet-600/20 text-violet-400' :
                      'bg-slate-900 text-slate-600 hover:text-slate-400'
                    }`}>
                    {i+1}
                  </button>
                ))}
              </div>

              {current < totalQ-1 ? (
                <button onClick={() => setCurrent(p => p+1)}
                  className="px-4 py-2.5 rounded-xl text-sm font-bold bg-violet-600 hover:bg-violet-500 text-white transition-all">
                  Next →
                </button>
              ) : (
                Object.keys(answers).length < totalQ ? (
                  <button onClick={() => {
                    const firstUnanswered = quiz.questions.findIndex(q => answers[q.id] === undefined)
                    if (firstUnanswered !== -1) setCurrent(firstUnanswered)
                  }}
                    className="px-4 py-2.5 rounded-xl text-sm font-bold bg-orange-600 hover:bg-orange-500 text-white transition-all">
                    ⚠️ {totalQ - Object.keys(answers).length} belum dijawab
                  </button>
                ) : (
                  <button onClick={handleSubmit} disabled={saving}
                    className="px-4 py-2.5 rounded-xl text-sm font-bold bg-emerald-600 hover:bg-emerald-500 text-white transition-all disabled:opacity-50">
                    {saving ? 'Menyimpan...' : '✓ Submit'}
                  </button>
                )
              )}
            </div>
          </>
        ) : (
          /* RESULT */
          <div>
            <div className={`p-8 rounded-2xl border text-center mb-6 ${passed ? 'bg-emerald-500/5 border-emerald-500/25' : 'bg-red-500/5 border-red-500/20'}`}>
              <div className={`w-28 h-28 rounded-full mx-auto mb-5 flex items-center justify-center text-5xl border-4 ${passed ? 'border-emerald-500/40 bg-emerald-500/10' : 'border-red-500/30 bg-red-500/10'}`}>
                {score === 100 ? '👑' : passed ? '🎉' : score >= 70 ? '⚡' : '📚'}
              </div>
              <div className="text-5xl font-black text-white mb-2">{score}%</div>
              <div className={`text-lg font-black mb-2 ${passed ? 'text-emerald-400' : 'text-red-400'}`}>
                {passed ? `✓ LULUS! (min ${quiz.minScore}%)` : `✗ Belum Lulus (min ${quiz.minScore}%)`}
              </div>
              {passed ? (
                <div className="mt-3 p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20">
                  <p className="text-emerald-300 text-sm font-semibold">🎯 XP Unlocked! Kamu bisa tandai materi selesai & ambil sertifikat.</p>
                </div>
              ) : (
                <div className="mt-3 p-3 rounded-xl bg-red-500/10 border border-red-500/20">
                  <p className="text-red-300 text-sm">📚 Pelajari lagi materinya dan coba ulang quiz.</p>
                  <p className="text-slate-500 text-xs mt-1">XP & sertifikat akan unlock setelah nilai ≥{quiz.minScore}%</p>
                </div>
              )}
              <p className="text-slate-500 text-sm mt-3">
                {passed ? `+${Math.round((score/100) * quiz.xp)} XP didapat` : `Perlu ${quiz.minScore - score}% lagi untuk lulus`}
              </p>
            </div>

            {/* Answer review */}
            <div className="space-y-2 mb-6">
              <p className="text-sm font-bold text-slate-400 mb-3">Review Jawaban</p>
              {quiz.questions.slice(0, 15).map((q, i) => {
                const isRight = answers[q.id] === q.correct
                return (
                  <div key={q.id} className={`p-3.5 rounded-xl border text-sm ${isRight ? 'bg-emerald-500/5 border-emerald-500/15' : 'bg-red-500/5 border-red-500/15'}`}>
                    <div className="flex items-start gap-2">
                      <span className="flex-shrink-0">{isRight ? '✅' : '❌'}</span>
                      <div>
                        <p className="text-slate-300 text-xs font-semibold mb-1">{i+1}. {q.question}</p>
                        {!isRight && <p className="text-emerald-400 text-xs">✓ {q.options[q.correct]}</p>}
                      </div>
                    </div>
                  </div>
                )
              })}
              {totalQ > 15 && <p className="text-xs text-slate-600 text-center">... dan {totalQ-15} soal lainnya</p>}
            </div>

            <div className="flex gap-3 flex-wrap">
              <button onClick={handleRetry} className="px-5 py-2.5 rounded-xl text-sm text-slate-400 bg-[#0f172a] border border-white/[0.06] hover:text-white transition-all">
                🔄 Coba Lagi
              </button>
              {passed ? (
                <>
                  <Link href={`/materi/${slug}`} className="px-5 py-2.5 rounded-xl text-sm font-bold bg-emerald-600 hover:bg-emerald-500 text-white transition-all">
                    📚 Tandai Materi Selesai
                  </Link>
                  <Link href="/sertifikat" className="px-5 py-2.5 rounded-xl text-sm font-bold bg-violet-600 hover:bg-violet-500 text-white transition-all">
                    📜 Ambil Sertifikat
                  </Link>
                </>
              ) : (
                <Link href={`/materi/${slug}`} className="px-5 py-2.5 rounded-xl text-sm font-bold bg-violet-600/80 hover:bg-violet-600 text-white transition-all">
                  📖 Pelajari Lagi
                </Link>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
