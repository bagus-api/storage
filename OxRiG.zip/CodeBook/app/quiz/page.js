'use client'
import Link from 'next/link'
import { useEffect, useState } from 'react'
import Navbar from '@/components/layout/Navbar'
import { QUIZ_DATA } from '@/data/quiz'

export default function QuizListPage() {
  const [user, setUser] = useState(null)
  useEffect(() => {
    const s = localStorage.getItem('cb_user')
    if (s) setUser(JSON.parse(s))
  }, [])

  const completedIds = new Set((user?.completedQuiz || []).map(q => q.quizId))

  return (
    <div className="min-h-screen bg-[#0a0b14]">
      <Navbar />
      <div className="max-w-4xl mx-auto px-4 py-24">
        <div className="mb-10">
          <p className="text-[#8095ff] text-sm font-medium mb-2 tracking-wide uppercase">Evaluasi</p>
          <h1 className="text-3xl sm:text-4xl font-bold text-white mb-3">Quiz Interaktif</h1>
          <p className="text-slate-500">45 soal pilihan ganda per quiz. Nilai minimal <span className="text-yellow-400 font-semibold">85%</span> untuk sertifikat.</p>
        </div>

        <div className="grid gap-4">
          {QUIZ_DATA.map((quiz) => {
            const done = completedIds.has(quiz.id)
            const record = (user?.completedQuiz || []).filter(q => q.quizId === quiz.id).sort((a,b) => b.score - a.score)[0]
            const passed = record && record.score >= 85
            return (
              <Link key={quiz.id} href={`/quiz/${quiz.slug}`}
                className="group flex items-center gap-5 p-5 rounded-2xl bg-[#0f1117] border border-white/[0.06] hover:border-[#6171f5]/30 transition-all hover:bg-[#111324]">
                <div className={`w-14 h-14 rounded-2xl flex items-center justify-center text-2xl flex-shrink-0 ${passed ? 'bg-emerald-500/15 border border-emerald-500/25' : done ? 'bg-yellow-500/10 border border-yellow-500/20' : 'bg-[#1a1d2e] border border-white/[0.06]'}`}>
                  {passed ? '✅' : done ? '🔄' : '📝'}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-3 flex-wrap">
                    <h3 className="font-semibold text-white group-hover:text-[#a5bbff] transition-colors">{quiz.title}</h3>
                    {record && (
                      <span className={`text-xs px-2 py-0.5 rounded-full border ${passed ? 'bg-emerald-500/15 text-emerald-400 border-emerald-500/20' : 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20'}`}>
                        {record.score}% {passed ? '✓ Lulus' : `(min ${quiz.minScore}%)`}
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-3 mt-1.5 text-xs text-slate-600 flex-wrap">
                    <span>📝 {quiz.questions.length} soal</span>
                    <span>•</span>
                    <span className="text-[#8095ff]">+{quiz.xp} XP</span>
                    <span>•</span>
                    <span className="text-yellow-500">Min: {quiz.minScore}% untuk sertifikat</span>
                  </div>
                </div>
                <svg className="w-5 h-5 text-slate-700 group-hover:text-[#6171f5] flex-shrink-0 transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </Link>
            )
          })}
        </div>

        <div className="mt-8 p-4 rounded-2xl bg-[#6171f5]/5 border border-[#6171f5]/15 text-sm text-slate-500">
          <span className="text-[#8095ff] font-medium">💡 Tips:</span> Selesaikan materi terlebih dahulu sebelum mengerjakan quiz. Nilai ≥85% diperlukan untuk mendapatkan sertifikat.
        </div>
      </div>
    </div>
  )
}
