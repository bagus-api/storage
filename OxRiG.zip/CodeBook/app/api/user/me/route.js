import { NextResponse } from 'next/server'
import { connectDB } from '@/lib/mongodb'
import User from '@/models/User'
import { getCurrentUser } from '@/lib/auth'
import { apiLimiter, getIP, rateLimitResponse } from '@/lib/security'

export async function GET(request) {
  const ip = getIP(request)
  const limit = apiLimiter(ip)
  if (!limit.allowed) return rateLimitResponse(limit.retryAfter)

  try {
    const decoded = await getCurrentUser(request)
    if (!decoded) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

    await connectDB()
    const user = await User.findById(decoded.userId).select('-password -__v')
    if (!user) return NextResponse.json({ error: 'User tidak ditemukan' }, { status: 404 })

    return NextResponse.json({ success: true, user })
  } catch (err) {
    return NextResponse.json({ error: 'Server error' }, { status: 500 })
  }
}
