import { NextResponse } from 'next/server'
import { connectChatDB } from '@/lib/chatdb'
import { getCurrentUser } from '@/lib/auth'
import { sanitizeString, apiLimiter, getIP, rateLimitResponse } from '@/lib/security'
import mongoose from 'mongoose'

const MSG_SCHEMA = new mongoose.Schema({
  room: { type: String, default: 'general' },
  authorId: String,
  authorName: String,
  content: { type: String, maxlength: 1000 },
  type: { type: String, default: 'text' },
  createdAt: { type: Date, default: Date.now },
})

async function getModel() {
  const conn = await connectChatDB()
  return conn.models.ChatMessage || conn.model('ChatMessage', MSG_SCHEMA)
}

export async function GET(request) {
  const ip = getIP(request)
  const rl = apiLimiter(ip)
  if (!rl.allowed) return rateLimitResponse(rl.retryAfter)

  try {
    const { searchParams } = new URL(request.url)
    const room = sanitizeString(searchParams.get('room') || 'general')
    const after = searchParams.get('after') // ISO timestamp for polling

    const Msg = await getModel()
    const filter = { room }
    if (after) filter.createdAt = { $gt: new Date(after) }

    const msgs = await Msg.find(filter)
      .sort({ createdAt: after ? 1 : -1 })
      .limit(after ? 100 : 60)
      .lean()

    return NextResponse.json({
      success: true,
      messages: after ? msgs : msgs.reverse(),
      serverTime: new Date(),
    })
  } catch (err) {
    console.error('Chat GET error:', err.message)
    return NextResponse.json({ error: 'Gagal memuat pesan' }, { status: 500 })
  }
}

export async function POST(request) {
  const ip = getIP(request)
  // Stricter rate limit for chat: 20 msg/minute
  const chatKey = `chat:${ip}`

  try {
    const user = await getCurrentUser(request)
    if (!user) return NextResponse.json({ error: 'Login dulu untuk chat' }, { status: 401 })

    const body = await request.json()
    const content = sanitizeString(body.content || '').trim()
    const room = sanitizeString(body.room || 'general')

    if (!content) return NextResponse.json({ error: 'Pesan tidak boleh kosong' }, { status: 400 })
    if (content.length < 1) return NextResponse.json({ error: 'Pesan terlalu pendek' }, { status: 400 })

    const VALID_ROOMS = ['general', 'materi', 'cybersecurity', 'frontend', 'backend', 'tantangan']
    if (!VALID_ROOMS.includes(room)) return NextResponse.json({ error: 'Room tidak valid' }, { status: 400 })

    const Msg = await getModel()
    const msg = await Msg.create({
      room,
      authorId: user.userId,
      authorName: user.name,
      content,
    })

    return NextResponse.json({ success: true, message: msg }, { status: 201 })
  } catch (err) {
    console.error('Chat POST error:', err.message)
    return NextResponse.json({ error: 'Gagal kirim pesan' }, { status: 500 })
  }
}
