import { NextResponse } from 'next/server'
import { connectDB } from '@/lib/mongodb'
import Certificate from '@/models/Certificate'
import { sanitizeString, detectMaliciousInput, securityHeaders } from '@/lib/security'

export async function GET(request, { params }) {
  try {
    const { id } = params
    if (!id || detectMaliciousInput(id)) {
      return securityHeaders(NextResponse.json({ valid: false, error: 'ID tidak valid' }, { status: 400 }))
    }
    const cleanId = sanitizeString(id).slice(0, 30)

    await connectDB()
    const cert = await Certificate.findOne({ certId: cleanId })
    if (!cert) return securityHeaders(NextResponse.json({ valid: false, error: 'Sertifikat tidak ditemukan' }, { status: 404 }))

    return securityHeaders(NextResponse.json({
      valid: true,
      certificate: {
        certId: cert.certId,
        userName: cert.userName,
        courseName: cert.courseName,
        quizScore: cert.quizScore,
        issuedAt: cert.issuedAt,
      }
    }))
  } catch (err) {
    return securityHeaders(NextResponse.json({ valid: false, error: 'Server error' }, { status: 500 }))
  }
}
