import { NextResponse } from 'next/server'
import { connectDB } from '@/lib/mongodb'
import User from '@/models/User'
import Certificate from '@/models/Certificate'
import { getCurrentUser } from '@/lib/auth'
import { sanitizeString, apiLimiter, getIP, rateLimitResponse } from '@/lib/security'

function generateCertId() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'
  const seg = () => Array.from({ length: 4 }, () => chars[Math.floor(Math.random() * chars.length)]).join('')
  return `CB-${seg()}-${seg()}-${seg()}`
}

export async function POST(request) {
  const ip = getIP(request)
  const limit = apiLimiter(ip)
  if (!limit.allowed) return rateLimitResponse(limit.retryAfter)

  try {
    const decoded = await getCurrentUser(request)
    if (!decoded) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

    const body = await request.json()
    const courseSlug = sanitizeString(body.courseSlug || '')
    const courseName = sanitizeString(body.courseName || '')

    if (!courseSlug || !courseName)
      return NextResponse.json({ error: 'Data kursus tidak lengkap' }, { status: 400 })

    await connectDB()
    const user = await User.findById(decoded.userId)
    if (!user) return NextResponse.json({ error: 'User tidak ditemukan' }, { status: 404 })

    // Cek materi sudah selesai
    if (!user.completedMateri.includes(courseSlug))
      return NextResponse.json({ error: 'Selesaikan materi ini dulu!' }, { status: 403 })

    // Cek quiz sudah lulus (≥85%)
    const quizRecord = (user.completedQuiz || [])
      .filter(q => q.quizId === `quiz-${courseSlug}` || q.quizId.includes(courseSlug))
      .sort((a, b) => b.score - a.score)[0]

    if (!quizRecord || quizRecord.score < 85)
      return NextResponse.json({
        error: `Kamu perlu nilai quiz minimal 85% untuk mendapatkan sertifikat. ${quizRecord ? `Nilai terbaik kamu: ${quizRecord.score}%` : 'Kerjakan quiz dulu!'}`,
        quizScore: quizRecord?.score || 0
      }, { status: 403 })

    // Cek duplikat
    const existing = await Certificate.findOne({ userId: decoded.userId, courseSlug })
    if (existing) return NextResponse.json({ success: true, certificate: existing, alreadyExists: true })

    const certId = generateCertId()
    const cert = await Certificate.create({
      certId,
      userId: decoded.userId,
      userName: user.name,
      courseName,
      courseSlug,
      quizScore: quizRecord.score,
      domain: process.env.NEXT_PUBLIC_BASE_URL || 'https://codebook.vercel.app',
    })

    const update = { $addToSet: { certificates: certId } }
    if (!user.badges.includes('first_cert')) {
      update.$addToSet.badges = 'first_cert'
    }
    await User.findByIdAndUpdate(decoded.userId, update)

    return NextResponse.json({ success: true, certificate: cert })
  } catch (err) {
    console.error(err)
    return NextResponse.json({ error: 'Server error' }, { status: 500 })
  }
}
