import { NextResponse } from 'next/server'
import { connectDB } from '@/lib/mongodb'
import Thread from '@/models/Thread'
import { getCurrentUser } from '@/lib/auth'

export async function POST(request, { params }) {
  try {
    const user = await getCurrentUser(request)
    if (!user) return NextResponse.json({ error: 'Login dulu' }, { status: 401 })

    const { dir } = await request.json()  // 1 or -1
    if (dir !== 1 && dir !== -1) return NextResponse.json({ error: 'Invalid' }, { status: 400 })

    await connectDB()
    const thread = await Thread.findByIdAndUpdate(
      params.id,
      { $inc: { votes: dir } },
      { new: true, select: 'votes' }
    )
    if (!thread) return NextResponse.json({ error: 'Thread tidak ditemukan' }, { status: 404 })

    return NextResponse.json({ success: true, votes: thread.votes })
  } catch {
    return NextResponse.json({ error: 'Server error' }, { status: 500 })
  }
}
