import { NextResponse } from 'next/server'
import { connectDB } from '@/lib/mongodb'
import Thread from '@/models/Thread'
import { getCurrentUser } from '@/lib/auth'
import { sanitizeString, apiLimiter, getIP, rateLimitResponse } from '@/lib/security'

// GET thread detail
export async function GET(request, { params }) {
  try {
    await connectDB()
    const thread = await Thread.findByIdAndUpdate(
      params.id,
      { $inc: { views: 1 } },
      { new: true }
    ).lean()

    if (!thread) return NextResponse.json({ error: 'Thread tidak ditemukan' }, { status: 404 })
    return NextResponse.json({ success: true, thread })
  } catch {
    return NextResponse.json({ error: 'Server error' }, { status: 500 })
  }
}
