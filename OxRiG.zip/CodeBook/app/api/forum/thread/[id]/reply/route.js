import { NextResponse } from 'next/server'
import { connectDB } from '@/lib/mongodb'
import Thread from '@/models/Thread'
import { getCurrentUser } from '@/lib/auth'
import { sanitizeString, apiLimiter, getIP, rateLimitResponse } from '@/lib/security'

export async function POST(request, { params }) {
  const ip = getIP(request)
  const rl = apiLimiter(ip)
  if (!rl.allowed) return rateLimitResponse(rl.retryAfter)

  try {
    const user = await getCurrentUser(request)
    if (!user) return NextResponse.json({ error: 'Login dulu' }, { status: 401 })

    const body = await request.json()
    const content = sanitizeString(body.content || '').trim()
    if (!content || content.length < 5) return NextResponse.json({ error: 'Balasan minimal 5 karakter' }, { status: 400 })

    await connectDB()
    const thread = await Thread.findByIdAndUpdate(
      params.id,
      {
        $push: { replies: { author: user.userId, authorName: user.name, content } },
        $set: { updatedAt: new Date() },
      },
      { new: true }
    )
    if (!thread) return NextResponse.json({ error: 'Thread tidak ditemukan' }, { status: 404 })

    const newReply = thread.replies[thread.replies.length - 1]
    return NextResponse.json({ success: true, reply: newReply })
  } catch (err) {
    console.error(err)
    return NextResponse.json({ error: 'Server error' }, { status: 500 })
  }
}
