import { NextResponse } from 'next/server'
import { connectDB } from '@/lib/mongodb'
import Thread from '@/models/Thread'
import { getCurrentUser } from '@/lib/auth'
import { sanitizeString, apiLimiter, getIP, rateLimitResponse } from '@/lib/security'

// GET threads
export async function GET(request) {
  const ip = getIP(request)
  const rl = apiLimiter(ip)
  if (!rl.allowed) return rateLimitResponse(rl.retryAfter)

  try {
    const { searchParams } = new URL(request.url)
    const cat = searchParams.get('cat') || 'all'
    const sort = searchParams.get('sort') || 'latest'  // latest | popular | unsolved
    const q = searchParams.get('q') || ''
    const page = Math.max(1, parseInt(searchParams.get('page') || '1'))
    const limit = 20

    await connectDB()

    const filter = {}
    if (cat !== 'all') filter.category = cat
    if (q) filter.$or = [
      { title: { $regex: q, $options: 'i' } },
      { tags: { $in: [new RegExp(q, 'i')] } },
    ]
    if (sort === 'unsolved') filter.solved = false

    const sortField = sort === 'popular' ? { votes: -1, views: -1 } : { isPinned: -1, createdAt: -1 }

    const [threads, total] = await Promise.all([
      Thread.find(filter)
        .sort(sortField)
        .skip((page - 1) * limit)
        .limit(limit)
        .select('title category tags authorName votes views solved isPinned createdAt updatedAt')
        .lean(),
      Thread.countDocuments(filter),
    ])

    // Add reply count
    const withCount = threads.map(t => ({
      ...t,
      replyCount: t.replies?.length || 0,
    }))

    return NextResponse.json({
      success: true,
      threads: withCount,
      total,
      page,
      pages: Math.ceil(total / limit),
      updatedAt: new Date(),
    })
  } catch (err) {
    console.error(err)
    return NextResponse.json({ error: 'Server error' }, { status: 500 })
  }
}

// POST - buat thread baru
export async function POST(request) {
  const ip = getIP(request)
  const rl = apiLimiter(ip)
  if (!rl.allowed) return rateLimitResponse(rl.retryAfter)

  try {
    const user = await getCurrentUser(request)
    if (!user) return NextResponse.json({ error: 'Login dulu untuk buat thread' }, { status: 401 })

    const body = await request.json()
    const title = sanitizeString(body.title || '').trim()
    const content = sanitizeString(body.content || '').trim()
    const category = sanitizeString(body.category || 'general')
    const tags = (body.tags || []).slice(0, 5).map(t => sanitizeString(t).toLowerCase())

    if (!title || title.length < 10) return NextResponse.json({ error: 'Judul minimal 10 karakter' }, { status: 400 })
    if (!content || content.length < 20) return NextResponse.json({ error: 'Isi thread minimal 20 karakter' }, { status: 400 })

    const VALID_CATS = ['html-css','javascript','react','backend','python','cybersecurity','database','git','general']
    if (!VALID_CATS.includes(category)) return NextResponse.json({ error: 'Kategori tidak valid' }, { status: 400 })

    await connectDB()

    const thread = await Thread.create({
      title,
      content,
      category,
      tags,
      author: user.userId,
      authorName: user.name,
    })

    return NextResponse.json({ success: true, thread }, { status: 201 })
  } catch (err) {
    console.error(err)
    return NextResponse.json({ error: 'Server error' }, { status: 500 })
  }
}
