import { NextResponse } from 'next/server'
import { connectDB } from '@/lib/mongodb'
import Thread from '@/models/Thread'
import mongoose from 'mongoose'

// Hanya bisa diakses sekali via GET /api/seed
// Untuk isi forum dengan data awal
export async function GET(request) {
  if (process.env.NODE_ENV === 'production') {
    // Di production, butuh secret key
    const url = new URL(request.url)
    const key = url.searchParams.get('key')
    if (key !== process.env.JWT_SECRET?.slice(0, 8)) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
    }
  }

  await connectDB()

  const count = await Thread.countDocuments()
  if (count > 0) {
    return NextResponse.json({ message: `Forum already has ${count} threads, skip seeding.` })
  }

  const fakeId = new mongoose.Types.ObjectId()
  const threads = [
    {
      title: 'Cara fix CORS error di Express.js saat deploy ke Vercel?',
      content: 'Halo semua!\n\nGue lagi deploy API Express.js ke Vercel, tapi pas di-hit dari frontend React dapet error:\n\n```\nAccess to XMLHttpRequest blocked by CORS policy\n```\n\nSudah coba pakai package `cors` tapi tetap error. Ada yang tau cara fix nya?\n\nIni kode Express ku:\n```javascript\nconst cors = require("cors")\napp.use(cors())\n```',
      authorName: 'DevBudi',
      author: fakeId,
      category: 'backend',
      tags: ['express', 'cors', 'vercel', 'api'],
      views: 142,
      votes: 8,
      solved: true,
      replies: [
        {
          authorName: 'FullstackRiz',
          author: fakeId,
          content: 'Masalahnya mungkin di konfigurasi cors. Coba spesifik origin-nya:\n\n```javascript\napp.use(cors({\n  origin: ["https://your-frontend.vercel.app", "http://localhost:3000"],\n  credentials: true,\n  methods: ["GET", "POST", "PUT", "DELETE"]\n}))\n```\n\nKalau masih error, cek juga di vercel.json untuk headers.',
          votes: 5,
          isSolution: true,
        },
        {
          authorName: 'NodeMaster',
          author: fakeId,
          content: 'Tambahan: di Vercel kalau pakai Next.js App Router, bisa set CORS di next.config.js lewat headers() function. Lebih clean daripada di Express.',
          votes: 3,
          isSolution: false,
        }
      ],
    },
    {
      title: 'useState vs useReducer — kapan sebaiknya pakai yang mana?',
      content: 'Hei teman-teman React!\n\nGue masih bingung kapan harus pakai `useState` dan kapan pakai `useReducer`. Keduanya kan buat manage state.\n\nAda yang bisa jelasin perbedaannya dengan contoh real case?',
      authorName: 'ReactNewbie',
      author: fakeId,
      category: 'react',
      tags: ['react', 'hooks', 'usestate', 'usereducer'],
      views: 234,
      votes: 12,
      solved: true,
      replies: [
        {
          authorName: 'ReactPro',
          author: fakeId,
          content: 'Simple rule:\n\n**Pakai useState kalau:**\n- State sederhana (string, boolean, number)\n- Maksimal 2-3 state yang tidak saling berkaitan\n\n**Pakai useReducer kalau:**\n- State berbentuk object kompleks\n- Banyak aksi yang bisa mengubah state\n- Logic update state saling berkaitan\n\n```javascript\n// useState - simple\nconst [count, setCount] = useState(0)\n\n// useReducer - kompleks\nconst [state, dispatch] = useReducer(reducer, {\n  count: 0,\n  loading: false,\n  error: null,\n  data: []\n})\n```',
          votes: 15,
          isSolution: true,
        }
      ],
    },
    {
      title: 'MongoDB Atlas connection timeout di Vercel Serverless Function',
      content: 'Bantu dong!\n\nApp Next.js gue koneksi ke MongoDB Atlas lancar di localhost, tapi setelah deploy ke Vercel sering timeout pas query pertama. Query kedua dan seterusnya lancar.\n\nIni connection code gue:\n```javascript\nmongoose.connect(process.env.MONGODB_URI)\n```\n\nAda yang pernah ngalamin masalah serupa?',
      authorName: 'NextDev',
      author: fakeId,
      category: 'database',
      tags: ['mongodb', 'vercel', 'serverless', 'mongoose', 'timeout'],
      views: 389,
      votes: 18,
      solved: true,
      replies: [
        {
          authorName: 'DBExpert',
          author: fakeId,
          content: 'Ini masalah umum di serverless! Solusinya: **connection caching**.\n\nVercel serverless function bisa "cold start" = koneksi MongoDB harus dibuat ulang dari awal.\n\nFix dengan cached connection:\n```javascript\nlet cached = global.mongoose\nif (!cached) cached = global.mongoose = { conn: null, promise: null }\n\nexport async function connectDB() {\n  if (cached.conn) return cached.conn\n  if (!cached.promise) {\n    cached.promise = mongoose.connect(MONGODB_URI, { bufferCommands: false })\n  }\n  cached.conn = await cached.promise\n  return cached.conn\n}\n```\n\nDengan ini, koneksi di-reuse antar invocation.',
          votes: 22,
          isSolution: true,
        }
      ],
    },
    {
      title: 'Perbedaan JWT di localStorage vs httpOnly Cookie — mana yang lebih aman?',
      content: 'Lagi belajar auth system. Banyak tutorial simpan JWT di localStorage, tapi ada yang bilang itu tidak aman.\n\nMana yang lebih aman dan kenapa? Apa tradeoff-nya?',
      authorName: 'SecLearn',
      author: fakeId,
      category: 'cybersecurity',
      tags: ['jwt', 'security', 'auth', 'cookie', 'localstorage'],
      views: 456,
      votes: 25,
      solved: true,
      replies: [
        {
          authorName: 'SecureBro',
          author: fakeId,
          content: '**httpOnly Cookie JAUH lebih aman.** Ini alasannya:\n\n**localStorage:**\n❌ Bisa diakses JavaScript → rentan XSS\n❌ Kalau ada XSS, token bisa dicuri\n\n**httpOnly Cookie:**\n✅ JavaScript tidak bisa baca sama sekali\n✅ Otomatis dikirim browser di setiap request\n✅ Bisa set Secure + SameSite untuk proteksi lebih\n\n```javascript\n// Set httpOnly cookie di server\nres.cookies.set("token", jwtToken, {\n  httpOnly: true,  // JS tidak bisa akses!\n  secure: true,    // HTTPS only\n  sameSite: "strict", // CSRF protection\n  maxAge: 86400\n})\n```\n\nSatu-satunya "kelemahan" httpOnly cookie: harus handle CSRF, tapi bisa diatasi dengan SameSite=Strict.',
          votes: 30,
          isSolution: true,
        }
      ],
    },
    {
      title: 'Async/Await vs Promise.then() — mana yang harus dipakai?',
      content: 'Newbie di sini. Sering lihat dua cara handle async:\n\n```javascript\n// Cara 1\nfetch(url).then(r => r.json()).then(data => console.log(data))\n\n// Cara 2\nconst r = await fetch(url)\nconst data = await r.json()\nconsole.log(data)\n```\n\nApa bedanya? Mana yang lebih disarankan?',
      authorName: 'JSBeginner',
      author: fakeId,
      category: 'javascript',
      tags: ['javascript', 'async', 'await', 'promise'],
      views: 178,
      votes: 9,
      solved: false,
      replies: [
        {
          authorName: 'JSNinja',
          author: fakeId,
          content: 'Keduanya hasilnya sama — async/await adalah "syntactic sugar" dari Promise.\n\n**async/await lebih disarankan karena:**\n- Lebih mudah dibaca (mirip kode synchronous)\n- Error handling dengan try/catch lebih natural\n- Debugging lebih mudah\n\n```javascript\n// Promise - callback hell risk\nfetch(url)\n  .then(r => r.json())\n  .then(data => process(data))\n  .then(result => save(result))\n  .catch(err => handle(err))\n\n// async/await - bersih!\nasync function main() {\n  try {\n    const r = await fetch(url)\n    const data = await r.json()\n    const result = await process(data)\n    await save(result)\n  } catch (err) {\n    handle(err)\n  }\n}\n```',
          votes: 12,
          isSolution: false,
        }
      ],
    },
  ]

  await Thread.insertMany(threads)
  return NextResponse.json({ success: true, message: `Seeded ${threads.length} threads!` })
}
