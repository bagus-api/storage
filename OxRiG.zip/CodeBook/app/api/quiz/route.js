import { NextResponse } from 'next/server'
import { connectDB } from '@/lib/mongodb'
import User from '@/models/User'
import { getCurrentUser } from '@/lib/auth'
import { sanitizeString, apiLimiter, getIP, rateLimitResponse } from '@/lib/security'

export async function POST(request) {
  const ip = getIP(request)
  const limit = apiLimiter(ip)
  if (!limit.allowed) return rateLimitResponse(limit.retryAfter)

  try {
    const decoded = await getCurrentUser(request)
    if (!decoded) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

    const body = await request.json()
    const quizId = sanitizeString(body.quizId || '')
    const score = Math.min(100, Math.max(0, parseInt(body.score) || 0))
    const xpEarned = Math.min(500, Math.max(0, parseInt(body.xpEarned) || 0))
    const isPerfect = body.isPerfect === true
    const passed = score >= 85   // minimum 85% untuk sertifikat

    if (!quizId) return NextResponse.json({ error: 'Data tidak valid' }, { status: 400 })

    await connectDB()
    const user = await User.findById(decoded.userId)
    if (!user) return NextResponse.json({ error: 'User tidak ditemukan' }, { status: 404 })

    const update = {
      $push: { completedQuiz: { quizId, score, passed, completedAt: new Date() } },
      $inc: { xp: xpEarned },
    }
    if (isPerfect && !user.badges.includes('quiz_perfect')) {
      update.$addToSet = { badges: 'quiz_perfect' }
    }

    const updated = await User.findByIdAndUpdate(decoded.userId, update, { new: true }).select('-password')
    return NextResponse.json({ success: true, user: updated, passed })
  } catch (err) {
    return NextResponse.json({ error: 'Server error' }, { status: 500 })
  }
}
