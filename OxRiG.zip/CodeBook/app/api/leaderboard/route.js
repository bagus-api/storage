import { NextResponse } from 'next/server'
import { connectDB } from '@/lib/mongodb'
import User from '@/models/User'
import { apiLimiter, getIP, rateLimitResponse } from '@/lib/security'

export async function GET(request) {
  const ip = getIP(request)
  const limit = apiLimiter(ip)
  if (!limit.allowed) return rateLimitResponse(limit.retryAfter)

  try {
    const { searchParams } = new URL(request.url)
    const sort = searchParams.get('sort') || 'xp'   // xp | streak | certs

    await connectDB()

    const sortField = sort === 'streak' ? 'streak' : sort === 'certs' ? 'certCount' : 'xp'

    const users = await User.aggregate([
      {
        $addFields: {
          certCount: { $size: { $ifNull: ['$certificates', []] } },
          badgeCount: { $size: { $ifNull: ['$badges', []] } },
          materiCount: { $size: { $ifNull: ['$completedMateri', []] } },
        }
      },
      { $sort: { [sortField]: -1 } },
      { $limit: 50 },
      {
        $project: {
          _id: 1,
          name: 1,
          xp: 1,
          streak: 1,
          badges: 1,
          badgeCount: 1,
          certCount: 1,
          materiCount: 1,
          createdAt: 1,
        }
      }
    ])

    return NextResponse.json({ success: true, users, updatedAt: new Date() })
  } catch (err) {
    console.error('Leaderboard error:', err)
    return NextResponse.json({ error: 'Server error' }, { status: 500 })
  }
}
