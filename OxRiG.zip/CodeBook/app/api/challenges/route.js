import { NextResponse } from 'next/server'
import { connectDB } from '@/lib/mongodb'
import ChallengeProgress from '@/models/Challenge'
import User from '@/models/User'
import { sanitizeString } from '@/lib/security'

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')

    if (!userId) {
      return NextResponse.json({ error: 'userId required' }, { status: 400 })
    }

    await connectDB()
    const progress = await ChallengeProgress.find({ userId })

    return NextResponse.json({
      success: true,
      progress,
    })
  } catch (err) {
    console.error('Challenge GET error:', err)
    return NextResponse.json({ error: 'Server error' }, { status: 500 })
  }
}

export async function POST(request) {
  try {
    const { challengeId, payload, userId } = await request.json()

    if (!userId || !challengeId || !payload) {
      return NextResponse.json({ error: 'Missing fields' }, { status: 400 })
    }

    const cleanPayload = sanitizeString(payload).slice(0, 500)

    await connectDB()

    // Get or create progress record
    let progress = await ChallengeProgress.findOne({ userId, challengeId })
    if (!progress) {
      progress = new ChallengeProgress({ userId, challengeId })
    }

    progress.attempts += 1

    // Simple validation logic (in production, use more sophisticated testing)
    const { CHALLENGES } = await import('@/data/challenges')
    const challenge = CHALLENGES.find(c => c.id === challengeId)

    if (!challenge) {
      return NextResponse.json({ error: 'Challenge not found' }, { status: 404 })
    }

    // Check if payload matches solution (basic check)
    const isSolved = cleanPayload.toLowerCase().includes(
      challenge.solution.toLowerCase().slice(0, 20)
    )

    if (isSolved && !progress.solved) {
      progress.solved = true
      progress.xpEarned = challenge.xp
      progress.solvedAt = new Date()

      // Award XP to user
      const user = await User.findById(userId)
      if (user) {
        user.xp = (user.xp || 0) + challenge.xp
        await user.save()
      }
    }

    await progress.save()

    return NextResponse.json({
      success: true,
      solved: progress.solved,
      attempts: progress.attempts,
      xpEarned: progress.xpEarned,
    })
  } catch (err) {
    console.error('Challenge POST error:', err)
    return NextResponse.json({ error: 'Server error' }, { status: 500 })
  }
}
