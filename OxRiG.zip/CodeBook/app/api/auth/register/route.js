import { NextResponse } from 'next/server'
import bcrypt from 'bcryptjs'
import { connectDB } from '@/lib/mongodb'
import User from '@/models/User'
import { signToken, setAuthCookie } from '@/lib/auth'
import { sanitizeString, isValidEmail, isValidPassword, registerLimiter, getIP, rateLimitResponse } from '@/lib/security'

export async function POST(request) {
  try {
    // Rate limit: max 5 register per IP per hour
    const ip = getIP(request)
    const limit = registerLimiter(ip)
    if (!limit.allowed) return rateLimitResponse(limit.retryAfter)

    const body = await request.json()
    const name = sanitizeString(body.name || '')
    const email = sanitizeString((body.email || '').toLowerCase())
    const password = body.password || ''

    // Validate
    if (!name || !email || !password)
      return NextResponse.json({ error: 'Semua field wajib diisi' }, { status: 400 })
    if (name.length < 2 || name.length > 50)
      return NextResponse.json({ error: 'Nama harus 2-50 karakter' }, { status: 400 })
    if (!isValidEmail(email))
      return NextResponse.json({ error: 'Format email tidak valid' }, { status: 400 })
    if (!isValidPassword(password))
      return NextResponse.json({ error: 'Password minimal 6 karakter' }, { status: 400 })

    await connectDB()

    // 1 email = 1 account
    const existing = await User.findOne({ email })
    if (existing)
      return NextResponse.json({ error: 'Email sudah terdaftar' }, { status: 409 })

    const hashed = await bcrypt.hash(password, 12)
    const user = await User.create({
      name: name.trim(),
      email,
      password: hashed,
      badges: ['first_login'],
      xp: 10,
      streak: 1,
      lastLogin: new Date(),
    })

    const token = signToken({ userId: user._id, email: user.email, name: user.name })
    const userData = { id: user._id, name: user.name, email: user.email, xp: user.xp, badges: user.badges, streak: user.streak }

    const res = NextResponse.json({ success: true, user: userData })
    return setAuthCookie(res, token)
  } catch (err) {
    console.error('Register error:', err.message)
    return NextResponse.json({ error: 'Terjadi kesalahan server' }, { status: 500 })
  }
}
