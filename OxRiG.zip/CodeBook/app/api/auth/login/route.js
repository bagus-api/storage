import { NextResponse } from 'next/server'
import bcrypt from 'bcryptjs'
import { connectDB } from '@/lib/mongodb'
import User from '@/models/User'
import { signToken, setAuthCookie } from '@/lib/auth'
import { sanitizeString, isValidEmail, authLimiter, getIP, rateLimitResponse } from '@/lib/security'

export async function POST(request) {
  try {
    // Rate limit: max 10 login attempts per 15 min per IP
    const ip = getIP(request)
    const limit = authLimiter(ip)
    if (!limit.allowed) return rateLimitResponse(limit.retryAfter)

    const body = await request.json()
    const email = sanitizeString((body.email || '').toLowerCase())
    const password = body.password || ''

    if (!email || !password)
      return NextResponse.json({ error: 'Email dan password wajib diisi' }, { status: 400 })
    if (!isValidEmail(email))
      return NextResponse.json({ error: 'Format email tidak valid' }, { status: 400 })

    await connectDB()
    const user = await User.findOne({ email })

    // Timing-safe: always run bcrypt even if user not found (prevent user enumeration)
    const dummyHash = '$2b$12$invalidhashfortimingsafety000000000000000000000000000'
    const isValid = user ? await bcrypt.compare(password, user.password) : await bcrypt.compare(password, dummyHash)

    if (!user || !isValid)
      return NextResponse.json({ error: 'Email atau password salah' }, { status: 401 })

    // Streak update
    const now = new Date()
    const last = user.lastLogin ? new Date(user.lastLogin) : null
    let streak = user.streak || 0
    if (last) {
      const diff = Math.floor((now - last) / 86400000)
      streak = diff === 1 ? streak + 1 : diff > 1 ? 1 : streak
    } else streak = 1

    const badges = [...(user.badges || [])]
    if (streak >= 7 && !badges.includes('streak_7')) badges.push('streak_7')

    await User.findByIdAndUpdate(user._id, { lastLogin: now, streak, badges })

    const token = signToken({ userId: user._id, email: user.email, name: user.name })
    const userData = {
      id: user._id, name: user.name, email: user.email,
      xp: user.xp, badges, streak,
      completedMateri: user.completedMateri,
      completedQuiz: user.completedQuiz,
    }

    const res = NextResponse.json({ success: true, user: userData })
    return setAuthCookie(res, token)
  } catch (err) {
    console.error('Login error:', err.message)
    return NextResponse.json({ error: 'Terjadi kesalahan server' }, { status: 500 })
  }
}
