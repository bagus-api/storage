import { NextResponse } from 'next/server'
import { connectDB } from '@/lib/mongodb'
import User from '@/models/User'
import { getCurrentUser } from '@/lib/auth'
import { sanitizeString, apiLimiter, getIP, rateLimitResponse } from '@/lib/security'

export async function POST(request) {
  const ip = getIP(request)
  const limit = apiLimiter(ip)
  if (!limit.allowed) return rateLimitResponse(limit.retryAfter)

  try {
    const decoded = await getCurrentUser(request)
    if (!decoded) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

    const body = await request.json()
    const materiSlug = sanitizeString(body.materiSlug || '')
    const xpEarned = Math.min(Math.max(0, parseInt(body.xpEarned) || 0), 1000)
    const badgeId = sanitizeString(body.badgeId || '')

    if (!materiSlug) return NextResponse.json({ error: 'Data tidak valid' }, { status: 400 })

    await connectDB()
    const user = await User.findById(decoded.userId)
    if (!user) return NextResponse.json({ error: 'User tidak ditemukan' }, { status: 404 })

    const update = {}
    if (!user.completedMateri.includes(materiSlug)) {
      update.$addToSet = { completedMateri: materiSlug }
      update.$inc = { xp: xpEarned }
    }
    if (badgeId && !user.badges.includes(badgeId)) {
      update.$addToSet = { ...update.$addToSet, badges: badgeId }
    }

    const updated = await User.findByIdAndUpdate(decoded.userId, update, { new: true }).select('-password')
    return NextResponse.json({ success: true, user: updated })
  } catch (err) {
    return NextResponse.json({ error: 'Server error' }, { status: 500 })
  }
}
