'use client'
import Link from 'next/link'
import Navbar from '@/components/layout/Navbar'
import { WORKSHOPS } from '@/data/workshop'
import {
  IconPython, IconJS, IconHTMLTag, IconSQL, IconGit,
  IconReact, IconServer, IconLock, IconBook, IconArrowRight,
  IconCheck, IconZap, IconBrain,
} from '@/components/ui/Icons'

const LANG_ICONS = {
  python: IconPython,
  javascript: IconJS,
  html: IconHTMLTag,
  css: IconHTMLTag,
  sql: IconSQL,
  git: IconGit,
  react: IconReact,
  nodejs: IconServer,
  security: IconLock,
}

const LANG_COLORS = {
  python:     { bg: 'bg-blue-500/10',   border: 'border-blue-500/20',   text: 'text-blue-400',   bar: '#3B82F6' },
  javascript: { bg: 'bg-yellow-500/10', border: 'border-yellow-500/20', text: 'text-yellow-400', bar: '#EAB308' },
  html:       { bg: 'bg-orange-500/10', border: 'border-orange-500/20', text: 'text-orange-400', bar: '#F97316' },
  css:        { bg: 'bg-purple-500/10', border: 'border-purple-500/20', text: 'text-purple-400', bar: '#8B5CF6' },
  sql:        { bg: 'bg-cyan-500/10',   border: 'border-cyan-500/20',   text: 'text-cyan-400',   bar: '#06B6D4' },
  git:        { bg: 'bg-orange-600/10', border: 'border-orange-600/20', text: 'text-orange-500', bar: '#EA580C' },
  react:      { bg: 'bg-sky-500/10',    border: 'border-sky-500/20',    text: 'text-sky-400',    bar: '#0EA5E9' },
  nodejs:     { bg: 'bg-green-500/10',  border: 'border-green-500/20',  text: 'text-green-400',  bar: '#22C55E' },
  security:   { bg: 'bg-red-500/10',    border: 'border-red-500/20',    text: 'text-red-400',    bar: '#EF4444' },
}

export default function WorkshopListPage() {
  const groups = {}
  WORKSHOPS.forEach(w => {
    if (!groups[w.category]) groups[w.category] = []
    groups[w.category].push(w)
  })

  return (
    <div className="min-h-screen bg-[#020617]">
      <Navbar />
      <div className="max-w-6xl mx-auto px-4 py-24">

        {/* Header */}
        <div className="mb-12">
          <div className="flex items-center gap-2 mb-3">
            <div className="w-1 h-6 rounded-full bg-violet-500" />
            <p className="text-violet-400 text-sm font-black uppercase tracking-widest">Interaktif</p>
          </div>
          <h1 className="text-4xl sm:text-5xl font-black text-white leading-tight mb-4">
            Workshop Coding
          </h1>
          <p className="text-slate-500 max-w-xl text-lg leading-relaxed">
            Belajar seperti freeCodeCamp — step-by-step, kamu yang coding langsung, sistem yang mengecek. Tidak ada copy-paste.
          </p>
        </div>

        {/* How it works */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-12 p-5 rounded-2xl bg-[#0f172a] border border-white/[0.06]">
          {[
            { Icon: IconBook,  title: 'Baca Instruksi', desc: 'Penjelasan teori + contoh kode per langkah' },
            { Icon: IconZap,   title: 'Ketik Kode',    desc: 'Editor seperti VSCode dengan syntax highlighting' },
            { Icon: IconBrain, title: 'Cek Otomatis',  desc: 'Sistem validasi kodeamu + feedback instan' },
          ].map((s, i) => (
            <div key={i} className="flex items-start gap-3">
              <div className="w-9 h-9 rounded-xl bg-violet-600/15 border border-violet-500/20 flex items-center justify-center flex-shrink-0">
                <s.Icon size={18} className="text-violet-400" />
              </div>
              <div>
                <p className="font-bold text-white text-sm">{s.title}</p>
                <p className="text-slate-500 text-xs mt-0.5">{s.desc}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Workshop groups */}
        {Object.entries(groups).map(([cat, workshops]) => (
          <div key={cat} className="mb-10">
            <div className="flex items-center gap-3 mb-5">
              <div className="flex-1 h-px bg-white/[0.06]" />
              <h2 className="text-sm font-black text-slate-500 uppercase tracking-widest">{cat}</h2>
              <div className="flex-1 h-px bg-white/[0.06]" />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {workshops.map(w => {
                const LIcon = LANG_ICONS[w.lang] || IconBook
                const lc = LANG_COLORS[w.lang] || LANG_COLORS.javascript
                return (
                  <Link key={w.id} href={`/workshop/${w.id}`}
                    className="group p-5 rounded-2xl bg-[#0f172a] border border-white/[0.06] hover:border-violet-500/30 transition-all duration-200 hover:-translate-y-0.5 flex flex-col">

                    {/* Lang badge + steps */}
                    <div className="flex items-center justify-between mb-4">
                      <div className={`flex items-center gap-2 px-2.5 py-1 rounded-lg ${lc.bg} border ${lc.border}`}>
                        <LIcon size={14} className={lc.text} />
                        <span className={`text-xs font-black ${lc.text}`}>{w.lang.toUpperCase()}</span>
                      </div>
                      <span className="text-xs text-slate-600">{w.steps.length} langkah</span>
                    </div>

                    {/* Title */}
                    <h3 className="font-black text-white text-base leading-tight mb-2 group-hover:text-violet-300 transition-colors">
                      {w.title}
                    </h3>
                    <p className="text-slate-500 text-sm leading-relaxed flex-1">{w.desc}</p>

                    {/* Footer */}
                    <div className="flex items-center justify-between mt-4 pt-4 border-t border-white/[0.04]">
                      <div className="flex items-center gap-3">
                        <span className="text-[11px] font-semibold px-2 py-0.5 rounded-md bg-white/[0.04] text-slate-500 border border-white/[0.06]">{w.level}</span>
                        <span className="text-[11px] font-black text-violet-400">+{w.xp} XP</span>
                      </div>
                      <div className="flex items-center gap-1 text-slate-600 group-hover:text-violet-400 transition-colors">
                        <span className="text-xs font-semibold">Mulai</span>
                        <IconArrowRight size={14} />
                      </div>
                    </div>

                    {/* Progress bar (visual only) */}
                    <div className="mt-3 h-0.5 rounded-full bg-white/[0.04] overflow-hidden">
                      <div className="h-full w-0 group-hover:w-1/4 transition-all duration-500 rounded-full" style={{ background: lc.bar }} />
                    </div>
                  </Link>
                )
              })}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
