'use client'
import { useState, useEffect, useRef } from 'react'
import { useParams } from 'next/navigation'
import Link from 'next/link'
import Navbar from '@/components/layout/Navbar'
import CodeEditor from '@/components/ui/CodeEditor'
import { getWorkshop, checkAnswer } from '@/data/workshop'
import {
  IconArrowRight, IconCheck, IconLightbulb, IconRefresh,
  IconPlay, IconClose, IconChevronDown,
} from '@/components/ui/Icons'
import toast from 'react-hot-toast'

function Md({ text }) {
  if (!text) return null
  const lines = text.split('\n')
  const out = []
  let i = 0, inCode = false, codeLines = []
  while (i < lines.length) {
    const line = lines[i]
    if (line.startsWith('```')) {
      if (!inCode) { inCode = true; codeLines = [] }
      else {
        inCode = false
        out.push(
          <pre key={`c${i}`} className="my-3 rounded-xl overflow-x-auto text-sm leading-relaxed" style={{ background: '#1E1E1E', border: '1px solid #3C3C3C', padding: '14px 16px', fontFamily: '"JetBrains Mono","Fira Code",monospace', color: '#ABB2BF' }}>
            <code>{codeLines.join('\n')}</code>
          </pre>
        )
      }
      i++; continue
    }
    if (inCode) { codeLines.push(line); i++; continue }

    if (line.startsWith('## ')) out.push(<h2 key={i} className="text-base font-black text-slate-100 mt-5 mb-2 pb-1.5 border-b border-white/[0.06]">{line.slice(3)}</h2>)
    else if (line.startsWith('### ')) out.push(<h3 key={i} className="text-sm font-bold text-violet-400 mt-3 mb-1.5">{line.slice(4)}</h3>)
    else if (line.startsWith('| ') && !line.includes('---')) {
      const cells = line.split('|').filter(c => c.trim())
      const isH = lines[i+1]?.includes('---')
      if (isH) { out.push(<tr key={i}>{cells.map((c,j) => <th key={j} className="py-2 px-3 text-left text-xs font-bold text-violet-400 bg-[#1a1a2e]">{c.trim()}</th>)}</tr>); i+=2; continue }
      out.push(<tr key={i} className="border-t border-white/[0.06]">{cells.map((c,j) => <td key={j} className="py-2 px-3 text-xs text-slate-400">{c.trim()}</td>)}</tr>)
    }
    else if (line.startsWith('- ')) {
      const html = line.slice(2).replace(/\*\*(.*?)\*\*/g, '<strong class="text-slate-200">$1</strong>').replace(/`([^`]+)`/g, '<code style="background:#1E1E1E;padding:1px 6px;border-radius:4px;color:#C678DD;font-family:JetBrains Mono,monospace;font-size:12px">$1</code>')
      out.push(<li key={i} className="text-slate-400 text-sm leading-relaxed ml-4 my-1" dangerouslySetInnerHTML={{ __html: html }} />)
    }
    else if (line.trim()) {
      const html = line.replace(/\*\*(.*?)\*\*/g, '<strong class="text-slate-200">$1</strong>').replace(/`([^`]+)`/g, '<code style="background:#1E1E1E;padding:1px 6px;border-radius:4px;color:#C678DD;font-family:JetBrains Mono,monospace;font-size:12px">$1</code>')
      out.push(<p key={i} className="text-slate-400 text-sm leading-relaxed my-1.5" dangerouslySetInnerHTML={{ __html: html }} />)
    } else out.push(<div key={i} className="my-1" />)
    i++
  }
  const tr = out.filter(el => el.type === 'tr')
  const rest = out.filter(el => el.type !== 'tr')
  if (tr.length) return <div>{rest}<div className="overflow-x-auto my-3 rounded-xl border border-white/[0.06]"><table className="w-full"><tbody>{tr}</tbody></table></div></div>
  return <div>{out}</div>
}

export default function WorkshopPage() {
  const { id } = useParams()
  const workshop = getWorkshop(id)

  const [stepIdx, setStepIdx] = useState(0)
  const [code, setCode] = useState('')
  const [status, setStatus] = useState(null)
  const [failMsg, setFailMsg] = useState('')
  const [showHint, setShowHint] = useState(false)
  const [completedSteps, setCompletedSteps] = useState(new Set())
  const [xpEarned, setXpEarned] = useState(false)
  const [finished, setFinished] = useState(false)

  const step = workshop?.steps[stepIdx]

  useEffect(() => {
    if (step) { setCode(step.starterCode || ''); setStatus(null); setFailMsg(''); setShowHint(false) }
  }, [stepIdx, step])

  if (!workshop) return (
    <div className="min-h-screen bg-[#020617] flex items-center justify-center">
      <div className="text-center">
        <div className="w-16 h-16 rounded-2xl bg-white/[0.04] border border-white/[0.08] flex items-center justify-center mx-auto mb-4">
          <IconClose size={28} className="text-slate-600" />
        </div>
        <p className="text-white font-bold mb-2">Workshop tidak ditemukan</p>
        <Link href="/workshop" className="text-violet-400 hover:text-violet-300 text-sm">← Kembali ke Workshop</Link>
      </div>
    </div>
  )

  const totalSteps = workshop.steps.length
  const progressPct = Math.round((completedSteps.size / totalSteps) * 100)

  const handleCheck = () => {
    if (!code.trim()) { toast.error('Tulis kode dulu!'); return }
    setStatus('checking')
    setTimeout(() => {
      const result = checkAnswer(code, step.check)
      if (result.passed) {
        setStatus('pass')
        const nc = new Set(completedSteps); nc.add(stepIdx); setCompletedSteps(nc)
        if (step.isFinal) { setFinished(true); awardXP() }
      } else {
        setStatus('fail'); setFailMsg(result.msg)
      }
    }, 500)
  }

  const awardXP = async () => {
    if (xpEarned) return
    try {
      await fetch('/api/progress', {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, credentials: 'include',
        body: JSON.stringify({ materiSlug: `workshop-${id}`, xpEarned: workshop.xp }),
      })
      setXpEarned(true)
      const s = localStorage.getItem('cb_user')
      if (s) { const u = JSON.parse(s); localStorage.setItem('cb_user', JSON.stringify({ ...u, xp: (u.xp||0)+workshop.xp })) }
    } catch {}
  }

  const handleKeyDown = (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') { e.preventDefault(); handleCheck() }
  }

  return (
    <div className="min-h-screen bg-[#020617] flex flex-col" onKeyDown={handleKeyDown}>
      <Navbar />

      {/* Finished modal */}
      {finished && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="max-w-md w-full p-8 rounded-3xl bg-[#0f172a] border border-violet-500/30 text-center shadow-2xl">
            <div className="w-20 h-20 rounded-full bg-violet-600/20 border-2 border-violet-500/40 flex items-center justify-center mx-auto mb-5">
              <IconCheck size={36} className="text-violet-400" />
            </div>
            <h2 className="text-2xl font-black text-white mb-2">Workshop Selesai!</h2>
            <p className="text-violet-400 font-bold mb-1">{workshop.title}</p>
            <p className="text-slate-500 text-sm mb-6">{totalSteps} langkah berhasil diselesaikan{xpEarned ? `. +${workshop.xp} XP ditambahkan!` : '.'}</p>
            <div className="flex gap-3">
              <button onClick={() => setFinished(false)} className="flex-1 py-3 rounded-xl text-sm font-bold text-slate-400 border border-white/10 hover:text-white transition-all">Review</button>
              <Link href="/workshop" className="flex-1 py-3 rounded-xl text-sm font-black text-center bg-violet-600 hover:bg-violet-500 text-white transition-all">Workshop Lain</Link>
            </div>
          </div>
        </div>
      )}

      <div className="flex-1 flex flex-col max-w-7xl mx-auto w-full px-4 pt-20 pb-4">
        {/* Header row */}
        <div className="flex items-center gap-3 py-3">
          <Link href="/workshop" className="p-2 rounded-xl text-slate-600 hover:text-slate-300 hover:bg-white/[0.05] transition-all flex-shrink-0">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="15 18 9 12 15 6"/></svg>
          </Link>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-sm font-black text-white truncate">{workshop.title}</span>
              <span className="text-[10px] font-black px-2 py-0.5 rounded-md border text-violet-400 border-violet-500/30 bg-violet-500/10 uppercase tracking-wider">{workshop.lang}</span>
            </div>
            {/* Progress */}
            <div className="flex items-center gap-3 mt-1.5">
              <div className="flex-1 h-1 rounded-full overflow-hidden bg-white/[0.05]">
                <div className="h-full bg-gradient-to-r from-violet-600 to-violet-400 rounded-full transition-all duration-700" style={{ width: `${progressPct}%` }} />
              </div>
              <span className="text-[11px] text-slate-600 flex-shrink-0 font-mono">{completedSteps.size}/{totalSteps}</span>
            </div>
          </div>
        </div>

        {/* Step pills */}
        <div className="flex gap-1.5 mb-4 overflow-x-auto pb-1 scrollbar-thin">
          {workshop.steps.map((s, i) => (
            <button key={i} onClick={() => setStepIdx(i)}
              className={`flex-shrink-0 w-8 h-7 rounded-lg text-xs font-black transition-all ${
                i === stepIdx ? 'bg-violet-600 text-white shadow-lg shadow-violet-500/30' :
                completedSteps.has(i) ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/25' :
                'bg-white/[0.04] text-slate-600 hover:text-slate-400 border border-white/[0.04]'
              }`}>
              {completedSteps.has(i) ? <IconCheck size={12} className="mx-auto" /> : i + 1}
            </button>
          ))}
        </div>

        {/* Main 2-panel layout */}
        <div className="flex-1 grid grid-cols-1 lg:grid-cols-2 gap-4" style={{ minHeight: '520px' }}>

          {/* LEFT — Instructions */}
          <div className="rounded-2xl overflow-hidden border border-white/[0.08] flex flex-col" style={{ background: '#0D1117' }}>
            {/* Panel header */}
            <div className="flex items-center gap-2 px-4 py-3 border-b border-white/[0.06]" style={{ background: '#161B22' }}>
              <div className="flex gap-1.5">
                <div className="w-3 h-3 rounded-full bg-[#FF5F57]" />
                <div className="w-3 h-3 rounded-full bg-[#FFBD2E]" />
                <div className="w-3 h-3 rounded-full bg-[#28CA41]" />
              </div>
              <span className="text-xs text-slate-500 ml-2 font-semibold">Langkah {stepIdx + 1} dari {totalSteps}</span>
              {completedSteps.has(stepIdx) && (
                <div className="ml-auto flex items-center gap-1 text-emerald-400 text-xs font-bold">
                  <IconCheck size={12} />
                  <span>Selesai</span>
                </div>
              )}
            </div>

            {/* Content */}
            <div className="flex-1 overflow-y-auto p-5">
              <p className="text-violet-400 text-[11px] font-black uppercase tracking-widest mb-2">{step?.title}</p>
              <Md text={step?.instruction} />
            </div>

            {/* Hint */}
            <div className="p-4 border-t border-white/[0.06] flex-shrink-0">
              <button onClick={() => setShowHint(!showHint)}
                className="w-full flex items-center gap-2.5 py-2.5 px-4 rounded-xl border transition-all text-sm font-semibold"
                style={{ background: showHint ? 'rgba(234,179,8,0.1)' : 'rgba(234,179,8,0.05)', borderColor: 'rgba(234,179,8,0.2)', color: '#FCD34D' }}>
                <IconLightbulb size={15} />
                {showHint ? 'Sembunyikan Petunjuk' : 'Tampilkan Petunjuk'}
                <IconChevronDown size={14} className={`ml-auto transition-transform ${showHint ? 'rotate-180' : ''}`} />
              </button>
              {showHint && (
                <div className="mt-2.5 p-3.5 rounded-xl text-xs leading-relaxed" style={{ background: 'rgba(234,179,8,0.05)', border: '1px solid rgba(234,179,8,0.15)', color: '#FDE68A', fontFamily: '"JetBrains Mono",monospace' }}>
                  {step?.hint}
                </div>
              )}
            </div>
          </div>

          {/* RIGHT — Code Editor */}
          <div className="rounded-2xl overflow-hidden flex flex-col border border-white/[0.08]" style={{ minHeight: '520px' }}>
            <div className="flex-1 flex flex-col">
              <CodeEditor
                value={code}
                onChange={(v) => { setCode(v); setStatus(null) }}
                lang={workshop.lang}
                minHeight={380}
              />
            </div>

            {/* Feedback + buttons */}
            <div style={{ background: '#1E1E1E', borderTop: '1px solid #3C3C3C' }}>
              {/* Feedback */}
              {status === 'pass' && (
                <div className="mx-4 mt-3 p-3 rounded-xl flex items-start gap-2.5" style={{ background: 'rgba(16,185,129,0.1)', border: '1px solid rgba(16,185,129,0.2)' }}>
                  <IconCheck size={18} className="text-emerald-400 flex-shrink-0 mt-0.5" />
                  <p className="text-emerald-300 text-sm">{step?.successMsg}</p>
                </div>
              )}
              {status === 'fail' && (
                <div className="mx-4 mt-3 p-3 rounded-xl flex items-start gap-2.5" style={{ background: 'rgba(239,68,68,0.08)', border: '1px solid rgba(239,68,68,0.2)' }}>
                  <IconClose size={18} className="text-red-400 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="text-red-300 text-sm font-bold">Belum tepat</p>
                    <p className="text-red-400/70 text-xs mt-0.5">{failMsg}</p>
                  </div>
                </div>
              )}

              {/* Action bar */}
              <div className="flex items-center gap-2 p-4">
                <button onClick={() => setStepIdx(p => Math.max(0, p-1))} disabled={stepIdx === 0}
                  className="px-3 py-2 rounded-lg text-xs font-bold transition-all disabled:opacity-30 disabled:cursor-not-allowed"
                  style={{ background: '#2D2D30', color: '#CCCCCC', border: '1px solid #3C3C3C' }}>
                  ← Prev
                </button>

                <button onClick={() => { setCode(step?.starterCode || ''); setStatus(null) }}
                  className="p-2 rounded-lg transition-all" title="Reset kode"
                  style={{ background: '#2D2D30', color: '#888', border: '1px solid #3C3C3C' }}>
                  <IconRefresh size={14} />
                </button>

                <button onClick={handleCheck} disabled={status === 'checking'}
                  className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg text-sm font-black transition-all ${status === 'pass' ? 'opacity-80' : ''}`}
                  style={{
                    background: status === 'pass' ? '#065f46' : '#7C3AED',
                    color: 'white',
                    border: 'none',
                    boxShadow: status === 'pass' ? 'none' : '0 4px 14px rgba(124,58,237,0.35)',
                  }}>
                  {status === 'checking' ? (
                    <><svg className="animate-spin w-4 h-4" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"/></svg>Mengecek...</>
                  ) : status === 'pass' ? (
                    <><IconCheck size={15} />Benar!</>
                  ) : (
                    <><IconPlay size={13} />Cek Jawaban</>
                  )}
                </button>

                {status === 'pass' && stepIdx < totalSteps - 1 && (
                  <button onClick={() => setStepIdx(p => p+1)}
                    className="flex items-center gap-1.5 px-4 py-2.5 rounded-lg text-sm font-black transition-all"
                    style={{ background: '#059669', color: 'white' }}>
                    Next <IconArrowRight size={14} />
                  </button>
                )}
                {status === 'pass' && stepIdx === totalSteps - 1 && (
                  <button onClick={() => setFinished(true)}
                    className="px-4 py-2.5 rounded-lg text-sm font-black"
                    style={{ background: '#EAB308', color: 'black' }}>
                    Selesai!
                  </button>
                )}
              </div>

              <p className="text-center pb-2 text-[10px]" style={{ color: '#555', fontFamily: 'monospace' }}>
                Tab = 4 spasi &nbsp;•&nbsp; Ctrl+Enter = Cek
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
