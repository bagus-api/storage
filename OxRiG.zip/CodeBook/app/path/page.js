'use client'
import { useState, useEffect } from 'react'
import Link from 'next/link'
import Navbar from '@/components/layout/Navbar'
import { MATERI_LIST } from '@/data/materi'

const PATHS = [
  {
    id: 'frontend',
    title: 'Frontend Developer',
    icon: '🎨',
    color: 'from-pink-500 to-rose-500',
    border: 'border-pink-500/20',
    glow: 'shadow-pink-500/20',
    desc: 'Kuasai HTML, CSS, JavaScript dan React untuk membangun tampilan website yang indah.',
    duration: '3-4 bulan',
    level: 'Beginner → Intermediate',
    steps: [
      { slug: 'html-fundamentals', label: 'HTML Fundamentals', desc: 'Struktur halaman web' },
      { slug: 'css-mastery', label: 'CSS Mastery', desc: 'Styling dan layout' },
      { slug: 'javascript-essentials', label: 'JavaScript Essentials', desc: 'Logika dan interaksi' },
      { slug: 'react-fundamentals', label: 'React.js', desc: 'Component-based UI' },
    ],
  },
  {
    id: 'backend',
    title: 'Backend Developer',
    icon: '⚙️',
    color: 'from-emerald-500 to-teal-500',
    border: 'border-emerald-500/20',
    glow: 'shadow-emerald-500/20',
    desc: 'Pelajari server-side programming, database, dan API untuk membangun backend yang solid.',
    duration: '3-4 bulan',
    level: 'Beginner → Intermediate',
    steps: [
      { slug: 'python-basics', label: 'Python Basics', desc: 'Bahasa backend modern' },
      { slug: 'nodejs-express', label: 'Node.js & Express', desc: 'JavaScript di server' },
      { slug: 'database-fundamentals', label: 'Database', desc: 'SQL & MongoDB' },
      { slug: 'backend-api', label: 'REST API', desc: 'Bangun API profesional' },
    ],
  },
  {
    id: 'fullstack',
    title: 'Fullstack Developer',
    icon: '🚀',
    color: 'from-violet-500 to-purple-600',
    border: 'border-violet-500/20',
    glow: 'shadow-violet-500/20',
    desc: 'Jadilah developer serba bisa — kuasai frontend, backend, database, dan deployment.',
    duration: '6-8 bulan',
    level: 'Beginner → Pro',
    steps: [
      { slug: 'html-fundamentals', label: 'HTML & CSS', desc: 'Foundation web' },
      { slug: 'javascript-essentials', label: 'JavaScript', desc: 'Core programming' },
      { slug: 'react-fundamentals', label: 'React.js', desc: 'Frontend modern' },
      { slug: 'backend-api', label: 'Backend & API', desc: 'Server-side' },
      { slug: 'database-fundamentals', label: 'Database', desc: 'Data management' },
      { slug: 'docker-deployment', label: 'Docker & Deploy', desc: 'Production ready' },
    ],
  },
  {
    id: 'cybersec',
    title: 'Cybersecurity',
    icon: '🛡️',
    color: 'from-red-500 to-orange-500',
    border: 'border-red-500/20',
    glow: 'shadow-red-500/20',
    desc: 'Pelajari keamanan web dari dasar hingga ethical hacking dan bug bounty.',
    duration: '4-5 bulan',
    level: 'Intermediate → Advanced',
    steps: [
      { slug: 'cybersecurity-fundamentals', label: 'Security Fundamentals', desc: 'CIA Triad & threats' },
      { slug: 'kriptografi', label: 'Kriptografi', desc: 'Enkripsi & hashing' },
      { slug: 'clean-code', label: 'Secure Coding', desc: 'Code yang aman' },
      { slug: 'pentest-basics', label: 'Penetration Testing', desc: 'Ethical hacking' },
    ],
  },
]

export default function PathPage() {
  const [user, setUser] = useState(null)
  const [selected, setSelected] = useState(null)

  useEffect(() => {
    const s = localStorage.getItem('cb_user')
    if (s) setUser(JSON.parse(s))
  }, [])

  const completedSlugs = new Set(user?.completedMateri || [])

  return (
    <div className="min-h-screen bg-[#020617]">
      <Navbar />
      <div className="max-w-6xl mx-auto px-4 py-24">
        <div className="mb-12">
          <p className="section-label">Roadmap</p>
          <h1 className="section-title">Learning Path</h1>
          <p className="section-desc">Pilih jalur belajarmu. Tidak perlu bingung mulai dari mana — ikuti step-by-step sampai selesai.</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          {PATHS.map(path => {
            const done = path.steps.filter(s => completedSlugs.has(s.slug)).length
            const pct = Math.round((done / path.steps.length) * 100)
            const isSelected = selected === path.id

            return (
              <div key={path.id}
                className={`rounded-2xl bg-[#0f172a] border transition-all duration-300 cursor-pointer ${isSelected ? `${path.border} shadow-xl ${path.glow}` : 'border-white/[0.06] hover:border-white/10'}`}
                onClick={() => setSelected(isSelected ? null : path.id)}>
                <div className="p-6">
                  <div className="flex items-start gap-4 mb-4">
                    <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${path.color} flex items-center justify-center text-3xl flex-shrink-0 shadow-xl`}>
                      {path.icon}
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="font-black text-white text-lg mb-1">{path.title}</h3>
                      <div className="flex gap-2 flex-wrap">
                        <span className="badge badge-purple">⏱ {path.duration}</span>
                        <span className="badge badge-blue">{path.level}</span>
                      </div>
                    </div>
                  </div>
                  <p className="text-slate-500 text-sm leading-relaxed mb-4">{path.desc}</p>

                  {/* Progress */}
                  <div className="mb-4">
                    <div className="flex justify-between text-xs text-slate-600 mb-1.5">
                      <span>{done}/{path.steps.length} selesai</span>
                      <span className="text-violet-400 font-bold">{pct}%</span>
                    </div>
                    <div className="progress-track h-2">
                      <div className="progress-fill h-2" style={{ width: `${pct}%` }} />
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-xs text-slate-600">{path.steps.length} materi</span>
                    <span className={`text-xs font-bold transition-colors ${isSelected ? 'text-violet-400' : 'text-slate-500'}`}>
                      {isSelected ? '▲ Sembunyikan' : '▼ Lihat detail'}
                    </span>
                  </div>
                </div>

                {/* Steps (expand) */}
                {isSelected && (
                  <div className="px-6 pb-6 border-t border-white/[0.06] pt-5">
                    <div className="space-y-2">
                      {path.steps.map((step, i) => {
                        const done = completedSlugs.has(step.slug)
                        return (
                          <Link key={step.slug} href={`/materi/${step.slug}`}
                            className="flex items-center gap-3 p-3 rounded-xl hover:bg-white/[0.04] transition-all group">
                            <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-black flex-shrink-0 ${done ? 'bg-emerald-500 text-white' : 'bg-white/[0.06] text-slate-500 group-hover:bg-violet-500/15 group-hover:text-violet-400'}`}>
                              {done ? '✓' : i + 1}
                            </div>
                            <div className="flex-1">
                              <p className={`text-sm font-semibold ${done ? 'text-emerald-400' : 'text-slate-300 group-hover:text-white'}`}>{step.label}</p>
                              <p className="text-xs text-slate-600">{step.desc}</p>
                            </div>
                            <svg className="w-4 h-4 text-slate-700 group-hover:text-violet-400 transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                            </svg>
                          </Link>
                        )
                      })}
                    </div>
                    <Link href="/materi" className="mt-4 flex items-center justify-center gap-2 w-full py-2.5 rounded-xl text-sm font-bold bg-violet-600 hover:bg-violet-500 text-white transition-all">
                      🚀 Mulai Path Ini
                    </Link>
                  </div>
                )}
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}
