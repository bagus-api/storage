'use client'
import { useState, useEffect } from 'react'
import { useParams, useRouter } from 'next/navigation'
import Link from 'next/link'
import Navbar from '@/components/layout/Navbar'
import { MATERI_LIST } from '@/data/materi'
import { QUIZ_DATA } from '@/data/quiz'
import toast from 'react-hot-toast'

function SimpleMarkdown({ content }) {
  const lines = content.split('\n')
  const result = []
  let i = 0
  let inCode = false
  let codeLines = []

  while (i < lines.length) {
    const line = lines[i]
    if (line.startsWith('```')) {
      if (!inCode) { inCode = true; codeLines = [] }
      else {
        inCode = false
        result.push(
          <pre key={`c${i}`} className="bg-[#020617] border border-slate-800 rounded-xl p-4 overflow-x-auto my-4 text-sm leading-relaxed font-mono text-slate-300">
            <code>{codeLines.join('\n')}</code>
          </pre>
        )
      }
      i++; continue
    }
    if (inCode) { codeLines.push(line); i++; continue }

    if (line.startsWith('# ')) result.push(<h1 key={i} className="text-2xl font-black text-white mt-6 mb-3">{line.slice(2)}</h1>)
    else if (line.startsWith('## ')) result.push(<h2 key={i} className="text-lg font-bold text-slate-200 mt-5 mb-2 pb-2 border-b border-slate-800">{line.slice(3)}</h2>)
    else if (line.startsWith('### ')) result.push(<h3 key={i} className="text-base font-bold text-slate-300 mt-4 mb-2">{line.slice(4)}</h3>)
    else if (line.startsWith('- ')) {
      const txt = line.slice(2).replace(/\*\*(.*?)\*\*/g, '<strong class="text-slate-200">$1</strong>').replace(/`([^`]+)`/g, '<code class="bg-slate-800 px-1.5 py-0.5 rounded text-violet-400 text-xs font-mono">$1</code>')
      result.push(<li key={i} className="text-slate-400 text-sm leading-relaxed my-1.5 ml-4" dangerouslySetInnerHTML={{ __html: txt }} />)
    }
    else if (line.startsWith('| ') && !line.includes('---')) {
      const cells = line.split('|').filter(c => c.trim())
      const isH = lines[i+1]?.includes('---')
      if (isH) { result.push(<tr key={i} className="border-b border-slate-800">{cells.map((c,j) => <th key={j} className="py-2 px-3 text-left text-xs font-bold text-violet-400 bg-slate-900">{c.trim()}</th>)}</tr>); i+=2; continue }
      result.push(<tr key={i} className="border-b border-slate-800/50">{cells.map((c,j) => <td key={j} className="py-2 px-3 text-xs text-slate-400">{c.trim()}</td>)}</tr>)
    }
    else if (line.trim()) {
      const txt = line.replace(/\*\*(.*?)\*\*/g, '<strong class="text-slate-200">$1</strong>').replace(/`([^`]+)`/g, '<code class="bg-slate-800 px-1.5 py-0.5 rounded text-violet-400 text-xs font-mono">$1</code>')
      result.push(<p key={i} className="text-slate-400 text-sm leading-relaxed my-2" dangerouslySetInnerHTML={{ __html: txt }} />)
    }
    else result.push(<div key={i} className="my-1" />)
    i++
  }
  const tableRows = result.filter(el => el.type === 'tr')
  const others = result.filter(el => el.type !== 'tr')
  if (tableRows.length > 0) return <div>{others}<div className="overflow-x-auto my-4 rounded-xl border border-slate-800"><table className="w-full"><tbody>{tableRows}</tbody></table></div></div>
  return <div>{result}</div>
}

export default function MateriDetailPage() {
  const { slug } = useParams()
  const router = useRouter()
  const [activeChapter, setActiveChapter] = useState(0)
  const [completing, setCompleting] = useState(false)
  const [completed, setCompleted] = useState(false)
  const [user, setUser] = useState(null)
  const [quizPassed, setQuizPassed] = useState(false)
  const [quizBestScore, setQuizBestScore] = useState(null)

  const materi = MATERI_LIST.find(m => m.slug === slug)
  const relatedQuiz = QUIZ_DATA.find(q => q.slug === slug)

  useEffect(() => {
    const stored = localStorage.getItem('cb_user')
    if (stored) {
      const u = JSON.parse(stored)
      setUser(u)
      setCompleted((u.completedMateri || []).includes(slug))

      // Check if quiz passed (score >= 85)
      if (relatedQuiz) {
        const records = (u.completedQuiz || []).filter(q => q.quizId === relatedQuiz.id)
        const best = records.sort((a, b) => b.score - a.score)[0]
        if (best) {
          setQuizBestScore(best.score)
          setQuizPassed(best.score >= 85)
        }
      } else {
        // Materi tanpa quiz bisa langsung tandai selesai
        setQuizPassed(true)
      }
    }
  }, [slug, relatedQuiz])

  if (!materi) return (
    <div className="min-h-screen bg-[#020617] flex items-center justify-center">
      <div className="text-center">
        <div className="text-5xl mb-4">🔍</div>
        <p className="text-white font-bold mb-2">Materi tidak ditemukan</p>
        <Link href="/materi" className="text-violet-400 hover:text-violet-300">← Kembali ke Materi</Link>
      </div>
    </div>
  )

  const chapter = materi.chapters[activeChapter]
  const isLast = activeChapter === materi.chapters.length - 1

  const handleComplete = async () => {
    if (!user) { toast.error('Login dulu!'); router.push('/login'); return }

    // WAJIB selesaikan quiz dulu
    if (!quizPassed) {
      if (quizBestScore !== null) {
        toast.error(`Nilai quiz kamu ${quizBestScore}%. Butuh minimal 85% untuk tandai selesai!`)
      } else {
        toast.error('Selesaikan quiz dengan nilai ≥85% terlebih dahulu!')
      }
      router.push(`/quiz/${slug}`)
      return
    }

    if (completed) { toast.success('Materi sudah selesai! 🎉'); return }

    setCompleting(true)
    try {
      const res = await fetch('/api/progress', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ materiSlug: slug, xpEarned: materi.xp, badgeId: materi.badgeId }),
      })
      const data = await res.json()
      if (data.success) {
        setCompleted(true)
        const newUser = { ...user, xp: data.user.xp, completedMateri: data.user.completedMateri, badges: data.user.badges }
        setUser(newUser)
        localStorage.setItem('cb_user', JSON.stringify(newUser))
        toast.success(`Materi selesai! +${materi.xp} XP 🎉`)
      }
    } catch { toast.error('Gagal menyimpan progress') }
    finally { setCompleting(false) }
  }

  return (
    <div className="min-h-screen bg-[#020617]">
      <Navbar />
      <div className="max-w-7xl mx-auto px-4 py-20 pt-24">
        {/* Breadcrumb */}
        <div className="flex items-center gap-2 text-sm text-slate-600 mb-6">
          <Link href="/materi" className="hover:text-violet-400 transition-colors">Materi</Link>
          <span>/</span>
          <span className="text-slate-400">{materi.title}</span>
        </div>

        <div className="flex gap-6 flex-col lg:flex-row">
          {/* Sidebar */}
          <div className="lg:w-64 flex-shrink-0">
            <div className="sticky top-24 space-y-3">
              {/* Materi info */}
              <div className="p-4 rounded-2xl bg-[#0f172a] border border-white/[0.06]">
                <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${materi.color} flex items-center justify-center text-xl mb-3`}>{materi.icon}</div>
                <h2 className="font-bold text-white text-sm mb-1">{materi.title}</h2>
                <div className="flex gap-2 flex-wrap">
                  <span className="badge badge-purple">{materi.level}</span>
                  <span className="badge badge-blue">+{materi.xp} XP</span>
                </div>
              </div>

              {/* Quiz status - WAJIB */}
              {relatedQuiz && (
                <div className={`p-4 rounded-2xl border ${quizPassed ? 'bg-emerald-500/5 border-emerald-500/25' : 'bg-yellow-500/5 border-yellow-500/20'}`}>
                  <p className="text-xs font-bold mb-2 flex items-center gap-1.5">
                    {quizPassed ? <span className="text-emerald-400">✓ Quiz Lulus!</span> : <span className="text-yellow-400">⚠️ Quiz Wajib</span>}
                  </p>
                  {quizPassed ? (
                    <p className="text-emerald-400 text-xs">Nilai: {quizBestScore}% ✓<br/>Kamu bisa tandai materi selesai.</p>
                  ) : (
                    <p className="text-slate-500 text-xs">
                      {quizBestScore !== null ? `Nilai terbaik: ${quizBestScore}%` : 'Belum dikerjakan'}<br/>
                      <span className="text-yellow-400 font-semibold">Min 85% untuk unlock XP</span>
                    </p>
                  )}
                  {!quizPassed && (
                    <Link href={`/quiz/${slug}`} className="mt-2 block w-full text-center py-1.5 rounded-lg text-xs font-bold bg-yellow-500/15 text-yellow-400 hover:bg-yellow-500/25 transition-all border border-yellow-500/20">
                      Kerjakan Quiz →
                    </Link>
                  )}
                </div>
              )}

              {/* Chapters */}
              <div className="p-4 rounded-2xl bg-[#0f172a] border border-white/[0.06]">
                <p className="text-[10px] font-black text-slate-600 uppercase tracking-widest mb-3">Chapter</p>
                <nav className="space-y-1">
                  {materi.chapters.map((ch, idx) => (
                    <button key={ch.id} onClick={() => setActiveChapter(idx)}
                      className={`w-full text-left px-3 py-2 rounded-xl text-sm transition-all flex items-center gap-2 ${activeChapter === idx ? 'bg-violet-600/15 text-violet-300 border border-violet-500/20' : 'text-slate-500 hover:text-slate-300 hover:bg-white/[0.03]'}`}>
                      <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-black flex-shrink-0 ${activeChapter === idx ? 'bg-violet-600 text-white' : 'bg-slate-800 text-slate-500'}`}>{idx+1}</span>
                      <span className="truncate text-xs">{ch.title}</span>
                    </button>
                  ))}
                </nav>
              </div>

              {/* Action buttons */}
              <div className="space-y-2">
                <button onClick={handleComplete} disabled={completing || completed}
                  className={`w-full py-2.5 rounded-xl text-sm font-bold transition-all ${
                    completed ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/20 cursor-default' :
                    !quizPassed ? 'bg-slate-800/50 text-slate-500 border border-slate-700/50 cursor-not-allowed' :
                    'bg-violet-600 hover:bg-violet-500 text-white shadow-lg shadow-violet-500/20'
                  }`}>
                  {completing ? '⏳ Menyimpan...' :
                   completed ? '✓ Selesai' :
                   !quizPassed ? '🔒 Selesaikan Quiz Dulu' :
                   '🎉 Tandai Selesai'}
                </button>

                {relatedQuiz && (
                  <Link href={`/quiz/${slug}`}
                    className={`block w-full py-2.5 rounded-xl text-sm font-bold text-center transition-all border ${quizPassed ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20 hover:bg-emerald-500/15' : 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20 hover:bg-yellow-500/15'}`}>
                    {quizPassed ? '📝 Review Quiz' : '🧠 Kerjakan Quiz'}
                  </Link>
                )}
              </div>
            </div>
          </div>

          {/* Content */}
          <div className="flex-1 min-w-0">
            <div className="p-6 sm:p-8 rounded-2xl bg-[#0f172a] border border-white/[0.06]">
              <SimpleMarkdown content={chapter.content} />
            </div>

            {/* Nav */}
            <div className="flex justify-between mt-4">
              <button onClick={() => setActiveChapter(p => Math.max(0, p-1))} disabled={activeChapter === 0}
                className="px-4 py-2 rounded-xl text-sm text-slate-400 bg-[#0f172a] border border-white/[0.06] hover:text-white hover:border-white/10 disabled:opacity-30 disabled:cursor-not-allowed transition-all">
                ← Sebelumnya
              </button>
              {!isLast ? (
                <button onClick={() => setActiveChapter(p => p+1)}
                  className="px-4 py-2 rounded-xl text-sm font-bold text-white bg-violet-600 hover:bg-violet-500 transition-all">
                  Selanjutnya →
                </button>
              ) : (
                <button onClick={handleComplete} disabled={completing || completed}
                  className={`px-4 py-2 rounded-xl text-sm font-bold transition-all ${
                    completed ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/20' :
                    !quizPassed ? 'bg-slate-800 text-slate-500 cursor-not-allowed' :
                    'bg-violet-600 hover:bg-violet-500 text-white'
                  }`}>
                  {completed ? '✓ Selesai' : !quizPassed ? '🔒 Butuh Quiz' : '🎉 Tandai Selesai'}
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
