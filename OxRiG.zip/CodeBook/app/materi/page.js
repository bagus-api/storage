'use client'
import { useState, useEffect } from 'react'
import Link from 'next/link'
import Navbar from '@/components/layout/Navbar'
import { MATERI_LIST } from '@/data/materi'

const CATEGORIES = ['Semua', 'Programming', 'Web Development', 'Cybersecurity']

export default function MateriPage() {
  const [filter, setFilter] = useState('Semua')
  const [user, setUser] = useState(null)
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
    const stored = localStorage.getItem('cb_user')
    if (stored) setUser(JSON.parse(stored))
  }, [])

  const filtered = filter === 'Semua' ? MATERI_LIST : MATERI_LIST.filter(m => m.category === filter)

  return (
    <div className="min-h-screen bg-[#0a0b14]">
      <Navbar />
      <div className="max-w-7xl mx-auto px-4 py-24">
        <div className="mb-10">
          <p className="text-[#8095ff] text-sm font-medium mb-2 tracking-wide uppercase">Kurikulum</p>
          <h1 className="text-3xl sm:text-4xl font-bold text-white mb-3">Materi Pembelajaran</h1>
          <p className="text-slate-500 max-w-lg">Pilih materi yang ingin kamu pelajari. Setiap materi dilengkapi quiz dan sertifikat.</p>
        </div>

        {/* Filter */}
        <div className="flex gap-2 mb-8 flex-wrap">
          {CATEGORIES.map(cat => (
            <button
              key={cat}
              onClick={() => setFilter(cat)}
              className={`px-4 py-1.5 rounded-full text-sm font-medium transition-all ${
                filter === cat
                  ? 'bg-[#6171f5] text-white shadow-lg shadow-[#6171f5]/20'
                  : 'bg-[#0f1117] text-slate-400 border border-white/[0.06] hover:border-white/10 hover:text-white'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((m, i) => {
            const done = mounted && user && (user.completedMateri || []).includes(m.slug)
            return (
              <Link
                key={m.slug}
                href={`/materi/${m.slug}`}
                className="group relative p-5 rounded-2xl bg-[#0f1117] border border-white/[0.06] hover:border-[#6171f5]/30 transition-all duration-300 hover:bg-[#111324] hover:-translate-y-0.5 flex flex-col"
                style={{ animationDelay: `${i * 60}ms` }}
              >
                {done && (
                  <div className="absolute top-4 right-4 text-xs bg-emerald-500/15 text-emerald-400 border border-emerald-500/20 px-2 py-0.5 rounded-full">
                    ✓ Selesai
                  </div>
                )}
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${m.color} flex items-center justify-center text-2xl mb-4 shadow-lg`}>
                  {m.icon}
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-white group-hover:text-[#a5bbff] transition-colors mb-1">{m.title}</h3>
                  <p className="text-slate-500 text-sm leading-relaxed mb-4">{m.description}</p>
                </div>
                <div className="flex items-center gap-2 flex-wrap mt-auto">
                  <span className="px-2 py-0.5 rounded-full text-xs bg-[#1a1d2e] text-slate-400 border border-white/[0.06]">{m.category}</span>
                  <span className="px-2 py-0.5 rounded-full text-xs bg-[#1a1d2e] text-slate-400 border border-white/[0.06]">{m.level}</span>
                  <span className="px-2 py-0.5 rounded-full text-xs bg-[#6171f5]/10 text-[#8095ff] border border-[#6171f5]/20 ml-auto">+{m.xp} XP</span>
                </div>
                <div className="mt-4 pt-4 border-t border-white/[0.04] flex items-center justify-between text-xs text-slate-600">
                  <span>⏱ {m.duration}</span>
                  <span>{m.chapters.length} chapter</span>
                </div>
              </Link>
            )
          })}
        </div>
      </div>
    </div>
  )
}
