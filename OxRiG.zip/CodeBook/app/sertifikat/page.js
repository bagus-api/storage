'use client'
import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import Navbar from '@/components/layout/Navbar'
import { MATERI_LIST, QUIZ_DATA } from '@/data/materi'
import toast from 'react-hot-toast'

function generateCertCanvas(cert, userName) {
  return new Promise((resolve) => {
    const W = 1400, H = 900
    const canvas = document.createElement('canvas')
    canvas.width = W; canvas.height = H
    const ctx = canvas.getContext('2d')

    // --- Background ---
    ctx.fillStyle = '#080a12'
    ctx.fillRect(0, 0, W, H)

    // Subtle gradient overlay
    const grad = ctx.createRadialGradient(W/2, H/2, 0, W/2, H/2, 700)
    grad.addColorStop(0, 'rgba(97,113,245,0.06)')
    grad.addColorStop(1, 'rgba(8,10,18,0)')
    ctx.fillStyle = grad
    ctx.fillRect(0, 0, W, H)

    // --- Outer Border ---
    ctx.strokeStyle = '#6171f5'
    ctx.lineWidth = 2.5
    roundRect(ctx, 28, 28, W-56, H-56, 20)
    ctx.stroke()

    // --- Inner Border ---
    ctx.strokeStyle = 'rgba(97,113,245,0.25)'
    ctx.lineWidth = 1
    roundRect(ctx, 44, 44, W-88, H-88, 14)
    ctx.stroke()

    // --- Corner Accents ---
    drawCorner(ctx, 44, 44, 40, '#6171f5')
    drawCorner(ctx, W-44, 44, 40, '#6171f5', true, false)
    drawCorner(ctx, 44, H-44, 40, '#6171f5', false, true)
    drawCorner(ctx, W-44, H-44, 40, '#6171f5', true, true)

    // --- Top Header Area ---
    ctx.fillStyle = 'rgba(97,113,245,0.08)'
    roundRectFill(ctx, 44, 44, W-88, 130, 14)

    // Logo Circle
    const logoGrad = ctx.createLinearGradient(W/2-30, 60, W/2+30, 130)
    logoGrad.addColorStop(0, '#6171f5')
    logoGrad.addColorStop(1, '#9b6dff')
    ctx.fillStyle = logoGrad
    circle(ctx, W/2, 100, 38)

    ctx.fillStyle = '#ffffff'
    ctx.font = 'bold 24px Arial'
    ctx.textAlign = 'center'
    ctx.fillText('CB', W/2, 108)

    // Platform name
    ctx.font = 'bold 20px Arial'
    ctx.fillStyle = '#ffffff'
    ctx.fillText('CodeBook', W/2, 148)

    ctx.font = '13px Arial'
    ctx.fillStyle = 'rgba(165,187,255,0.7)'
    ctx.fillText('Platform Belajar Coding Indonesia', W/2, 168)

    // --- Divider ---
    const divGrad = ctx.createLinearGradient(100, 0, W-100, 0)
    divGrad.addColorStop(0, 'transparent')
    divGrad.addColorStop(0.5, '#6171f5')
    divGrad.addColorStop(1, 'transparent')
    ctx.strokeStyle = divGrad
    ctx.lineWidth = 1.5
    ctx.beginPath()
    ctx.moveTo(100, 192); ctx.lineTo(W-100, 192)
    ctx.stroke()

    // --- Certificate Title ---
    ctx.font = '14px Arial'
    ctx.fillStyle = 'rgba(165,187,255,0.6)'
    ctx.letterSpacing = '4px'
    ctx.fillText('S E R T I F I K A T   P E N Y E L E S A I A N', W/2, 240)

    // --- Decoration line under title ---
    ctx.strokeStyle = 'rgba(97,113,245,0.3)'
    ctx.lineWidth = 1
    ctx.setLineDash([4, 4])
    ctx.beginPath()
    ctx.moveTo(W/2-180, 255); ctx.lineTo(W/2+180, 255)
    ctx.stroke()
    ctx.setLineDash([])

    // --- "Diberikan kepada" ---
    ctx.font = '16px Arial'
    ctx.fillStyle = '#64748b'
    ctx.fillText('Diberikan dengan bangga kepada', W/2, 305)

    // --- Recipient Name ---
    const nameText = userName || cert.userName
    ctx.font = `bold ${nameText.length > 20 ? '52' : '64'}px Georgia`
    const nameGrad = ctx.createLinearGradient(W/2-300, 0, W/2+300, 0)
    nameGrad.addColorStop(0, '#a5bbff')
    nameGrad.addColorStop(0.5, '#ffffff')
    nameGrad.addColorStop(1, '#a5bbff')
    ctx.fillStyle = nameGrad
    ctx.fillText(nameText, W/2, 385)

    // Underline name
    const nw = ctx.measureText(nameText).width
    const lineGrad = ctx.createLinearGradient(W/2-nw/2, 0, W/2+nw/2, 0)
    lineGrad.addColorStop(0, 'transparent')
    lineGrad.addColorStop(0.5, '#6171f5')
    lineGrad.addColorStop(1, 'transparent')
    ctx.strokeStyle = lineGrad
    ctx.lineWidth = 2
    ctx.beginPath()
    ctx.moveTo(W/2-nw/2, 398); ctx.lineTo(W/2+nw/2, 398)
    ctx.stroke()

    // --- Description ---
    ctx.font = '17px Arial'
    ctx.fillStyle = '#64748b'
    ctx.fillText('telah berhasil menyelesaikan kursus dengan nilai quiz', W/2, 448)

    // --- Course Name ---
    ctx.font = 'bold 30px Arial'
    const courseGrad = ctx.createLinearGradient(0, 0, W, 0)
    courseGrad.addColorStop(0.3, '#8095ff')
    courseGrad.addColorStop(0.5, '#c7d7ff')
    courseGrad.addColorStop(0.7, '#8095ff')
    ctx.fillStyle = courseGrad
    ctx.fillText(cert.courseName, W/2, 493)

    // Quiz score badge
    if (cert.quizScore) {
      ctx.font = 'bold 14px Arial'
      ctx.fillStyle = '#10b981'
      ctx.fillText(`Nilai Quiz: ${cert.quizScore}% ✓`, W/2, 528)
    }

    // --- Bottom Section Divider ---
    const divGrad2 = ctx.createLinearGradient(80, 0, W-80, 0)
    divGrad2.addColorStop(0, 'transparent')
    divGrad2.addColorStop(0.5, 'rgba(97,113,245,0.3)')
    divGrad2.addColorStop(1, 'transparent')
    ctx.strokeStyle = divGrad2
    ctx.lineWidth = 1
    ctx.beginPath()
    ctx.moveTo(80, 570); ctx.lineTo(W-80, 570)
    ctx.stroke()

    // --- Footer Details ---
    const colW = (W - 160) / 3

    // Col 1: Date
    const col1x = 130
    ctx.font = '12px Arial'
    ctx.fillStyle = '#475569'
    ctx.textAlign = 'left'
    ctx.fillText('TANGGAL DITERBITKAN', col1x, 608)
    ctx.font = 'bold 15px Arial'
    ctx.fillStyle = '#94a3b8'
    ctx.fillText(new Date(cert.issuedAt).toLocaleDateString('id-ID', { year:'numeric', month:'long', day:'numeric' }), col1x, 630)

    // Col 2: Cert ID (center)
    ctx.textAlign = 'center'
    ctx.font = '12px Arial'
    ctx.fillStyle = '#475569'
    ctx.fillText('CERTIFICATE ID', W/2, 608)
    ctx.font = 'bold 16px "Courier New"'
    ctx.fillStyle = '#6171f5'
    ctx.fillText(cert.certId, W/2, 630)

    // Col 3: Issuer
    ctx.textAlign = 'right'
    ctx.font = '12px Arial'
    ctx.fillStyle = '#475569'
    ctx.fillText('DITERBITKAN OLEH', W-130, 608)
    ctx.font = 'bold 15px Arial'
    ctx.fillStyle = '#94a3b8'
    ctx.fillText('Tim CodeBook', W-130, 630)

    // --- Verify URL ---
    ctx.textAlign = 'center'
    ctx.font = '12px Arial'
    ctx.fillStyle = 'rgba(97,113,245,0.5)'
    const baseUrl = window.location.origin
    ctx.fillText(`Verifikasi: ${baseUrl}/verify/${cert.certId}`, W/2, 680)

    // --- QR Code Placeholder Box ---
    ctx.strokeStyle = 'rgba(97,113,245,0.25)'
    ctx.lineWidth = 1
    roundRect(ctx, W/2-55, 690, 110, 110, 8)
    ctx.stroke()
    ctx.font = '10px Arial'
    ctx.fillStyle = 'rgba(97,113,245,0.4)'
    ctx.fillText('QR Verifikasi', W/2, 755)

    // Scan lines QR effect
    ctx.strokeStyle = 'rgba(97,113,245,0.15)'
    ctx.lineWidth = 0.5
    for (let i = 0; i < 8; i++) {
      ctx.beginPath()
      ctx.moveTo(W/2-45, 700+i*12)
      ctx.lineTo(W/2+45, 700+i*12)
      ctx.stroke()
    }

    // Watermark
    ctx.save()
    ctx.globalAlpha = 0.03
    ctx.font = 'bold 300px Arial'
    ctx.fillStyle = '#6171f5'
    ctx.textAlign = 'center'
    ctx.fillText('CB', W/2, 600)
    ctx.restore()

    // Border bottom shine
    ctx.strokeStyle = 'rgba(97,113,245,0.15)'
    ctx.lineWidth = 1
    ctx.beginPath()
    ctx.moveTo(80, H-60); ctx.lineTo(W-80, H-60)
    ctx.stroke()

    // Bottom text
    ctx.font = '11px Arial'
    ctx.fillStyle = 'rgba(100,116,139,0.5)'
    ctx.fillText('© 2024 CodeBook — Platform Belajar Coding Indonesia', W/2, H-38)

    const link = document.createElement('a')
    link.download = `CodeBook-Certificate-${cert.certId}.png`
    link.href = canvas.toDataURL('image/png', 0.95)
    link.click()
    resolve()
  })
}

// Helper functions
function roundRect(ctx, x, y, w, h, r) {
  ctx.beginPath()
  ctx.moveTo(x+r, y)
  ctx.lineTo(x+w-r, y)
  ctx.quadraticCurveTo(x+w, y, x+w, y+r)
  ctx.lineTo(x+w, y+h-r)
  ctx.quadraticCurveTo(x+w, y+h, x+w-r, y+h)
  ctx.lineTo(x+r, y+h)
  ctx.quadraticCurveTo(x, y+h, x, y+h-r)
  ctx.lineTo(x, y+r)
  ctx.quadraticCurveTo(x, y, x+r, y)
  ctx.closePath()
}
function roundRectFill(ctx, x, y, w, h, r) {
  roundRect(ctx, x, y, w, h, r)
  ctx.fill()
}
function circle(ctx, cx, cy, r) {
  ctx.beginPath()
  ctx.arc(cx, cy, r, 0, Math.PI*2)
  ctx.fill()
}
function drawCorner(ctx, x, y, size, color, flipX=false, flipY=false) {
  const sx = flipX ? -1 : 1, sy = flipY ? -1 : 1
  ctx.strokeStyle = color; ctx.lineWidth = 2.5
  ctx.beginPath()
  ctx.moveTo(x + sx*size, y)
  ctx.lineTo(x, y)
  ctx.lineTo(x, y + sy*size)
  ctx.stroke()
}

export default function SertifikatPage() {
  const [user, setUser] = useState(null)
  const [generating, setGenerating] = useState(null)
  const [loading, setLoading] = useState(true)
  const router = useRouter()

  useEffect(() => {
    const stored = localStorage.getItem('cb_user')
    if (!stored) { router.push('/login'); return }
    setUser(JSON.parse(stored))

    fetch('/api/user/me', { credentials: 'include' })
      .then(r => r.json())
      .then(data => { if (data.user) setUser(data.user) })
      .finally(() => setLoading(false))
  }, [router])

  const handleGenerate = async (materi) => {
    if (!(user?.completedMateri || []).includes(materi.slug)) {
      toast.error('Selesaikan materi ini dulu!')
      return
    }

    const quizRecord = (user?.completedQuiz || []).filter(q => q.quizId.includes(materi.slug.split('-')[0])).sort((a, b) => b.score - a.score)[0]
    if (!quizRecord || quizRecord.score < 85) {
      toast.error(`Nilai quiz minimal 85%! ${quizRecord ? `Nilai terbaik: ${quizRecord.score}%` : 'Kerjakan quiz dulu!'}`)
      return
    }

    setGenerating(materi.slug)
    try {
      const res = await fetch('/api/certificate/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ courseSlug: materi.slug, courseName: materi.title }),
      })
      const data = await res.json()
      if (!data.success) { toast.error(data.error || 'Gagal generate'); return }

      toast.loading('Membuat sertifikat...', { id: 'cert' })
      await generateCertCanvas({ ...data.certificate, quizScore: quizRecord.score }, user.name)
      toast.success('Sertifikat berhasil diunduh! 🎉', { id: 'cert' })

      const stored = localStorage.getItem('cb_user')
      if (stored) {
        const u = JSON.parse(stored)
        localStorage.setItem('cb_user', JSON.stringify({ ...u, certificates: [...(u.certificates || []), data.certificate.certId] }))
        setUser(p => ({ ...p, certificates: [...(p?.certificates || []), data.certificate.certId] }))
      }
    } catch { toast.error('Terjadi kesalahan') }
    finally { setGenerating(null) }
  }

  if (loading) return (
    <div className="min-h-screen bg-[#0a0b14]"><Navbar />
      <div className="flex items-center justify-center h-[80vh]">
        <svg className="animate-spin w-6 h-6 text-[#6171f5]" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"/></svg>
      </div>
    </div>
  )

  const completedSlugs = new Set(user?.completedMateri || [])

  return (
    <div className="min-h-screen bg-[#0a0b14]">
      <Navbar />
      <div className="max-w-5xl mx-auto px-4 py-24">
        <div className="mb-10">
          <p className="text-[#8095ff] text-sm font-medium mb-2 tracking-wide uppercase">Pencapaian</p>
          <h1 className="text-3xl sm:text-4xl font-bold text-white mb-3">Sertifikat</h1>
          <p className="text-slate-500">Selesaikan materi + nilai quiz ≥85% untuk mendapatkan sertifikat PDF profesional.</p>
        </div>

        {/* Requirement info */}
        <div className="mb-8 p-4 rounded-2xl bg-[#6171f5]/8 border border-[#6171f5]/20 flex items-start gap-3">
          <span className="text-xl flex-shrink-0 mt-0.5">📋</span>
          <div className="text-sm text-slate-400">
            <p className="font-medium text-[#a5bbff] mb-1">Syarat mendapatkan sertifikat:</p>
            <p>1. Selesaikan semua chapter materi &nbsp;✓ &nbsp; 2. Nilai quiz minimal <strong className="text-emerald-400">85%</strong> &nbsp;✓ &nbsp; 3. Klik "Unduh Sertifikat"</p>
          </div>
        </div>

        <div className="grid gap-3">
          {MATERI_LIST.map(m => {
            const done = completedSlugs.has(m.slug)
            const quizRecord = (user?.completedQuiz || []).filter(q => q.quizId.includes(m.slug.split('-')[0])).sort((a,b) => b.score - a.score)[0]
            const quizPassed = quizRecord && quizRecord.score >= 85
            const canGetCert = done && quizPassed
            const isGen = generating === m.slug

            return (
              <div key={m.slug} className={`flex items-center gap-4 p-4 rounded-xl border transition-all ${done ? 'bg-[#0f1117] border-white/[0.06]' : 'bg-[#0d0f1a] border-white/[0.04] opacity-50'}`}>
                <div className={`w-11 h-11 rounded-xl bg-gradient-to-br ${m.color} flex items-center justify-center text-xl flex-shrink-0 ${!done ? 'grayscale' : ''}`}>{m.icon}</div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-white text-sm truncate">{m.title}</p>
                  <div className="flex items-center gap-2 mt-1 flex-wrap">
                    <span className={`text-xs px-1.5 py-0.5 rounded ${done ? 'text-emerald-400 bg-emerald-500/10' : 'text-slate-600 bg-white/5'}`}>
                      {done ? '✓ Materi' : '○ Materi'}
                    </span>
                    <span className={`text-xs px-1.5 py-0.5 rounded ${quizPassed ? 'text-emerald-400 bg-emerald-500/10' : quizRecord ? 'text-yellow-400 bg-yellow-500/10' : 'text-slate-600 bg-white/5'}`}>
                      {quizPassed ? `✓ Quiz ${quizRecord.score}%` : quizRecord ? `Quiz ${quizRecord.score}% (min 85%)` : '○ Quiz'}
                    </span>
                  </div>
                </div>
                <div className="flex-shrink-0">
                  {canGetCert ? (
                    <button onClick={() => handleGenerate(m)} disabled={isGen}
                      className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium bg-[#6171f5] hover:bg-[#4f52ea] text-white disabled:opacity-60 transition-all">
                      {isGen ? <svg className="animate-spin w-3.5 h-3.5" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"/></svg> : '⬇'}
                      {isGen ? 'Membuat...' : 'Unduh'}
                    </button>
                  ) : done ? (
                    <Link href={`/quiz/${m.slug}`} className="px-4 py-2 rounded-xl text-sm text-yellow-400 border border-yellow-500/20 hover:bg-yellow-500/5 transition-all">
                      Kerjakan Quiz →
                    </Link>
                  ) : (
                    <Link href={`/materi/${m.slug}`} className="px-4 py-2 rounded-xl text-sm text-slate-500 border border-white/[0.06] hover:text-slate-300 transition-all">
                      Pelajari →
                    </Link>
                  )}
                </div>
              </div>
            )
          })}
        </div>

        {(user?.certificates || []).length > 0 && (
          <div className="mt-8">
            <h2 className="font-semibold text-white mb-4">🏆 Sertifikat Kamu</h2>
            <div className="grid gap-2">
              {(user.certificates || []).map(certId => (
                <div key={certId} className="flex items-center gap-3 p-3.5 rounded-xl bg-[#0f1117] border border-[#6171f5]/15">
                  <span className="text-xl">📜</span>
                  <span className="font-mono text-sm text-[#8095ff]">{certId}</span>
                  <Link href={`/verify/${certId}`} className="ml-auto text-xs text-slate-600 hover:text-slate-400 transition-colors">Verifikasi →</Link>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
