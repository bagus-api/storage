'use client'
import { useState, useEffect } from 'react'
import Link from 'next/link'
import Navbar from '@/components/layout/Navbar'

const CHALLENGES = [
  // === SECURITY LABS ===
  {
    id: 'xss-reflected',
    category: 'Security Lab',
    title: 'XSS: Reflected Attack Lab',
    icon: '🎯',
    difficulty: 'Beginner',
    diffColor: 'badge-green',
    xp: 100,
    tags: ['xss', 'security', 'web'],
    desc: 'Temukan dan eksploitasi celah XSS reflected pada form input, lalu pelajari cara memperbaikinya.',
  },
  {
    id: 'xss-stored',
    category: 'Security Lab',
    title: 'XSS: Stored Attack Lab',
    icon: '💾',
    difficulty: 'Intermediate',
    diffColor: 'badge-yellow',
    xp: 200,
    tags: ['xss', 'stored', 'security'],
    desc: 'Temukan celah XSS stored yang tersimpan di database dan ditampilkan ke semua user.',
  },
  {
    id: 'sqli-basic',
    category: 'Security Lab',
    title: 'SQL Injection: Basic Lab',
    icon: '💉',
    difficulty: 'Beginner',
    diffColor: 'badge-green',
    xp: 120,
    tags: ['sqli', 'database', 'security'],
    desc: 'Bypass login form menggunakan SQL injection klasik, lalu pahami cara mengamankannya.',
  },
  {
    id: 'csrf-lab',
    category: 'Security Lab',
    title: 'CSRF: Cross-Site Request Lab',
    icon: '🔄',
    difficulty: 'Intermediate',
    diffColor: 'badge-yellow',
    xp: 180,
    tags: ['csrf', 'auth', 'security'],
    desc: 'Simulasikan serangan CSRF pada form yang tidak terproteksi dan pelajari SameSite cookie.',
  },
  // === CODING CHALLENGES ===
  {
    id: 'algo-sort',
    category: 'Coding',
    title: 'Implementasi Sorting Algorithm',
    icon: '📊',
    difficulty: 'Beginner',
    diffColor: 'badge-green',
    xp: 80,
    tags: ['algorithm', 'javascript', 'sorting'],
    desc: 'Implementasikan Bubble Sort, Selection Sort, dan Quick Sort dari nol tanpa library.',
  },
  {
    id: 'algo-ds',
    category: 'Coding',
    title: 'Data Structures: Stack & Queue',
    icon: '🗂️',
    difficulty: 'Intermediate',
    diffColor: 'badge-yellow',
    xp: 150,
    tags: ['data-structure', 'javascript'],
    desc: 'Buat implementasi Stack dan Queue dengan JavaScript class + semua method-nya.',
  },
  {
    id: 'api-build',
    category: 'Coding',
    title: 'Build REST API dari Nol',
    icon: '🔌',
    difficulty: 'Intermediate',
    diffColor: 'badge-yellow',
    xp: 200,
    tags: ['api', 'backend', 'node'],
    desc: 'Bangun REST API lengkap: auth, CRUD, validasi, dan error handling tanpa framework.',
  },
  {
    id: 'regex-master',
    category: 'Coding',
    title: 'Regex Master Challenge',
    icon: '🔤',
    difficulty: 'Advanced',
    diffColor: 'badge-red',
    xp: 250,
    tags: ['regex', 'javascript', 'string'],
    desc: '10 soal regex dari mudah ke sulit — validasi email, parse URL, extract data, dan lainnya.',
  },
  // === CTF-STYLE ===
  {
    id: 'ctf-token',
    category: 'CTF',
    title: 'Find the Hidden Token',
    icon: '🔑',
    difficulty: 'Intermediate',
    diffColor: 'badge-yellow',
    xp: 300,
    tags: ['ctf', 'security', 'recon'],
    desc: 'Temukan token tersembunyi dalam kode HTML yang disengaja tidak aman. Inspeksi & decode!',
  },
  {
    id: 'ctf-crypto',
    category: 'CTF',
    title: 'Decode the Secret Message',
    icon: '🔐',
    difficulty: 'Advanced',
    diffColor: 'badge-red',
    xp: 350,
    tags: ['ctf', 'crypto', 'base64'],
    desc: 'Decode pesan yang di-encode dengan beberapa layer: Base64 → ROT13 → Hex → Flag!',
  },
]

const CATS = ['Semua', 'Security Lab', 'Coding', 'CTF']
const DIFFS = ['Semua', 'Beginner', 'Intermediate', 'Advanced']

export default function TantanganPage() {
  const [cat, setCat] = useState('Semua')
  const [diff, setDiff] = useState('Semua')
  const [user, setUser] = useState(null)

  useEffect(() => {
    const s = localStorage.getItem('cb_user')
    if (s) setUser(JSON.parse(s))
  }, [])

  const filtered = CHALLENGES.filter(c =>
    (cat === 'Semua' || c.category === cat) &&
    (diff === 'Semua' || c.difficulty === diff)
  )

  const completedIds = new Set(user?.completedMateri || [])

  return (
    <div className="min-h-screen bg-[#020617]">
      <Navbar />
      <div className="max-w-6xl mx-auto px-4 py-24">
        <div className="mb-10">
          <p className="section-label">Arena</p>
          <h1 className="section-title">Tantangan & Lab</h1>
          <p className="text-slate-500 mt-2">Uji kemampuanmu — dari Security Labs, Coding Challenges, hingga CTF-style challenges.</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-3 mb-8">
          {[
            { label: 'Total Tantangan', value: CHALLENGES.length, icon: '🎯' },
            { label: 'Security Labs', value: CHALLENGES.filter(c=>c.category==='Security Lab').length, icon: '🛡️' },
            { label: 'Total XP', value: CHALLENGES.reduce((a,c)=>a+c.xp,0), icon: '⚡' },
          ].map(s => (
            <div key={s.label} className="p-4 rounded-2xl bg-[#0f172a] border border-white/[0.06] text-center">
              <div className="text-2xl mb-1">{s.icon}</div>
              <div className="font-black text-white text-xl">{s.value}</div>
              <div className="text-slate-600 text-xs mt-0.5">{s.label}</div>
            </div>
          ))}
        </div>

        {/* Filters */}
        <div className="flex gap-2 flex-wrap mb-6">
          <div className="flex gap-1 p-1 bg-[#0f172a] border border-white/[0.06] rounded-xl">
            {CATS.map(c => (
              <button key={c} onClick={() => setCat(c)}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${cat===c ? 'bg-violet-600 text-white' : 'text-slate-500 hover:text-slate-200'}`}>
                {c}
              </button>
            ))}
          </div>
          <div className="flex gap-1 p-1 bg-[#0f172a] border border-white/[0.06] rounded-xl">
            {DIFFS.map(d => (
              <button key={d} onClick={() => setDiff(d)}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${diff===d ? 'bg-violet-600 text-white' : 'text-slate-500 hover:text-slate-200'}`}>
                {d}
              </button>
            ))}
          </div>
        </div>

        {/* Challenge grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map(c => (
            <Link key={c.id} href={`/tantangan/${c.id}`}
              className="group p-5 rounded-2xl bg-[#0f172a] border border-white/[0.06] hover:border-violet-500/30 transition-all hover:-translate-y-0.5 flex flex-col">
              <div className="flex items-start gap-3 mb-3">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-slate-800 to-slate-900 flex items-center justify-center text-2xl flex-shrink-0 border border-white/[0.06] group-hover:border-violet-500/25 transition-all">
                  {c.icon}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1 flex-wrap">
                    <span className={`badge ${c.diffColor}`}>{c.difficulty}</span>
                    <span className="badge badge-purple">{c.category}</span>
                  </div>
                  <h3 className="font-bold text-white text-sm group-hover:text-violet-300 transition-colors leading-tight">{c.title}</h3>
                </div>
              </div>
              <p className="text-slate-500 text-xs leading-relaxed flex-1">{c.desc}</p>
              <div className="flex items-center gap-2 mt-4 pt-3 border-t border-white/[0.04] flex-wrap">
                {c.tags.slice(0,3).map(t => (
                  <span key={t} className="text-[10px] text-slate-600">#{t}</span>
                ))}
                <span className="ml-auto text-xs font-bold text-violet-400">+{c.xp} XP</span>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  )
}
