'use client'
import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import Navbar from '@/components/layout/Navbar'
import ProgressBar from '@/components/ui/ProgressBar'
import { BadgeChip } from '@/components/ui/Badge'
import { SkeletonCard } from '@/components/ui/Skeleton'
import { MATERI_LIST } from '@/data/materi'
import { QUIZ_DATA } from '@/data/quiz'
import { calcLevel, calcXPPercent, BADGES } from '@/lib/utils'

export default function DashboardPage() {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)
  const router = useRouter()

  useEffect(() => {
    fetch('/api/user/me', { credentials: 'include' })
      .then(r => r.json())
      .then(data => {
        if (data.user) {
          setUser(data.user)
          localStorage.setItem('cb_user', JSON.stringify({
            id: data.user._id, name: data.user.name, email: data.user.email,
            xp: data.user.xp, badges: data.user.badges, streak: data.user.streak,
            completedMateri: data.user.completedMateri, completedQuiz: data.user.completedQuiz,
          }))
        } else {
          router.push('/login')
        }
      })
      .catch(() => router.push('/login'))
      .finally(() => setLoading(false))
  }, [router])

  if (loading) return (
    <div className="min-h-screen bg-[#0a0b14]">
      <Navbar />
      <div className="max-w-7xl mx-auto px-4 py-24">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">{[1,2,3].map(i => <SkeletonCard key={i} />)}</div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">{[1,2,3,4,5,6].map(i => <SkeletonCard key={i} />)}</div>
      </div>
    </div>
  )
  if (!user) return null

  const { level, next, icon } = calcLevel(user.xp || 0)
  const xpPct = calcXPPercent(user.xp || 0)
  const completedCount = (user.completedMateri || []).length
  const completedQuizIds = new Set((user.completedQuiz || []).map(q => q.quizId))
  const passedQuizIds = new Set((user.completedQuiz || []).filter(q => q.score >= 85).map(q => q.quizId))

  return (
    <div className="min-h-screen bg-[#0a0b14]">
      <Navbar />
      <div className="max-w-7xl mx-auto px-4 py-24">

        {/* Header */}
        <div className="mb-8 flex items-start justify-between flex-wrap gap-4">
          <div>
            <h1 className="text-2xl font-bold text-white">Halo, {user.name.split(' ')[0]}! {icon}</h1>
            <p className="text-slate-500 text-sm mt-1">
              {user.streak > 0 ? `🔥 Streak ${user.streak} hari • ` : ''}Level {level} • {user.xp || 0} XP
            </p>
          </div>
          <Link href="/materi" className="px-4 py-2 rounded-xl text-sm font-medium bg-[#6171f5] text-white hover:bg-[#4f52ea] transition-colors">
            Lanjut Belajar →
          </Link>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-6">
          {[
            { label: 'Total XP', value: user.xp || 0, icon: '⚡', color: 'text-[#8095ff]' },
            { label: 'Level', value: level, icon, color: 'text-white' },
            { label: 'Materi Selesai', value: `${completedCount}/${MATERI_LIST.length}`, icon: '📚', color: 'text-emerald-400' },
            { label: 'Streak', value: `${user.streak || 0} hari`, icon: '🔥', color: 'text-orange-400' },
          ].map(s => (
            <div key={s.label} className="p-4 rounded-xl bg-[#0f1117] border border-white/[0.06]">
              <div className="text-2xl mb-2">{s.icon}</div>
              <div className={`font-bold text-lg ${s.color}`}>{s.value}</div>
              <div className="text-slate-600 text-xs mt-0.5">{s.label}</div>
            </div>
          ))}
        </div>

        {/* XP Progress */}
        <div className="mb-6 p-5 rounded-2xl bg-[#0f1117] border border-white/[0.06]">
          <div className="flex items-center justify-between mb-3">
            <span className="font-semibold text-white">{icon} Level {level} <span className="text-slate-500 text-sm font-normal">— {user.xp || 0}{next ? ` / ${next}` : '+'} XP</span></span>
            <span className="text-[#8095ff] font-semibold text-sm">{xpPct}%</span>
          </div>
          <ProgressBar value={xpPct} max={100} size="lg" />
          {next && <p className="text-slate-600 text-xs mt-2">{next - (user.xp || 0)} XP lagi untuk level berikutnya</p>}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Materi list */}
          <div className="lg:col-span-2">
            <h2 className="font-semibold text-white mb-4">Progress Materi</h2>
            <div className="space-y-2">
              {MATERI_LIST.map(m => {
                const done = (user.completedMateri || []).includes(m.slug)
                const quizDone = QUIZ_DATA.find(q => q.slug === m.slug)
                const quizPassed = quizDone && passedQuizIds.has(quizDone.id)
                return (
                  <Link key={m.slug} href={`/materi/${m.slug}`}
                    className="flex items-center gap-3 p-4 rounded-xl bg-[#0f1117] border border-white/[0.06] hover:border-white/10 group transition-all">
                    <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${m.color} flex items-center justify-center text-xl flex-shrink-0`}>{m.icon}</div>
                    <div className="flex-1 min-w-0">
                      <span className="font-medium text-white text-sm group-hover:text-[#a5bbff] transition-colors truncate block">{m.title}</span>
                      <div className="flex gap-2 mt-0.5">
                        <span className={`text-xs ${done ? 'text-emerald-400' : 'text-slate-600'}`}>{done ? '✓ Materi' : '○ Materi'}</span>
                        {quizDone && <span className={`text-xs ${quizPassed ? 'text-emerald-400' : 'text-slate-600'}`}>{quizPassed ? '✓ Quiz' : '○ Quiz'}</span>}
                      </div>
                    </div>
                    <span className="text-xs text-[#8095ff]">+{m.xp} XP</span>
                  </Link>
                )
              })}
            </div>
          </div>

          {/* Right sidebar */}
          <div className="space-y-6">
            {/* Badges */}
            <div>
              <h2 className="font-semibold text-white mb-3">Badge Koleksi</h2>
              <div className="p-4 rounded-2xl bg-[#0f1117] border border-white/[0.06]">
                <div className="grid grid-cols-4 gap-3">
                  {Object.entries(BADGES).map(([id, badge]) => (
                    <BadgeChip key={id} {...badge} earned={(user.badges || []).includes(id)} small />
                  ))}
                </div>
                <p className="text-xs text-slate-600 mt-3 text-center">{(user.badges || []).length}/{Object.keys(BADGES).length} badge</p>
              </div>
            </div>

            {/* Quiz Status */}
            <div>
              <h2 className="font-semibold text-white mb-3">Status Quiz</h2>
              <div className="space-y-2">
                {QUIZ_DATA.map(quiz => {
                  const records = (user.completedQuiz || []).filter(q => q.quizId === quiz.id)
                  const best = records.sort((a,b) => b.score - a.score)[0]
                  const passed = best && best.score >= quiz.minScore
                  return (
                    <Link key={quiz.id} href={`/quiz/${quiz.slug}`}
                      className="flex items-center gap-3 p-3 rounded-xl bg-[#0f1117] border border-white/[0.06] hover:border-white/10 group transition-all">
                      <span className="text-lg">{passed ? '✅' : best ? '🔄' : '📝'}</span>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-white truncate group-hover:text-[#a5bbff] transition-colors">{quiz.title}</p>
                        {best ? (
                          <p className={`text-xs ${passed ? 'text-emerald-400' : 'text-yellow-400'}`}>
                            {best.score}% {passed ? '✓ Lulus' : `(min ${quiz.minScore}%)`}
                          </p>
                        ) : <p className="text-xs text-slate-600">Belum dikerjakan</p>}
                      </div>
                    </Link>
                  )
                })}
              </div>
            </div>

            {/* Certs */}
            <div>
              <h2 className="font-semibold text-white mb-3">Sertifikat</h2>
              {(user.certificates || []).length === 0 ? (
                <div className="p-4 rounded-xl bg-[#0f1117] border border-white/[0.06] text-center">
                  <div className="text-3xl mb-2">📜</div>
                  <p className="text-xs text-slate-500 mb-2">Lulus quiz ≥85% untuk sertifikat</p>
                  <Link href="/sertifikat" className="text-xs text-[#8095ff] hover:text-[#a5bbff]">Halaman Sertifikat →</Link>
                </div>
              ) : (
                <div className="space-y-2">
                  {(user.certificates || []).slice(0, 3).map(certId => (
                    <div key={certId} className="flex items-center gap-2 p-3 rounded-xl bg-[#0f1117] border border-[#6171f5]/15">
                      <span>📜</span>
                      <span className="text-xs text-[#8095ff] font-mono truncate">{certId}</span>
                    </div>
                  ))}
                  <Link href="/sertifikat" className="text-xs text-[#8095ff] block text-center hover:text-[#a5bbff]">Lihat semua →</Link>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
