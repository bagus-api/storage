'use client'
import { useState, useEffect, useRef, useCallback } from 'react'
import Link from 'next/link'
import Navbar from '@/components/layout/Navbar'
import toast from 'react-hot-toast'

const ROOMS = [
  { id: 'general',       label: 'General',       icon: '💬', desc: 'Diskusi umum' },
  { id: 'materi',        label: 'Materi',         icon: '📚', desc: 'Tanya tentang materi' },
  { id: 'frontend',      label: 'Frontend',       icon: '🎨', desc: 'HTML, CSS, React' },
  { id: 'backend',       label: 'Backend',        icon: '⚙️', desc: 'Node.js, API, DB' },
  { id: 'cybersecurity', label: 'Security',       icon: '🛡️', desc: 'Diskusi keamanan' },
  { id: 'tantangan',     label: 'Tantangan',      icon: '🏆', desc: 'Diskusi challenge' },
]

function timeStr(date) {
  return new Date(date).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })
}
function dateSep(date) {
  const d = new Date(date)
  const now = new Date()
  if (d.toDateString() === now.toDateString()) return 'Hari ini'
  const yesterday = new Date(now); yesterday.setDate(now.getDate()-1)
  if (d.toDateString() === yesterday.toDateString()) return 'Kemarin'
  return d.toLocaleDateString('id-ID', { day:'numeric', month:'long' })
}

const COLORS = [
  'from-violet-500 to-purple-600',
  'from-blue-500 to-cyan-600',
  'from-emerald-500 to-teal-600',
  'from-pink-500 to-rose-600',
  'from-orange-500 to-amber-600',
  'from-red-500 to-pink-600',
]
function avatarColor(name) {
  let hash = 0; for (const c of (name||'?')) hash = hash*31 + c.charCodeAt(0)
  return COLORS[Math.abs(hash) % COLORS.length]
}

export default function ChatPage() {
  const [user, setUser] = useState(null)
  const [room, setRoom] = useState('general')
  const [messages, setMessages] = useState([])
  const [input, setInput] = useState('')
  const [sending, setSending] = useState(false)
  const [loading, setLoading] = useState(true)
  const [onlineCount, setOnlineCount] = useState(0)
  const [lastTimestamp, setLastTimestamp] = useState(null)
  const [showRooms, setShowRooms] = useState(false)
  const bottomRef = useRef(null)
  const inputRef = useRef(null)
  const pollingRef = useRef(null)

  useEffect(() => {
    const s = localStorage.getItem('cb_user')
    if (s) setUser(JSON.parse(s))
  }, [])

  // Load initial messages
  const loadMessages = useCallback(async () => {
    try {
      setLoading(true)
      const res = await fetch(`/api/chat/messages?room=${room}`)
      const data = await res.json()
      if (data.success) {
        setMessages(data.messages)
        if (data.messages.length > 0) {
          setLastTimestamp(data.messages[data.messages.length - 1].createdAt)
        }
        setOnlineCount(Math.floor(Math.random() * 8) + 2) // simulated
      }
    } catch { toast.error('Gagal memuat chat') }
    finally { setLoading(false) }
  }, [room])

  useEffect(() => {
    setMessages([])
    setLastTimestamp(null)
    loadMessages()
  }, [loadMessages])

  // Poll for new messages every 3 seconds
  const pollMessages = useCallback(async () => {
    if (!lastTimestamp) return
    try {
      const res = await fetch(`/api/chat/messages?room=${room}&after=${encodeURIComponent(lastTimestamp)}`)
      const data = await res.json()
      if (data.success && data.messages.length > 0) {
        setMessages(prev => {
          const ids = new Set(prev.map(m => m._id))
          const newMsgs = data.messages.filter(m => !ids.has(m._id))
          return newMsgs.length > 0 ? [...prev, ...newMsgs] : prev
        })
        setLastTimestamp(data.messages[data.messages.length - 1].createdAt)
      }
    } catch {}
  }, [room, lastTimestamp])

  useEffect(() => {
    pollingRef.current = setInterval(pollMessages, 3000)
    return () => clearInterval(pollingRef.current)
  }, [pollMessages])

  // Auto scroll to bottom
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  const sendMessage = async (e) => {
    e.preventDefault()
    if (!user) { toast.error('Login dulu untuk chat!'); return }
    if (!input.trim()) return
    if (input.trim().length > 1000) { toast.error('Pesan terlalu panjang (max 1000 karakter)'); return }

    setSending(true)
    const optimistic = {
      _id: `temp-${Date.now()}`,
      room,
      authorId: user.id,
      authorName: user.name,
      content: input.trim(),
      createdAt: new Date().toISOString(),
      pending: true,
    }
    setMessages(prev => [...prev, optimistic])
    setInput('')

    try {
      const res = await fetch('/api/chat/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ room, content: input.trim() }),
      })
      const data = await res.json()
      if (!res.ok) {
        toast.error(data.error)
        setMessages(prev => prev.filter(m => m._id !== optimistic._id))
        setInput(input)
        return
      }
      setMessages(prev => prev.map(m => m._id === optimistic._id ? { ...data.message, pending: false } : m))
      setLastTimestamp(data.message.createdAt)
    } catch {
      toast.error('Gagal kirim pesan')
      setMessages(prev => prev.filter(m => m._id !== optimistic._id))
    } finally { setSending(false); inputRef.current?.focus() }
  }

  const currentRoom = ROOMS.find(r => r.id === room)

  // Group messages by date and consecutive author
  const grouped = []
  let lastDate = null
  let lastAuthor = null
  messages.forEach((msg, i) => {
    const d = dateSep(msg.createdAt)
    if (d !== lastDate) { grouped.push({ type: 'separator', label: d, id: `sep-${i}` }); lastDate = d }
    const showAvatar = msg.authorId !== lastAuthor
    grouped.push({ ...msg, showAvatar })
    lastAuthor = msg.authorId
  })

  return (
    <div className="min-h-screen bg-[#020617] flex flex-col">
      <Navbar />
      <div className="flex flex-1 max-w-7xl mx-auto w-full px-4 pt-20 pb-0 gap-4" style={{ height: 'calc(100vh - 64px)' }}>

        {/* Room list sidebar */}
        <div className="hidden lg:flex flex-col w-56 flex-shrink-0 py-4">
          <p className="text-[10px] font-black text-slate-600 uppercase tracking-widest mb-2 px-2">Chat Rooms</p>
          <nav className="space-y-0.5 flex-1">
            {ROOMS.map(r => (
              <button key={r.id} onClick={() => setRoom(r.id)}
                className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-sm font-semibold transition-all text-left ${room === r.id ? 'bg-violet-600/15 text-violet-300 border border-violet-500/20' : 'text-slate-500 hover:text-slate-200 hover:bg-white/[0.04]'}`}>
                <span className="text-base">{r.icon}</span>
                <div>
                  <p className="text-xs font-bold leading-tight">{r.label}</p>
                  <p className={`text-[10px] leading-tight ${room === r.id ? 'text-violet-500' : 'text-slate-700'}`}>{r.desc}</p>
                </div>
              </button>
            ))}
          </nav>
          <div className="mt-4 pt-4 border-t border-white/[0.06]">
            <div className="flex items-center gap-2 px-2">
              <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
              <span className="text-xs text-slate-600">{onlineCount} online</span>
            </div>
            <p className="text-[10px] text-slate-700 px-2 mt-1">Pesan tersimpan 7 hari</p>
          </div>
        </div>

        {/* Main chat area */}
        <div className="flex-1 flex flex-col min-w-0 py-4">
          {/* Chat header */}
          <div className="flex items-center gap-3 mb-3 px-1">
            <button className="lg:hidden p-2 rounded-xl text-slate-500 hover:text-white hover:bg-white/[0.05] transition-all" onClick={() => setShowRooms(!showRooms)}>
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" /></svg>
            </button>
            <div className="flex items-center gap-2">
              <span className="text-xl">{currentRoom?.icon}</span>
              <div>
                <h2 className="font-black text-white text-sm">#{currentRoom?.label}</h2>
                <div className="flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
                  <span className="text-xs text-slate-600">Live • {messages.length} pesan</span>
                </div>
              </div>
            </div>
            <button onClick={loadMessages} className="ml-auto text-xs text-violet-400 hover:text-violet-300 transition-colors px-3 py-1.5 rounded-lg hover:bg-violet-500/10">
              ↻ Refresh
            </button>
          </div>

          {/* Mobile room picker */}
          {showRooms && (
            <div className="lg:hidden mb-3 flex gap-2 overflow-x-auto pb-1">
              {ROOMS.map(r => (
                <button key={r.id} onClick={() => { setRoom(r.id); setShowRooms(false) }}
                  className={`flex-shrink-0 flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold transition-all ${room === r.id ? 'bg-violet-600 text-white' : 'bg-[#0f172a] text-slate-500 border border-white/[0.06]'}`}>
                  {r.icon} {r.label}
                </button>
              ))}
            </div>
          )}

          {/* Messages */}
          <div className="flex-1 overflow-y-auto rounded-2xl bg-[#0a0f1e] border border-white/[0.06] p-4 space-y-1 min-h-0">
            {loading ? (
              <div className="flex items-center justify-center h-full">
                <div className="text-center">
                  <svg className="animate-spin w-6 h-6 text-violet-500 mx-auto mb-2" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"/></svg>
                  <p className="text-slate-600 text-xs">Memuat pesan...</p>
                </div>
              </div>
            ) : messages.length === 0 ? (
              <div className="flex items-center justify-center h-full">
                <div className="text-center">
                  <div className="text-5xl mb-3">💬</div>
                  <p className="text-slate-500 font-semibold text-sm">Belum ada pesan</p>
                  <p className="text-slate-700 text-xs mt-1">Jadilah yang pertama ngobrol di #{currentRoom?.label}!</p>
                </div>
              </div>
            ) : (
              grouped.map(item => {
                if (item.type === 'separator') return (
                  <div key={item.id} className="flex items-center gap-3 my-3">
                    <div className="flex-1 h-px bg-white/[0.04]" />
                    <span className="text-[10px] text-slate-700 font-semibold">{item.label}</span>
                    <div className="flex-1 h-px bg-white/[0.04]" />
                  </div>
                )

                const isMe = item.authorId === user?.id
                return (
                  <div key={item._id} className={`flex gap-2.5 ${isMe ? 'flex-row-reverse' : ''} ${item.showAvatar ? 'mt-3' : 'mt-0.5'}`}>
                    {/* Avatar */}
                    <div className={`flex-shrink-0 ${item.showAvatar ? 'visible' : 'invisible'}`}>
                      <div className={`w-7 h-7 rounded-xl bg-gradient-to-br ${avatarColor(item.authorName)} flex items-center justify-center text-white font-black text-[11px] shadow-lg`}>
                        {item.authorName?.[0]?.toUpperCase()}
                      </div>
                    </div>
                    {/* Bubble */}
                    <div className={`max-w-[72%] ${isMe ? 'items-end' : 'items-start'} flex flex-col`}>
                      {item.showAvatar && (
                        <span className={`text-[10px] text-slate-600 mb-1 font-semibold ${isMe ? 'text-right' : ''}`}>
                          {isMe ? 'Kamu' : item.authorName}
                        </span>
                      )}
                      <div className={`px-3.5 py-2.5 rounded-2xl text-sm leading-relaxed break-words ${
                        isMe
                          ? 'bg-violet-600 text-white rounded-tr-sm'
                          : 'bg-[#1e293b] text-slate-200 rounded-tl-sm'
                      } ${item.pending ? 'opacity-60' : ''}`}>
                        {item.content}
                      </div>
                      <span className="text-[9px] text-slate-700 mt-0.5 px-1">
                        {item.pending ? '⏳' : timeStr(item.createdAt)}
                      </span>
                    </div>
                  </div>
                )
              })
            )}
            <div ref={bottomRef} />
          </div>

          {/* Input */}
          <div className="mt-3">
            {user ? (
              <form onSubmit={sendMessage} className="flex gap-2">
                <div className="flex-1 relative">
                  <input
                    ref={inputRef}
                    value={input}
                    onChange={e => setInput(e.target.value)}
                    onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(e) } }}
                    placeholder={`Kirim pesan ke #${currentRoom?.label}...`}
                    maxLength={1000}
                    className="w-full px-4 py-3 bg-[#0f172a] border border-white/[0.08] rounded-xl text-sm text-slate-200 placeholder-slate-600 focus:outline-none focus:border-violet-500/50 focus:ring-1 focus:ring-violet-500/20 transition-all pr-16"
                    autoComplete="off"
                  />
                  <span className={`absolute right-3 top-1/2 -translate-y-1/2 text-[10px] font-mono ${input.length > 900 ? 'text-red-400' : 'text-slate-700'}`}>
                    {input.length}/1000
                  </span>
                </div>
                <button type="submit" disabled={sending || !input.trim()}
                  className="px-4 py-3 rounded-xl font-bold bg-violet-600 hover:bg-violet-500 text-white disabled:opacity-40 disabled:cursor-not-allowed transition-all flex items-center gap-2 flex-shrink-0">
                  {sending ? (
                    <svg className="animate-spin w-4 h-4" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"/></svg>
                  ) : (
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" /></svg>
                  )}
                </button>
              </form>
            ) : (
              <div className="p-4 rounded-xl bg-[#0f172a] border border-white/[0.06] flex items-center justify-between">
                <p className="text-slate-500 text-sm">Login untuk ikut ngobrol</p>
                <Link href="/login" className="btn btn-primary px-4 py-2 rounded-xl text-sm">Login</Link>
              </div>
            )}
            <p className="text-[10px] text-slate-700 mt-1.5 text-center">
              🔄 Auto-refresh 3 detik • Pesan tersimpan di cloud database • Jaga sopan santun 🙏
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
