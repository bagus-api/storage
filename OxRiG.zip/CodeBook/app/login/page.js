'use client'
import { useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import toast from 'react-hot-toast'

export default function LoginPage() {
  const [form, setForm] = useState({ email: '', password: '' })
  const [loading, setLoading] = useState(false)
  const [showPass, setShowPass] = useState(false)
  const router = useRouter()

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',   // include cookies
        body: JSON.stringify(form),
      })
      const data = await res.json()
      if (!res.ok) { toast.error(data.error); return }
      // Token ada di httpOnly cookie — TIDAK disimpan di localStorage
      // Hanya simpan info user (non-sensitive) untuk UI
      localStorage.setItem('cb_user', JSON.stringify(data.user))
      toast.success(`Selamat datang, ${data.user.name}! 🎉`)
      router.push('/dashboard')
      router.refresh()
    } catch {
      toast.error('Gagal terhubung ke server')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-[#0a0b14] flex items-center justify-center px-4">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/3 left-1/3 w-64 h-64 bg-[#6171f5]/8 rounded-full blur-[100px]" />
        <div className="absolute bottom-1/3 right-1/3 w-64 h-64 bg-purple-600/6 rounded-full blur-[100px]" />
      </div>
      <div className="w-full max-w-sm relative z-10">
        <div className="text-center mb-8">
          <Link href="/" className="inline-flex items-center gap-2 mb-6">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#6171f5] to-purple-600 flex items-center justify-center text-white font-bold">CB</div>
            <span className="font-bold text-xl text-white">Code<span className="text-[#8095ff]">Book</span></span>
          </Link>
          <h1 className="text-2xl font-bold text-white">Masuk ke Akun</h1>
          <p className="text-slate-500 text-sm mt-1.5">Lanjutkan perjalanan belajarmu</p>
        </div>
        <div className="bg-[#0f1117] border border-white/[0.08] rounded-2xl p-6 shadow-2xl">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-slate-400 mb-1.5">Email</label>
              <input type="email" required autoComplete="email" value={form.email}
                onChange={e => setForm(p => ({ ...p, email: e.target.value }))}
                className="w-full px-4 py-2.5 rounded-xl bg-[#1a1d2e] border border-white/[0.08] text-white placeholder-slate-600 focus:outline-none focus:border-[#6171f5]/50 focus:ring-1 focus:ring-[#6171f5]/30 transition-all text-sm"
                placeholder="kamu@example.com" maxLength={320} />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-400 mb-1.5">Password</label>
              <div className="relative">
                <input type={showPass ? 'text' : 'password'} required autoComplete="current-password"
                  value={form.password}
                  onChange={e => setForm(p => ({ ...p, password: e.target.value }))}
                  className="w-full px-4 py-2.5 pr-10 rounded-xl bg-[#1a1d2e] border border-white/[0.08] text-white placeholder-slate-600 focus:outline-none focus:border-[#6171f5]/50 focus:ring-1 focus:ring-[#6171f5]/30 transition-all text-sm"
                  placeholder="Password kamu" maxLength={128} />
                <button type="button" onClick={() => setShowPass(!showPass)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-600 hover:text-slate-400">
                  {showPass ? '🙈' : '👁️'}
                </button>
              </div>
            </div>
            <button type="submit" disabled={loading}
              className="w-full py-3 rounded-xl font-semibold text-white bg-[#6171f5] hover:bg-[#4f52ea] disabled:opacity-60 disabled:cursor-not-allowed transition-all duration-200 shadow-lg shadow-[#6171f5]/20 mt-2 flex items-center justify-center gap-2">
              {loading ? <><svg className="animate-spin w-4 h-4" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"/></svg>Masuk...</> : 'Masuk'}
            </button>
          </form>
          <p className="text-center text-sm text-slate-500 mt-5">
            Belum punya akun?{' '}
            <Link href="/register" className="text-[#8095ff] hover:text-[#a5bbff] font-medium transition-colors">Daftar gratis</Link>
          </p>
        </div>
      </div>
    </div>
  )
}
