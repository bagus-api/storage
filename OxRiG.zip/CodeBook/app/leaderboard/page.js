'use client'
import { useState, useEffect, useCallback } from 'react'
import Navbar from '@/components/layout/Navbar'

function getLevelInfo(xp = 0) {
  if (xp < 500) return { level: 'Beginner', icon: '🌱', color: 'text-emerald-400' }
  if (xp < 1500) return { level: 'Intermediate', icon: '⚡', color: 'text-blue-400' }
  if (xp < 3500) return { level: 'Pro', icon: '🔥', color: 'text-orange-400' }
  return { level: 'Master', icon: '👑', color: 'text-yellow-400' }
}

const TABS = [
  { key: 'xp', label: '⚡ XP', field: 'xp', unit: 'XP' },
  { key: 'streak', label: '🔥 Streak', field: 'streak', unit: 'hari' },
  { key: 'certs', label: '📜 Sertifikat', field: 'certCount', unit: 'cert' },
]

export default function LeaderboardPage() {
  const [users, setUsers] = useState([])
  const [tab, setTab] = useState('xp')
  const [loading, setLoading] = useState(true)
  const [updatedAt, setUpdatedAt] = useState(null)
  const [myId, setMyId] = useState(null)
  const [pulse, setPulse] = useState(false)

  useEffect(() => {
    const s = localStorage.getItem('cb_user')
    if (s) setMyId(JSON.parse(s).id)
  }, [])

  const fetchData = useCallback(async (silent = false) => {
    try {
      if (!silent) setLoading(true)
      const res = await fetch(`/api/leaderboard?sort=${tab}`, { credentials: 'include' })
      const data = await res.json()
      if (data.success) {
        setUsers(data.users)
        setUpdatedAt(new Date(data.updatedAt))
        if (!silent) { setPulse(true); setTimeout(() => setPulse(false), 600) }
      }
    } catch {}
    finally { setLoading(false) }
  }, [tab])

  // Initial fetch + re-fetch when tab changes
  useEffect(() => { fetchData() }, [fetchData])

  // Realtime polling every 30 seconds
  useEffect(() => {
    const interval = setInterval(() => fetchData(true), 30000)
    return () => clearInterval(interval)
  }, [fetchData])

  const myRank = users.findIndex(u => u._id === myId) + 1
  const activeTab = TABS.find(t => t.key === tab)

  const rankBadge = (i) => {
    if (i === 0) return { text: '🥇', bg: 'bg-yellow-500/15 text-yellow-400 border-yellow-500/25' }
    if (i === 1) return { text: '🥈', bg: 'bg-slate-400/15 text-slate-300 border-slate-400/25' }
    if (i === 2) return { text: '🥉', bg: 'bg-orange-600/15 text-orange-400 border-orange-600/25' }
    return { text: `#${i + 1}`, bg: 'bg-white/[0.04] text-slate-500 border-white/[0.06]' }
  }

  return (
    <div className="min-h-screen bg-[#020617]">
      <Navbar />
      <div className="max-w-3xl mx-auto px-4 py-24">

        {/* Header */}
        <div className="flex items-end justify-between flex-wrap gap-3 mb-8">
          <div>
            <p className="section-label">Kompetisi</p>
            <h1 className="section-title">Leaderboard</h1>
          </div>
          <div className="flex items-center gap-2 text-xs">
            <span className={`w-2 h-2 rounded-full ${pulse ? 'bg-green-400 scale-125' : 'bg-green-500'} transition-all`} />
            <span className="text-slate-600">
              {updatedAt ? `Update ${updatedAt.toLocaleTimeString('id-ID')}` : 'Memuat...'}
            </span>
            <button onClick={() => fetchData()} className="ml-1 text-violet-400 hover:text-violet-300 transition-colors font-semibold">
              ↻ Refresh
            </button>
          </div>
        </div>

        {/* My rank card */}
        {myRank > 0 && (
          <div className={`mb-6 p-4 rounded-2xl border flex items-center gap-4 transition-all ${pulse ? 'border-violet-400/40 bg-violet-600/15' : 'border-violet-500/20 bg-violet-600/8'}`}>
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center text-white font-black text-lg flex-shrink-0">
              #{myRank}
            </div>
            <div className="flex-1">
              <p className="font-bold text-white text-sm">Posisimu: <span className="text-violet-400">Rank #{myRank}</span> dari {users.length} pelajar</p>
              <p className="text-xs text-slate-500 mt-0.5">
                {activeTab.unit === 'XP' ? `⚡ ${users[myRank-1]?.xp || 0} XP` :
                 activeTab.unit === 'hari' ? `🔥 ${users[myRank-1]?.streak || 0} hari streak` :
                 `📜 ${users[myRank-1]?.certCount || 0} sertifikat`}
              </p>
            </div>
            <button onClick={() => fetchData()} className="text-xs text-violet-400 hover:text-violet-300">Update ↻</button>
          </div>
        )}

        {/* Tabs */}
        <div className="flex gap-1 p-1 bg-[#0f172a] border border-white/[0.06] rounded-xl mb-6">
          {TABS.map(t => (
            <button key={t.key} onClick={() => setTab(t.key)}
              className={`flex-1 py-2.5 rounded-lg text-sm font-bold transition-all ${tab === t.key ? 'bg-violet-600 text-white shadow-lg shadow-violet-500/20' : 'text-slate-500 hover:text-slate-300'}`}>
              {t.label}
            </button>
          ))}
        </div>

        {/* Podium top 3 */}
        {!loading && users.length >= 3 && (
          <div className="flex items-end justify-center gap-3 mb-6">
            {[1, 0, 2].map((pos, displayIdx) => {
              const u = users[pos]
              if (!u) return null
              const { icon, color } = getLevelInfo(u.xp)
              const heights = ['h-24', 'h-32', 'h-20']
              const colors = ['bg-gradient-to-b from-slate-500 to-slate-600', 'bg-gradient-to-b from-yellow-500 to-amber-600', 'bg-gradient-to-b from-orange-600 to-orange-700']
              const isMe = u._id === myId
              return (
                <div key={u._id} className="flex flex-col items-center flex-1">
                  <div className={`w-11 h-11 rounded-xl flex items-center justify-center text-white font-black text-base mb-1.5 shadow-xl ${isMe ? 'bg-gradient-to-br from-violet-500 to-purple-600 ring-2 ring-violet-400' : 'bg-gradient-to-br from-slate-600 to-slate-700'}`}>
                    {u.name[0].toUpperCase()}
                  </div>
                  <p className="text-xs font-bold text-white mb-0.5 truncate max-w-[70px] text-center">{u.name}</p>
                  <p className={`text-[10px] font-semibold mb-1.5 ${color}`}>{icon}</p>
                  <div className={`w-full ${heights[displayIdx]} ${colors[displayIdx]} rounded-t-xl flex items-center justify-center text-white font-black text-xl shadow-lg`}>
                    {rankBadge(pos).text}
                  </div>
                </div>
              )
            })}
          </div>
        )}

        {/* Full list */}
        {loading ? (
          <div className="space-y-2">
            {[...Array(8)].map((_, i) => (
              <div key={i} className="skeleton h-16 rounded-xl" />
            ))}
          </div>
        ) : users.length === 0 ? (
          <div className="text-center py-16">
            <div className="text-5xl mb-3">🏆</div>
            <p className="text-slate-500 font-semibold">Belum ada data</p>
            <p className="text-slate-600 text-sm mt-1">Jadilah yang pertama masuk leaderboard!</p>
          </div>
        ) : (
          <div className="space-y-2">
            {users.map((u, i) => {
              const { icon, color, level } = getLevelInfo(u.xp)
              const { text, bg } = rankBadge(i)
              const isMe = u._id === myId
              const val = tab === 'xp' ? `${u.xp} XP` : tab === 'streak' ? `${u.streak} hari` : `${u.certCount} sertifikat`
              return (
                <div key={u._id}
                  className={`flex items-center gap-3 p-3.5 rounded-xl border transition-all ${isMe ? 'bg-violet-600/10 border-violet-500/30 ring-1 ring-violet-500/20' : 'bg-[#0f172a] border-white/[0.06] hover:border-white/[0.1]'} ${pulse && isMe ? 'scale-[1.01]' : ''}`}>
                  <span className={`w-9 h-9 rounded-lg border flex items-center justify-center text-sm font-black flex-shrink-0 ${bg}`}>
                    {text}
                  </span>
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center text-white font-black text-sm flex-shrink-0 ${isMe ? 'bg-gradient-to-br from-violet-500 to-purple-600' : 'bg-[#1e293b]'}`}>
                    {u.name[0].toUpperCase()}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className={`font-bold text-sm truncate ${isMe ? 'text-violet-300' : 'text-white'}`}>
                      {u.name} {isMe && <span className="text-[10px] text-violet-500 font-normal">(Kamu)</span>}
                    </p>
                    <p className={`text-[11px] ${color}`}>{icon} {level} • {u.materiCount || 0} materi</p>
                  </div>
                  <span className={`font-bold text-sm tabular-nums ${isMe ? 'text-violet-400' : 'text-slate-400'}`}>{val}</span>
                </div>
              )
            })}
          </div>
        )}

        <p className="text-center text-xs text-slate-700 mt-6">
          🔄 Auto-refresh setiap 30 detik • Data realtime dari database
        </p>
      </div>
    </div>
  )
}
