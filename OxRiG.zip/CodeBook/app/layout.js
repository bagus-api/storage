import './globals.css'
import { Toaster } from 'react-hot-toast'

export const metadata = {
  title: 'CodeBook — Platform Belajar Coding Indonesia',
  description: 'Belajar HTML, CSS, JavaScript, Python, React, Backend & Cybersecurity. Quiz 45 soal, sertifikat PDF, dan komunitas developer Indonesia.',
  keywords: 'belajar coding, programming, web development, cybersecurity, JavaScript, React, Python, Indonesia',
}

export default function RootLayout({ children }) {
  return (
    <html lang="id">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="true" />
        <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800;900&family=JetBrains+Mono:wght@400;500;600&display=swap" rel="stylesheet" />
        <meta name="theme-color" content="#020617" />
      </head>
      <body className="bg-[#020617] text-slate-200 min-h-screen antialiased">
        {children}
        <Toaster position="top-right" toastOptions={{
          duration: 3500,
          style: {
            background: '#0f172a',
            color: '#e2e8f0',
            border: '1px solid rgba(148,163,184,0.1)',
            borderRadius: '12px',
            fontFamily: "'Plus Jakarta Sans', sans-serif",
            fontSize: '14px',
            fontWeight: '500',
            padding: '12px 16px',
            boxShadow: '0 20px 40px rgba(0,0,0,0.4)',
          },
          success: { iconTheme: { primary: '#7c3aed', secondary: '#0f172a' } },
          error: { iconTheme: { primary: '#ef4444', secondary: '#0f172a' } },
        }} />
      </body>
    </html>
  )
}
