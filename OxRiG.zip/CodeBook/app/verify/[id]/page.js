'use client'
import { useState, useEffect } from 'react'
import { useParams } from 'next/navigation'
import Link from 'next/link'
import Navbar from '@/components/layout/Navbar'

export default function VerifyPage() {
  const { id } = useParams()
  const [result, setResult] = useState(null)
  const [loading, setLoading] = useState(false)
  const [input, setInput] = useState(id !== 'CB-XXXX-XXXX' ? id : '')
  const [searched, setSearched] = useState(false)

  useEffect(() => {
    if (id && id !== 'CB-XXXX-XXXX' && id !== 'CB-XXXX') {
      handleVerify(id)
    }
  }, [id])

  const handleVerify = async (certId) => {
    const target = certId || input.trim()
    if (!target) return
    setLoading(true)
    setSearched(true)
    try {
      const res = await fetch(`/api/certificate/verify/${target}`)
      const data = await res.json()
      setResult(data)
    } catch {
      setResult({ valid: false, error: 'Gagal terhubung ke server' })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-[#0a0b14]">
      <Navbar />
      <div className="max-w-xl mx-auto px-4 py-24">
        <div className="text-center mb-10">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#6171f5] to-purple-600 flex items-center justify-center text-3xl mx-auto mb-4 shadow-xl shadow-[#6171f5]/20">
            🔍
          </div>
          <h1 className="text-2xl font-bold text-white mb-2">Verifikasi Sertifikat</h1>
          <p className="text-slate-500 text-sm">Masukkan Certificate ID untuk memverifikasi keaslian sertifikat CodeBook.</p>
        </div>

        <div className="p-6 rounded-2xl bg-[#0f1117] border border-white/[0.06] mb-6">
          <label className="block text-sm font-medium text-slate-400 mb-2">Certificate ID</label>
          <div className="flex gap-2">
            <input
              type="text"
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handleVerify()}
              placeholder="CB-XXXX-XXXX-XXXX"
              className="flex-1 px-4 py-2.5 rounded-xl bg-[#1a1d2e] border border-white/[0.08] text-white placeholder-slate-600 focus:outline-none focus:border-[#6171f5]/50 transition-all text-sm font-mono"
            />
            <button
              onClick={() => handleVerify()}
              disabled={loading || !input.trim()}
              className="px-4 py-2.5 rounded-xl text-sm font-medium bg-[#6171f5] hover:bg-[#4f52ea] text-white disabled:opacity-50 transition-all"
            >
              {loading ? (
                <svg className="animate-spin w-4 h-4" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" /><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" /></svg>
              ) : 'Cek'}
            </button>
          </div>
        </div>

        {searched && !loading && result && (
          <div className={`p-6 rounded-2xl border ${result.valid ? 'bg-emerald-500/5 border-emerald-500/25' : 'bg-red-500/5 border-red-500/25'}`}>
            {result.valid ? (
              <div>
                <div className="flex items-center gap-3 mb-5">
                  <div className="w-10 h-10 rounded-full bg-emerald-500/15 flex items-center justify-center text-xl">✅</div>
                  <div>
                    <p className="font-semibold text-emerald-400">Sertifikat Valid</p>
                    <p className="text-xs text-slate-600">Sertifikat ini diterbitkan oleh CodeBook</p>
                  </div>
                </div>
                <div className="space-y-3">
                  {[
                    { label: 'Nama Penerima', value: result.certificate.userName, icon: '👤' },
                    { label: 'Nama Kursus', value: result.certificate.courseName, icon: '📚' },
                    { label: 'Tanggal Diterbitkan', value: new Date(result.certificate.issuedAt).toLocaleDateString('id-ID', { year:'numeric', month:'long', day:'numeric' }), icon: '📅' },
                    { label: 'Certificate ID', value: result.certificate.certId, icon: '🔑', mono: true },
                  ].map(item => (
                    <div key={item.label} className="flex items-start gap-3 p-3 rounded-xl bg-emerald-500/5 border border-emerald-500/10">
                      <span className="text-base flex-shrink-0 mt-0.5">{item.icon}</span>
                      <div>
                        <p className="text-xs text-slate-600 mb-0.5">{item.label}</p>
                        <p className={`text-slate-200 text-sm font-medium ${item.mono ? 'font-mono' : ''}`}>{item.value}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="text-center py-4">
                <div className="text-4xl mb-3">❌</div>
                <p className="font-semibold text-red-400 mb-1">Sertifikat Tidak Valid</p>
                <p className="text-slate-500 text-sm">{result.error || 'Certificate ID tidak ditemukan di sistem kami.'}</p>
              </div>
            )}
          </div>
        )}

        <div className="mt-6 text-center">
          <Link href="/" className="text-slate-600 hover:text-slate-400 text-sm transition-colors">
            ← Kembali ke CodeBook
          </Link>
        </div>
      </div>
    </div>
  )
}
