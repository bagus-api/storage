import React, { useState, useEffect } from 'react';
import { Search as SearchIcon, Sparkles, Globe, Flame, Play, Pause } from 'lucide-react';
import { usePlayer } from '../context/PlayerContext';
import { toHDCover, toWebp, cn, FI, handleImgError } from '../utils/helpers';
import BannerVideo from '../components/BannerVideo';

export default function SearchView() {
    const {
        playTrack,
        currentTrack,
        isPlaying,
        isLoading,
        togglePlay,
        setActiveAlbum,
        setActiveArtist,
        searchQuery,
        setSearchQuery
    } = usePlayer();

    const [query, setQuery] = useState(searchQuery || '');
    const [suggestions, setSuggestions] = useState([]);
    const [showSuggestions, setShowSuggestions] = useState(false);
    const [filter, setFilter] = useState('songs'); // 'songs', 'playlists', 'artists'
    const [loading, setLoading] = useState(false);

    const [searchResults, setSearchResults] = useState({ songs: [], playlists: [], artists: [] });
    const [recs, setRecs] = useState({ rec0: [], rec1: [], rec2: [] });
    const [loadingRecs, setLoadingRecs] = useState(true);

    const recRows = [
        { key: 'rec0', label: 'Rilis Anyar', q: 'baru rilis', icon: Sparkles, color: 'text-white' },
        { key: 'rec1', label: 'Barat Top', q: 'barat Top', icon: Globe, color: 'text-white' },
        { key: 'rec2', label: 'Rapp Top', q: 'Rapp Top', icon: Flame, color: 'text-white' }
    ];

    // Load recommendations
    useEffect(() => {
        setLoadingRecs(true);
        Promise.all(recRows.map(row =>
            fetch(`/api/search?query=${encodeURIComponent(row.q)}&type=songs`)
                .then(r => r.json())
                .then(d => {
                    if (d.status && d.result && d.result.songs) {
                        return {
                            key: row.key,
                            data: d.result.songs.map(s => ({
                                id: s.videoId,
                                videoId: s.videoId,
                                title: cn(s.title),
                                artist: cn(s.artist),
                                artistId: s.artistId || '',
                                cover: toHDCover(s.thumbnail, s.videoId),
                                ytUrl: s.url
                            }))
                        };
                    }
                    return { key: row.key, data: [] };
                })
                .catch(() => ({ key: row.key, data: [] }))
        )).then(results => {
            const newRecs = {};
            results.forEach(r => { newRecs[r.key] = r.data; });
            setRecs(newRecs);
            setLoadingRecs(false);
        });
    }, []);

    // Suggestions handler
    useEffect(() => {
        const q = query.trim();
        if (!q) {
            setSuggestions([]);
            setShowSuggestions(false);
            return;
        }
        const timer = setTimeout(() => {
            fetch(`/api/suggest?q=${encodeURIComponent(q)}`)
                .then(r => r.json())
                .then(s => {
                    if (Array.isArray(s) && s.length > 0) {
                        setSuggestions(s);
                        setShowSuggestions(true);
                    } else {
                        setSuggestions([]);
                        setShowSuggestions(false);
                    }
                })
                .catch(() => setSuggestions([]));
        }, 200);
        return () => clearTimeout(timer);
    }, [query]);

    // Perform search
    const handleSearch = async (searchTerm, updateUrl = true) => {
        const q = (searchTerm !== undefined ? searchTerm : query).trim();
        if (!q) return;
        setQuery(q);
        if (setSearchQuery) setSearchQuery(q);
        setShowSuggestions(false);
        setLoading(true);

        if (updateUrl && typeof window !== 'undefined') {
            const slug = encodeURIComponent(q.replace(/\s+/g, '_'));
            const targetPath = `/search/${slug}/`;
            if (window.location.pathname !== targetPath) {
                window.history.pushState({ tab: 'search', query: q }, '', targetPath);
            }
        }

        try {
            const res = await fetch(`/api/search?query=${encodeURIComponent(q)}&type=all`);
            const d = await res.json();
            if (d.status && d.result) {
                const songs = (d.result.songs || []).map(s => ({
                    id: s.videoId,
                    videoId: s.videoId,
                    title: cn(s.title),
                    artist: cn(s.artist),
                    artistId: s.artistId || '',
                    cover: toHDCover(s.thumbnail, s.videoId),
                    ytUrl: s.url
                }));
                const playlists = [].concat(d.result.playlists || []).concat(d.result.albums || []);
                const artists = d.result.artists || [];
                setSearchResults({ songs, playlists, artists });
            } else {
                setSearchResults({ songs: [], playlists: [], artists: [] });
            }
        } catch(e) {
            setSearchResults({ songs: [], playlists: [], artists: [] });
        }
        setLoading(false);
    };

    // Auto-search if searchQuery was initialized from URL (e.g. /search/teh_hijau/)
    useEffect(() => {
        if (searchQuery && searchQuery.trim()) {
            setQuery(searchQuery);
            handleSearch(searchQuery, false);
        }
    }, [searchQuery]);

    const hasSearched = query.trim().length > 0;

    return (
        <div id="view-search" className="animate-fade-in pb-12">
            {/* Sticky Header with Search Input */}
            <div className="pt-3.5 pb-2 px-4 sticky top-0 z-30 border-b border-[var(--header-border)] shadow-2xl transition-all relative overflow-hidden backdrop-blur-md bg-[var(--header-bg)]">
                <BannerVideo />
                <h1 className="text-2xl font-black text-[var(--text-primary)] tracking-tight drop-shadow-md mb-2">Cari</h1>

                <form
                    onSubmit={(e) => {
                        e.preventDefault();
                        handleSearch();
                    }}
                    className="relative"
                    autoComplete="off"
                >
                    <div className="absolute inset-y-0 left-0 pl-4 flex items-center text-[var(--text-muted)] pointer-events-none">
                        <SearchIcon className="h-5 w-5" />
                    </div>
                    <input
                        type="text"
                        value={query}
                        onChange={(e) => setQuery(e.target.value)}
                        onFocus={() => { if (suggestions.length > 0) setShowSuggestions(true); }}
                        className="w-full bg-[var(--card-bg)] backdrop-blur-md border border-[var(--border-color)] text-[var(--text-primary)] font-medium rounded-2xl pl-12 pr-20 py-3.5 focus:outline-none placeholder:text-[var(--text-muted)] text-sm shadow-md"
                        placeholder="Cari lagu, artis, atau album..."
                        autoComplete="off"
                    />
                    <button
                        type="submit"
                        className="absolute right-2 top-1/2 -translate-y-1/2 bg-[var(--chip-active-bg)] text-[var(--chip-active-text)] font-extrabold px-4 py-2 rounded-xl active:scale-90 shadow-md text-xs cursor-pointer"
                    >
                        Cari
                    </button>
                </form>

                {/* Suggestions Dropdown */}
                {showSuggestions && suggestions.length > 0 && (
                    <div className="absolute left-4 right-4 mt-2 glass-strong rounded-2xl max-h-72 overflow-y-auto hide-scrollbar border border-white/10 z-50">
                        {suggestions.map((sg, i) => (
                            <div
                                key={i}
                                onClick={() => handleSearch(sg)}
                                className="px-4 py-3 hover:bg-white/10 cursor-pointer text-sm flex items-center gap-3 transition-colors border-b border-white/5 last:border-0"
                            >
                                <SearchIcon className="w-3.5 h-3.5 text-white/70 shrink-0" />
                                <span className="text-white truncate">{sg}</span>
                            </div>
                        ))}
                    </div>
                )}
            </div>

            {/* Filter Tabs (when searched) */}
            {hasSearched && (
                <div className="flex gap-2 p-1.5 glass rounded-full mx-4 mb-3 mt-4 border border-white/10">
                    <button
                        onClick={() => setFilter('songs')}
                        className={`filter-tab flex-1 py-2 px-4 rounded-full text-xs font-bold transition-all cursor-pointer ${
                            filter === 'songs'
                                ? 'active btn-chrome text-white border border-white/30 scale-105'
                                : 'text-[#a0a5b0] hover:text-white'
                        }`}
                    >
                        Musik
                    </button>
                    <button
                        onClick={() => setFilter('playlists')}
                        className={`filter-tab flex-1 py-2 px-4 rounded-full text-xs font-bold transition-all cursor-pointer ${
                            filter === 'playlists'
                                ? 'active btn-chrome text-white border border-white/30 scale-105'
                                : 'text-[#a0a5b0] hover:text-white'
                        }`}
                    >
                        Playlist
                    </button>
                    <button
                        onClick={() => setFilter('artists')}
                        className={`filter-tab flex-1 py-2 px-4 rounded-full text-xs font-bold transition-all cursor-pointer ${
                            filter === 'artists'
                                ? 'active btn-chrome text-white border border-white/30 scale-105'
                                : 'text-[#a0a5b0] hover:text-white'
                        }`}
                    >
                        Artis
                    </button>
                </div>
            )}

            {/* Search Results Area */}
            {hasSearched ? (
                <div className="px-4 mt-2">
                    {loading ? (
                        <div className="text-center mt-10">
                            <div className="w-8 h-8 border-3 border-[#cfd3d8] border-t-transparent rounded-full animate-spin mx-auto"></div>
                        </div>
                    ) : filter === 'songs' ? (
                        /* Songs Results */
                        searchResults.songs.length === 0 ? (
                            <p className="text-center text-white/70 mt-10">Tidak ada lagu ditemukan</p>
                        ) : (
                            <div className="space-y-2">
                                {searchResults.songs.map((t, i) => {
                                    const isCur = currentTrack && (
                                        currentTrack.id === t.id ||
                                        currentTrack.videoId === t.id ||
                                        (currentTrack.title === t.title && currentTrack.artist === t.artist)
                                    );
                                    const isPlay = isCur && isPlaying;
                                    const isLoad = isCur && isLoading;

                                    const itemBg = isPlay
                                        ? 'bg-[#343a4e] border border-white/40 shadow-xl'
                                        : isCur
                                        ? 'bg-[#2e3344] border border-white/30'
                                        : 'bg-[#20222c] border border-white/10 hover:bg-[#282b38]';

                                    return (
                                        <div
                                            key={i}
                                            onClick={() => {
                                                if (isCur) togglePlay();
                                                else playTrack(t, searchResults.songs, i, 'search');
                                            }}
                                            className={`search-song-item flex items-center gap-3.5 p-2.5 rounded-2xl cursor-pointer active:scale-[0.98] transition-all shadow-lg shadow-black/25 ${itemBg}`}
                                        >
                                            <img
                                                src={toWebp(t.cover)}
                                                className="w-12 h-12 rounded-xl object-cover shadow-md shrink-0 border border-white/10"
                                                alt=""
                                                onError={handleImgError}
                                            />
                                            <div className="truncate flex-1 min-w-0">
                                                <div className="flex items-center">
                                                    <h3 className={`search-song-title font-semibold text-sm truncate ${isCur ? 'text-white font-black' : 'text-white'}`}>
                                                        {t.title}
                                                    </h3>
                                                    {isPlay ? (
                                                        <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-white/20 text-white font-bold uppercase tracking-wider ml-2 border border-white/30 shrink-0">
                                                            Diputar
                                                        </span>
                                                    ) : isCur ? (
                                                        <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-white/10 text-white/80 font-bold uppercase tracking-wider ml-2 border border-white/20 shrink-0">
                                                            Dijeda
                                                        </span>
                                                    ) : null}
                                                </div>
                                                <p className="text-white/60 text-xs truncate mt-0.5">{t.artist}</p>
                                            </div>
                                            <div className="shrink-0">
                                                {isLoad ? (
                                                    <div className="w-9 h-9 rounded-full bg-white/20 flex items-center justify-center shrink-0">
                                                        <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                                                    </div>
                                                ) : isPlay ? (
                                                    <div className="w-9 h-9 rounded-full bg-white text-black flex items-center justify-center shrink-0 shadow-white/30 ring-2 ring-white scale-105">
                                                        <div className="flex items-end justify-center gap-[2.5px] w-4 h-4 pb-0.5">
                                                            <span className="w-[2.5px] bg-black rounded-full animate-eq-1"></span>
                                                            <span className="w-[2.5px] bg-black rounded-full animate-eq-2"></span>
                                                            <span className="w-[2.5px] bg-black rounded-full animate-eq-3"></span>
                                                        </div>
                                                    </div>
                                                ) : isCur ? (
                                                    <div className="w-9 h-9 rounded-full bg-white text-black flex items-center justify-center shrink-0 border border-white scale-105">
                                                        <Pause className="w-4 h-4 fill-current" />
                                                    </div>
                                                ) : (
                                                    <div className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center shrink-0 text-white">
                                                        <Play className="w-3.5 h-3.5 fill-current ml-0.5" />
                                                    </div>
                                                )}
                                            </div>
                                        </div>
                                    );
                                })}
                            </div>
                        )
                    ) : filter === 'artists' ? (
                        /* Artists Results */
                        searchResults.artists.length === 0 ? (
                            <p className="text-center text-white/70 mt-10">Tidak ada artis ditemukan</p>
                        ) : (
                            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-3 pb-8">
                                {searchResults.artists.map((p, i) => (
                                    <div
                                        key={i}
                                        onClick={() => setActiveArtist({ id: p.id, name: p.name || p.title, cover: p.cover })}
                                        className="p-3 rounded-2xl bg-[#20222c] border border-white/10 shadow-xl hover:bg-[#282b38] cursor-pointer active:scale-95 transition-all text-center flex flex-col items-center justify-center group"
                                    >
                                        <div className="relative w-20 h-20 mb-2.5 rounded-full overflow-hidden border-2 border-white/10 shadow-md group-hover:scale-105 transition-transform duration-300">
                                            <img src={toWebp(p.cover)} className="w-full h-full object-cover" alt="" onError={handleImgError} />
                                        </div>
                                        <h3 className="font-bold text-sm truncate text-white w-full px-1">{p.name || p.title}</h3>
                                        <p className="text-white/60 text-[10px] uppercase tracking-wider font-semibold mt-0.5">Artist</p>
                                    </div>
                                ))}
                            </div>
                        )
                    ) : (
                        /* Playlists / Albums Results */
                        searchResults.playlists.length === 0 ? (
                            <p className="text-center text-white/70 mt-10">Tidak ada playlist ditemukan</p>
                        ) : (
                            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-3 pb-8">
                                {searchResults.playlists.map((p, i) => (
                                    <div
                                        key={i}
                                        onClick={() => setActiveAlbum({ id: p.id, cover: p.cover || FI })}
                                        className="p-2.5 rounded-2xl bg-[#20222c] border border-white/10 shadow-xl hover:bg-[#282b38] cursor-pointer active:scale-95 transition-all group flex flex-col"
                                    >
                                        <div className="w-full aspect-square mb-2.5 rounded-xl overflow-hidden shadow-md">
                                            <img src={toWebp(p.cover)} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" alt="" onError={handleImgError} />
                                        </div>
                                        <h3 className="font-semibold text-sm truncate text-white px-0.5">{p.title}</h3>
                                        <p className="text-white/60 text-xs truncate mt-0.5 px-0.5">{p.artist}</p>
                                    </div>
                                ))}
                            </div>
                        )
                    )}
                </div>
            ) : (
                /* Default Recommendations when not searching */
                <div id="search-recs" className="px-4 mt-4 space-y-6 pb-8">
                    {loadingRecs ? (
                        Array(3).fill(0).map((_, i) => (
                            <div key={i} className="animate-pulse">
                                <div className="h-5 w-32 bg-white/10 rounded mb-3"></div>
                                <div className="flex gap-3 overflow-x-auto hide-scrollbar pb-1">
                                    {Array(4).fill(0).map((_, j) => (
                                        <div key={j} className="flex-shrink-0 w-32">
                                            <div className="w-32 h-32 rounded-xl bg-white/5 mb-2"></div>
                                            <div className="h-3 bg-white/10 rounded w-3/4"></div>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        ))
                    ) : (
                        recRows.map((row) => {
                            const list = (recs[row.key] || []).slice(0, 6);
                            if (list.length === 0) return null;
                            const Icon = row.icon;
                            return (
                                <div key={row.key} className="animate-card-up">
                                    <h2 className="text-base font-bold mb-3 flex items-center gap-2 text-white">
                                        <Icon className={`w-4 h-4 ${row.color}`} />
                                        <span>{row.label}</span>
                                    </h2>
                                    <div className="flex gap-3 overflow-x-auto hide-scrollbar pb-1">
                                        {list.map((t, i) => {
                                            const isCur = currentTrack && (
                                                currentTrack.id === t.id ||
                                                currentTrack.videoId === t.id ||
                                                (currentTrack.title === t.title && currentTrack.artist === t.artist)
                                            );
                                            const isPlay = isCur && isPlaying;
                                            const isLoad = isCur && isLoading;

                                            return (
                                                <div
                                                    key={i}
                                                    onClick={() => {
                                                        if (isCur) togglePlay();
                                                        else playTrack(t, list, i, row.key);
                                                    }}
                                                    className="search-rec-item flex-shrink-0 w-36 cursor-pointer active:scale-95 group p-2.5 rounded-2xl bg-[#20222c] border border-white/10 shadow-xl hover:bg-[#282b38] transition-all flex flex-col"
                                                >
                                                    <div className="search-rec-cover w-full aspect-square mb-2 relative rounded-xl overflow-hidden shadow-md">
                                                        <img
                                                            src={t.cover}
                                                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                                                            alt=""
                                                            onError={handleImgError}
                                                        />
                                                        <div className="absolute bottom-1.5 right-1.5 rounded-full p-2 bg-white text-black shadow-md">
                                                            {isLoad ? (
                                                                <div className="w-3.5 h-3.5 border-2 border-black border-t-transparent rounded-full animate-spin"></div>
                                                            ) : isPlay ? (
                                                                <div className="flex items-end justify-center gap-[2px] w-3.5 h-3.5 pb-0.5">
                                                                    <span className="w-[2px] bg-black rounded-full animate-eq-1"></span>
                                                                    <span className="w-[2px] bg-black rounded-full animate-eq-2"></span>
                                                                    <span className="w-[2px] bg-black rounded-full animate-eq-3"></span>
                                                                </div>
                                                            ) : isCur ? (
                                                                <Pause className="w-3.5 h-3.5 fill-current" />
                                                            ) : (
                                                                <Play className="w-3.5 h-3.5 fill-current ml-0.5" />
                                                            )}
                                                        </div>
                                                    </div>
                                                    <h3 className={`font-semibold text-xs truncate text-white px-0.5 ${isCur ? 'font-black' : ''}`}>
                                                        {t.title}
                                                    </h3>
                                                    <p className="text-white/60 text-[10px] truncate mt-0.5 px-0.5">{t.artist}</p>
                                                </div>
                                            );
                                        })}
                                    </div>
                                </div>
                            );
                        })
                    )}
                </div>
            )}
        </div>
    );
}
