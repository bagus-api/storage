// Netlify Function v2: proxy audio dengan streaming + dukungan Range (seek).
// Path /api/proxy-audio ditangani langsung oleh function ini (lihat config.path).
const UA =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, HEAD, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Range',
  'Access-Control-Expose-Headers': 'Content-Length, Content-Range, Accept-Ranges, Content-Type',
};

export default async (req) => {
  if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: cors });

  const target = new URL(req.url).searchParams.get('url');
  if (!target) return new Response('Missing url parameter', { status: 400, headers: cors });

  let parsed;
  try {
    parsed = new URL(target);
  } catch {
    return new Response('Invalid url parameter', { status: 400, headers: cors });
  }
  if (!/^https?:$/.test(parsed.protocol)) {
    return new Response('Invalid protocol', { status: 400, headers: cors });
  }

  const headers = { 'User-Agent': UA };
  if (parsed.hostname.includes('vidssave.com') || parsed.hostname.includes('aliyuncs.com')) {
    headers['Referer'] = 'https://vidssave.com/';
    headers['Origin'] = 'https://vidssave.com';
  }
  const range = req.headers.get('range');
  if (range) headers['Range'] = range;

  try {
    const upstream = await fetch(parsed.href, { headers, redirect: 'follow' });
    const out = new Headers(cors);
    for (const h of ['content-type', 'content-length', 'accept-ranges', 'content-range']) {
      const v = upstream.headers.get(h);
      if (v) out.set(h, v);
    }
    if (!out.has('accept-ranges')) out.set('Accept-Ranges', 'bytes');
    return new Response(upstream.body, { status: upstream.status, headers: out });
  } catch (err) {
    return new Response('Proxy error: ' + err.message, { status: 502, headers: cors });
  }
};

export const config = { path: '/api/proxy-audio' };
