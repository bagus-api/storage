// params : ?page=1&label=<slug-id>&locale=id
// apikey = true

const axios = require('axios');

const BASE = 'https://netshort.com';

const USER_AGENTS = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.3 Safari/605.1.15',
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
    'Mozilla/5.0 (iPhone; CPU iPhone OS 17_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Mobile/15E148 Safari/604.1'
];

function randomUA() {
    return USER_AGENTS[Math.floor(Math.random() * USER_AGENTS.length)];
}

function randomIP() {
    const r = () => Math.floor(Math.random() * 254) + 1;
    return `${r()}.${r()}.${r()}.${r()}`;
}

function baseHeaders(locale) {
    return {
        'User-Agent': randomUA(),
        'Accept-Language': `${locale || 'id'},en;q=0.9`,
        'Cache-Control': 'no-cache',
        'Pragma': 'no-cache',
        'X-Forwarded-For': randomIP(),
        'X-Real-IP': randomIP(),
        'Connection': 'keep-alive'
    };
}

function extractFlightProps(text) {
    const re = /\{"locale":"[^"]*","seriesSlug"/;
    const m = re.exec(text);
    const start = m ? m.index : text.indexOf('"seriesSlug"') > -1
        ? text.lastIndexOf('{', text.indexOf('"seriesSlug"'))
        : -1;
    if (start === -1) throw new Error('Struktur payload NetShort berubah / data kosong');
    let depth = 0, inStr = false, esc = false;
    for (let i = start; i < text.length; i++) {
        const ch = text[i];
        if (inStr) {
            if (esc) esc = false;
            else if (ch === '\\') esc = true;
            else if (ch === '"') inStr = false;
            continue;
        }
        if (ch === '"') inStr = true;
        else if (ch === '{') depth++;
        else if (ch === '}') {
            depth--;
            if (depth === 0) return JSON.parse(text.slice(start, i + 1));
        }
    }
    throw new Error('Gagal parsing payload NetShort');
}

async function scrapeList(page, label, locale) {
    page = Math.max(1, parseInt(page) || 1);
    let url;
    if (label) {
        url = `${BASE}/${locale}/drama/${label}${page > 1 ? '/page/' + page : ''}`;
    } else {
        url = `${BASE}/${locale}/drama/all-plots${page > 1 ? '/page/' + page : ''}`;
    }

    let res;
    for (let attempt = 0; attempt < 3; attempt++) {
        res = await axios.get(url, {
            headers: { ...baseHeaders(locale), 'RSC': '1', 'Accept': 'text/x-component' },
            timeout: 30000,
            maxRedirects: 5,
            responseType: 'text'
        });
        const text = String(res.data);
        if (text.includes('"videoList":[{')) break;
        if (attempt === 2) throw new Error('Gagal mengambil data list NetShort (payload tidak lengkap)');
        await new Promise(r => setTimeout(r, 800));
    }

    const props = extractFlightProps(String(res.data));
    return {
        page: props.pageNum,
        pageSize: props.pageSize,
        total: props.totalCount,
        totalPages: Math.ceil((props.totalCount || 0) / (props.pageSize || 24)),
        count: (props.videoList || []).length,
        dramas: (props.videoList || []).map(v => ({
            id: v.shortPlayId,
            libraryId: v.shortPlayLibraryId,
            title: v.shortPlayNameNoHL || v.shortPlayName,
            url: v.shortPlayNameUrl ? BASE + v.shortPlayNameUrl : null,
            fullEpisodesUrl: v.fullEpisodeNameUrl ? BASE + v.fullEpisodeNameUrl : null,
            cover: (v.shortPlayCover || '').split('~')[0],
            synopsis: v.shotIntroduce || '',
            labels: (v.labelList || []).map(l => l.labelName),
            totalEpisode: v.totalEpisode || null
        }))
    };
}

module.exports = {
    category: 'Stalker',
    params: ['page'],
    'desc-url': 'https://netshort.com/id/drama/all-plots',
    desc: 'NetShort Drama List - semua drama all-plots, support pagination & filter genre',

    async run(req, res) {
        const page = req.query.page || req.body.page || 1;
        const label = String(req.query.label || req.body.label || '').trim();
        const locale = String(req.query.locale || req.body.locale || 'id').trim().toLowerCase();

        try {
            const result = await scrapeList(page, label || undefined, locale);
            return res.json({ creator: 'Nanzz', status: true, result });
        } catch (err) {
            return res.status(500).json({ creator: 'Nanzz', status: false, message: err.message });
        }
    }
};

if (require.main === module) {
    (async () => {
        const rawArgs = process.argv.slice(2);
        let args = [];
        for (let i = 0; i < rawArgs.length; i++) {
            if (rawArgs[i].startsWith('--')) { i++; continue; }
            args.push(rawArgs[i]);
        }
        const flag = (name, def) => {
            const i = rawArgs.indexOf('--' + name);
            return i > -1 && rawArgs[i + 1] ? rawArgs[i + 1] : def;
        };
        try {
            const result = await scrapeList(flag('page', 1), args[0], flag('locale', 'id'));
            console.log(JSON.stringify(result, null, 2));
        } catch (err) {
            console.error(JSON.stringify({ status: false, message: err.message }));
            process.exit(1);
        }
    })();
}
