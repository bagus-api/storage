// params : ?keyword=cinta&page=1&locale=id
// apikey = true

const axios = require('axios');

const BASE = 'https://netshort.com';
const API_BASE = BASE + '/prod-web-api';
const AES_KEY = '5k3KYTOO9jnO0CeyGhdHc3pIjGnVgrMN';

const RSA_PUB = [
    '-----BEGIN PUBLIC KEY-----',
    'MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA2poXMstZ8NCWE7915MXz',
    'DWC5/t+oB2waGfskPqSZwLqxd4ZBR0H1cb1tAZRZcV7P+LmOd6SYNxhnELaWuKTD',
    '+D3xkz8Tt1L5j/ynGqVt1MDbiQIEzXQKUkNDSH6T0A+Xzo/67/8QOQXlVJfW06res',
    'baeNvibfx6Qc78j96bCIPlxPrtieilVTBHUFOXjirxK/ki/mO8P2smRbpt73fsQW',
    'dGmTGMfYGvfPApGyxbxLkL/qrBjU25XpM8a0MBqzFWUAchHmqSBJ6Mbfam1SSgf3',
    'b2U28s67nOW+JiOrhd6iVLcsLFxXA54HX+Zbej3AbOB6jKaEmp/bz1amneE1NYXw',
    'wIDAQAB',
    '-----END PUBLIC KEY-----'
].join('\n');

const PRIV_KEY_PEM = [
    "-----BEGIN PRIVATE KEY-----",
    "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCK0Tl1pd7bjTRU93bWoHW1hLCDj2+9bg1MgY8j5C7xXaw6bJfToXhWbH1fXNbnFFVqxyYNErcuOUwJZxyDgcxUXM4yWnRseb2GF97GOicAQ2keDzVYmwky4lrSRwvcXutJRLPUCRQNfc6upfk2G5TKh6/CcP4TV1eXTF7+vdEw2SHxAOITKbSfcaZXr/hVs6a1aRHsBF+7RG99ebwZIP6/AgIyqX9RbDVN6ixi1v2G3/bwAULHLSqGdSaqij/ca17fbFGITaeCeEaZ6d/P4ZuOK+PEPdbPQt6SbY4lZaYwRvdrpH73kigPITgDzIDONFybJ1m7wRKlq1wxWHwbimptAgMBAAECggEAPz3cYJXFtt5YphDrahJGLgEabYVOUc2ub1li/eX54OpdCWzpqneYnD7myyg/m5zu4SuDUVdibsOZuXrpSZw7m3+ATP5apgS8bDe5vTNHC16qqBAjrI9NHIp09/F4HNh9dq6/Am10XkUfgP+KTrU4DyDL2NijV+pltD8N1B5kDE1igokVcsavhnu2INoMRXYE78Wq6urNECuFWw9hldv81M9m2w56t1CQOUukpo4mfmLjZRe2s+kwtcBVefGHP8Cj0OeH2dGltjl2YSQMRBFUCVoixYpOrcjIHoqzWri8IfUZ2tW+nUvHl5IZ9RVxefnFaLGnxiXd2sk6Sn4aD/l9YQKBgQDVv3HaOZxHRqlNSPrNGqplGhE066HnDsq6MlPukiovxE43CRBmpTnk9zDCqrDh9t2HbJuao7nSq5WlBERWgwqXU/qDpH43W7Y/lJfHkDv6A2m0viJa0a9x8+CJpNnCDu1ATo4/IQKwoXYice6JKnUyXgkGKn+HipiN6tO0EtWHlQKBgQCmQfklKFtXtm/FZ6NIMs+d+EyvaE5xNLKGYQxmiCR10WGYd8ZV+K0Q6qXHS+a32TirWB9F3TqPOklTytMrfPZB3BCXj4weEldb8W716G8FYf7LLhaT+MdpF7KDcruObwoQAvKV3N4eX6tUEMmdrx9hpCmmIU5EeXUkhGdmwk7BeQKBgAIXMkThJV8pGMTRvuo8pYgBnkN3PoklAuSZU2rU8Sawc9dj9k4atZtAs7BjvQEoyffmHwt/KHUgCoGnrgdulq7uOlgJRtbBxeGPUYC5L2z9lY4YAfwDawThTsPp4dtdDAMCAbAqYX1axu4FUUD0MltAwjPWPJMVzvIsZs+vE3mVAoGAJPja3OaCmZjadj2709xoyypic0dw2j/ry3JdfZec9A5h87P/CTNJ2U81GoLIhe3qakAohDLUSPGfSOD74NnjMXYswmeLs0xE3Q9tq4XK2pmWPby8DJ/wSHCapByplN0gkbr2E1mQk5SW1xT8oPJGukH1eRpC+3s/D6XaEMH5HZECgYEAigoX5l39LDsCgeaUcI4S9grkaas/WsKv37eqo3oD9Qk6VFiMM5L5Zig6aXJxuAPLVjb38caJRPmPmOXLT2kEP1E1h6OJOhEhETwVIUtcBzsK25ju9LqL89bC+W0uS7BPvk6Tcws/tXHCkQCTgb9jVXceZ2ox+6axvlW/5WgHt5Q=",
    "-----END PRIVATE KEY-----"
].join('\n');

const LOCALE_LANG = {
    en: 'en_US', zh: 'zh_TW', cn: 'zh_CN', ja: 'ja_JP', ko: 'ko_KR',
    es: 'es_ES', th: 'th_TH', id: 'id_ID', pt: 'pt_PT', it: 'it_IT',
    de: 'de_DE', fr: 'fr_FR', tr: 'tr_TR', ms: 'ms_MY', ar: 'ar_AE',
    vi: 'vi_VN', hi: 'hi_IN'
};

const USER_AGENTS = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.3 Safari/605.1.15',
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36'
];

function randomUA() {
    return USER_AGENTS[Math.floor(Math.random() * USER_AGENTS.length)];
}

function randomIP() {
    const r = () => Math.floor(Math.random() * 254) + 1;
    return `${r()}.${r()}.${r()}.${r()}`;
}

function baseHeaders(locale) {
    return {
        'User-Agent': randomUA(),
        'Accept-Language': `${locale || 'id'},en;q=0.9`,
        'Cache-Control': 'no-cache',
        'Pragma': 'no-cache',
        'X-Forwarded-For': randomIP(),
        'X-Real-IP': randomIP(),
        'Connection': 'keep-alive'
    };
}

function aesEncryptECB(plain) {
    const c = require('crypto').createCipheriv('aes-256-ecb', Buffer.from(AES_KEY), null);
    return Buffer.concat([c.update(plain, 'utf8'), c.final()]).toString('base64');
}

function aesDecryptECB(key, buf) {
    const d = require('crypto').createDecipheriv('aes-256-ecb', Buffer.from(key), null);
    return Buffer.concat([d.update(buf), d.final()]).toString('utf8');
}

function rsaEncryptKey(keyB64) {
    return require('crypto').publicEncrypt(
        { key: RSA_PUB, padding: require('crypto').constants.RSA_PKCS1_PADDING },
        Buffer.from(keyB64)
    ).toString('base64');
}

function rsaDecryptKey(b64) {
    const crypto = require('crypto');
    const jwk = crypto.createPrivateKey(PRIV_KEY_PEM).export({ format: 'jwk' });
    const b2i = (s) => BigInt('0x' + Buffer.from(s, 'base64').toString('hex'));
    const n = b2i(jwk.n), d = b2i(jwk.d);
    let base = b2i(b64), exp = d, res = 1n;
    while (exp > 0n) {
        if (exp & 1n) res = (res * base) % n;
        base = (base * base) % n;
        exp >>= 1n;
    }
    const modBytes = Buffer.from(jwk.n, 'base64').length;
    const buf = Buffer.from(res.toString(16).padStart(modBytes * 2, '0'), 'hex');
    const sep = buf.indexOf(0x00, 2);
    return buf.slice(sep + 1).toString('utf8');
}

async function apiPost(path, body, locale) {
    const lang = LOCALE_LANG[locale] || locale || 'id_ID';
    const keyB64 = Buffer.from(AES_KEY).toString('base64');
    const res = await axios.post(API_BASE + path, aesEncryptECB(JSON.stringify(body || {})), {
        headers: {
            ...baseHeaders(locale),
            'Content-Type': 'application/json;charset=utf-8',
            'Content-Language': lang,
            'encrypt-key': rsaEncryptKey(keyB64),
            'OS': '4',
            'canary': 'v1',
            'version': '1.2.0',
            'Origin': BASE,
            'Referer': `${BASE}/${locale}/search`
        },
        timeout: 30000,
        maxRedirects: 5,
        responseType: 'text'
    });

    const respKey = res.headers['encrypt-key'] || res.headers['Encrypt-Key'];
    if (!respKey) {
        return typeof res.data === 'string' ? JSON.parse(res.data) : res.data;
    }
    const aesKey = Buffer.from(rsaDecryptKey(respKey), 'base64').toString('utf8');
    return JSON.parse(aesDecryptECB(aesKey, Buffer.from(res.data, 'base64')));
}

async function searchDrama(keyword, page, locale) {
    page = Math.max(1, parseInt(page) || 1);
    const r = await apiPost('/web/short_play/search/keyword/seo', {
        queryKeyword: keyword,
        pageQuery: { pageNum: page, pageSize: 24 }
    }, locale);
    if (r.code !== 200) throw new Error(r.msg || 'Pencarian gagal');
    const list = (r.data && r.data.list) || [];
    return {
        keyword,
        page,
        count: list.length,
        results: list.map(v => ({
            id: v.shortPlayId,
            title: v.shortPlayNameNoHL || v.shortPlayName,
            url: v.shortPlayNameUrl ? BASE + v.shortPlayNameUrl : null,
            cover: (v.shortPlayCover || '').split('~')[0],
            totalEpisode: v.totalEpisode || null
        }))
    };
}

module.exports = {
    category: 'Search',
    params: ['keyword'],
    'desc-url': 'https://netshort.com/id/shortsearch',
    desc: 'NetShort Search - cari drama berdasarkan keyword',

    async run(req, res) {
        const keyword = String(req.query.keyword || req.body.keyword || '').trim();
        const page = req.query.page || req.body.page || 1;
        const locale = String(req.query.locale || req.body.locale || 'id').trim().toLowerCase();

        if (!keyword) {
            return res.status(400).json({ creator: 'Nanzz', status: false, message: 'Parameter keyword diperlukan' });
        }

        try {
            const result = await searchDrama(keyword, page, locale);
            return res.json({ creator: 'Nanzz', status: true, result });
        } catch (err) {
            return res.status(500).json({ creator: 'Nanzz', status: false, message: err.message });
        }
    }
};

if (require.main === module) {
    (async () => {
        const rawArgs = process.argv.slice(2);
        let args = [];
        for (let i = 0; i < rawArgs.length; i++) {
            if (rawArgs[i].startsWith('--')) { i++; continue; }
            args.push(rawArgs[i]);
        }
        const flag = (name, def) => {
            const i = rawArgs.indexOf('--' + name);
            return i > -1 && rawArgs[i + 1] ? rawArgs[i + 1] : def;
        };
        try {
            const result = await searchDrama(args[0] || '', flag('page', 1), flag('locale', 'id'));
            console.log(JSON.stringify(result, null, 2));
        } catch (err) {
            console.error(JSON.stringify({ status: false, message: err.message }));
            process.exit(1);
        }
    })();
}
