# Synox Cloud v1 — YouTube REST API Suite
**Owner:** @nanasnih

Paket endpoint YouTube lengkap untuk Synox Cloud v1. Semua endpoint menggunakan format standar:
- `module.exports` dengan `async run(req, res)`
- Mendukung metode GET dan POST untuk semua parameter
- Error response standar JSON
- Tanpa dependensi berat (hanya axios)

## Daftar Endpoint (9 Endpoint):
1. `youtube-home.js` — Beranda & Rekomendasi Trending Indonesia (?gl=ID&hl=id)
2. `youtube-shorts.js` — YouTube Shorts Trending & Pencarian (?query=indonesia)
3. `youtube-feed.js` — Feed Topik: trending, music, gaming, news, movies, sports (?feed=music)
4. `youtube-category.js` — Katalog Kategori & Video Rekomendasi (?category=musik)
5. `youtube-search.js` — Pencarian Video, Channel, & Playlist (?query=lagu&type=playlist)
6. `youtube-stream.js` — Responsive Iframe Player Embed, Direct Watch & Thumbnails (?id=...)
7. `youtube-metadata.js` — Metadata Lengkap: Likes, Views, Subscribers, Description (?id=...)
8. `youtube-channel.js` — Profil Channel, Subs, Avatar, Banner, & Tab Konten (home/videos/shorts/playlists/posts) (?id=@nanasnih&tab=videos)
9. `youtube-playlist.js` — Detail Playlist Lengkap & Daftar Seluruh Video di Dalamnya (?id=PL...)
