// params : ?gl=ID&hl=id

const axios = require('axios');

module.exports = {
  category: 'YouTube',
  params: ['gl', 'hl'],
  'desc-gl': 'Kode negara (default: ID)',
  'desc-hl': 'Kode bahasa (default: id)',
  desc: 'Menampilkan daftar video rekomendasi dan trending beranda YouTube Indonesia',

  async run(req, res) {
    const gl = String(req.query?.gl || req.body?.gl || 'ID').trim().toUpperCase();
    const hl = String(req.query?.hl || req.body?.hl || 'id').trim().toLowerCase();

    try {
      const payload = {
        context: {
          client: {
            clientName: 'WEB',
            clientVersion: '2.20240101.00.00',
            hl,
            gl
          }
        },
        query: 'trending indonesia hari ini'
      };

      const response = await axios.post('https://www.youtube.com/youtubei/v1/search', payload, {
        headers: {
          'Content-Type': 'application/json',
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        },
        timeout: 10000
      });

      const list = [];
      const contents = response.data?.contents?.twoColumnSearchResultsRenderer?.primaryContents?.sectionListRenderer?.contents || [];

      for (const section of contents) {
        const items = section.itemSectionRenderer?.contents || [];
        for (const item of items) {
          if (item.videoRenderer) {
            const v = item.videoRenderer;
            const videoId = v.videoId;
            if (!videoId) continue;

            const isLive = v.badges?.some(b => b.metadataBadgeRenderer?.style === 'BADGE_STYLE_TYPE_LIVE_NOW');
            const duration = isLive ? 'LIVE' : (v.lengthText?.simpleText || '');
            const views = v.viewCountText?.simpleText || v.viewCountText?.runs?.map(r => r.text).join('') || v.shortViewCountText?.simpleText || '';

            list.push({
              videoId,
              title: v.title?.runs?.[0]?.text || '',
              channel: {
                name: v.ownerText?.runs?.[0]?.text || '',
                id: v.ownerText?.runs?.[0]?.navigationEndpoint?.browseEndpoint?.browseId || ''
              },
              views,
              duration,
              publishedTime: v.publishedTimeText?.simpleText || '',
              thumbnail: `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`,
              url: `https://www.youtube.com/watch?v=${videoId}`
            });
          }
        }
      }

      return res.json({
        status: true,
        region: gl,
        total: list.length,
        result: list
      });
    } catch (err) {
      return res.status(500).json({
        status: false,
        message: err.message
      });
    }
  }
};
