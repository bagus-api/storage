// params : ?id=PL9y1tLe074BDmrM7DO1nBfu6265mRJ6DF

const axios = require('axios');

module.exports = {
  category: 'YouTube',
  params: ['id'],
  'desc-id': 'ID Playlist (PL...) atau URL lengkap playlist YouTube',
  desc: 'Mengambil detail lengkap playlist YouTube dan seluruh daftar video di dalamnya',

  async run(req, res) {
    const rawId = String(req.query?.id || req.body?.id || req.query?.url || req.body?.url || '').trim();

    if (!rawId) {
      return res.status(400).json({
        status: false,
        message: 'Parameter id atau url playlist diperlukan'
      });
    }

    let playlistId = rawId;
    const listMatch = playlistId.match(/[?&]list=([a-zA-Z0-9_-]+)/);
    if (listMatch) {
      playlistId = listMatch[1];
    }
    playlistId = playlistId.replace(/^VL/, '');

    try {
      const browseId = `VL${playlistId}`;
      const payload = {
        context: {
          client: {
            clientName: 'WEB',
            clientVersion: '2.20240101.00.00',
            hl: 'id',
            gl: 'ID'
          }
        },
        browseId
      };

      let response;
      try {
        response = await axios.post('https://www.youtube.com/youtubei/v1/browse', payload, {
          headers: {
            'Content-Type': 'application/json',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
          },
          timeout: 10000
        });
      } catch (err) {
        return res.status(404).json({
          status: false,
          message: 'Playlist tidak ditemukan atau disetel ke pribadi (private)'
        });
      }

      const data = response.data;
      if (!data.contents && !data.header) {
        return res.status(404).json({
          status: false,
          message: 'Playlist tidak ditemukan atau disetel ke pribadi (private)'
        });
      }

      // Metadata Header & Sidebar
      const pageHeader = data.header?.pageHeaderRenderer?.content?.pageHeaderViewModel;
      const primarySidebar = data.sidebar?.playlistSidebarRenderer?.items?.find(i => i.playlistSidebarPrimaryInfoRenderer)?.playlistSidebarPrimaryInfoRenderer;
      const secondarySidebar = data.sidebar?.playlistSidebarRenderer?.items?.find(i => i.playlistSidebarSecondaryInfoRenderer)?.playlistSidebarSecondaryInfoRenderer;

      const title = pageHeader?.title?.dynamicTextViewModel?.text?.content ||
        primarySidebar?.title?.runs?.[0]?.text ||
        data.metadata?.playlistMetadataRenderer?.title || '';

      const description = data.metadata?.playlistMetadataRenderer?.description || '';
      const thumbnail = pageHeader?.heroImage?.contentPreviewImageViewModel?.image?.sources?.slice(-1)[0]?.url ||
        primarySidebar?.thumbnailRenderer?.playlistVideoThumbnailRenderer?.thumbnail?.thumbnails?.slice(-1)[0]?.url ||
        `https://i.ytimg.com/vi/${playlistId}/hqdefault.jpg`;

      let videoCount = '';
      let viewCount = '';
      let lastUpdated = '';

      const stats = primarySidebar?.stats || [];
      for (const s of stats) {
        const text = s.runs?.map(r => r.text).join('') || s.simpleText || '';
        if (/video/i.test(text)) videoCount = text;
        else if (/ditonton|views/i.test(text)) viewCount = text;
        else if (/diperbarui|updated/i.test(text)) lastUpdated = text;
      }

      const metaRows = pageHeader?.metadata?.contentMetadataViewModel?.metadataRows || [];
      for (const row of metaRows) {
        for (const part of row.metadataParts || []) {
          const text = part.text?.content || '';
          if (/video/i.test(text)) videoCount = text;
          else if (/ditonton|views/i.test(text)) viewCount = text;
        }
      }

      const ownerRenderer = secondarySidebar?.videoOwner?.videoOwnerRenderer;
      const channel = {
        name: ownerRenderer?.title?.runs?.[0]?.text || '',
        id: ownerRenderer?.navigationEndpoint?.browseEndpoint?.browseId || '',
        url: ownerRenderer?.navigationEndpoint?.browseEndpoint?.canonicalBaseUrl ? `https://www.youtube.com${ownerRenderer.navigationEndpoint.browseEndpoint.canonicalBaseUrl}` : '',
        avatar: ownerRenderer?.thumbnail?.thumbnails?.slice(-1)[0]?.url || ''
      };

      // Extract Daftar Video
      const tabs = data.contents?.twoColumnBrowseResultsRenderer?.tabs || [];
      const sec = tabs[0]?.tabRenderer?.content?.sectionListRenderer?.contents || [];
      const rawItems = sec[0]?.itemSectionRenderer?.contents || [];

      const videos = [];
      for (const item of rawItems) {
        // 1. Modern lockupViewModel
        if (item.lockupViewModel) {
          const l = item.lockupViewModel;
          const meta = l.metadata?.lockupMetadataViewModel;
          const rows = meta?.metadata?.contentMetadataViewModel?.metadataRows || [];
          const channelPart = rows[0]?.metadataParts?.[0]?.text?.content || '';
          const statParts = rows[1]?.metadataParts || [];
          const durationBadge = l.contentImage?.thumbnailViewModel?.overlays?.find(o => o.thumbnailBottomOverlayViewModel)?.thumbnailBottomOverlayViewModel?.badges?.[0]?.thumbnailBadgeViewModel?.text || '';

          videos.push({
            videoId: l.contentId,
            title: meta?.title?.content || '',
            channel: channelPart,
            views: statParts[0]?.text?.content || '',
            publishedTime: statParts[1]?.text?.content || '',
            duration: durationBadge,
            thumbnail: `https://i.ytimg.com/vi/${l.contentId}/hqdefault.jpg`,
            url: `https://www.youtube.com/watch?v=${l.contentId}&list=${playlistId}`
          });
        }

        // 2. Classic playlistVideoRenderer
        if (item.playlistVideoRenderer) {
          const v = item.playlistVideoRenderer;
          videos.push({
            videoId: v.videoId,
            title: v.title?.runs?.[0]?.text || '',
            channel: v.shortBylineText?.runs?.[0]?.text || '',
            duration: v.lengthText?.simpleText || '',
            thumbnail: `https://i.ytimg.com/vi/${v.videoId}/hqdefault.jpg`,
            url: `https://www.youtube.com/watch?v=${v.videoId}&list=${playlistId}`
          });
        }
      }

      return res.json({
        status: true,
        result: {
          playlistId,
          title,
          channel,
          videoCount: videoCount || `${videos.length} video`,
          viewCount,
          lastUpdated,
          description,
          thumbnail,
          url: `https://www.youtube.com/playlist?list=${playlistId}`,
          totalVideos: videos.length,
          videos
        }
      });
    } catch (err) {
      return res.status(500).json({
        status: false,
        message: err.message
      });
    }
  }
};
