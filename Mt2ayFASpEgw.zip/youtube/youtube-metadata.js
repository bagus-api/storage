// params : ?id=dQw4w9WgXcQ

const axios = require('axios');

module.exports = {
  category: 'YouTube',
  params: ['id'],
  'desc-id': 'ID video YouTube atau URL lengkap (watch / shorts / youtu.be)',
  desc: 'Mengambil metadata lengkap video YouTube (like, view, subscriber, deskripsi, channel)',

  async run(req, res) {
    const rawId = String(req.query?.id || req.body?.id || req.query?.url || req.body?.url || '').trim();

    if (!rawId) {
      return res.status(400).json({
        status: false,
        message: 'Parameter id atau url diperlukan'
      });
    }

    let videoId = rawId;
    const match = rawId.match(/(?:youtu\.be\/|youtube\.com\/(?:embed\/|v\/|watch\?v=|shorts\/|live\/))([\w-]{11})/);
    if (match) {
      videoId = match[1];
    }

    if (!videoId || videoId.length < 11) {
      return res.status(400).json({
        status: false,
        message: 'ID atau URL YouTube tidak valid'
      });
    }

    try {
      const payload = {
        context: {
          client: {
            clientName: 'WEB',
            clientVersion: '2.20240101.00.00',
            hl: 'id',
            gl: 'ID'
          }
        },
        videoId
      };

      const response = await axios.post('https://www.youtube.com/youtubei/v1/next', payload, {
        headers: {
          'Content-Type': 'application/json',
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        },
        timeout: 10000
      });

      const json = response.data;
      const results = json.contents?.twoColumnWatchNextResults?.results?.results?.contents || [];
      const primary = results.find(r => r.videoPrimaryInfoRenderer)?.videoPrimaryInfoRenderer;
      const secondary = results.find(r => r.videoSecondaryInfoRenderer)?.videoSecondaryInfoRenderer;

      if (!primary && !secondary) {
        return res.status(404).json({
          status: false,
          message: 'Video tidak ditemukan atau tidak dapat diakses'
        });
      }

      const title = primary?.title?.runs?.[0]?.text || '';
      const views = primary?.viewCount?.videoViewCountRenderer?.viewCount?.simpleText || primary?.viewCount?.videoViewCountRenderer?.shortViewCount?.simpleText || '';
      const publishedDate = primary?.dateText?.simpleText || '';
      const relativeDate = primary?.relativeDateText?.simpleText || '';

      // Extract Likes
      let likes = '';
      const buttons = primary?.videoActions?.menuRenderer?.topLevelButtons || [];
      for (const b of buttons) {
        const likeVM = b.segmentedLikeDislikeButtonViewModel?.likeButtonViewModel?.likeButtonViewModel?.toggleButtonViewModel?.toggleButtonViewModel;
        if (likeVM?.defaultButtonViewModel?.buttonViewModel?.title) {
          likes = likeVM.defaultButtonViewModel.buttonViewModel.title;
          break;
        }
        const likeRen = b.segmentedLikeDislikeButtonRenderer?.likeButton?.toggleButtonRenderer;
        if (likeRen) {
          likes = likeRen.defaultText?.simpleText || likeRen.accessibility?.label || '';
          break;
        }
      }

      // Extract Channel Info
      const owner = secondary?.owner?.videoOwnerRenderer;
      const channel = {
        id: owner?.navigationEndpoint?.browseEndpoint?.browseId || '',
        name: owner?.title?.runs?.[0]?.text || '',
        subscribers: owner?.subscriberCountText?.simpleText || '',
        avatar: owner?.thumbnail?.thumbnails?.slice(-1)[0]?.url || '',
        url: owner?.navigationEndpoint?.browseEndpoint?.canonicalBaseUrl ? `https://www.youtube.com${owner.navigationEndpoint.browseEndpoint.canonicalBaseUrl}` : ''
      };

      const description = secondary?.attributedDescription?.content || secondary?.description?.runs?.map(r => r.text).join('') || '';

      return res.json({
        status: true,
        result: {
          videoId,
          title,
          views,
          likes,
          publishedDate,
          relativeDate,
          channel,
          description,
          thumbnails: {
            default: `https://i.ytimg.com/vi/${videoId}/default.jpg`,
            mq: `https://i.ytimg.com/vi/${videoId}/mqdefault.jpg`,
            hq: `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`,
            sd: `https://i.ytimg.com/vi/${videoId}/sddefault.jpg`,
            maxres: `https://i.ytimg.com/vi/${videoId}/maxresdefault.jpg`
          },
          url: `https://www.youtube.com/watch?v=${videoId}`
        }
      });
    } catch (err) {
      return res.status(500).json({
        status: false,
        message: err.message
      });
    }
  }
};
