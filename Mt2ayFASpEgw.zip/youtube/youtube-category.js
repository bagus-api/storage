// params : ?category=musik

const axios = require('axios');

module.exports = {
  category: 'YouTube',
  params: ['category'],
  'desc-category': 'Nama kategori atau "list" untuk daftar kategori',
  paramsSelect: {
    category: [
      'list',
      'musik',
      'gaming',
      'berita',
      'film',
      'hiburan',
      'edukasi',
      'olahraga',
      'teknologi',
      'kuliner',
      'otomotif'
    ]
  },
  desc: 'Menampilkan daftar kategori YouTube atau mengambil video rekomendasi berdasarkan kategori',

  async run(req, res) {
    const category = String(req.query?.category || req.body?.category || 'list').trim().toLowerCase();

    const categoryCatalog = {
      musik: {
        name: 'Musik & Lagu',
        query: 'lagu hits dan musik viral indonesia'
      },
      gaming: {
        name: 'Gaming & Esport',
        query: 'game gameplay populer indonesia'
      },
      berita: {
        name: 'Berita & Politik',
        query: 'berita terkini nasional indonesia'
      },
      film: {
        name: 'Film & Animasi',
        query: 'trailer review film bioskop indonesia'
      },
      hiburan: {
        name: 'Hiburan & Komedi',
        query: 'sketsa komedi hiburan podcast viral indonesia'
      },
      edukasi: {
        name: 'Edukasi & Sains',
        query: 'edukasi sains teknologi ilmu pengetahuan indonesia'
      },
      olahraga: {
        name: 'Olahraga & Sport',
        query: 'highlight pertandingan olahraga indonesia'
      },
      teknologi: {
        name: 'Teknologi & Gadget',
        query: 'review gadget smartphone teknologi indonesia'
      },
      kuliner: {
        name: 'Kuliner & Masakan',
        query: 'wisata kuliner resep makanan viral indonesia'
      },
      otomotif: {
        name: 'Otomotif (Mobil & Motor)',
        query: 'review motor mobil otomotif modifikasi indonesia'
      }
    };

    if (category === 'list' || !categoryCatalog[category]) {
      return res.json({
        status: true,
        message: 'Daftar kategori YouTube yang tersedia',
        categories: Object.keys(categoryCatalog).map(key => ({
          key,
          name: categoryCatalog[key].name,
          sampleUrl: `?category=${key}`
        }))
      });
    }

    try {
      const selected = categoryCatalog[category];
      const payload = {
        context: {
          client: {
            clientName: 'WEB',
            clientVersion: '2.20240101.00.00',
            hl: 'id',
            gl: 'ID'
          }
        },
        query: selected.query
      };

      const response = await axios.post('https://www.youtube.com/youtubei/v1/search', payload, {
        headers: {
          'Content-Type': 'application/json',
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        },
        timeout: 10000
      });

      const list = [];
      const contents = response.data?.contents?.twoColumnSearchResultsRenderer?.primaryContents?.sectionListRenderer?.contents || [];

      for (const section of contents) {
        const items = section.itemSectionRenderer?.contents || [];
        for (const item of items) {
          if (item.videoRenderer) {
            const v = item.videoRenderer;
            const videoId = v.videoId;
            if (!videoId) continue;

            const isLive = v.badges?.some(b => b.metadataBadgeRenderer?.style === 'BADGE_STYLE_TYPE_LIVE_NOW');
            const duration = isLive ? 'LIVE' : (v.lengthText?.simpleText || '');
            const views = v.viewCountText?.simpleText || v.viewCountText?.runs?.map(r => r.text).join('') || v.shortViewCountText?.simpleText || '';

            list.push({
              videoId,
              title: v.title?.runs?.[0]?.text || '',
              channel: {
                name: v.ownerText?.runs?.[0]?.text || '',
                id: v.ownerText?.runs?.[0]?.navigationEndpoint?.browseEndpoint?.browseId || ''
              },
              views,
              duration,
              publishedTime: v.publishedTimeText?.simpleText || '',
              thumbnail: `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`,
              url: `https://www.youtube.com/watch?v=${videoId}`
            });
          }
        }
      }

      return res.json({
        status: true,
        category,
        categoryName: selected.name,
        total: list.length,
        result: list
      });
    } catch (err) {
      return res.status(500).json({
        status: false,
        message: err.message
      });
    }
  }
};
