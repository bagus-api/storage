// params : ?query=indonesia

const axios = require('axios');

module.exports = {
  category: 'YouTube',
  params: ['query'],
  'desc-query': 'Kata kunci atau topik Shorts (default: indonesia)',
  desc: 'Mengambil daftar video YouTube Shorts trending dan populer',

  async run(req, res) {
    const rawQuery = String(req.query?.query || req.body?.query || 'indonesia').trim();
    const query = rawQuery.startsWith('#shorts') ? rawQuery : `#shorts ${rawQuery}`;

    try {
      const payload = {
        context: {
          client: {
            clientName: 'WEB',
            clientVersion: '2.20240101.00.00',
            hl: 'id',
            gl: 'ID'
          }
        },
        query
      };

      const response = await axios.post('https://www.youtube.com/youtubei/v1/search', payload, {
        headers: {
          'Content-Type': 'application/json',
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        },
        timeout: 10000
      });

      const list = [];
      const seenIds = new Set();
      const contents = response.data?.contents?.twoColumnSearchResultsRenderer?.primaryContents?.sectionListRenderer?.contents || [];

      for (const section of contents) {
        const items = section.itemSectionRenderer?.contents || [];
        for (const item of items) {
          // Format 1: Modern shortsLockupViewModel
          if (item.gridShelfViewModel?.contents) {
            for (const shelfItem of item.gridShelfViewModel.contents) {
              const s = shelfItem.shortsLockupViewModel;
              const videoId = s?.onTap?.innertubeCommand?.reelWatchEndpoint?.videoId || (s?.entityId || '').replace(/^shorts-shelf-item-/, '');
              if (videoId && !seenIds.has(videoId)) {
                seenIds.add(videoId);
                list.push({
                  videoId,
                  title: s.overlayMetadata?.primaryText?.content || '',
                  views: s.overlayMetadata?.secondaryText?.content || '',
                  thumbnail: `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`,
                  url: `https://www.youtube.com/shorts/${videoId}`
                });
              }
            }
          }

          // Format 2: Classic reelShelfRenderer
          if (item.reelShelfRenderer?.items) {
            for (const reelItem of item.reelShelfRenderer.items) {
              const r = reelItem.reelItemRenderer;
              if (r?.videoId && !seenIds.has(r.videoId)) {
                seenIds.add(r.videoId);
                list.push({
                  videoId: r.videoId,
                  title: r.headline?.simpleText || '',
                  views: r.viewCountText?.simpleText || '',
                  thumbnail: `https://i.ytimg.com/vi/${r.videoId}/hqdefault.jpg`,
                  url: `https://www.youtube.com/shorts/${r.videoId}`
                });
              }
            }
          }

          // Format 3: Regular short video
          if (item.videoRenderer?.videoId) {
            const v = item.videoRenderer;
            if (!seenIds.has(v.videoId)) {
              seenIds.add(v.videoId);
              list.push({
                videoId: v.videoId,
                title: v.title?.runs?.[0]?.text || '',
                views: v.viewCountText?.simpleText || '',
                thumbnail: `https://i.ytimg.com/vi/${v.videoId}/hqdefault.jpg`,
                url: `https://www.youtube.com/shorts/${v.videoId}`
              });
            }
          }
        }
      }

      return res.json({
        status: true,
        query: rawQuery,
        total: list.length,
        result: list
      });
    } catch (err) {
      return res.status(500).json({
        status: false,
        message: err.message
      });
    }
  }
};
