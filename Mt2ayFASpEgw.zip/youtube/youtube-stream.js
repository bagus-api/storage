// params : ?id=dQw4w9WgXcQ&autoplay=0&controls=1

const axios = require('axios');

module.exports = {
  category: 'YouTube',
  params: ['id', 'autoplay', 'controls', 'mute', 'loop'],
  'desc-id': 'ID video YouTube atau URL lengkap (watch / shorts / youtu.be)',
  'desc-autoplay': 'Putar otomatis (1 atau 0)',
  'desc-controls': 'Tampilkan kontrol video (1 atau 0)',
  'desc-mute': 'Mute audio saat mulai (1 atau 0)',
  'desc-loop': 'Ulangi video terus menerus (1 atau 0)',
  paramsSelect: {
    autoplay: ['0', '1'],
    controls: ['1', '0'],
    mute: ['0', '1'],
    loop: ['0', '1']
  },
  desc: 'Menghasilkan kode embed iframe responsif, link player streaming, dan preview YouTube',

  async run(req, res) {
    const rawId = String(req.query?.id || req.body?.id || req.query?.url || req.body?.url || '').trim();
    const autoplay = String(req.query?.autoplay || req.body?.autoplay || '0').trim() === '1' ? '1' : '0';
    const controls = String(req.query?.controls || req.body?.controls || '1').trim() === '0' ? '0' : '1';
    const mute = String(req.query?.mute || req.body?.mute || '0').trim() === '1' ? '1' : '0';
    const loop = String(req.query?.loop || req.body?.loop || '0').trim() === '1' ? '1' : '0';

    if (!rawId) {
      return res.status(400).json({
        status: false,
        message: 'Parameter id atau url diperlukan'
      });
    }

    let videoId = rawId;
    const match = rawId.match(/(?:youtu\.be\/|youtube\.com\/(?:embed\/|v\/|watch\?v=|shorts\/|live\/))([\w-]{11})/);
    if (match) {
      videoId = match[1];
    }

    if (!videoId || videoId.length < 11) {
      return res.status(400).json({
        status: false,
        message: 'ID atau URL YouTube tidak valid'
      });
    }

    try {
      let title = 'YouTube Video Player';
      let author = '';
      let authorUrl = '';

      try {
        const oembed = await axios.get(`https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v=${videoId}&format=json`, {
          timeout: 4000
        });
        if (oembed.data) {
          title = oembed.data.title || title;
          author = oembed.data.author_name || '';
          authorUrl = oembed.data.author_url || '';
        }
      } catch (e) {
        // Abaikan jika oembed timeout/error, tetap buat player
      }

      const queryParams = new URLSearchParams({
        autoplay,
        controls,
        mute,
        rel: '0',
        playsinline: '1'
      });

      if (loop === '1') {
        queryParams.set('loop', '1');
        queryParams.set('playlist', videoId);
      }

      const embedUrl = `https://www.youtube-nocookie.com/embed/${videoId}?${queryParams.toString()}`;
      const iframe = `<iframe width="100%" height="100%" src="${embedUrl}" title="${title.replace(/"/g, '&quot;')}" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>`;

      return res.json({
        status: true,
        result: {
          videoId,
          title,
          author,
          authorUrl,
          embedUrl,
          iframe,
          watchUrl: `https://www.youtube.com/watch?v=${videoId}`,
          thumbnails: {
            default: `https://i.ytimg.com/vi/${videoId}/default.jpg`,
            mq: `https://i.ytimg.com/vi/${videoId}/mqdefault.jpg`,
            hq: `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`,
            sd: `https://i.ytimg.com/vi/${videoId}/sddefault.jpg`,
            maxres: `https://i.ytimg.com/vi/${videoId}/maxresdefault.jpg`
          }
        }
      });
    } catch (err) {
      return res.status(500).json({
        status: false,
        message: err.message
      });
    }
  }
};
