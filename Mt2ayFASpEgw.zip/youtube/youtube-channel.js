// params : ?id=@nanasnih&tab=videos

const axios = require('axios');

module.exports = {
  category: 'YouTube',
  params: ['id', 'tab'],
  'desc-id': 'Channel ID (UC...), @handle, link channel, atau video ID/URL',
  'desc-tab': 'Tab konten: home, videos, shorts, playlists, posts',
  paramsSelect: {
    tab: [
      'home',
      'videos',
      'shorts',
      'playlists',
      'posts'
    ]
  },
  desc: 'Mengambil profil channel YouTube lengkap beserta video, shorts, playlist, atau postingan',

  async run(req, res) {
    const rawId = String(req.query?.id || req.body?.id || '').trim();
    const tab = String(req.query?.tab || req.body?.tab || 'videos').trim().toLowerCase();

    if (!rawId) {
      return res.status(400).json({
        status: false,
        message: 'Parameter id (Channel ID, @handle, atau URL) diperlukan'
      });
    }

    const tabParamsMap = {
      videos: 'EgZ2aWRlb3PyBgQKAjoA',
      shorts: 'EgZzaG9ydHPyBgUKA5oBAA%3D%3D',
      playlists: 'EglwbGF5bGlzdHPyBgoKCEIGCgIQaCIA',
      posts: 'EgVwb3N0c_IGBAoCSgA%3D'
    };

    try {
      let browseId = rawId;

      // 1. Deteksi jika input adalah Video ID (11 karakter) atau link video YouTube
      const videoMatch = rawId.match(/(?:youtu\.be\/|youtube\.com\/(?:embed\/|v\/|watch\?v=|shorts\/|live\/))([\w-]{11})/);
      if (videoMatch || (/^[\w-]{11}$/.test(rawId) && !rawId.startsWith('UC'))) {
        const videoId = videoMatch ? videoMatch[1] : rawId;
        try {
          const nextRes = await axios.post('https://www.youtube.com/youtubei/v1/next', {
            context: {
              client: { clientName: 'WEB', clientVersion: '2.20240101.00.00', hl: 'id', gl: 'ID' }
            },
            videoId
          }, {
            headers: { 'Content-Type': 'application/json', 'User-Agent': 'Mozilla/5.0' },
            timeout: 6000
          });
          const results = nextRes.data?.contents?.twoColumnWatchNextResults?.results?.results?.contents || [];
          const sec = results.find(r => r.videoSecondaryInfoRenderer)?.videoSecondaryInfoRenderer;
          const foundId = sec?.owner?.videoOwnerRenderer?.navigationEndpoint?.browseEndpoint?.browseId;
          if (foundId && foundId.startsWith('UC')) {
            browseId = foundId;
          }
        } catch (e) {}
      }

      // 2. Resolve @handle atau custom URL jika bukan browseId UC...
      if (!browseId.startsWith('UC')) {
        let cleanHandle = browseId;
        if (cleanHandle.includes('youtube.com/')) {
          const match = cleanHandle.match(/youtube\.com\/(?:@|channel\/|c\/)?([^/?]+)/);
          if (match) cleanHandle = match[1];
        }
        if (!cleanHandle.startsWith('@') && !cleanHandle.startsWith('UC')) {
          cleanHandle = `@${cleanHandle}`;
        }

        const resolvePayload = {
          context: {
            client: { clientName: 'WEB', clientVersion: '2.20240101.00.00', hl: 'id', gl: 'ID' }
          },
          url: cleanHandle.startsWith('http') ? cleanHandle : `https://www.youtube.com/${cleanHandle}`
        };

        try {
          const resolveRes = await axios.post('https://www.youtube.com/youtubei/v1/navigation/resolve_url', resolvePayload, {
            headers: {
              'Content-Type': 'application/json',
              'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            },
            timeout: 6000
          });
          const resolvedBrowseId = resolveRes.data?.endpoint?.browseEndpoint?.browseId;
          if (resolvedBrowseId && resolvedBrowseId.startsWith('UC')) {
            browseId = resolvedBrowseId;
          }
        } catch (e) {}
      }

      // 3. Fallback: Cari channel lewat Search jika masih belum ketemu UC...
      if (!browseId.startsWith('UC')) {
        try {
          const searchRes = await axios.post('https://www.youtube.com/youtubei/v1/search', {
            context: {
              client: { clientName: 'WEB', clientVersion: '2.20240101.00.00', hl: 'id', gl: 'ID' }
            },
            query: rawId,
            params: 'EgIQAg%3D%3D'
          }, {
            headers: { 'Content-Type': 'application/json', 'User-Agent': 'Mozilla/5.0' },
            timeout: 6000
          });

          const searchContents = searchRes.data?.contents?.twoColumnSearchResultsRenderer?.primaryContents?.sectionListRenderer?.contents || [];
          for (const sec of searchContents) {
            const secItems = sec.itemSectionRenderer?.contents || [];
            for (const item of secItems) {
              if (item.channelRenderer?.channelId) {
                browseId = item.channelRenderer.channelId;
                break;
              }
            }
            if (browseId.startsWith('UC')) break;
          }
        } catch (e) {}
      }

      // 4. Request Browse Channel dengan tab yang diminta
      const browsePayload = {
        context: {
          client: {
            clientName: 'WEB',
            clientVersion: '2.20240101.00.00',
            hl: 'id',
            gl: 'ID'
          }
        },
        browseId
      };

      if (tabParamsMap[tab]) {
        browsePayload.params = tabParamsMap[tab];
      }

      let response;
      try {
        response = await axios.post('https://www.youtube.com/youtubei/v1/browse', browsePayload, {
          headers: {
            'Content-Type': 'application/json',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
          },
          timeout: 10000
        });
      } catch (reqErr) {
        return res.status(404).json({
          status: false,
          message: 'Channel tidak ditemukan atau tidak dapat diakses'
        });
      }

      const data = response.data;
      if (!data.contents && !data.header) {
        return res.status(404).json({
          status: false,
          message: 'Channel tidak ditemukan atau tidak dapat diakses'
        });
      }

      // Extract Header Profil Channel
      const header = data.header?.c4TabbedHeaderRenderer || data.header?.pageHeaderRenderer;
      const title = header?.pageTitle || header?.title?.runs?.[0]?.text || '';
      const avatar = header?.content?.pageHeaderViewModel?.image?.decoratedAvatarViewModel?.avatar?.avatarViewModel?.image?.sources?.slice(-1)[0]?.url ||
        header?.avatar?.thumbnails?.slice(-1)[0]?.url || '';
      const banner = header?.banner?.thumbnails?.slice(-1)[0]?.url || '';

      let subscribers = '';
      let videosCount = '';
      let handle = '';

      const metaRows = header?.content?.pageHeaderViewModel?.metadata?.contentMetadataViewModel?.metadataRows || [];
      for (const row of metaRows) {
        for (const part of row.metadataParts || []) {
          const text = part.text?.content || '';
          if (text.startsWith('@')) handle = text;
          if (/subscribers|subscriber|pelanggan/i.test(text)) subscribers = text;
          if (/videos|video/i.test(text)) videosCount = text;
        }
      }

      if (!subscribers && header?.subscriberCountText?.simpleText) {
        subscribers = header.subscriberCountText.simpleText;
      }

      // Extract Konten Tab Aktif
      const tabs = data.contents?.twoColumnBrowseResultsRenderer?.tabs || [];
      const activeTab = tabs.find(t => t.tabRenderer?.selected)?.tabRenderer ||
        tabs.find(t => t.tabRenderer?.content?.richGridRenderer || t.tabRenderer?.content?.sectionListRenderer)?.tabRenderer;
      const richItems = activeTab?.content?.richGridRenderer?.contents || [];
      const sectionItems = activeTab?.content?.sectionListRenderer?.contents || [];

      const items = [];

      // Helper parser video/item
      const parseVideoObj = (v, itemType = 'video') => {
        if (!v || !v.videoId) return null;
        return {
          type: itemType,
          id: v.videoId,
          title: v.title?.runs?.[0]?.text || v.title?.simpleText || '',
          views: v.viewCountText?.simpleText || v.viewCountText?.runs?.map(r => r.text).join('') || v.shortViewCountText?.simpleText || '',
          duration: v.lengthText?.simpleText || '',
          publishedTime: v.publishedTimeText?.simpleText || '',
          thumbnail: `https://i.ytimg.com/vi/${v.videoId}/hqdefault.jpg`,
          url: `https://www.youtube.com/watch?v=${v.videoId}`
        };
      };

      // 1. Parse item dari richGrid (Videos, Shorts, Playlists)
      for (const item of richItems) {
        const content = item.richItemRenderer?.content;
        if (!content) continue;

        if (content.lockupViewModel) {
          const l = content.lockupViewModel;
          const meta = l.metadata?.lockupMetadataViewModel;
          const parts = meta?.metadata?.contentMetadataViewModel?.metadataRows?.[0]?.metadataParts || [];
          items.push({
            type: l.contentType === 'LOCKUP_CONTENT_TYPE_PLAYLIST' ? 'playlist' : 'video',
            id: l.contentId,
            title: meta?.title?.content || '',
            views: parts[0]?.text?.content || '',
            publishedTime: parts[1]?.text?.content || '',
            thumbnail: `https://i.ytimg.com/vi/${l.contentId}/hqdefault.jpg`,
            url: l.contentType === 'LOCKUP_CONTENT_TYPE_PLAYLIST' ? `https://www.youtube.com/playlist?list=${l.contentId}` : `https://www.youtube.com/watch?v=${l.contentId}`
          });
        } else if (content.videoRenderer) {
          const parsed = parseVideoObj(content.videoRenderer, 'video');
          if (parsed) items.push(parsed);
        } else if (content.shortsLockupViewModel) {
          const s = content.shortsLockupViewModel;
          const vId = s.onTap?.innertubeCommand?.reelWatchEndpoint?.videoId || (s.entityId || '').replace(/^shorts-shelf-item-/, '');
          items.push({
            type: 'short',
            id: vId,
            title: s.overlayMetadata?.primaryText?.content || '',
            views: s.overlayMetadata?.secondaryText?.content || '',
            thumbnail: `https://i.ytimg.com/vi/${vId}/hqdefault.jpg`,
            url: `https://www.youtube.com/shorts/${vId}`
          });
        }
      }

      // 2. Parse item dari sectionList (Beranda / Shelves & Postingan Komunitas)
      for (const section of sectionItems) {
        const secContents = section.itemSectionRenderer?.contents || [];
        for (const sc of secContents) {
          // Postingan Komunitas
          if (sc.backstagePostThreadRenderer?.post?.backstagePostRenderer) {
            const bp = sc.backstagePostThreadRenderer.post.backstagePostRenderer;
            items.push({
              type: 'post',
              postId: bp.postId,
              text: bp.contentText?.runs?.map(r => r.text).join('') || '',
              publishedTime: bp.publishedTimeText?.runs?.[0]?.text || '',
              likes: bp.voteCount?.simpleText || '0'
            });
          }

          // Shelves di Beranda (Horizontal List atau Expanded Shelf)
          if (sc.shelfRenderer?.content) {
            const shelfList = sc.shelfRenderer.content.horizontalListRenderer?.items ||
              sc.shelfRenderer.content.expandedShelfContentsRenderer?.items || [];
            for (const si of shelfList) {
              if (si.lockupViewModel) {
                const l = si.lockupViewModel;
                const meta = l.metadata?.lockupMetadataViewModel;
                const parts = meta?.metadata?.contentMetadataViewModel?.metadataRows?.[0]?.metadataParts || [];
                items.push({
                  type: l.contentType === 'LOCKUP_CONTENT_TYPE_PLAYLIST' ? 'playlist' : 'video',
                  id: l.contentId,
                  title: meta?.title?.content || '',
                  views: parts[0]?.text?.content || '',
                  publishedTime: parts[1]?.text?.content || '',
                  thumbnail: `https://i.ytimg.com/vi/${l.contentId}/hqdefault.jpg`,
                  url: l.contentType === 'LOCKUP_CONTENT_TYPE_PLAYLIST' ? `https://www.youtube.com/playlist?list=${l.contentId}` : `https://www.youtube.com/watch?v=${l.contentId}`
                });
              } else if (si.gridVideoRenderer) {
                const parsed = parseVideoObj(si.gridVideoRenderer, 'video');
                if (parsed) items.push(parsed);
              } else if (si.videoRenderer) {
                const parsed = parseVideoObj(si.videoRenderer, 'video');
                if (parsed) items.push(parsed);
              } else if (si.reelItemRenderer) {
                items.push({
                  type: 'short',
                  id: si.reelItemRenderer.videoId,
                  title: si.reelItemRenderer.headline?.simpleText || '',
                  views: si.reelItemRenderer.viewCountText?.simpleText || '',
                  thumbnail: `https://i.ytimg.com/vi/${si.reelItemRenderer.videoId}/hqdefault.jpg`,
                  url: `https://www.youtube.com/shorts/${si.reelItemRenderer.videoId}`
                });
              }
            }
          }
        }
      }

      return res.json({
        status: true,
        channel: {
          browseId,
          title,
          handle,
          subscribers,
          videosCount,
          avatar,
          banner,
          url: `https://www.youtube.com/channel/${browseId}`
        },
        tab,
        total: items.length,
        items
      });
    } catch (err) {
      return res.status(500).json({
        status: false,
        message: err.message
      });
    }
  }
};
