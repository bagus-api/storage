// params : ?query=nanas&type=video

const axios = require('axios');

module.exports = {
  category: 'YouTube',
  params: ['query', 'type'],
  'desc-query': 'Kata kunci pencarian (judul video, channel, atau topik)',
  'desc-type': 'Tipe pencarian: all, video, channel, playlist',
  paramsSelect: {
    type: [
      'all',
      'video',
      'channel',
      'playlist'
    ]
  },
  desc: 'Mencari video, channel, atau playlist di YouTube',

  async run(req, res) {
    const query = String(req.query?.query || req.body?.query || '').trim();
    const type = String(req.query?.type || req.body?.type || 'all').trim().toLowerCase();

    if (!query) {
      return res.status(400).json({
        status: false,
        message: 'Parameter query diperlukan'
      });
    }

    const typeParamsMap = {
      video: 'EgIQAQ%3D%3D',
      channel: 'EgIQAg%3D%3D',
      playlist: 'EgIQAw%3D%3D'
    };

    try {
      const payload = {
        context: {
          client: {
            clientName: 'WEB',
            clientVersion: '2.20240101.00.00',
            hl: 'id',
            gl: 'ID'
          }
        },
        query
      };

      if (typeParamsMap[type]) {
        payload.params = typeParamsMap[type];
      }

      const response = await axios.post('https://www.youtube.com/youtubei/v1/search', payload, {
        headers: {
          'Content-Type': 'application/json',
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        },
        timeout: 10000
      });

      const list = [];
      const contents = response.data?.contents?.twoColumnSearchResultsRenderer?.primaryContents?.sectionListRenderer?.contents || [];

      for (const section of contents) {
        const items = section.itemSectionRenderer?.contents || [];
        for (const item of items) {
          // 1. Classic Video Renderer
          if (item.videoRenderer) {
            const v = item.videoRenderer;
            const videoId = v.videoId;
            if (!videoId) continue;

            const isLive = v.badges?.some(b => b.metadataBadgeRenderer?.style === 'BADGE_STYLE_TYPE_LIVE_NOW');
            const duration = isLive ? 'LIVE' : (v.lengthText?.simpleText || '');
            const views = v.viewCountText?.simpleText || v.viewCountText?.runs?.map(r => r.text).join('') || v.shortViewCountText?.simpleText || '';

            list.push({
              type: 'video',
              videoId,
              title: v.title?.runs?.[0]?.text || '',
              channel: {
                name: v.ownerText?.runs?.[0]?.text || '',
                id: v.ownerText?.runs?.[0]?.navigationEndpoint?.browseEndpoint?.browseId || ''
              },
              views,
              duration,
              publishedTime: v.publishedTimeText?.simpleText || '',
              thumbnail: `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`,
              url: `https://www.youtube.com/watch?v=${videoId}`
            });
          }

          // 2. Classic Channel Renderer
          if (item.channelRenderer) {
            const c = item.channelRenderer;
            const channelId = c.channelId;
            list.push({
              type: 'channel',
              channelId,
              title: c.title?.simpleText || '',
              handle: c.subscriberCountText?.simpleText?.startsWith('@') ? c.subscriberCountText.simpleText : '',
              subscribers: c.videoCountText?.simpleText || c.subscriberCountText?.simpleText || '',
              thumbnail: c.thumbnail?.thumbnails?.slice(-1)[0]?.url || '',
              url: `https://www.youtube.com/channel/${channelId}`
            });
          }

          // 3. Classic Playlist Renderer
          if (item.playlistRenderer) {
            const p = item.playlistRenderer;
            const playlistId = p.playlistId;
            list.push({
              type: 'playlist',
              playlistId,
              title: p.title?.simpleText || '',
              channel: {
                name: p.shortBylineText?.runs?.[0]?.text || '',
                id: p.shortBylineText?.runs?.[0]?.navigationEndpoint?.browseEndpoint?.browseId || ''
              },
              videoCount: p.videoCount || '',
              thumbnail: p.thumbnails?.[0]?.thumbnails?.slice(-1)[0]?.url || '',
              url: `https://www.youtube.com/playlist?list=${playlistId}`
            });
          }

          // 4. Modern lockupViewModel (Playlists, Channels, Videos)
          if (item.lockupViewModel) {
            const l = item.lockupViewModel;
            const meta = l.metadata?.lockupMetadataViewModel;
            const rows = meta?.metadata?.contentMetadataViewModel?.metadataRows || [];
            const isPlaylist = l.contentType === 'LOCKUP_CONTENT_TYPE_PLAYLIST' || l.contentId?.startsWith('PL') || l.contentId?.startsWith('VL');
            const isChannel = l.contentType === 'LOCKUP_CONTENT_TYPE_CHANNEL' || l.contentId?.startsWith('UC');

            if (isPlaylist) {
              const channelName = rows[0]?.metadataParts?.[0]?.text?.content || '';
              const channelId = rows[0]?.metadataParts?.[0]?.text?.commandRuns?.[0]?.onTap?.innertubeCommand?.browseEndpoint?.browseId || '';
              const playlistThumb = l.contentImage?.collectionThumbnailViewModel?.primaryThumbnail?.thumbnailViewModel?.image?.sources?.slice(-1)[0]?.url ||
                `https://i.ytimg.com/vi/${l.contentId}/hqdefault.jpg`;
              const badgeText = l.contentImage?.collectionThumbnailViewModel?.primaryThumbnail?.thumbnailViewModel?.overlays?.[0]?.thumbnailOverlayBadgeViewModel?.thumbnailBadges?.[0]?.thumbnailBadgeViewModel?.text || '';

              list.push({
                type: 'playlist',
                playlistId: l.contentId,
                title: meta?.title?.content || '',
                channel: {
                  name: channelName,
                  id: channelId
                },
                videoCount: badgeText,
                thumbnail: playlistThumb,
                url: `https://www.youtube.com/playlist?list=${l.contentId}`
              });
            } else if (isChannel) {
              const subsText = rows[0]?.metadataParts?.[0]?.text?.content || '';
              const channelAvatar = l.contentImage?.decoratedAvatarViewModel?.avatar?.avatarViewModel?.image?.sources?.slice(-1)[0]?.url || '';

              list.push({
                type: 'channel',
                channelId: l.contentId,
                title: meta?.title?.content || '',
                subscribers: subsText,
                thumbnail: channelAvatar,
                url: `https://www.youtube.com/channel/${l.contentId}`
              });
            } else {
              const channelName = rows[0]?.metadataParts?.[0]?.text?.content || '';
              const channelId = rows[0]?.metadataParts?.[0]?.text?.commandRuns?.[0]?.onTap?.innertubeCommand?.browseEndpoint?.browseId || '';
              const statPart1 = rows[1]?.metadataParts?.[0]?.text?.content || '';
              const statPart2 = rows[1]?.metadataParts?.[1]?.text?.content || '';
              const videoThumb = l.contentImage?.thumbnailViewModel?.image?.sources?.slice(-1)[0]?.url || `https://i.ytimg.com/vi/${l.contentId}/hqdefault.jpg`;
              const durationBadge = l.contentImage?.thumbnailViewModel?.overlays?.find(o => o.thumbnailBottomOverlayViewModel)?.thumbnailBottomOverlayViewModel?.badges?.[0]?.thumbnailBadgeViewModel?.text || '';

              list.push({
                type: 'video',
                videoId: l.contentId,
                title: meta?.title?.content || '',
                channel: {
                  name: channelName,
                  id: channelId
                },
                views: statPart1,
                duration: durationBadge,
                publishedTime: statPart2,
                thumbnail: videoThumb,
                url: `https://www.youtube.com/watch?v=${l.contentId}`
              });
            }
          }
        }
      }

      // Filter ketat berdasarkan tipe yang diminta jika bukan 'all'
      const filteredList = type === 'all'
        ? list
        : list.filter(item => item.type === type);

      return res.json({
        status: true,
        query,
        type,
        total: filteredList.length,
        result: filteredList
      });
    } catch (err) {
      return res.status(500).json({
        status: false,
        message: err.message
      });
    }
  }
};
