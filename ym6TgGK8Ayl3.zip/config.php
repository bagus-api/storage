<?php
declare(strict_types=1);

/*
 * DooNokoz single configuration file.
 * Set secrets as hosting environment variables. Never commit passwords/API secrets.
 * Required: DOONOKOZ_DB_PASS. Rotate the database password previously shared in chat.
 */
return [
    'app_name' => 'DooNokoz',
    'base_url' => rtrim((string)(getenv('DOONOKOZ_BASE_URL') ?: 'https://doonokoz.site.je'), '/'),
    'timezone' => 'Asia/Jakarta',
    'db' => [
        'host' => (string)(getenv('DOONOKOZ_DB_HOST') ?: 'sql203.infinityfree.com'),
        'name' => (string)(getenv('DOONOKOZ_DB_NAME') ?: 'if0_43433165_DooNoks'),
        'user' => (string)(getenv('DOONOKOZ_DB_USER') ?: 'if0_43433165'),
        'pass' => (string)(getenv('DOONOKOZ_DB_PASS') ?: ''),
        'charset' => 'utf8mb4',
    ],
    'firebase' => [
        'api_key' => (string)(getenv('DOONOKOZ_FIREBASE_API_KEY') ?: ''),
        'auth_domain' => 'doonokoz.firebaseapp.com',
        'project_id' => 'doonokoz',
        'app_id' => '1:578020454148:web:02ac002a71fcce7c3fea51',
    ],
    'push' => [
        'public_key' => (string)(getenv('DOONOKOZ_VAPID_PUBLIC_KEY') ?: ''),
        'private_key' => (string)(getenv('DOONOKOZ_VAPID_PRIVATE_KEY') ?: ''),
        'subject' => 'mailto:admin@doonokoz.site.je',
    ],
    'fees' => ['topup_admin' => 500, 'min_topup' => 5000, 'max_topup' => 100000],
    'telegram' => [
        'bot_token' => (string)(getenv('DOONOKOZ_TELEGRAM_BOT_TOKEN') ?: ''),
        'chat_id' => (string)(getenv('DOONOKOZ_TELEGRAM_CHAT_ID') ?: ''),
    ],
    'admin_email' => 'admin@doonokoz.site.je',
];
