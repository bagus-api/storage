# DooNokoz — PHP account & wallet update

This package is a PHP/MySQL application. It is **not** a Node.js full-stack package and it is not a production-ready payment gateway integration.

## Included in this update

- Email/username registration and login, plus Firebase Google sign-in verification.
- Session cookie hardening and session ID regeneration on login.
- Per-user wallet balance read from the authenticated database user.
- Deposit request workflow with `pending` status. A request does **not** credit a balance.
- Admin review workflow. Approval uses a database transaction and row lock, credits only the request owner's account, and writes a ledger transaction.
- User-owned transaction history.
- Owner broadcast inbox and Web Push fan-out to subscribed devices.
- Responsive pages for wallet, history, notifications, and admin console.
- Single `config.php`; secrets are read from hosting environment variables.

## Not included / intentionally disabled

- Virtual-number ordering, OTP retrieval, resend, or cancellation workflows.
- Automated Midtrans/QRIS payment creation or payment webhook verification.
- A separate Vercel notification-center deployment.
- A Node.js service.

The public catalogue area is intentionally disabled. This build does not implement renting numbers or receiving verification codes.

## Requirements

- PHP 8.1+ with PDO MySQL, cURL, OpenSSL, JSON.
- MySQL 5.7+/MariaDB 10.3+.
- HTTPS enabled.
- Composer only if Web Push delivery is required.

## Installation

1. Upload the contents of this folder to the PHP document root.
2. Create the database and import `schema.sql` using the database account provided by your host.
3. Set these environment variables in the hosting control panel:
   - `DOONOKOZ_DB_HOST`
   - `DOONOKOZ_DB_NAME`
   - `DOONOKOZ_DB_USER`
   - `DOONOKOZ_DB_PASS`
   - `DOONOKOZ_BASE_URL`
   - `DOONOKOZ_FIREBASE_API_KEY` (only if Google sign-in is used)
   - `DOONOKOZ_VAPID_PUBLIC_KEY` and `DOONOKOZ_VAPID_PRIVATE_KEY` (only if Web Push is used)
4. Run `composer install --no-dev` in the project folder if the host supports Composer. This installs `minishlink/web-push`.
5. Add the first trusted administrator through a secure database session, after registering that account:

   ```sql
   UPDATE users SET role = 'admin' WHERE email = 'YOUR_ADMIN_EMAIL';
   ```

6. Test registration, login, deposit request, admin approval, transaction history, inbox, and push on a staging domain before production.

## Deposit review safety

The user-facing form only creates a pending request. Admin approval is a manual decision and should only happen after checking the actual payment through the payment provider's official dashboard. Never approve a request based only on a screenshot or user-submitted note. Automated payment crediting is not implemented in this package.

## Important credential notice

A database password was previously pasted into a chat. Treat it as exposed and rotate it at the hosting provider before deployment. Put the new password in `DOONOKOZ_DB_PASS`; do not place it in source code or commit it to Git.

## Rewrite rules

`.htaccess` routes `/api/...` to `api.php` and other paths to `index.php`. If the hosting provider does not support Apache rewrite rules, configure equivalent routes or use the query-string routes supported by your host.


## ID anggota, struk, dan notifikasi Telegram
- ID anggota ditampilkan sebagai `#0000001`, dibentuk dari ID auto-increment database sehingga unik dan berurutan.
- Struk deposit/transaksi tersedia dari Riwayat dan halaman Saldo; format HTML dapat dicetak atau disimpan sebagai PDF, dan tersedia unduhan TXT.
- Notifikasi Telegram menggunakan `DOONOKOZ_TELEGRAM_BOT_TOKEN` dan `DOONOKOZ_TELEGRAM_CHAT_ID` sebagai environment variables. Pesan memakai format kutipan dan hanya memuat ID anggota, referensi, nominal, serta status. Jangan kirim kode verifikasi atau OTP ke Telegram.
- Endpoint struk: `/api/receipt?ref=KODE` atau `/api/receipt?ref=KODE&format=txt`; hanya pemilik transaksi yang dapat membukanya.
