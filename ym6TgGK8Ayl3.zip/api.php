<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, private');
$secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
ini_set('session.use_strict_mode', '1');
ini_set('session.use_only_cookies', '1');
ini_set('session.use_trans_sid', '0');
session_set_cookie_params(['lifetime'=>0,'path'=>'/','secure'=>$secure,'httponly'=>true,'samesite'=>'Lax']);
session_start();
$cfg = require __DIR__.'/config.php';
$path = trim((string)($_GET['path'] ?? ''), '/');
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
date_default_timezone_set($cfg['timezone'] ?? 'Asia/Jakarta');

function out(array $data, int $status=200): never { http_response_code($status); echo json_encode($data, JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE); exit; }
function input(): array { $v=json_decode((string)file_get_contents('php://input'), true); return is_array($v)?$v:$_POST; }
function db(array $cfg): PDO {
    static $pdo=null; if($pdo instanceof PDO) return $pdo;
    $d=$cfg['db']; if(empty($d['pass'])) out(['ok'=>false,'message'=>'Database belum dikonfigurasi. Isi environment DOONOKOZ_DB_PASS.'],503);
    try { $pdo=new PDO('mysql:host='.$d['host'].';dbname='.$d['name'].';charset='.$d['charset'], $d['user'], $d['pass'], [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,PDO::ATTR_EMULATE_PREPARES=>false]); }
    catch(Throwable $e) { error_log('DooNokoz DB connection failed: '.$e->getMessage()); out(['ok'=>false,'message'=>'Database tidak dapat dihubungi.'],503); }
    return $pdo;
}
function sameOrigin(): void {
    $origin=(string)($_SERVER['HTTP_ORIGIN']??'');
    if($origin!=='') { $host=(string)($_SERVER['HTTP_HOST']??''); $o=parse_url($origin); if(!$o||strcasecmp((string)($o['host']??''),preg_replace('/:\d+$/','',$host))!==0) out(['ok'=>false,'message'=>'Permintaan lintas situs ditolak.'],403); }
}
function user(array $cfg): ?array {
    if(empty($_SESSION['user_id'])) return null;
    $q=db($cfg)->prepare("SELECT id,CONCAT('#',LPAD(id,7,'0')) AS user_code,email,username,display_name,balance,role,created_at FROM users WHERE id=? LIMIT 1"); $q->execute([(int)$_SESSION['user_id']]); return $q->fetch()?:null;
}
function needUser(array $cfg): array { $u=user($cfg); if(!$u) out(['ok'=>false,'message'=>'Silakan masuk terlebih dahulu.'],401); return $u; }
function needAdmin(array $cfg): array { $u=needUser($cfg); if(($u['role']??'user')!=='admin') out(['ok'=>false,'message'=>'Akses khusus admin.'],403); return $u; }
function firebaseLookup(array $cfg,string $token): array { $key=(string)($cfg['firebase']['api_key']??''); if($key==='') out(['ok'=>false,'message'=>'Login Google belum dikonfigurasi.'],503); $ch=curl_init('https://identitytoolkit.googleapis.com/v1/accounts:lookup?key='.rawurlencode($key)); curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_POST=>true,CURLOPT_HTTPHEADER=>['Content-Type: application/json'],CURLOPT_POSTFIELDS=>json_encode(['idToken'=>$token]),CURLOPT_TIMEOUT=>15]); $raw=curl_exec($ch);$code=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);curl_close($ch);$data=is_string($raw)?json_decode($raw,true):null;if($code>=400||empty($data['users'][0]))out(['ok'=>false,'message'=>'Verifikasi Google gagal.'],401);return $data['users'][0]; }
function makeUsername(PDO $p,string $email): string { $base=substr(preg_replace('/[^a-z0-9_]/','',strtolower((string)strtok($email,'@')))?:'user',0,16);$candidate=$base;for($i=0;$i<40;$i++){ $q=$p->prepare('SELECT id FROM users WHERE username=?');$q->execute([$candidate]);if(!$q->fetch())return $candidate;$candidate=$base.random_int(10,9999);}return 'user'.bin2hex(random_bytes(4));}
function telegramNotice(array $cfg,string $title,array $lines): void {
    $t=$cfg['telegram']??[]; $token=(string)($t['bot_token']??''); $chat=(string)($t['chat_id']??'');
    if($token===''||$chat===''||!function_exists('curl_init')) return;
    $safe=static fn($v)=>htmlspecialchars((string)$v,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8');
    $body='<blockquote><b>'.$safe($title)."</b>\n".implode("\n",array_map($safe,$lines))."\n\n<i>DooNokoz • Notifikasi sistem</i></blockquote>";
    $ch=curl_init('https://api.telegram.org/bot'.$token.'/sendMessage');
    curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_POST=>true,CURLOPT_HTTPHEADER=>['Content-Type: application/json'],CURLOPT_POSTFIELDS=>json_encode(['chat_id'=>$chat,'text'=>$body,'parse_mode'=>'HTML','disable_web_page_preview'=>true]),CURLOPT_TIMEOUT=>8]);
    curl_exec($ch); curl_close($ch);
}
function receiptPage(array $r,string $format='html'): never {
    $status=strtolower((string)$r['status']); $label=match($status){'success','approved','done'=>'BERHASIL','pending'=>'PENDING','rejected','failed'=>'DITOLAK',default=>strtoupper($status)};
    $rows=['DooNokoz - STRUK TRANSAKSI','Status: '.$label,'Username: @'.$r['username'],'User ID: '.$r['user_code'],'ID transaksi: '.$r['ref'],'Tanggal: '.$r['created_at'],'Produk: '.$r['product'],'Nominal: Rp'.number_format((int)$r['amount'],0,',','.'),'Biaya admin: Rp'.number_format((int)$r['fee'],0,',','.'),'Total: Rp'.number_format((int)$r['total'],0,',','.')];
    if($format==='txt'){header_remove('Content-Type');header('Content-Type: text/plain; charset=utf-8');header('Content-Disposition: attachment; filename="DooNokoz-'.$r['ref'].'.txt"');echo implode("\n",$rows)."\n";exit;}
    header_remove('Content-Type');header('Content-Type: text/html; charset=utf-8');
    $e=static fn($v)=>htmlspecialchars((string)$v,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8');
    echo '<!doctype html><html lang="id"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Struk '.$e($r['ref']).'</title><style>body{margin:0;background:#080d1c;color:#eef1ff;font:15px system-ui;padding:22px}.receipt{max-width:540px;margin:20px auto;padding:28px;border:1px solid #34345e;border-radius:24px;background:linear-gradient(145deg,#11152d,#21164a);box-shadow:0 20px 60px #0006}.logo{text-align:center;font-size:28px;font-weight:800}.sub{text-align:center;color:#a9add0;letter-spacing:3px;font-size:12px}.status{text-align:center;margin:22px auto;padding:9px;border:1px solid #16a36c;border-radius:30px;color:#35df9a;max-width:150px;font-weight:800}.pending{color:#ffc04a;border-color:#b97817}.line{display:flex;justify-content:space-between;gap:18px;padding:13px 0;border-bottom:1px solid #ffffff14}.line span:first-child{color:#aeb5d3}.line b{text-align:right;overflow-wrap:anywhere}.total{margin-top:24px;padding:16px;border-radius:14px;background:#ffffff12;display:flex;justify-content:space-between;font-weight:800}.total strong{color:#a68aff;font-size:22px}.actions{display:flex;gap:10px;margin-top:22px}.actions a,.actions button{flex:1;text-align:center;padding:12px;border:0;border-radius:12px;background:#6638e9;color:white;text-decoration:none;font-weight:700}.actions button{background:#252b45}@media print{body{background:white;color:#111;padding:0}.receipt{box-shadow:none;background:white;color:#111;border:1px solid #ddd}.line span:first-child{color:#555}.actions{display:none}}</style><main class="receipt"><div class="logo">Doo<span style="color:#8e69ff">Nokoz</span></div><div class="sub">STRUK TRANSAKSI</div><div class="status '.($status==='pending'?'pending':'').'">'.$e($label).'</div>'.'<h2 style="text-align:center">'.$e($r['product']).'</h2>';
    foreach(array_slice($rows,2,8) as $line){[$k,$v]=array_pad(explode(': ',$line,2),2,'');echo '<div class="line"><span>'.$e($k).'</span><b>'.$e($v).'</b></div>';}
    echo '<div class="total"><span>Total pembayaran</span><strong>Rp'.number_format((int)$r['total'],0,',','.').'</strong></div><p style="text-align:center;color:#9da4c4;font-size:12px;margin-top:28px">Simpan struk ini sebagai bukti transaksi.</p><div class="actions"><a href="?path=receipt&ref='.rawurlencode((string)$r['ref']).'&format=txt">Unduh TXT</a><button onclick="window.print()">Cetak / PDF</button></div></main></html>';exit;
}
function sendPush(PDO $pdo,array $cfg,int $userId,array $payload): int {
    $autoload=__DIR__.'/vendor/autoload.php'; $v=$cfg['push']??[];
    if(!is_file($autoload)||empty($v['public_key'])||empty($v['private_key'])) return 0;
    require_once $autoload; if(!class_exists(\Minishlink\WebPush\WebPush::class)) return 0;
    $q=$pdo->prepare('SELECT subscription_json FROM push_subscriptions WHERE user_id=?'); $q->execute([$userId]);
    $web=new \Minishlink\WebPush\WebPush(['VAPID'=>['subject'=>$v['subject'],'publicKey'=>$v['public_key'],'privateKey'=>$v['private_key']]]); $sent=0;
    foreach($q->fetchAll() as $r){$sub=json_decode($r['subscription_json'],true);if(!$sub)continue;$report=$web->sendOneNotification(\Minishlink\WebPush\Subscription::create($sub),json_encode($payload));if($report->isSuccess())$sent++;elseif($report->isSubscriptionExpired()){$pdo->prepare('DELETE FROM push_subscriptions WHERE subscription_json=?')->execute([$r['subscription_json']]);}}
    return $sent;
}
function notifyAll(PDO $pdo,array $cfg,string $title,string $body,string $url='/notifikasi'): int {
    $pdo->prepare('INSERT INTO notifications(user_id,title,body,target_url,is_broadcast) SELECT id,?,?,?,1 FROM users')->execute([$title,$body,$url]);
    $ids=$pdo->query('SELECT DISTINCT user_id FROM push_subscriptions')->fetchAll(PDO::FETCH_COLUMN); $sent=0;
    foreach($ids as $id) $sent+=sendPush($pdo,$cfg,(int)$id,['title'=>$title,'body'=>$body,'url'=>$url]);
    return $sent;
}
if($method!=='GET') sameOrigin();

if($path==='public-config' && $method==='GET') out(['ok'=>true,'firebase'=>['apiKey'=>$cfg['firebase']['api_key'],'authDomain'=>$cfg['firebase']['auth_domain'],'projectId'=>$cfg['firebase']['project_id']],'vapidPublicKey'=>$cfg['push']['public_key']]);

if(str_starts_with($path,'auth/')) {
    $action=substr($path,5);
    if($action==='me'&&$method==='GET'){ $u=user($cfg); out(['ok'=>true,'authenticated'=>(bool)$u,'user'=>$u]); }
    if($action==='logout'&&$method==='POST'){ $_SESSION=[]; session_regenerate_id(true); out(['ok'=>true]); }
    if($action==='register'&&$method==='POST'){
        $v=input();$name=trim((string)($v['name']??''));$username=strtolower(trim((string)($v['username']??'')));$email=strtolower(trim((string)($v['email']??'')));$pass=(string)($v['password']??'');
        if(!$name||!preg_match('/^[a-z0-9_]{3,24}$/',$username)||!filter_var($email,FILTER_VALIDATE_EMAIL)||strlen($pass)<10||empty($v['terms']))out(['ok'=>false,'message'=>'Periksa data dan password minimal 10 karakter.'],422);
        try{$p=db($cfg);$q=$p->prepare('INSERT INTO users(email,username,display_name,password_hash,terms_accepted_at) VALUES(?,?,?,?,NOW())');$q->execute([$email,$username,$name,password_hash($pass,PASSWORD_DEFAULT)]);$id=(int)$p->lastInsertId();telegramNotice($cfg,'Pengguna baru terdaftar',['ID Pengguna: #'.str_pad((string)$id,7,'0',STR_PAD_LEFT),'Status: Akun berhasil dibuat']);session_regenerate_id(true);$_SESSION['user_id']=$id;out(['ok'=>true,'user_code'=>'#'.str_pad((string)$id,7,'0',STR_PAD_LEFT)]);}catch(PDOException $e){if($e->getCode()==='23000')out(['ok'=>false,'message'=>'Email atau username sudah digunakan.'],409);throw $e;}
    }
    if($action==='google'&&$method==='POST'){$v=input();$token=(string)($v['idToken']??'');if(strlen($token)<100)out(['ok'=>false,'message'=>'Token Google tidak valid.'],422);$profile=firebaseLookup($cfg,$token);$email=strtolower((string)($profile['email']??''));$uid=(string)($profile['localId']??'');if(!$email||!filter_var($email,FILTER_VALIDATE_EMAIL)||!$uid)out(['ok'=>false,'message'=>'Profil Google tidak lengkap.'],422);$p=db($cfg);$q=$p->prepare('SELECT id FROM users WHERE firebase_uid=? OR email=? LIMIT 1');$q->execute([$uid,$email]);$found=$q->fetch();if($found){$id=(int)$found['id'];$p->prepare('UPDATE users SET firebase_uid=? WHERE id=?')->execute([$uid,$id]);}else{$username=makeUsername($p,$email);$name=trim((string)($profile['displayName']??$username));$p->prepare('INSERT INTO users(firebase_uid,email,username,display_name) VALUES(?,?,?,?)')->execute([$uid,$email,$username,$name]);$id=(int)$p->lastInsertId();telegramNotice($cfg,'Pengguna baru terdaftar',['ID Pengguna: #'.str_pad((string)$id,7,'0',STR_PAD_LEFT),'Metode: Google']);}session_regenerate_id(true);$_SESSION['user_id']=$id;out(['ok'=>true,'user_code'=>'#'.str_pad((string)$id,7,'0',STR_PAD_LEFT)]);}
    if($action==='login'&&$method==='POST'){$v=input();$identity=strtolower(trim((string)($v['identity']??'')));$pass=(string)($v['password']??'');$q=db($cfg)->prepare('SELECT id,password_hash FROM users WHERE email=? OR username=? LIMIT 1');$q->execute([$identity,$identity]);$u=$q->fetch();if(!$u||!$u['password_hash']||!password_verify($pass,$u['password_hash']))out(['ok'=>false,'message'=>'Email/username atau password tidak cocok.'],401);session_regenerate_id(true);$_SESSION['user_id']=(int)$u['id'];out(['ok'=>true]);}
    out(['ok'=>false,'message'=>'Rute autentikasi tidak ditemukan.'],404);
}

if(str_starts_with($path,'push/')){
    $u=needUser($cfg);$action=substr($path,5);$v=input();
    if($action==='subscribe'&&$method==='POST'){$s=$v['subscription']??null;if(!is_array($s)||empty($s['endpoint'])||empty($s['keys']['p256dh'])||empty($s['keys']['auth']))out(['ok'=>false,'message'=>'Data perangkat tidak valid.'],422);$p=db($cfg);$p->prepare('INSERT INTO push_subscriptions(user_id,endpoint,subscription_json) VALUES(?,?,?) ON DUPLICATE KEY UPDATE user_id=VALUES(user_id),subscription_json=VALUES(subscription_json)')->execute([$u['id'],$s['endpoint'],json_encode($s)]);out(['ok'=>true]);}
    if($action==='test'&&$method==='POST'){$n=sendPush(db($cfg),$cfg,(int)$u['id'],['title'=>'DooNokoz','body'=>'Notifikasi berhasil diaktifkan.','url'=>'/notifikasi']);out(['ok'=>true,'sent'=>$n,'message'=>$n?'Notifikasi tes dikirim.':'Konfigurasi Web Push belum lengkap.']);}
    out(['ok'=>false,'message'=>'Endpoint push tidak ditemukan.'],404);
}

if($path==='wallet/summary'&&$method==='GET'){$u=needUser($cfg);$q=db($cfg)->prepare("SELECT COUNT(*) total, COALESCE(SUM(CASE WHEN type='topup' AND status='success' THEN nominal ELSE 0 END),0) total_topup FROM transactions WHERE user_id=?");$q->execute([$u['id']]);out(['ok'=>true,'balance'=>(int)$u['balance'],'stats'=>$q->fetch()]);}
if($path==='wallet/requests'&&$method==='GET'){$u=needUser($cfg);$q=db($cfg)->prepare('SELECT request_code,amount,status,note,created_at,reviewed_at FROM topup_requests WHERE user_id=? ORDER BY id DESC LIMIT 30');$q->execute([$u['id']]);out(['ok'=>true,'items'=>$q->fetchAll()]);}
if($path==='wallet/history'&&$method==='GET'){$u=needUser($cfg);$q=db($cfg)->prepare('SELECT trx_id,type,nominal,admin_fee,total,status,payment_method,created_at FROM transactions WHERE user_id=? ORDER BY id DESC LIMIT 50');$q->execute([$u['id']]);out(['ok'=>true,'items'=>$q->fetchAll()]);}
if($path==='wallet/request'&&$method==='POST'){$u=needUser($cfg);$v=input();$amount=(int)($v['amount']??0);$min=(int)$cfg['fees']['min_topup'];$max=(int)$cfg['fees']['max_topup'];if($amount<$min||$amount>$max)out(['ok'=>false,'message'=>'Nominal deposit di luar batas yang diizinkan.'],422);$ref='DP'.date('ymd').strtoupper(bin2hex(random_bytes(4)));$q=db($cfg)->prepare("INSERT INTO topup_requests(user_id,request_code,amount,status,note) VALUES(?,?,?,'pending',?)");$q->execute([$u['id'],$ref,$amount,trim((string)($v['note']??''))]);telegramNotice($cfg,'Permintaan deposit baru',['Referensi: '.$ref,'User ID: #'.str_pad((string)$u['id'],7,'0',STR_PAD_LEFT),'Nominal: Rp'.number_format($amount,0,',','.'),'Status: PENDING']);out(['ok'=>true,'request_code'=>$ref,'message'=>'Permintaan deposit tercatat dan menunggu pemeriksaan admin. Saldo belum bertambah.']);}


if($path==='receipt'&&$method==='GET'){$u=needUser($cfg);$ref=trim((string)($_GET['ref']??''));if($ref==='')out(['ok'=>false,'message'=>'Referensi struk wajib diisi.'],422);$p=db($cfg);$q=$p->prepare('SELECT t.trx_id ref,t.status,t.nominal amount,t.admin_fee fee,t.total,t.created_at,t.type,u.username,u.id FROM transactions t JOIN users u ON u.id=t.user_id WHERE t.trx_id=? AND t.user_id=? LIMIT 1');$q->execute([$ref,$u['id']]);$r=$q->fetch();if(!$r){$q=$p->prepare('SELECT t.request_code ref,t.status,t.amount,0 fee,t.amount total,t.created_at,u.username,u.id FROM topup_requests t JOIN users u ON u.id=t.user_id WHERE t.request_code=? AND t.user_id=? LIMIT 1');$q->execute([$ref,$u['id']]);$r=$q->fetch();}if(!$r)out(['ok'=>false,'message'=>'Struk tidak ditemukan.'],404);$r['user_code']='#'.str_pad((string)$r['id'],7,'0',STR_PAD_LEFT);$r['product']=($r['type']??'topup')==='topup'?'Top Up Saldo':'Transaksi';receiptPage($r,(string)($_GET['format']??'html'));}

if($path==='notifications'&&$method==='GET'){$u=needUser($cfg);$q=db($cfg)->prepare('SELECT id,title,body,target_url,is_read,created_at FROM notifications WHERE user_id=? ORDER BY id DESC LIMIT 60');$q->execute([$u['id']]);out(['ok'=>true,'items'=>$q->fetchAll()]);}
if($path==='notifications/read'&&$method==='POST'){$u=needUser($cfg);$id=(int)(input()['id']??0);$q=db($cfg)->prepare('UPDATE notifications SET is_read=1 WHERE id=? AND user_id=?');$q->execute([$id,$u['id']]);out(['ok'=>true]);}

if(str_starts_with($path,'admin/')){
    needAdmin($cfg);$p=db($cfg);$action=substr($path,6);
    if($action==='overview'&&$method==='GET'){$stats=$p->query("SELECT (SELECT COUNT(*) FROM users) users,(SELECT COUNT(*) FROM topup_requests WHERE status='pending') pending_topups,(SELECT COUNT(*) FROM transactions) transactions")->fetch();out(['ok'=>true,'stats'=>$stats]);}
    if($action==='topups'&&$method==='GET'){$q=$p->query("SELECT t.id,t.request_code,t.amount,t.status,t.note,t.created_at,u.username,u.email FROM topup_requests t JOIN users u ON u.id=t.user_id ORDER BY t.id DESC LIMIT 100");out(['ok'=>true,'items'=>$q->fetchAll()]);}
    if($action==='topup-decision'&&$method==='POST'){$v=input();$id=(int)($v['id']??0);$decision=(string)($v['decision']??'');if(!$id||!in_array($decision,['approve','reject'],true))out(['ok'=>false,'message'=>'Keputusan tidak valid.'],422);$p->beginTransaction();try{$q=$p->prepare('SELECT * FROM topup_requests WHERE id=? FOR UPDATE');$q->execute([$id]);$r=$q->fetch();if(!$r||$r['status']!=='pending')throw new RuntimeException('Permintaan tidak tersedia atau sudah diproses.');if($decision==='approve'){$p->prepare('UPDATE users SET balance=balance+? WHERE id=?')->execute([(int)$r['amount'],(int)$r['user_id']]);$trx='TRX'.date('ymdHis').strtoupper(bin2hex(random_bytes(3)));$p->prepare("INSERT INTO transactions(trx_id,user_id,type,nominal,admin_fee,total,status,payment_method,metadata) VALUES(?,?,'topup',?,0,?,'success','manual_review',?)")->execute([$trx,$r['user_id'],$r['amount'],$r['amount'],json_encode(['request_code'=>$r['request_code']])]);$status='approved';}else{$status='rejected';}$p->prepare('UPDATE topup_requests SET status=?,reviewed_at=NOW(),reviewed_by=? WHERE id=?')->execute([$status,$_SESSION['user_id'],$id]);$p->commit();$msg=$status==='approved'?'Deposit disetujui dan saldo akun telah diperbarui.':'Permintaan deposit ditolak.';$p->prepare('INSERT INTO notifications(user_id,title,body,target_url) VALUES(?,?,?,?)')->execute([$r['user_id'],'Status deposit diperbarui',$msg,'/saldo']);sendPush($p,$cfg,(int)$r['user_id'],['title'=>'Status deposit diperbarui','body'=>$msg,'url'=>'/saldo']);telegramNotice($cfg,'Status deposit diperbarui',['Referensi: '.$r['request_code'],'User ID: #'.str_pad((string)$r['user_id'],7,'0',STR_PAD_LEFT),'Nominal: Rp'.number_format((int)$r['amount'],0,',','.'),'Status: '.strtoupper($status)]);out(['ok'=>true,'status'=>$status]);}catch(Throwable $e){$p->rollBack();out(['ok'=>false,'message'=>$e instanceof RuntimeException?$e->getMessage():'Gagal memproses deposit.'],409);}}
    if($action==='broadcast'&&$method==='POST'){$v=input();$title=trim((string)($v['title']??''));$body=trim((string)($v['body']??''));if($title===''||$body===''||mb_strlen($title)>100||mb_strlen($body)>1000)out(['ok'=>false,'message'=>'Judul dan isi wajib diisi (maksimal 100/1000 karakter).'],422);$sent=notifyAll($p,$cfg,$title,$body);out(['ok'=>true,'push_sent'=>$sent,'message'=>'Pengumuman tersimpan ke inbox pengguna.']);}
    out(['ok'=>false,'message'=>'Endpoint admin tidak ditemukan.'],404);
}

// Public catalog/order endpoints intentionally remain disabled; no virtual-number or OTP ordering is provided.
if(in_array($path,['countries','services','prices'],true))out(['ok'=>false,'message'=>'Katalog pemesanan sedang dinonaktifkan.'],503);
out(['ok'=>false,'message'=>'Endpoint tidak ditemukan.'],404);
