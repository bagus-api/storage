CREATE DATABASE IF NOT EXISTS doonokoz CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE doonokoz;
CREATE TABLE IF NOT EXISTS users (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 firebase_uid VARCHAR(128) UNIQUE NULL,
 email VARCHAR(190) UNIQUE NOT NULL,
 username VARCHAR(60) UNIQUE NOT NULL,
 display_name VARCHAR(120) NOT NULL,
 password_hash VARCHAR(255) NULL,
 balance BIGINT NOT NULL DEFAULT 0,
 role ENUM('user','admin') NOT NULL DEFAULT 'user',
 terms_accepted_at DATETIME NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS transactions (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 trx_id VARCHAR(64) UNIQUE NOT NULL,
 user_id BIGINT UNSIGNED NOT NULL,
 type ENUM('topup','purchase','refund') NOT NULL,
 nominal BIGINT NOT NULL,
 admin_fee BIGINT NOT NULL DEFAULT 0,
 total BIGINT NOT NULL,
 status VARCHAR(30) NOT NULL,
 payment_method VARCHAR(30) NULL,
 metadata JSON NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 INDEX idx_transactions_user_created(user_id,created_at),
 FOREIGN KEY(user_id) REFERENCES users(id)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS settings (
 setting_key VARCHAR(100) PRIMARY KEY,
 setting_value TEXT NOT NULL,
 updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;
INSERT IGNORE INTO settings(setting_key,setting_value) VALUES
 ('topup_admin_fee','500'),
 ('product_markup','500'),
 ('min_topup','5000'),
 ('max_topup','100000'),
 ('provider_enabled','true'),
 ('maintenance_mode','false');

CREATE TABLE IF NOT EXISTS push_subscriptions (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 user_id BIGINT UNSIGNED NOT NULL,
 endpoint TEXT NOT NULL,
 subscription_json LONGTEXT NOT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 UNIQUE KEY uq_push_endpoint (endpoint(190)),
 INDEX idx_push_user(user_id),
 CONSTRAINT fk_push_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Owner broadcast inbox and manually reviewed deposit requests.
CREATE TABLE IF NOT EXISTS notifications (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 user_id BIGINT UNSIGNED NOT NULL,
 title VARCHAR(100) NOT NULL,
 body VARCHAR(1000) NOT NULL,
 target_url VARCHAR(255) NOT NULL DEFAULT '/notifikasi',
 is_broadcast TINYINT(1) NOT NULL DEFAULT 0,
 is_read TINYINT(1) NOT NULL DEFAULT 0,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 INDEX idx_notifications_user_created(user_id,created_at),
 CONSTRAINT fk_notifications_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS topup_requests (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 user_id BIGINT UNSIGNED NOT NULL,
 request_code VARCHAR(40) NOT NULL UNIQUE,
 amount BIGINT UNSIGNED NOT NULL,
 status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
 note VARCHAR(255) NULL,
 reviewed_by BIGINT UNSIGNED NULL,
 reviewed_at DATETIME NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 INDEX idx_topup_user_created(user_id,created_at),
 INDEX idx_topup_status_created(status,created_at),
 CONSTRAINT fk_topup_request_user FOREIGN KEY(user_id) REFERENCES users(id),
 CONSTRAINT fk_topup_request_admin FOREIGN KEY(reviewed_by) REFERENCES users(id)
) ENGINE=InnoDB;
