import React, { createContext, useContext, useState, useEffect, useRef } from 'react';
import { toHDCover, toWebp, cn, getTrackColors, FI, getOfflineSongs } from '../utils/helpers';
import { extractClientSide } from '../utils/clientExtractor';

const PlayerContext = createContext();

export function PlayerProvider({ children }) {
    const audioRef = useRef(null);
    const audioCtxRef = useRef(null);
    const sourceNodeRef = useRef(null);
    const eqNodesRef = useRef({ bass: null, mid: null, treble: null });
    const gainNodeRef = useRef(null);
    const compressorNodeRef = useRef(null);

    const [currentTrack, setCurrentTrack] = useState(null);
    const [isPlaying, setIsPlaying] = useState(false);
    const [isLoading, setIsLoading] = useState(false);
    const [playlist, setPlaylist] = useState([]);
    const [playlistIndex, setPlaylistIndex] = useState(-1);
    const [playlistSource, setPlaylistSource] = useState('home');
    const [currentTime, setCurrentTime] = useState(0);
    const [duration, setDuration] = useState(0);
    const [repeatMode, setRepeatMode] = useState('all'); // 'all', 'one', 'off'
    const [isShuffle, setIsShuffle] = useState(false);
    const [autoNext, setAutoNext] = useState(true);
    const [playbackRate, setPlaybackRate] = useState(1.0);
    const [volume, setVolume] = useState(() => {
        try {
            const saved = localStorage.getItem('nanz_volume');
            return saved !== null ? parseFloat(saved) : 1.0;
        } catch {
            return 1.0;
        }
    });
    const [preampBoost, setPreampBoost] = useState(() => {
        try {
            const saved = localStorage.getItem('nanz_preamp_boost');
            return saved !== null ? parseFloat(saved) : 1.8; // default 1.8x loudness boost
        } catch {
            return 1.8;
        }
    });
    const [lastVolume, setLastVolume] = useState(1.0);
    const [lyrics, setLyrics] = useState({ type: 'none', lines: [] });
    const [currentLyricIndex, setCurrentLyricIndex] = useState(-1);
    const [lyricOffset, setLyricOffset] = useState(0);
    const [accentColors, setAccentColors] = useState(['#ff2a5f', '#7c3aed', '#2563eb']);
    const [bgGlowEnabled, setBgGlowEnabled] = useState(true);

    // Navigation & Views
    const [activeTab, setActiveTab] = useState(() => {
        if (typeof window !== 'undefined') {
            const p = window.location.pathname;
            if (p === '/' || p === '') return 'landing';
            if (p.startsWith('/id')) return 'home';
        }
        return 'landing';
    });
    const [searchQuery, setSearchQuery] = useState('');
    const [isFullPlayerOpen, setIsFullPlayerOpen] = useState(false);
    const [fullPlayerView, setFullPlayerView] = useState('cover'); // 'cover' or 'lyrics'
    const [isLyricsOverlayOpen, setIsLyricsOverlayOpen] = useState(false);

    // Developer Profile configuration
    const [devProfile, setDevProfile] = useState({
        developer: {
            name: 'Nanzz',
            role: 'Fullstack Developer & Audio Enthusiast',
            tagline: 'Streaming Musik YouTube dengan Lirik',
            bio: 'Pengembang & Pembuat NanzMusify. Selamat menikmati streaming musik favorit tanpa gangguan!',
            avatar: '/logo.webp',
            channelUrl: 'https://whatsapp.com/channel/0029VbCsS2r2phHIV3O0nO1a',
            channelLabel: 'Gabung Channel WhatsApp',
            appVersion: 'v2.0.0 (React Vite)'
        },
        favorites: {
            artistName: 'XXXTENTACION',
            artistSearchQuery: 'XXXTENTACION',
            likedSongsLabel: 'Semua lagu XXXTENTACION',
            likedPlaylistsLabel: 'Semua album & playlist XXXTENTACION',
            songs: [],
            playlists: []
        }
    });

    // Theme state: 'dark' (default) or 'light'
    const [theme, setTheme] = useState(() => {
        try {
            return localStorage.getItem('nanz_theme') || 'dark';
        } catch (e) {
            return 'dark';
        }
    });

    useEffect(() => {
        try {
            localStorage.setItem('nanz_theme', theme);
        } catch (e) {}
        document.documentElement.setAttribute('data-theme', theme);
        if (theme === 'dark') {
            document.documentElement.classList.add('dark');
            document.documentElement.classList.remove('light');
        } else {
            document.documentElement.classList.add('light');
            document.documentElement.classList.remove('dark');
        }
    }, [theme]);

    const toggleTheme = () => {
        setTheme(prev => (prev === 'dark' ? 'light' : 'dark'));
    };

    // Load profile.json configuration dynamically
    useEffect(() => {
        fetch('/profile.json?t=' + Date.now())
            .then(res => res.json())
            .then(data => {
                if (data && (data.developer || data.favorites)) {
                    setDevProfile(prev => ({
                        ...prev,
                        ...data,
                        developer: { ...prev.developer, ...(data.developer || {}) },
                        favorites: { ...prev.favorites, ...(data.favorites || {}) }
                    }));
                }
            })
            .catch(err => {
                console.warn('Could not load profile.json:', err);
            });
    }, []);

    // Switch tab with URL history pushState support
    const switchTab = (tabId, pushHistory = true, customQuery = null) => {
        setActiveTab(tabId);
        setIsFullPlayerOpen(false);
        setActiveAlbum(null);
        setActiveArtist(null);

        if (customQuery !== null) {
            setSearchQuery(customQuery);
        }

        if (pushHistory && typeof window !== 'undefined') {
            let targetPath = '/id/';
            if (tabId === 'landing') targetPath = '/';
            else if (tabId === 'home') targetPath = '/id/';
            else if (tabId === 'search') {
                const q = customQuery !== null ? customQuery : searchQuery;
                targetPath = q && q.trim() ? `/search/${encodeURIComponent(q.trim().replace(/\s+/g, '_'))}/` : '/search/';
            }
            else if (tabId === 'library') targetPath = '/library/';
            else if (tabId === 'offline') targetPath = '/offline/';
            else if (tabId === 'liked') targetPath = '/liked/';
            else if (tabId === 'dev') targetPath = '/profile/';

            if (window.location.pathname !== targetPath) {
                window.history.pushState({ tab: tabId, query: customQuery || searchQuery }, '', targetPath);
            }
        }
    };

    // Modals
    const [activeArtist, setActiveArtist] = useState(null); // { id, name, cover }
    const [activeAlbum, setActiveAlbum] = useState(null);   // { id, cover }
    const [isEqualizerOpen, setIsEqualizerOpen] = useState(false);
    const [isSleepTimerOpen, setIsSleepTimerOpen] = useState(false);
    const [isSpeedOpen, setIsSpeedOpen] = useState(false);
    const [isQueueOpen, setIsQueueOpen] = useState(false);
    const [isAddToPlaylistOpen, setIsAddToPlaylistOpen] = useState(false);
    const [isShareCardOpen, setIsShareCardOpen] = useState(false);
    const [isCreatePlaylistOpen, setIsCreatePlaylistOpen] = useState(false);
    const [toastMessage, setToastMessage] = useState('');

    // EQ Preset State
    const [eqValues, setEqValues] = useState({ bass: 0, mid: 0, treble: 0, preset: 'Normal' });

    // Sleep Timer
    const [sleepSecondsLeft, setSleepSecondsLeft] = useState(0);
    const sleepIntervalRef = useRef(null);

    // Toast helper
    const showToast = (msg) => {
        setToastMessage(msg);
        setTimeout(() => {
            setToastMessage((prev) => (prev === msg ? '' : prev));
        }, 3200);
    };

    // Load saved settings
    useEffect(() => {
        try {
            const savedRate = parseFloat(localStorage.getItem('nanzz_playback_rate'));
            if (savedRate) setPlaybackRate(savedRate);
            const savedAuto = localStorage.getItem('nanzz_auto_next');
            if (savedAuto !== null) setAutoNext(savedAuto === 'true');
            const savedGlow = localStorage.getItem('nanz_bg_glow_enabled');
            if (savedGlow !== null) setBgGlowEnabled(savedGlow === '1');
        } catch(e){}
    }, []);

    // Init Audio Context, Equalizer, Preamp Gain & Compressor
    const initAudioContext = () => {
        if (audioCtxRef.current) return;
        try {
            const AudioContext = window.AudioContext || window.webkitAudioContext;
            if (!AudioContext || !audioRef.current) return;
            const ctx = new AudioContext();
            audioCtxRef.current = ctx;

            // 1. Equalizer Filter Nodes
            const bass = ctx.createBiquadFilter();
            bass.type = 'lowshelf';
            bass.frequency.value = 150;
            bass.gain.value = eqValues.bass;

            const mid = ctx.createBiquadFilter();
            mid.type = 'peaking';
            mid.frequency.value = 1000;
            mid.gain.value = eqValues.mid;

            const treble = ctx.createBiquadFilter();
            treble.type = 'highshelf';
            treble.frequency.value = 3500;
            treble.gain.value = eqValues.treble;

            // 2. Master Gain Node (Preamp Volume Booster: default 1.8x boost)
            const masterGain = ctx.createGain();
            const initialGain = Math.max(0, volume * (preampBoost || 1.8));
            masterGain.gain.setValueAtTime(initialGain, ctx.currentTime);

            // 3. Dynamics Compressor (Peak Limiter & Loudness Maximizer)
            // Prevents any clipping/distortion when volume or bass is boosted high!
            const compressor = ctx.createDynamicsCompressor();
            compressor.threshold.setValueAtTime(-12, ctx.currentTime);
            compressor.knee.setValueAtTime(12, ctx.currentTime);
            compressor.ratio.setValueAtTime(4, ctx.currentTime);
            compressor.attack.setValueAtTime(0.003, ctx.currentTime);
            compressor.release.setValueAtTime(0.25, ctx.currentTime);

            // 4. Connect Audio Pipeline:
            // source -> bass -> mid -> treble -> masterGain -> compressor -> ctx.destination
            const source = ctx.createMediaElementSource(audioRef.current);
            source.connect(bass);
            bass.connect(mid);
            mid.connect(treble);
            treble.connect(masterGain);
            masterGain.connect(compressor);
            compressor.connect(ctx.destination);

            sourceNodeRef.current = source;
            eqNodesRef.current = { bass, mid, treble };
            gainNodeRef.current = masterGain;
            compressorNodeRef.current = compressor;

            if (ctx.state === 'suspended') {
                ctx.resume().catch(() => {});
            }
        } catch (e) {
            console.warn('Web Audio initialization failed:', e);
        }
    };

    // Set Preamp Boost level (1.0x to 2.5x)
    const setPreampBoostLevel = (boostFactor) => {
        const factor = Math.max(1.0, Math.min(3.0, boostFactor));
        setPreampBoost(factor);
        try {
            localStorage.setItem('nanz_preamp_boost', String(factor));
        } catch {}

        if (gainNodeRef.current && audioCtxRef.current) {
            const targetGain = Math.max(0, volume * factor);
            try {
                gainNodeRef.current.gain.setTargetAtTime(targetGain, audioCtxRef.current.currentTime, 0.05);
            } catch {
                gainNodeRef.current.gain.value = targetGain;
            }
        }
    };

    // Apply EQ values to nodes
    const applyEqualizer = (bass, mid, treble, preset = 'Custom') => {
        setEqValues({ bass, mid, treble, preset });
        if (eqNodesRef.current.bass) eqNodesRef.current.bass.gain.value = bass;
        if (eqNodesRef.current.mid) eqNodesRef.current.mid.gain.value = mid;
        if (eqNodesRef.current.treble) eqNodesRef.current.treble.gain.value = treble;
    };

    // Equalizer presets
    const setEqPreset = (name) => {
        switch(name) {
            case 'Bass Boost': applyEqualizer(6, 1, -1, 'Bass Boost'); break;
            case 'Treble': applyEqualizer(-1, 0, 6, 'Treble'); break;
            case 'Vocal': applyEqualizer(-2, 5, 2, 'Vocal'); break;
            case 'Electronic': applyEqualizer(5, 1, 4, 'Electronic'); break;
            case 'Rock': applyEqualizer(4, 2, 4, 'Rock'); break;
            case 'Pop': applyEqualizer(2, 3, 2, 'Pop'); break;
            default: applyEqualizer(0, 0, 0, 'Normal'); break;
        }
    };

    // Set Sleep Timer
    const setSleepTimer = (minutes) => {
        if (sleepIntervalRef.current) clearInterval(sleepIntervalRef.current);
        if (minutes <= 0) {
            setSleepSecondsLeft(0);
            showToast('Sleep Timer dimatikan');
            return;
        }
        const totalSec = minutes * 60;
        setSleepSecondsLeft(totalSec);
        showToast(`Sleep Timer disetel untuk ${minutes} menit`);

        sleepIntervalRef.current = setInterval(() => {
            setSleepSecondsLeft(prev => {
                if (prev <= 1) {
                    clearInterval(sleepIntervalRef.current);
                    if (audioRef.current) audioRef.current.pause();
                    setIsPlaying(false);
                    showToast('Waktu habis! Pemutaran musik dihentikan.');
                    return 0;
                }
                return prev - 1;
            });
        }, 1000);
    };

    // Playback Rate
    const changePlaybackRate = (rate) => {
        setPlaybackRate(rate);
        if (audioRef.current) audioRef.current.playbackRate = rate;
        try { localStorage.setItem('nanzz_playback_rate', String(rate)); } catch(e){}
        showToast(`Kecepatan putar: ${rate}x`);
    };

    // Toggle Background Glow
    const toggleBgGlow = () => {
        const next = !bgGlowEnabled;
        setBgGlowEnabled(next);
        try { localStorage.setItem('nanz_bg_glow_enabled', next ? '1' : '0'); } catch(e){}
    };

    // Fetch and Load Track
    const loadTrack = async (track) => {
        if (!track) return;
        const vid = track.videoId || track.id;
        if (!vid) return;

        setIsLoading(true);
        setCurrentTime(0);
        setDuration(0);
        setCurrentLyricIndex(-1);

        // Compute accent colors
        const colors = getTrackColors(track);
        setAccentColors(colors);
        document.documentElement.style.setProperty('--glow-c1', colors[0]);
        document.documentElement.style.setProperty('--glow-c2', colors[1]);
        document.documentElement.style.setProperty('--glow-c3', colors[2]);

        // Fetch stream URL
        try {
            const ytUrl = track.ytUrl || `https://youtube.com/watch?v=${vid}`;
            let audioStreamUrl = '';
            let audioTitle = null;
            let audioThumbnail = null;

            // 1. First attempt: server endpoint /api/ytplay with 5s timeout
            try {
                const controller = new AbortController();
                const timeoutId = setTimeout(() => controller.abort(), 5000);
                const res = await fetch('/api/ytplay', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ query: ytUrl }),
                    signal: controller.signal
                });
                clearTimeout(timeoutId);
                const data = await res.json().catch(() => ({}));
                if (data && data.status && data.result?.download?.audio) {
                    audioStreamUrl = data.result.download.audio;
                    audioTitle = data.result.title;
                    audioThumbnail = data.result.thumbnail;
                } else if (data && data.url) {
                    audioStreamUrl = data.url;
                }
            } catch (serverErr) {
                console.warn('[Player] Server /api/ytplay error or timeout:', serverErr.message);
            }

            // 2. Client-side extraction fallback (CRITICAL for Netlify serverless Lambda 503)
            if (!audioStreamUrl) {
                console.log('[Player] Falling back to browser-side media extraction for:', vid);
                try {
                    const clientResult = await extractClientSide(vid, ytUrl);
                    if (clientResult && clientResult.audioUrl) {
                        audioStreamUrl = clientResult.audioUrl;
                        audioTitle = clientResult.title;
                        audioThumbnail = clientResult.thumbnail;
                        console.log('[Player] Browser-side extraction succeeded:', clientResult.title);
                    }
                } catch (clientErr) {
                    console.error('[Player] Browser-side extraction failed:', clientErr);
                }
            }

            // Update title and cover dynamically if placeholder was used
            let finalTitle = track.title;
            if (audioTitle) {
                finalTitle = audioTitle;
                setCurrentTrack(prev => {
                    if (!prev) return prev;
                    const isPlaceholder = !prev.title || prev.title === 'Memuat...' || prev.title === 'Lagu';
                    return {
                        ...prev,
                        title: isPlaceholder ? audioTitle : prev.title,
                        cover: prev.cover || audioThumbnail || toHDCover('', vid)
                    };
                });
            }

            if (audioStreamUrl && audioRef.current) {
                // If it's a direct CDN stream (vidssave / aliyuncs / OSS), play directly without crossorigin
                // to prevent browser CORS blocks on cross-origin redirects.
                const isDirectCdn = audioStreamUrl.includes('vidssave.com') || audioStreamUrl.includes('aliyuncs.com');
                const playUrl = isDirectCdn ? audioStreamUrl : `/api/proxy-audio?url=${encodeURIComponent(audioStreamUrl)}`;

                let hasFallenBack = false;
                audioRef.current.onerror = () => {
                    if (!hasFallenBack && audioStreamUrl) {
                        hasFallenBack = true;
                        console.warn('[Player] PlayUrl error, attempting direct stream playback fallback...');
                        try {
                            audioRef.current.removeAttribute('crossorigin');
                        } catch (e) {}
                        audioRef.current.src = audioStreamUrl;
                        audioRef.current.play().then(() => {
                            setIsPlaying(true);
                            setIsLoading(false);
                        }).catch(() => {
                            setIsLoading(false);
                        });
                    } else {
                        setIsLoading(false);
                    }
                };

                try {
                    if (isDirectCdn) {
                        audioRef.current.removeAttribute('crossorigin');
                    } else {
                        audioRef.current.setAttribute('crossorigin', 'anonymous');
                        initAudioContext();
                        if (audioCtxRef.current && audioCtxRef.current.state === 'suspended') {
                            audioCtxRef.current.resume().catch(() => {});
                        }
                    }
                } catch(e) {}

                audioRef.current.src = playUrl;
                audioRef.current.playbackRate = playbackRate;
                audioRef.current.volume = Math.min(1.0, volume);
                audioRef.current.play().then(() => {
                    setIsPlaying(true);
                    setIsLoading(false);
                }).catch(err => {
                    // Autoplay was blocked by browser policy (e.g. direct link navigation)
                    console.warn('Autoplay waiting for user interaction:', err.message);
                    setIsLoading(false);
                    setIsPlaying(false);

                    // Allow first touch/click anywhere on page to trigger playback
                    const onFirstUserGesture = () => {
                        if (audioRef.current && audioRef.current.paused) {
                            if (audioCtxRef.current && audioCtxRef.current.state === 'suspended') {
                                audioCtxRef.current.resume();
                            }
                            audioRef.current.play().then(() => setIsPlaying(true)).catch(() => {});
                        }
                    };
                    window.addEventListener('click', onFirstUserGesture, { once: true });
                    window.addEventListener('touchstart', onFirstUserGesture, { once: true });
                });
            } else {
                showToast('Gagal memuat audio stream');
                setIsLoading(false);
            }
        } catch (e) {
            console.error('Error loading audio:', e);
            showToast('Koneksi bermasalah saat memutar');
            setIsLoading(false);
        }

        // Fetch Lyrics
        fetchLyrics(vid, track.title, track.artist);

        // Update Media Session
        if ('mediaSession' in navigator) {
            const cover = toHDCover(track.cover, vid);
            navigator.mediaSession.metadata = new MediaMetadata({
                title: track.title || 'NanzMusify',
                artist: track.artist || '',
                album: 'NanzMusify',
                artwork: [
                    { src: cover, sizes: '96x96', type: 'image/webp' },
                    { src: cover, sizes: '256x256', type: 'image/webp' },
                    { src: cover, sizes: '512x512', type: 'image/webp' }
                ]
            });
        }
    };

    // Fetch Lyrics
    const fetchLyrics = async (vid, title, artist) => {
        setLyrics({ type: 'loading', lines: [] });
        try {
            const tParam = title ? `&title=${encodeURIComponent(title)}` : '';
            const aParam = artist ? `&artist=${encodeURIComponent(artist)}` : '';
            const res = await fetch(`/api/lyrics?id=${vid}${tParam}${aParam}`);
            const data = await res.json();
            if (data.status && data.result && data.result.lyrics) {
                setLyrics(data.result.lyrics);
            } else {
                setLyrics({ type: 'none', lines: [] });
            }
        } catch(e) {
            setLyrics({ type: 'none', lines: [] });
        }
    };

    // Play a Track directly or from a list
    const playTrack = (track, list = null, index = -1, source = 'direct') => {
        setIsLoading(true);
        setCurrentTrack(track);
        if (list && list.length > 0) {
            setPlaylist(list);
            setPlaylistIndex(index !== -1 ? index : list.findIndex(s => (s.videoId === (track.videoId || track.id) || s.id === (track.videoId || track.id))));
            setPlaylistSource(source);
        } else {
            setPlaylist([track]);
            setPlaylistIndex(0);
            setPlaylistSource(source);
        }
        loadTrack(track);
    };

    // Toggle Play / Pause
    const togglePlay = () => {
        if (!currentTrack) {
            showToast('Pilih lagu terlebih dahulu');
            return;
        }
        if (!audioRef.current) return;
        if (audioRef.current.paused) {
            if (audioCtxRef.current && audioCtxRef.current.state === 'suspended') {
                audioCtxRef.current.resume();
            }
            audioRef.current.play().then(() => setIsPlaying(true)).catch(() => {});
        } else {
            audioRef.current.pause();
            setIsPlaying(false);
        }
    };

    // Next Track
    const nextTrack = () => {
        if (!playlist || playlist.length === 0) return;
        let nextIdx;
        if (isShuffle) {
            nextIdx = Math.floor(Math.random() * playlist.length);
        } else {
            nextIdx = playlistIndex + 1;
            if (nextIdx >= playlist.length) {
                if (repeatMode === 'all') nextIdx = 0;
                else return;
            }
        }
        const nextTrackObj = playlist[nextIdx];
        if (nextTrackObj) {
            setPlaylistIndex(nextIdx);
            setCurrentTrack(nextTrackObj);
            loadTrack(nextTrackObj);
        }
    };

    // Previous Track
    const prevTrack = (forcePrev = false) => {
        if (audioRef.current && audioRef.current.currentTime > 3 && !forcePrev) {
            audioRef.current.currentTime = 0;
            return;
        }
        if (!playlist || playlist.length === 0) return;
        let prevIdx = playlistIndex - 1;
        if (prevIdx < 0) {
            prevIdx = playlist.length - 1;
        }
        const prevTrackObj = playlist[prevIdx];
        if (prevTrackObj) {
            setPlaylistIndex(prevIdx);
            setCurrentTrack(prevTrackObj);
            loadTrack(prevTrackObj);
        }
    };

    // Seek
    const seek = (time) => {
        if (audioRef.current && isFinite(time)) {
            audioRef.current.currentTime = time;
            setCurrentTime(time);
        }
    };

    // Volume (Supports up to 150% with preamp gain boost)
    const setVolumeLevel = (val) => {
        const v = Math.max(0, Math.min(1.5, val / 100));
        setVolume(v);
        if (v > 0) setLastVolume(v);

        if (audioRef.current) {
            audioRef.current.volume = Math.min(1.0, v);
        }

        if (gainNodeRef.current && audioCtxRef.current) {
            const targetGain = Math.max(0, v * (preampBoost || 1.8));
            try {
                gainNodeRef.current.gain.setTargetAtTime(targetGain, audioCtxRef.current.currentTime, 0.05);
            } catch {
                gainNodeRef.current.gain.value = targetGain;
            }
        }

        try {
            localStorage.setItem('nanz_volume', String(v));
        } catch {}
    };

    const toggleMute = () => {
        if (volume > 0) {
            setLastVolume(volume);
            setVolumeLevel(0);
        } else {
            setVolumeLevel((lastVolume || 1) * 100);
        }
    };

    // Repeat mode toggle: all -> one -> off -> all
    const toggleRepeat = () => {
        if (repeatMode === 'all') setRepeatMode('one');
        else if (repeatMode === 'one') setRepeatMode('off');
        else setRepeatMode('all');
    };

    // Shuffle toggle
    const toggleShuffle = () => {
        setIsShuffle(prev => !prev);
    };

    // Lyric sync offset
    const lyricSyncPrev = () => setLyricOffset(prev => prev - 0.5);
    const lyricSyncNext = () => setLyricOffset(prev => prev + 0.5);

    // Audio element event listeners
    useEffect(() => {
        const au = audioRef.current;
        if (!au) return;

        const handleTimeUpdate = () => {
            const cur = au.currentTime || 0;
            const dur = au.duration || 0;
            setCurrentTime(cur);
            setDuration(dur);

            // Sync lyrics
            if (lyrics && lyrics.lines && lyrics.lines.length > 0) {
                const effectiveTime = cur + lyricOffset;
                let activeIndex = -1;
                for (let i = 0; i < lyrics.lines.length; i++) {
                    if (lyrics.lines[i].time <= effectiveTime) {
                        activeIndex = i;
                    } else {
                        break;
                    }
                }
                setCurrentLyricIndex(activeIndex);
            }
        };

        const handlePlay = () => setIsPlaying(true);
        const handlePause = () => setIsPlaying(false);
        const handleLoadStart = () => setIsLoading(true);
        const handleWaiting = () => setIsLoading(true);
        const handleSeeking = () => setIsLoading(true);
        const handleSeeked = () => setIsLoading(false);
        const handleCanPlay = () => setIsLoading(false);
        const handlePlaying = () => {
            setIsLoading(false);
            setIsPlaying(true);
        };
        const handleError = () => {
            setIsLoading(false);
            setIsPlaying(false);
        };
        const handleEnded = () => {
            if (repeatMode === 'one') {
                au.currentTime = 0;
                au.play().catch(() => {});
            } else if (autoNext) {
                nextTrack();
            } else {
                setIsPlaying(false);
            }
        };

        au.addEventListener('timeupdate', handleTimeUpdate);
        au.addEventListener('play', handlePlay);
        au.addEventListener('pause', handlePause);
        au.addEventListener('loadstart', handleLoadStart);
        au.addEventListener('waiting', handleWaiting);
        au.addEventListener('seeking', handleSeeking);
        au.addEventListener('seeked', handleSeeked);
        au.addEventListener('canplay', handleCanPlay);
        au.addEventListener('playing', handlePlaying);
        au.addEventListener('error', handleError);
        au.addEventListener('ended', handleEnded);

        return () => {
            au.removeEventListener('timeupdate', handleTimeUpdate);
            au.removeEventListener('play', handlePlay);
            au.removeEventListener('pause', handlePause);
            au.removeEventListener('loadstart', handleLoadStart);
            au.removeEventListener('waiting', handleWaiting);
            au.removeEventListener('seeking', handleSeeking);
            au.removeEventListener('seeked', handleSeeked);
            au.removeEventListener('canplay', handleCanPlay);
            au.removeEventListener('playing', handlePlaying);
            au.removeEventListener('error', handleError);
            au.removeEventListener('ended', handleEnded);
        };
    }, [lyrics, lyricOffset, repeatMode, autoNext, playlist, playlistIndex, isShuffle]);

    // MediaSession action handlers
    useEffect(() => {
        if (!('mediaSession' in navigator)) return;
        try {
            navigator.mediaSession.setActionHandler('play', togglePlay);
            navigator.mediaSession.setActionHandler('pause', togglePlay);
            navigator.mediaSession.setActionHandler('previoustrack', () => prevTrack(true));
            navigator.mediaSession.setActionHandler('nexttrack', nextTrack);
            navigator.mediaSession.setActionHandler('seekto', (details) => {
                if (details.seekTime !== undefined) seek(details.seekTime);
            });
            navigator.mediaSession.playbackState = isPlaying ? 'playing' : 'paused';
        } catch(e){}
    }, [isPlaying, currentTrack, playlist, playlistIndex]);

    return (
        <PlayerContext.Provider value={{
            audioRef,
            currentTrack,
            isPlaying,
            isLoading,
            playlist,
            playlistIndex,
            playlistSource,
            currentTime,
            duration,
            repeatMode,
            isShuffle,
            autoNext,
            playbackRate,
            volume,
            lyrics,
            currentLyricIndex,
            lyricOffset,
            accentColors,
            bgGlowEnabled,
            isFullPlayerOpen,
            fullPlayerView,
            isLyricsOverlayOpen,
            activeArtist,
            activeAlbum,
            isEqualizerOpen,
            isSleepTimerOpen,
            isSpeedOpen,
            isQueueOpen,
            isAddToPlaylistOpen,
            isShareCardOpen,
            isCreatePlaylistOpen,
            toastMessage,
            eqValues,
            sleepSecondsLeft,

            // Actions
            playTrack,
            togglePlay,
            nextTrack,
            prevTrack,
            seek,
            setVolumeLevel,
            toggleMute,
            toggleRepeat,
            toggleShuffle,
            setAutoNext: (val) => {
                setAutoNext(val);
                try { localStorage.setItem('nanzz_auto_next', String(val)); } catch(e){}
            },
            changePlaybackRate,
            toggleBgGlow,
            lyricSyncPrev,
            lyricSyncNext,
            showToast,

            // Navigation & Routing
            activeTab,
            setActiveTab,
            searchQuery,
            setSearchQuery,
            devProfile,
            setDevProfile,
            navigateToTab: switchTab,
            setIsFullPlayerOpen,
            setFullPlayerView,
            setIsLyricsOverlayOpen,
            setActiveArtist,
            setActiveAlbum,
            setIsEqualizerOpen,
            setIsSleepTimerOpen,
            setIsSpeedOpen,
            setIsQueueOpen,
            setIsAddToPlaylistOpen,
            setIsShareCardOpen,
            setIsCreatePlaylistOpen,
            setEqPreset,
            applyEqualizer,
            setSleepTimer,
            preampBoost,
            setPreampBoostLevel,

            // Theme
            theme,
            setTheme,
            toggleTheme,
        }}>
            <audio ref={audioRef} preload="auto" crossOrigin="anonymous" style={{ display: 'none' }} />
            {children}
        </PlayerContext.Provider>
    );
}

export function usePlayer() {
    return useContext(PlayerContext);
}
