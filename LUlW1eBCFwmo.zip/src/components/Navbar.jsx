import React from 'react';
import { Home, Search, Library, User } from 'lucide-react';
import { usePlayer } from '../context/PlayerContext';
import GooeyNav from './GooeyNav';

export default function Navbar() {
    const { activeTab, navigateToTab } = usePlayer();

    const tabs = [
        { id: 'home', label: 'Home', icon: <Home className="w-6 h-6 sm:w-7 sm:h-7" /> },
        { id: 'search', label: 'Search', icon: <Search className="w-6 h-6 sm:w-7 sm:h-7" /> },
        { id: 'library', label: 'Library', icon: <Library className="w-6 h-6 sm:w-7 sm:h-7" /> },
        { id: 'dev', label: 'Profile', icon: <User className="w-6 h-6 sm:w-7 sm:h-7" /> },
    ];

    // Bila sedang di view liked atau offline, navbar tetap mengaktifkan tab Library
    const currentNavTab = (activeTab === 'liked' || activeTab === 'offline') ? 'library' : activeTab;

    const handleSwitch = (id) => {
        if (navigateToTab) {
            navigateToTab(id, true);
        }
        const mainArea = document.getElementById('main-area');
        if (mainArea) mainArea.scrollTop = 0;
    };

    return (
        <div className="fixed bottom-4 sm:bottom-6 left-1/2 -translate-x-1/2 z-40 w-auto max-w-xl flex justify-center pointer-events-none px-2 sm:px-3">
            <div className="pointer-events-auto bg-[var(--dock-bg)] backdrop-blur-2xl border border-[var(--border-color)] rounded-full px-3 py-2 sm:px-4 sm:py-2.5 shadow-2xl shadow-black/80 flex items-center justify-center transition-all duration-300">
                <GooeyNav
                    items={tabs}
                    activeTab={currentNavTab}
                    onTabChange={handleSwitch}
                    particleCount={26}
                    particleR={440}
                    timeVariance={400}
                />
            </div>
        </div>
    );
}
