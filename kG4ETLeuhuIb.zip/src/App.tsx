import React, { useState, FormEvent, useRef, useEffect } from 'react';
import { 
  Video, Globe, Link2, Youtube, Twitter, Instagram, 
  Facebook, Music, Loader2, Download, AlertCircle, Moon, Sun,
  Film, Headphones, Image as ImageIcon, Scissors
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from './lib/utils';
import { useNotifications, NotificationStack } from './lib/notifications';
import axios from 'axios';

type MediaObj = {
  type: string;
  quality?: string;
  label?: string;
  url: string;
  
  downloadUrl?: string;
  format?: string;
  size?: string;
};

type ResultObj = {
  platform: string;
  title?: string;
  thumbnail?: string;
  image?: string;
  author?: string;
  duration?: string;
  media: MediaObj[];
};

const TRANSLATIONS = {
  en: {
    title: 'Online Video',
    subtitle: 'Downloader',
    desc: 'A Free Solution To Quickly Download Videos Or Music With Just One Click!',
    placeholder: 'Insert Video Link Here ...',
    btn_download: 'Download',
    supported: 'Supported Platforms',
    options: 'Download Options',
    no_links: 'No download links found.',
    error_empty: 'Please insert a URL.',
    by: 'by',
    untitled: 'Untitled Video'
  },
  id: {
    title: 'Pengunduh Video',
    subtitle: 'Online',
    desc: 'Solusi Gratis Untuk Mengunduh Video Atau Musik Dengan Cepat Hanya Sekali Klik!',
    placeholder: 'Masukkan Tautan Video Di Sini ...',
    btn_download: 'Unduh',
    supported: 'Platform Didukung',
    options: 'Opsi Unduhan',
    no_links: 'Tidak ada tautan unduhan.',
    error_empty: 'Harap masukkan tautan (URL).',
    by: 'oleh',
    untitled: 'Video Tanpa Judul'
  }
};

const PLATFORMS_TEXT = "Tiktok, Douyin, Capcut, Threads, Instagram, Facebook, Espn, Pinterest, imdb, imgur, ifunny, Izlesene, Reddit, Youtube, Twitter, Vimeo, Snapchat, Bilibili, Dailymotion, Sharechat, Likee, Linkedin, Tumblr, Hipi, Telegram, Getstickerpack, Bitchute, Febspot, 9GAG, ok.ru, Rumble, Streamable, Ted, SohuTv, Xvideos, Xnxx, Xiaohongshu, Ixigua, Weibo, Miaopai, Meipai, Xiaoying, National Video, Yingke, Sina, Vk-vkvideo, Soundcloud, Mixcloud, Spotify, Zingmp3, Bandcamp, TeraBox";
const PLATFORMS = PLATFORMS_TEXT.split(", ");

function formatBytes(bytes: number, decimals = 2) {
    if (!+bytes) return '';
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return `${parseFloat((bytes / Math.pow(k, i)).toFixed(dm))} ${sizes[i]}`;
}

export default function App() {
  const [url, setUrl] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [result, setResult] = useState<ResultObj | null>(null);
  const { items: notifications, push: pushNotification, dismiss: dismissNotification } = useNotifications();
  
  const [isDark, setIsDark] = useState(false);
  const [downloadingUrl, setDownloadingUrl] = useState<string | null>(null);
  const [lang, setLang] = useState<'en'|'id'>('en');

  const inputRef = useRef<HTMLInputElement>(null);
  const resultRef = useRef<HTMLDivElement>(null);
  const t = TRANSLATIONS[lang];

  useEffect(() => {
    if (result && resultRef.current) {
      resultRef.current.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  }, [result]);

  


  const handleDownload = async (e: FormEvent) => {
    e.preventDefault();
    if (!url.trim()) {
      setError(t.error_empty);
      return;
    }

    setLoading(true);
    setError('');
    setResult(null);

    try {
      const response = await axios.get(`/api/download?url=${encodeURIComponent(url.trim())}`);
      const data = response.data?.result;

      if (!data || !(data.medias || data.media)) {
        throw new Error('Download failed or platform unsupported.');
      }
      
      const media = (data.medias || data.media).map((m: any) => {
        let type = m.type; 
        let quality = m.quality || '';
        let label = '';
        
        if (m.type === 'video') {
           label = quality ? `Video ${quality}` : 'Video';
           if (quality === 'hd_no_watermark' || quality === 'no_watermark_hd') type = 'no_watermark_hd';
           else if (quality === 'no_watermark') type = 'no_watermark';
           else if (quality === 'watermark') type = 'watermark';
           else if (quality === 'HD') type = 'HD';
        } else if (m.type === 'audio') {
           label = 'Audio';
           type = 'audio';
        } else if (m.type === 'image') {
           label = 'Image';
           type = 'image';
        } else {
           label = quality || type || 'File';
        }
        
        return {
          type: type,
          label: label,
          quality: quality,
          url: m.url,
          format: m.extension || '',
          size: m.data_size ? formatBytes(m.data_size) : undefined
        };
      });

      setResult({
        platform: data.source || 'unknown',
        title: data.title || '',
        thumbnail: data.thumbnail || '',
        author: data.author || '',
        duration: data.duration,
        media: media
      });
      pushNotification(lang === 'id' ? 'Tautan unduhan sudah siap!' : 'Your download links are ready!');
    } catch (err: any) {
      setError(err.response?.data?.message || err.message || 'An error occurred while fetching the video.');
    } finally {
      setLoading(false);
    }
  };

  const handlePlatformClick = () => {
    if (inputRef.current) {
      inputRef.current.focus();
    }
  };

  const isVideoType = (type: string) => ['video', 'no_watermark', 'no_watermark_hd', 'watermark', 'HD'].includes(type);
  
  const getPreview = () => {
    if (!result) return null;
    const video = result.media.find(m => m.quality?.toLowerCase().includes('hd') || m.quality?.toLowerCase().includes('no_watermark')) 
               || result.media.find(m => isVideoType(m.type));
    if (video) return { type: 'video', url: video.url,  };
    
    const audio = result.media.find(m => m.type === 'audio' || m.type === 'mp3');
    if (audio) return { type: 'audio', url: audio.url,  };
    
    return null;
  };

  const preview = getPreview();
  const thumbnailUrl = (result?.thumbnail || result?.image) ? (result.thumbnail || result.image) : undefined;

  // Theme Classes
  const bgClass = isDark ? "bg-[#0f0f0f]" : "bg-[#ffffff]";
  const textClass = isDark ? "text-white" : "text-gray-900";
  const cardBg = isDark ? "bg-[#161616]" : "bg-white";
  const cardBorder = isDark ? "border-[#2a2a2a]" : "border-gray-200";
  const inputBg = isDark ? "bg-[#1c1c1c]" : "bg-white";
  const inputBorder = isDark ? "border-[#333]" : "border-gray-200";
  const mutedText = isDark ? "text-gray-400" : "text-gray-500";
  const itemHover = isDark ? "hover:border-[#E63946] hover:bg-[#222]" : "hover:border-[#E63946] hover:bg-gray-50";

  return (
    <div className={cn("min-h-screen w-full overflow-x-hidden font-sans transition-colors duration-300 relative", bgClass, textClass)}>
      {/* Background Decor */}
      <div className="absolute inset-0 z-0 pointer-events-none opacity-20 overflow-hidden">
        <div className={cn(
          "absolute top-[-20%] left-[-10%] w-[120%] h-[120%] bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] blur-[100px]",
          isDark ? "from-gray-800 via-transparent to-transparent" : "from-gray-300 via-transparent to-transparent"
        )}></div>
      </div>

      {/* Header */}
      <header className="relative z-10 flex justify-between items-center py-5 px-6 md:px-12 max-w-[1400px] mx-auto">
        <button onClick={() => setResult(null)} className="flex items-center gap-3 group outline-none text-left">
          <div className="shrink-0 group-hover:scale-105 transition-transform">
            <img src="/logo.png" alt="Logo" className="w-10 h-10 md:w-12 md:h-12 object-contain" onError={(e) => { e.currentTarget.style.display = 'none'; e.currentTarget.nextElementSibling!.style.display = 'block'; }} />
            <div style={{ display: 'none' }} className="bg-[#E63946] p-3 rounded-xl shadow-lg">
              <Video className="w-7 h-7 text-white" />
            </div>
          </div>
          <div className="flex flex-col leading-[1.1] tracking-tight">
            <span className="text-sm md:text-base font-black">Multi</span>
            <span className="text-sm md:text-base font-black">Downloader</span>
          </div>
        </button>
        
        <div className="flex items-center gap-3 md:gap-4 shrink-0">
          <button 
            onClick={() => setLang(lang === 'en' ? 'id' : 'en')}
            className={cn("flex items-center gap-2 px-4 py-2 rounded-full text-sm font-bold transition-colors border", 
              isDark ? "border-gray-800 hover:bg-gray-800 text-gray-300" : "border-gray-200 hover:bg-gray-100 text-gray-700"
            )}
          >
            <Globe className="w-4 h-4" />
            <span className="uppercase">{lang}</span>
          </button>
          <button 
            onClick={() => setIsDark(!isDark)}
            className={cn("p-2.5 rounded-full transition-colors border", 
              isDark ? "border-gray-800 hover:bg-gray-800 text-yellow-400" : "border-gray-200 hover:bg-gray-100 text-gray-700"
            )}
            title="Toggle Theme"
          >
            {isDark ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
          </button>
        </div>
      </header>

      {/* Layout wrapper */}
      <div className="relative z-10 flex flex-col lg:flex-row gap-8 max-w-[1400px] mx-auto w-full mt-6 md:mt-12 px-6 pb-24">
        
        {/* Sidebar Platforms (Desktop) */}
        <aside className="hidden lg:flex flex-col w-64 shrink-0">
          <h3 className={cn("text-xs font-bold mb-5 uppercase tracking-widest pl-2", mutedText)}>
            {t.supported} ({PLATFORMS.length})
          </h3>
          <div className="flex flex-wrap gap-2 overflow-y-auto max-h-[600px] custom-scrollbar pr-2 pb-4">
            {PLATFORMS.map((plat) => {
              return (
                <button 
                  key={plat} 
                  onClick={handlePlatformClick}
                  className={cn(
                    "flex items-center gap-2 px-3 py-2 rounded-xl border transition-colors cursor-pointer outline-none text-left w-auto",
                    isDark ? "bg-[#161616] border-[#222] hover:bg-[#1f1f1f]" : "bg-white border-gray-100 hover:bg-gray-50 shadow-sm",
                    textClass
                  )}
                >
                  <span className="font-bold text-xs">{plat}</span>
                </button>
              )
            })}
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 flex flex-col items-center lg:items-start text-center lg:text-left w-full min-w-0">
          
          {/* Title Section */}
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, ease: "easeOut" }}
            className="flex flex-col items-center lg:items-start w-full"
          >
            <div className="mb-4 inline-flex items-center gap-3">
              <svg width="40" height="20" viewBox="0 0 40 20" className="text-[#E63946] fill-current shrink-0">
                <path d="M0,10 Q10,0 20,10 T40,10" stroke="currentColor" strokeWidth="2" fill="none" />
              </svg>
              <span className={cn("text-lg md:text-xl font-bold tracking-wide", mutedText)}>
                {t.title}
              </span>
            </div>
            
            <h1 className="text-5xl md:text-7xl lg:text-8xl font-black tracking-tighter mb-6 drop-shadow-sm leading-tight">
              {t.subtitle}
            </h1>
            
            <p className={cn("max-w-xl mb-10 leading-relaxed text-base font-medium", mutedText)}>
              {t.desc}
            </p>
          </motion.div>

          {/* Search Input */}
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, ease: "easeOut", delay: 0.1 }}
            className="w-full relative z-20 max-w-3xl"
          >
            <form 
              onSubmit={handleDownload}
              className={cn("flex flex-col md:flex-row items-center w-full rounded-3xl p-2.5 shadow-xl relative z-10 border overflow-hidden", inputBg, inputBorder)}
            >
              <div className="flex items-center flex-1 min-w-0 w-full pl-5 py-2">
                <Link2 className={cn("w-6 h-6 shrink-0", isDark ? "text-gray-500" : "text-gray-400")} />
                <input 
                  ref={inputRef}
                  type="text" 
                  placeholder={t.placeholder}
                  className={cn("flex-1 min-w-0 bg-transparent border-none outline-none px-4 font-semibold text-[16px] md:text-lg m-0 p-0 pl-4 appearance-none w-full", 
                    isDark ? "text-gray-100 placeholder-gray-600" : "text-gray-900 placeholder-gray-400"
                  )}
                  value={url}
                  onChange={(e) => setUrl(e.target.value)}
                  disabled={loading}
                />
              </div>
              <button 
                type="submit"
                disabled={loading}
                className="w-full md:w-auto mt-3 md:mt-0 bg-[#E63946] hover:bg-[#d92c3a] text-white font-bold text-lg py-4 px-10 rounded-2xl transition-all flex items-center justify-center gap-3 shrink-0 disabled:opacity-70 disabled:cursor-not-allowed shadow-md"
              >
                {loading ? <Loader2 className="w-6 h-6 animate-spin" /> : t.btn_download}
              </button>
            </form>
          </motion.div>

          {/* Error Message */}
          <AnimatePresence>
            {error && (
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="mt-8 bg-red-500/10 text-red-500 px-6 py-4 rounded-2xl flex items-center gap-3 border border-red-500/20 w-full max-w-3xl"
              >
                <AlertCircle className="w-6 h-6 shrink-0" />
                <p className="text-sm md:text-base font-bold">{error}</p>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Results Area */}
          <AnimatePresence>
            {result && (
              <motion.div 
                ref={resultRef}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 10 }}
                transition={{ duration: 0.5, ease: "easeOut" }}
                className={cn("mt-12 w-full max-w-6xl rounded-3xl p-5 lg:p-8 shadow-2xl text-left flex flex-col lg:flex-row gap-8 lg:gap-12 border", cardBg, cardBorder)}
              >
                <div className="w-full lg:w-[50%] xl:w-[55%] flex-shrink-0 relative rounded-2xl overflow-hidden bg-black shadow-lg group flex items-center justify-center min-h-[300px] max-h-[75vh]">
                  {preview?.type === 'video' ? (
                    <video 
                      src={preview.url} 
                      controls
                      autoPlay
                      muted
                      loop
                      playsInline
                      referrerPolicy="no-referrer"
                      className="w-full h-full max-h-[75vh] object-contain bg-black"
                      poster={thumbnailUrl}
                    />
                  ) : (
                    <>
                      {thumbnailUrl ? (
                        <img 
                          src={thumbnailUrl} 
                          alt="Thumbnail" 
                          referrerPolicy="no-referrer"
                          className="w-full h-full max-h-[75vh] object-contain bg-black opacity-90 transition-transform duration-700 group-hover:scale-105"
                        />
                      ) : (
                        <div className="w-full h-full flex flex-col items-center justify-center text-gray-500">
                          <Video className="w-12 h-12 mb-3 opacity-50" />
                          <span className="text-sm font-bold">No Preview</span>
                        </div>
                      )}
                      {preview?.type === 'audio' && (
                        <div className="absolute inset-x-0 bottom-0 p-4 bg-gradient-to-t from-black to-transparent">
                          <audio src={preview.url} controls preload="metadata" referrerPolicy="no-referrer" className="w-full h-12" />
                        </div>
                      )}
                    </>
                  )}
                  <div className="absolute top-4 left-4 bg-black/80 backdrop-blur-md text-white text-xs font-black px-3 py-1.5 rounded-lg uppercase tracking-widest z-10 pointer-events-none shadow-xl border border-white/10">
                    {result.platform}
                  </div>
                </div>
                
                <div className="flex-1 flex flex-col py-2 overflow-hidden">
                  <h3 className={cn("text-2xl md:text-3xl font-black mb-3 line-clamp-3 leading-snug", textClass)}>
                    {result.title || t.untitled}
                  </h3>
                  {result.author && (
                    <p className={cn("text-sm md:text-base font-bold mb-8 flex items-center gap-2", mutedText)}>
                      <span className="opacity-70">{t.by}</span> 
                      <span className="text-[#E63946]">{result.author}</span>
                    </p>
                  )}

                  <div className="flex-1 mt-auto">
                    <h4 className={cn("text-xs md:text-sm font-black mb-4 flex items-center gap-2 uppercase tracking-widest", textClass)}>
                      <Download className="w-4 h-4 text-[#E63946]" /> {t.options}
                    </h4>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-[60vh] lg:max-h-[600px] overflow-y-auto pr-2 custom-scrollbar">
                      {result.media.length > 0 ? (
                        result.media.map((item, idx) => (
                          <a 
                            key={idx}
                            href={item.downloadUrl || item.url}
                            download
                            className={cn(
                              "flex items-center justify-between p-3.5 md:p-4 rounded-2xl border transition-all duration-200 group relative overflow-hidden",
                              isDark ? "bg-[#1f1f1f] border-[#333]" : "bg-white border-gray-200 shadow-sm",
                              
                              itemHover
                            )}
                          >
                            <div className="flex flex-col relative z-10 overflow-hidden">
                              <span className={cn("font-bold text-sm truncate mb-1", textClass)}>
                                {item.label || item.quality || item.type || 'Download File'}
                              </span>
                              <span className={cn("text-[10px] uppercase tracking-widest font-bold", mutedText)}>
                                {item.type} {item.format ? `• ${item.format}` : ''} {item.size ? `• ${item.size}` : ''}
                              </span>
                            </div>
                            <div className="w-10 h-10 shrink-0 rounded-xl bg-[#E63946]/10 flex items-center justify-center text-[#E63946] group-hover:bg-[#E63946] group-hover:text-white transition-all duration-300 relative z-10 group-hover:scale-110 shadow-sm group-active:scale-95 ml-2">
                              <Download className="w-4 h-4" />
                            </div>
                          </a>
                        ))
                      ) : (
                        <div className={cn("col-span-1 sm:col-span-2 text-sm font-bold py-8 text-center rounded-2xl border-2 border-dashed", isDark ? "border-[#333] text-gray-500" : "border-gray-200 text-gray-400")}>
                          {t.no_links}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Supported Platforms (Mobile) */}
          <div className="lg:hidden w-full mt-12 max-w-3xl">
            <h3 className={cn("text-xs font-bold mb-5 uppercase tracking-widest text-left pl-2", mutedText)}>
              {t.supported} ({PLATFORMS.length})
            </h3>
            <div className="flex flex-wrap gap-2">
              {PLATFORMS.map((plat) => {
                return (
                  <button 
                    key={plat} 
                    onClick={handlePlatformClick}
                    className={cn(
                      "flex items-center gap-2 px-3 py-2 rounded-xl border transition-colors cursor-pointer outline-none w-auto text-left",
                      isDark ? "bg-[#161616] border-[#222]" : "bg-white border-gray-100 shadow-sm",
                      textClass
                    )}
                  >
                    <span className="font-bold text-xs truncate">{plat}</span>
                  </button>
                )
              })}
            </div>
          </div>

        </main>
      </div>

      <style>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 6px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: transparent; 
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: ${isDark ? '#444' : '#e5e7eb'}; 
          border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: ${isDark ? '#666' : '#d1d5db'}; 
        }
      `}</style>

      <NotificationStack items={notifications} onDismiss={dismissNotification} isDark={isDark} />
    </div>
  );
}
