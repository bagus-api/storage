import { useEffect, useRef, useState } from 'react';

const SW_URL = '/sw.js';

export function registerServiceWorker() {
  if (typeof window === 'undefined' || !('serviceWorker' in navigator)) return;
  window.addEventListener('load', () => {
    navigator.serviceWorker.register(SW_URL).catch(() => {});
  });
}

async function requestNotificationPermission() {
  if (typeof window === 'undefined' || !('Notification' in window)) return 'unsupported';
  if (Notification.permission === 'granted') return 'granted';
  if (Notification.permission === 'denied') return 'denied';
  try {
    return await Notification.requestPermission();
  } catch {
    return 'denied';
  }
}

// Fires a real system/PWA notification (icon = /logo.png, app name = MultiDown)
// via the service worker, with a "Close" action baked in.
export async function firePwaNotification(body: string, tag = 'multidown-notification') {
  if (typeof window === 'undefined' || !('serviceWorker' in navigator)) return;
  const permission = await requestNotificationPermission();
  if (permission !== 'granted') return;
  try {
    const reg = await navigator.serviceWorker.ready;
    reg.active?.postMessage({ type: 'SHOW_NOTIFICATION', title: 'MultiDown', body, tag });
  } catch {
    // ignore - in-app notification card below still shows
  }
}

export type NotificationItem = {
  id: number;
  message: string;
};

export function useNotifications() {
  const [items, setItems] = useState<NotificationItem[]>([]);
  const idRef = useRef(0);

  const push = (message: string) => {
    const id = ++idRef.current;
    setItems((prev) => [...prev, { id, message }]);
    firePwaNotification(message);
    setTimeout(() => dismiss(id), 6000);
  };

  const dismiss = (id: number) => {
    setItems((prev) => prev.filter((n) => n.id !== id));
  };

  return { items, push, dismiss };
}

// The in-app "PWA notification" card: logo icon on the left, MultiDown title +
// message in the middle, and a close (X) button on the right.
export function NotificationStack({
  items,
  onDismiss,
  isDark,
}: {
  items: NotificationItem[];
  onDismiss: (id: number) => void;
  isDark: boolean;
}) {
  if (items.length === 0) return null;

  return (
    <div className="fixed top-4 right-4 z-[60] flex flex-col gap-3 w-[calc(100%-2rem)] max-w-sm">
      {items.map((n) => (
        <div
          key={n.id}
          className={`flex items-start gap-3 p-4 rounded-2xl shadow-2xl border animate-in slide-in-from-top-4 fade-in duration-300 ${
            isDark ? 'bg-[#1c1c1c] border-[#333] text-white' : 'bg-white border-gray-200 text-gray-900'
          }`}
        >
          <img src="/logo.png" alt="MultiDown" className="w-9 h-9 rounded-lg object-contain shrink-0" />
          <div className="flex-1 min-w-0">
            <p className="text-sm font-black leading-tight">MultiDown</p>
            <p className={`text-xs mt-0.5 leading-snug ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>{n.message}</p>
          </div>
          <button
            onClick={() => onDismiss(n.id)}
            aria-label="Close notification"
            className={`shrink-0 w-6 h-6 rounded-full flex items-center justify-center transition-colors ${
              isDark ? 'hover:bg-white/10 text-gray-400 hover:text-white' : 'hover:bg-gray-100 text-gray-400 hover:text-gray-700'
            }`}
          >
            <svg viewBox="0 0 24 24" className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth={2.5}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M6 6l12 12M18 6L6 18" />
            </svg>
          </button>
        </div>
      ))}
    </div>
  );
}
