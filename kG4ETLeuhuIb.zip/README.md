# MultiDown

Frontend React (Vite) + backend 1 serverless function plain Node.js. Siap deploy Vercel, zero-config.

```
src/App.tsx, main.tsx, ...   -> frontend React (build via Vite)
public/logo.png, manifest, sw.js -> PWA
api/download.js               -> satu-satunya endpoint API (plain CommonJS, gak ada TypeScript/build)
api/_lib.js                   -> helper (scraping + proxy token), di-exclude dari routing (prefix _)
vercel.json
```

## Jalankan lokal

```bash
npm install
npx vercel dev
```

(pakai `vercel dev`, bukan cuma `vite`, biar `/api/download` ikut jalan)

## Deploy ke Vercel

Push ke GitHub → import di vercel.com/new → deploy. Gak ada environment variable yang wajib diisi.

## Cara kerja `/api/download`

- `?url=<link asli>` → server scrape link tsb, balikin JSON. Semua link media di JSON diganti jadi `/api/download?file=<token>` — URL sumber asli **gak pernah** dikirim ke browser.
- `?file=<token>` → server stream file aslinya ke browser. Token ini stateless & otomatis expired **5 menit**.
- CORS dibatasi same-origin (cek header `Origin`/`Referer`) + rate limit per-IP.
- Tombol download pakai atribut `download` (bukan buka tab baru), jadi langsung ke-download di halaman yang sama.
