const axios = require("axios");
const http = require("http");
const https = require("https");

const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36";

const UAs = [
  "Mozilla/5.0 (Linux; Android 15; SM-F958 Build/AP3A.240905.015) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.6723.86 Mobile Safari/537.36",
  "Mozilla/5.0 (Linux; Android 14; SM-S928B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Mobile Safari/537.36",
  "Mozilla/5.0 (iPhone; CPU iPhone OS 17_5_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1",
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36",
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36",
];
function getRandomUA() {
  return UAs[Math.floor(Math.random() * UAs.length)];
}

const httpAgent = new http.Agent({ keepAlive: true, maxSockets: 100 });
const httpsAgent = new https.Agent({ keepAlive: true, maxSockets: 100 });
const apiClient = axios.create({ httpAgent, httpsAgent });

const BASE = "https://downr.org";
const ANALYTICS = `${BASE}/.netlify/functions/analytics`;
const DOWNLOAD = `${BASE}/.netlify/functions/download`;
const NYT = `${BASE}/.netlify/functions/nyt`;

function parseCookie(setCookie) {
  return (setCookie || []).map((v) => v.split(";")[0]).join("; ");
}

function parseData(data) {
  if (typeof data !== "string") return data;
  const text = data.trim();
  try {
    return JSON.parse(text);
  } catch {
    return text;
  }
}

function isOk(status, data) {
  const isObject = data && typeof data === "object";
  if (status < 200 || status >= 300) return false;
  if (data === null || data === undefined || data === "") return false;
  if (data === "error" || data === "failed" || data === "user_retry_required") return false;
  if (isObject && data.error === true) return false;
  if (isObject && data.status === false) return false;
  if (isObject && data.success === false) return false;
  return true;
}

function getError(data, status) {
  if (typeof data === "string") return data || `HTTP ${status}`;
  if (data && typeof data === "object") return data.message || data.error || data.status || data.reason || `HTTP ${status}`;
  return `HTTP ${status}`;
}

function getHeaders(cookie) {
  return {
    accept: "*/*",
    "accept-encoding": "gzip, deflate, br",
    "accept-language": "en-US,en;q=0.9",
    "content-type": "application/json",
    cookie: cookie || "",
    origin: BASE,
    referer: `${BASE}/`,
    "user-agent": getRandomUA(),
  };
}

async function getCookie() {
  try {
    const res = await apiClient.get(ANALYTICS, { timeout: 10000, headers: getHeaders() });
    return parseCookie(res.headers["set-cookie"]);
  } catch {
    return "";
  }
}

async function postEndpoint(endpoint, url, cookie) {
  try {
    const res = await apiClient.post(
      endpoint,
      { url },
      {
        timeout: 30000,
        validateStatus: () => true,
        responseType: "text",
        transformResponse: [(v) => v],
        headers: getHeaders(cookie),
      }
    );
    return { endpoint, status: res.status, data: parseData(res.data) };
  } catch (err) {
    return { endpoint, status: (err.response && err.response.status) || 500, data: null };
  }
}

async function downr(url) {
  let cookie = await getCookie();
  let result = await postEndpoint(DOWNLOAD, url, cookie);
  if (isOk(result.status, result.data)) return result;

  cookie = await getCookie();
  result = await postEndpoint(DOWNLOAD, url, cookie);
  if (isOk(result.status, result.data)) return result;

  return postEndpoint(NYT, url, cookie);
}

// ========== STATELESS PROXY TOKEN, EXPIRES IN 5 MINUTES ==========
// Everything the proxy needs (source url, title, ext, expiry timestamp) is
// encoded straight into the token. Nothing is kept in server memory, so it
// works the same no matter which serverless instance handles the request,
// and it can never leak/grow memory across invocations -> can't crash the
// function like the old in-memory Map approach did.
const PROXY_TTL_MS = 5 * 60 * 1000; // 5 minutes

function encodeProxyToken(originalUrl, title, ext, inline) {
  const payload = { u: originalUrl, t: title, e: ext, i: inline ? 1 : 0, exp: Date.now() + PROXY_TTL_MS };
  return Buffer.from(JSON.stringify(payload), "utf-8").toString("base64url");
}

function decodeProxyToken(token) {
  try {
    const json = Buffer.from(String(token), "base64url").toString("utf-8");
    const obj = JSON.parse(json);
    if (!obj.u || typeof obj.u !== "string" || !/^https?:\/\//i.test(obj.u)) return { error: "invalid" };
    if (!obj.exp || Date.now() > obj.exp) return { error: "expired" };
    return { url: obj.u, title: obj.t || "media", ext: obj.e || "mp4", inline: !!obj.i };
  } catch {
    return { error: "invalid" };
  }
}

async function streamProxiedFile(target, rangeHeader, res) {
  const targetUrl = target.url;
  try {
    let origin = "";
    try {
      origin = new URL(targetUrl).origin;
    } catch {}

    const headers = {
      "User-Agent": UA,
      Accept: "*/*",
      "Accept-Language": "en-US,en;q=0.9",
      Connection: "keep-alive",
    };
    if (origin) {
      headers["Referer"] = origin;
      headers["Origin"] = origin;
    }
    if (rangeHeader) headers["Range"] = rangeHeader;

    const response = await axios({
      method: "GET",
      url: targetUrl,
      responseType: "stream",
      headers,
      maxRedirects: 10,
      decompress: false,
      timeout: 15000,
      validateStatus: () => true,
    });

    const contentType = String(response.headers["content-type"] || "");

    if (response.status >= 400 || contentType.includes("text/html")) {
      res.statusCode = 302;
      res.setHeader("Location", targetUrl);
      res.end();
      return;
    }

    ["content-length", "content-range", "accept-ranges", "cache-control"].forEach((h) => {
      if (response.headers[h]) res.setHeader(h, String(response.headers[h]));
    });

    res.statusCode = response.status;

    let ext = target.ext;
    if (contentType.includes("audio")) ext = "mp3";
    else if (contentType.includes("image")) ext = "jpg";
    else if (contentType.includes("video")) ext = "mp4";

    const title = target.title || "media";
    const disposition = target.inline ? "inline" : "attachment";
    res.setHeader("Content-Disposition", `${disposition}; filename="${title}_multidown_nanzz.${ext}"`);
    res.setHeader("Content-Type", contentType || "application/octet-stream");
    res.setHeader("Access-Control-Allow-Origin", "*");

    response.data.pipe(res);
  } catch (err) {
    res.statusCode = 302;
    res.setHeader("Location", targetUrl);
    res.end();
  }
}

function isAllowedOrigin(req) {
  const host = req.headers.host;
  const origin = req.headers.origin;
  const referer = req.headers.referer;

  // Direct navigation / <a> click / curl without Origin or Referer header
  // (normal for top-level downloads) is allowed through.
  if (!origin && !referer) return true;

  try {
    if (origin) return new URL(origin).host === host;
    if (referer) return new URL(referer).host === host;
  } catch {
    return false;
  }
  return true;
}

module.exports = {
  downr,
  isOk,
  getError,
  encodeProxyToken,
  decodeProxyToken,
  streamProxiedFile,
  isAllowedOrigin,
  PROXY_TTL_MS,
};
