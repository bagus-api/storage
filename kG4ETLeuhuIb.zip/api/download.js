const axios = require("axios");
const {
  downr,
  isOk,
  getError,
  encodeProxyToken,
  decodeProxyToken,
  streamProxiedFile,
  isAllowedOrigin,
} = require("./_lib");

function sanitizeTitle(raw) {
  return (raw || "media")
    .replace(/[^a-zA-Z0-9_-]/g, "_")
    .replace(/_+/g, "_")
    .substring(0, 50)
    .replace(/_$/, "");
}

function makeFileLink(originalUrl, title, ext, inline) {
  return `/api/download?file=${encodeProxyToken(originalUrl, title, ext, inline)}`;
}

async function handler(req, res) {
  // No wildcard CORS: only our own frontend (same-origin) can call this.
  if (!isAllowedOrigin(req)) {
    res.status(403).json({ status: false, message: "Forbidden" });
    return;
  }

  if (req.method === "OPTIONS") {
    res.status(200).end();
    return;
  }

  // ===== Streaming a proxied file: /api/download?file=<token> =====
  const fileParam = req.query.file;
  if (fileParam) {
    const decoded = decodeProxyToken(Array.isArray(fileParam) ? fileParam[0] : fileParam);
    if (decoded.error === "expired") {
      res.status(410).json({ status: false, message: "Link download sudah kadaluarsa (lebih dari 5 menit). Silakan generate ulang." });
      return;
    }
    if (decoded.error) {
      res.status(404).json({ status: false, message: "Link download tidak valid." });
      return;
    }
    const rangeHeader = Array.isArray(req.headers.range) ? req.headers.range[0] : req.headers.range;
    await streamProxiedFile(decoded, rangeHeader, res);
    return;
  }

  // ===== Fetching metadata: /api/download?url=<link asli> =====
  const raw = String(req.query.url || "").trim();
  if (!raw) {
    res.status(400).json({ status: false, message: "Parameter url wajib diisi" });
    return;
  }
  if (!/^https?:\/\//i.test(raw)) {
    res.status(400).json({ status: false, message: "Parameter url tidak valid" });
    return;
  }

  try {
    let resultData;

    if (/terabox|1024tera/.test(raw)) {
      const response = await axios.get(
        `https://api-nanzz.my.id/docs/api/downloader/terabox.php?url=${encodeURIComponent(raw)}`,
        { timeout: 15000 }
      );
      const data = response.data;
      if (data.status && data.result) {
        resultData = {
          platform: "terabox",
          title: `Terabox Files (${data.result.totalFiles || (data.result.files || []).length})`,
          media: (data.result.files || [])
            .filter((f) => !f.isFolder && f.downloadUrl)
            .map((f) => ({ type: f.type || "file", quality: f.name || "File", sizeFormatted: f.sizeFormatted, url: f.downloadUrl })),
        };
      } else {
        res.status(500).json({ status: false, message: "Gagal mengambil data Terabox" });
        return;
      }
    } else {
      const result = await downr(raw);
      const ok = isOk(result.status, result.data);
      if (!ok || !result.data) {
        res.status(500).json({ status: false, message: getError(result.data, result.status) || "Gagal mengunduh." });
        return;
      }
      resultData = result.data;
    }

    if (resultData) {
      const safeTitle = sanitizeTitle(resultData.title || resultData.platform || "media");

      // Original CDN/media URL never leaves the server - only our own
      // /api/download?file=<token> link is sent back to the browser.
      if (resultData.thumbnail) {
        resultData.thumbnail = makeFileLink(resultData.thumbnail, safeTitle + "_thumb", "jpg", true);
      }
      if (resultData.image) {
        resultData.image = makeFileLink(resultData.image, safeTitle + "_image", "jpg", true);
      }

      const rawMedia = resultData.medias || resultData.media || [];
      resultData.media = rawMedia.map((m) => {
        let ext = "mp4";
        if (m.type === "audio") ext = "mp3";
        else if (m.type === "image") ext = "jpg";

        const proxied = makeFileLink(m.url, safeTitle, ext, false);
        const clean = { ...m };
        delete clean.url;
        delete clean.originalUrl;
        delete clean.url_original;
        return { ...clean, url: proxied, downloadUrl: proxied };
      });
      delete resultData.medias;
    }

    res.status(200).json({ status: true, creator: "Nanzz", input: { url: raw }, result: resultData });
  } catch (err) {
    res.status(500).json({ status: false, message: err.message || "Server error" });
  }
}

handler.config = {
  api: {
    responseLimit: false,
  },
};

module.exports = handler;
