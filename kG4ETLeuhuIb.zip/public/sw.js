self.addEventListener("install", () => self.skipWaiting());
self.addEventListener("activate", () => self.clients.claim());

self.addEventListener("message", (event) => {
  const data = event.data || {};
  if (data.type !== "SHOW_NOTIFICATION") return;
  self.registration.showNotification(data.title || "MultiDown", {
    body: data.body || "",
    icon: "/logo.png",
    badge: "/logo.png",
    tag: "multidown-notification",
    renotify: true,
    actions: [{ action: "close", title: "Close" }],
  });
});

self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  if (event.action === "close") return;
  event.waitUntil(
    self.clients.matchAll({ type: "window" }).then((clients) => {
      if (clients.length > 0) return clients[0].focus();
      return self.clients.openWindow("/");
    })
  );
});
