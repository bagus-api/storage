/* --- LOGIKA UTAMA ZAAMTUBE --- */
const loader = document.getElementById('loader');
const feed = document.getElementById('feed');
const searchInput = document.getElementById('searchInput');
const ytPlayer = document.getElementById('ytPlayer');
const stTitle = document.getElementById('stTitle');
const recomList = document.getElementById('recomList');
const pwaNotif = document.getElementById('pwa-notif');
let currentVideos = [];
let deferredPrompt;

// 1. Notifikasi PWA (Slide Down -> Jeda -> Slide Up)
window.addEventListener('load', () => {
    setTimeout(() => {
        pwaNotif.classList.add('show'); // Turun dari atas
        
        // Jeda 5 detik lalu naik lagi ke atas
        setTimeout(() => {
            if (!deferredPrompt) pwaNotif.classList.remove('show');
        }, 5000);
    }, 1500);
});

window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferredPrompt = e;
});

document.getElementById('btn-install').onclick = async () => {
    if (deferredPrompt) {
        deferredPrompt.prompt();
        const { outcome } = await deferredPrompt.userChoice;
        if (outcome === 'accepted') pwaNotif.classList.remove('show');
        deferredPrompt = null;
    }
};

// 2. Fungsi Loading (Clean Spinner)
function toggleLoading(show) {
    loader.style.display = show ? 'flex' : 'none';
}

// 3. API Fetch & Render
async function fetchVideos(query) {
    toggleLoading(true);
    try {
        const res = await fetch(`https://kyzznekoo.zone.id/api/search/youtube?q=${encodeURIComponent(query)}`);
        const data = await res.json();
        currentVideos = data.results || [];
        renderFeed();
    } catch (e) {
        console.error("Koneksi gagal");
    } finally {
        setTimeout(() => toggleLoading(false), 500);
    }
}

function renderFeed() {
    feed.innerHTML = currentVideos.map((v, i) => `
        <div class="v-item" onclick="startStream(${i})">
            <div class="thumb"><img src="${v.thumbnail}" loading="lazy"></div>
            <div class="v-meta">
                <div class="avatar"><img src="foto.jpg"></div>
                <div class="v-text">
                    <h3 style="font-size:14px; font-weight:500;">${v.title}</h3>
                    <p style="font-size:12px; color:#aaa; margin-top:4px;">ZAAMTUBE PREMIUM • 1jt ditonton</p>
                </div>
            </div>
        </div>
    `).join('');
}

// 4. Streaming Logic
function startStream(index) {
    const v = currentVideos[index];
    toggleLoading(true);
    
    setTimeout(() => {
        document.body.classList.add('is-streaming');
        stTitle.innerText = v.title;
        ytPlayer.innerHTML = `<iframe src="https://www.youtube-nocookie.com/embed/${v.videoId}?autoplay=1&rel=0&modestbranding=1" allow="autoplay; encrypted-media" allowfullscreen></iframe>`;
        
        recomList.innerHTML = currentVideos.map((item, idx) => idx !== index ? `
            <div class="recom-card" onclick="startStream(${idx})">
                <div class="recom-thumb"><img src="${item.thumbnail}"></div>
                <div style="flex:1;"><h4 style="font-size:13px; font-weight:500;">${item.title}</h4><p style="font-size:11px; color:#aaa;">ZAAMTUBE PREMIUM</p></div>
            </div>
        ` : '').join('');
        toggleLoading(false);
    }, 600);
}

// 5. Tombol Kembali ke Beranda
document.getElementById('exitStream').onclick = () => {
    toggleLoading(true);
    setTimeout(() => {
        document.body.classList.remove('is-streaming');
        ytPlayer.innerHTML = ''; 
        toggleLoading(false);
    }, 500);
};

// 6. Input Events
searchInput.onkeypress = (e) => {
    if (e.key === 'Enter') {
        fetchVideos(searchInput.value);
        searchInput.blur();
    }
};

document.querySelectorAll('.tag').forEach(tag => {
    tag.onclick = () => {
        document.querySelector('.tag.active').classList.remove('active');
        tag.classList.add('active');
        fetchVideos(tag.dataset.query);
    };
});

// Load awal
fetchVideos('Efootball 2026');
