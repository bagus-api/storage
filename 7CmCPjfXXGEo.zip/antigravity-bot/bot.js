require('dotenv').config();
const { Bot, InlineKeyboard, InputFile } = require('grammy');
const { run: runGrammy } = require('@grammyjs/runner');
const { exec } = require('node:child_process');
const path = require('node:path');
const fs = require('node:fs');
const os = require('node:os');

const { runAgy, abortUserProcess: abortAgyProcess, isUserRunning: isAgyRunning } = require('./agy-runner');
const { runOpenCode, abortOpenCodeProcess, isOpenCodeRunning, AVAILABLE_OPENCODE_MODELS } = require('./opencode-runner');

// Track active agent turns in memory to avoid race conditions and handle instant aborts
const activeUserTurns = new Map();

function isUserRunning(userId) {
  const uId = String(userId);
  return activeUserTurns.has(uId) || isAgyRunning(uId) || isOpenCodeRunning(uId);
}

function abortUserProcess(userId) {
  const uId = String(userId);
  const turn = activeUserTurns.get(uId);
  if (turn) {
    turn.aborted = true;
    if (turn.statusMsg && turn.chatId) {
      try {
        bot.api.deleteMessage(turn.chatId, turn.statusMsg.message_id).catch(() => {});
      } catch (_) {}
    }
    activeUserTurns.delete(uId);
  }
  const agy = abortAgyProcess(uId);
  const oc = abortOpenCodeProcess(uId);
  return agy || oc || Boolean(turn);
}
const {
  getSession,
  updateSession,
  resetSession,
  isAllowed,
  setOwner,
  allowUser,
  disallowUser,
  getConfig
} = require('./session-store');
const {
  getRecentConversations,
  getConversationById,
  getRecentOpenCodeSessions,
  getOpenCodeSessionById
} = require('./conversation-db');
const {
  sendSafeMessage,
  formatToolNotification,
  formatTokens,
  formatMetadataFooter
} = require('./formatter');
const { extractTikTokUrl, getTikTokData, fetchMediaBuffer } = require('./tiktok');
const { extractOuoUrl, extractOuoUrls, solveOuo } = require('./ouo');
const {
  extractVideyUrls,
  resolveVideyMedia,
  fetchMediaBuffer: fetchVideyBuffer,
  formatBytes: formatVideyBytes
} = require('./videy');
const { processRemotionZip } = require('./remotion');
const { startWebAppService, getWebAppUrl } = require('./web-server');
const {
  parseCookies,
  hasGoogleAuthCookies,
  loadSession: loadAisSession,
  saveSession: saveAisSession,
  deleteSession: deleteAisSession,
  verifyAndSaveSession,
  createNewApp,
  listRecentPrompts,
  sendPromptToAIStudio
} = require('./aistudio');

const BOT_TOKEN = process.env.BOT_TOKEN;
if (!BOT_TOKEN) {
  console.error('Error: BOT_TOKEN is required in .env!');
  process.exit(1);
}

const bot = new Bot(BOT_TOKEN);

// List of available models
const AVAILABLE_MODELS = [
  { id: 'gemini-4-argon', label: '🚀 Gemini 4 Argon (Flagship Frontier)' },
  { id: 'gemini-3.8-flash-high', label: '⚡ Gemini 3.8 Flash (High) - Cepat & Cerdas' },
  { id: 'gemini-3.8-flash-medium', label: '⚡ Gemini 3.8 Flash (Medium)' },
  { id: 'gemini-3.8-flash-low', label: '⚡ Gemini 3.8 Flash (Low)' },
  { id: 'claude-sonnet-4-6', label: '🧠 Claude Sonnet 4.6 (Thinking)' },
  { id: 'claude-opus-4-6-thinking', label: '🧠 Claude Opus 4.6 (Thinking)' },
  { id: 'gpt-oss-120b-medium', label: '🤖 GPT-OSS 120B (Medium)' }
];

const AVAILABLE_EFFORTS = [
  { id: 'auto', label: '⚡ Auto (Cepat di chat, Dalam saat coding)' },
  { id: 'low', label: '🟢 Low (Super Cepat, Tanpa Mikir)' },
  { id: 'medium', label: '🟡 Medium (Seimbang)' },
  { id: 'high', label: '🟠 High (Mikir Mendalam)' },
  { id: 'max', label: '🔴 Max (Maksimal Thinking)' }
];
const AVAILABLE_MODES = [
  { id: 'auto', label: '🤖 Auto (Full Agentic + Tools)' },
  { id: 'accept-edits', label: '✏️ Accept Edits' },
  { id: 'plan', label: '📋 Plan Mode (Perencanaan)' }
];

// Helper to check user permission
function checkAuth(ctx) {
  const userId = ctx.from?.id;
  if (!userId) return false;
  return isAllowed(userId);
}

// Security Auth Middleware
bot.use(async (ctx, next) => {
  const userId = ctx.from?.id;
  if (!userId) return;

  const config = getConfig();
  // Auto-register first user as Owner
  if (!config.ownerId && (!config.allowedUsers || config.allowedUsers.length === 0)) {
    setOwner(userId);
    console.log(`[AUTH] User ${userId} (${ctx.from.username || ctx.from.first_name}) registered as OWNER.`);
  }

  if (!checkAuth(ctx)) {
    if (ctx.message?.text?.startsWith('/id')) {
      return ctx.reply(`🆔 ID Telegram Anda: \`${userId}\``, { parse_mode: 'Markdown' });
    }
    return ctx.reply(
      `⛔ *Akses Ditolak*\n\nBot Antigravity ini terhubung ke VPS server dan diproteksi demi keamanan.\n\nID Anda: \`${userId}\`\nHubungi pemilik server untuk menambahkan ID Anda.`,
      { parse_mode: 'Markdown' }
    );
  }

  return next();
});

/**
 * Render Main Menu (Sleek, Simple HTML format with WebApp App)
 */
function renderMainMenu(userId, firstName = 'User') {
  const session = getSession(userId);
  const config = getConfig();
  const isOwner = String(config.ownerId) === String(userId);
  const webAppUrl = getWebAppUrl();
  const engine = session.engine || 'antigravity';
  const isOpencode = engine === 'opencode';
  const engineLabel = isOpencode ? 'OpenCode 💻' : 'Antigravity 🤖';
  const activeModel = isOpencode
    ? (session.opencodeModel || 'opencode/deepseek-v4.1-flash-free').replace('opencode/', '')
    : session.model;
  const activeSessionId = isOpencode ? session.opencodeSessionId : session.conversationId;

  const text =
    `⚡ <b>NANASMUDA CONTROL PANEL</b>\n` +
    `<i>Interactive Terminal &amp; Dual AI Agent</i>\n\n` +
    `<blockquote>⚙️ <b>Engine Aktif:</b> <b>${engineLabel}</b>\n` +
    `🧠 <b>Model Aktif:</b> <code>${escapeHtml(activeModel)}</code>\n` +
    `💬 <b>Sesi Aktif:</b> <code>${activeSessionId ? activeSessionId.slice(0, 16) + '...' : 'Belum ada (Sesi Baru)'}</code>\n` +
    `👤 <b>User:</b> <b>${escapeHtml(firstName)}</b> ${isOwner ? '👑' : ''}</blockquote>\n\n` +
    `<blockquote>💡 <b>AI Prompt:</b> Gunakan <code>/ai &lt;pesan&gt;</code> untuk engine aktif (${engineLabel}).\n` +
    `<i>Atau gunakan <code>/oc &lt;pesan&gt;</code> langsung ke OpenCode.</i></blockquote>`;

  const keyboard = new InlineKeyboard();

  if (webAppUrl) {
    keyboard.webApp('🌐 Buka Menu (HTML WebApp)', webAppUrl).row();
  }

  keyboard.text(`⚙️ Engine: ${engineLabel}`, 'menu_engine_select').row();

  if (isOpencode) {
    keyboard
      .text('💻 Tanya OpenCode (/oc)', 'menu_ai_guide')
      .text('🛠️ Tools (Videy, TT, OuO)', 'menu_tools').row()
      .text('🧠 Model OpenCode', 'btn_model_oc')
      .text('📋 Resume Sesi OpenCode', 'btn_resume_oc').row()
      .text('➕ Sesi Baru OpenCode', 'btn_new_oc')
      .text('🤖 Switch ke Antigravity', 'set_engine_antigravity').row()
      .text('✨ Google AI Studio', 'menu_ais_dashboard').row()
      .text('🖥️ Spek VPS', 'btn_spek_menu')
      .text('📦 Backup ZIP', 'menu_backup_action').row()
      .text('🔄 Refresh', 'menu_refresh');
  } else {
    keyboard
      .text('🤖 Tanya AI (/ai)', 'menu_ai_guide')
      .text('🛠️ Tools (Videy, TT, OuO)', 'menu_tools').row()
      .text('🧠 Ganti Model', 'btn_model')
      .text('📋 Resume Sesi', 'btn_resume').row()
      .text('➕ Sesi Baru', 'btn_new')
      .text('🎯 Atur Effort', 'menu_effort').row()
      .text('💻 Switch ke OpenCode', 'set_engine_opencode').row()
      .text('✨ Google AI Studio', 'menu_ais_dashboard').row()
      .text('🖥️ Spek VPS', 'btn_spek_menu')
      .text('📦 Backup ZIP', 'menu_backup_action').row()
      .text('🔄 Refresh', 'menu_refresh');
  }

  return { text, keyboard };
}

/**
 * Render Engine Selection Menu (Antigravity vs OpenCode)
 */
function renderEngineMenu(userId) {
  const session = getSession(userId);
  const currentEngine = session.engine || 'antigravity';
  const ocModel = (session.opencodeModel || 'opencode/deepseek-v4.1-flash-free').replace('opencode/', '');
  const agyModel = session.model;

  const text =
    `⚙️ <b>PILIH AI ENGINE &amp; PENGATURAN</b>\n` +
    `━━━━━━━━━━━━━━━━━━━━━━━━━\n\n` +
    `Pilih engine aktif untuk memproses perintah <code>/ai &lt;pesan&gt;</code>:\n\n` +
    `🤖 <b>1. Antigravity AI (agy):</b>\n` +
    `• Model: <code>${agyModel}</code>\n` +
    `• Berbasis Google Gemini &amp; Claude dengan tools sistem lengkap.\n` +
    `• Status: ${currentEngine === 'antigravity' ? '✅ <b>AKTIF</b>' : '⚪ Standby'}\n\n` +
    `💻 <b>2. OpenCode AI (opencode):</b>\n` +
    `• Model: <code>${ocModel}</code>\n` +
    `• Agent coding terminal open-source, cepat &amp; multi-turn session.\n` +
    `• Status: ${currentEngine === 'opencode' ? '✅ <b>AKTIF</b>' : '⚪ Standby'}\n\n` +
    `💡 <i>Gunakan tombol di bawah untuk ganti engine, pilih model, atau kelola sesi masing-masing AI.</i>`;

  const keyboard = new InlineKeyboard()
    .text(currentEngine === 'antigravity' ? '✅ 🤖 Antigravity AI' : '🤖 Antigravity AI', 'set_engine_antigravity')
    .text(currentEngine === 'opencode' ? '✅ 💻 OpenCode AI' : '💻 OpenCode AI', 'set_engine_opencode').row()
    .text('🧠 Model Antigravity', 'btn_model_agy')
    .text('🧠 Model OpenCode', 'btn_model_oc').row()
    .text('📋 Sesi Antigravity', 'btn_resume_agy')
    .text('📋 Sesi OpenCode', 'btn_resume_oc').row()
    .text('⬅️ Kembali ke Dashboard', 'menu_main');

  return { text, keyboard };
}

/**
 * Render Model Selection Menu (Supports both Antigravity & OpenCode)
 */
function renderModelMenu(userId, targetEngine = null) {
  const session = getSession(userId);
  const engine = targetEngine || session.engine || 'antigravity';
  const keyboard = new InlineKeyboard();

  if (engine === 'opencode') {
    const curModel = session.opencodeModel || 'opencode/deepseek-v4.1-flash-free';
    const text =
      `💻 <b>PILIH MODEL OPENCODE AI</b>\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━━\n\n` +
      `Model OpenCode aktif: <code>${escapeHtml(curModel)}</code>\n\n` +
      `Pilih model OpenCode gratis yang ingin digunakan:`;

    AVAILABLE_OPENCODE_MODELS.forEach((m) => {
      const isCurrent = m.id === curModel;
      const label = `${isCurrent ? '✅ ' : ''}${m.label}`;
      keyboard.text(label, `ocmodel_${m.id}`).row();
    });

    keyboard
      .text('🤖 Beralih ke Model Antigravity', 'btn_model_agy').row()
      .text('⬅️ Kembali ke Dashboard', 'menu_main');

    return { text, keyboard, engine };
  } else {
    const curModel = session.model;
    const text =
      `🧠 <b>PILIH MODEL ANTIGRAVITY AI</b>\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━━\n\n` +
      `Model Antigravity aktif: <code>${escapeHtml(curModel)}</code>\n\n` +
      `Pilih model Antigravity (Google Gemini / Claude / GPT):`;

    AVAILABLE_MODELS.forEach((m) => {
      const isCurrent = m.id === curModel;
      const label = `${isCurrent ? '✅ ' : ''}${m.label}`;
      keyboard.text(label, `model_${m.id}`).row();
    });

    keyboard
      .text('💻 Beralih ke Model OpenCode', 'btn_model_oc').row()
      .text('⬅️ Kembali ke Dashboard', 'menu_main');

    return { text, keyboard, engine };
  }
}

/**
 * Render Resume Session Menu (Supports both Antigravity & OpenCode)
 */
function renderResumeMenu(userId, targetEngine = null) {
  const session = getSession(userId);
  const engine = targetEngine || session.engine || 'antigravity';
  const keyboard = new InlineKeyboard();

  if (engine === 'opencode') {
    const recents = getRecentOpenCodeSessions(8);
    if (!recents.length) {
      const text =
        `📭 <b>Belum ada riwayat sesi OpenCode di database VPS.</b>\n\n` +
        `Kirim prompt via <code>/oc &lt;pesan&gt;</code> untuk memulai sesi OpenCode pertama Anda!`;
      keyboard
        .text('🤖 Lihat Sesi Antigravity', 'btn_resume_agy').row()
        .text('⬅️ Kembali ke Dashboard', 'menu_main');
      return { text, keyboard, engine };
    }

    let text =
      `📋 <b>PILIH SESI OPENCODE UNTUK DI-RESUME</b>\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━━\n\n` +
      `Sesi OpenCode aktif saat ini:\n<code>${session.opencodeSessionId || 'Belum ada (Sesi Baru)'}</code>\n\n` +
      `Pilih sesi sebelumnya:\n\n`;

    recents.forEach((item, idx) => {
      const num = idx + 1;
      const title = item.title || 'Percakapan OpenCode';
      const isCur = session.opencodeSessionId === item.id;
      const marker = isCur ? '✅ ' : '';
      text += `<b>${num}.</b> ${marker}<b>${escapeHtml(title)}</b>\n   🆔 <code>${item.id}</code>\n\n`;
      keyboard.text(`${num}. ${title.slice(0, 18)}`, `ocresume_${item.id}`);
      if (num % 2 === 0) keyboard.row();
    });

    if (recents.length % 2 !== 0) keyboard.row();

    keyboard
      .text('🤖 Lihat Sesi Antigravity', 'btn_resume_agy').row()
      .text('⬅️ Kembali ke Dashboard', 'menu_main');

    return { text, keyboard, engine };
  } else {
    const recents = getRecentConversations(8);
    if (!recents.length) {
      const text =
        `📭 <b>Belum ada riwayat sesi Antigravity di database VPS.</b>\n\n` +
        `Kirim prompt via <code>/ai &lt;pesan&gt;</code> untuk memulai sesi Antigravity!`;
      keyboard
        .text('💻 Lihat Sesi OpenCode', 'btn_resume_oc').row()
        .text('⬅️ Kembali ke Dashboard', 'menu_main');
      return { text, keyboard, engine };
    }

    let text =
      `📋 <b>PILIH SESI ANTIGRAVITY UNTUK DI-RESUME</b>\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━━\n\n` +
      `Sesi Antigravity aktif saat ini:\n<code>${session.conversationId || 'Belum ada (Sesi Baru)'}</code>\n\n` +
      `Pilih sesi sebelumnya:\n\n`;

    recents.forEach((item, idx) => {
      const num = idx + 1;
      const title = item.title || item.preview || 'Percakapan Tanpa Judul';
      const isCur = session.conversationId === item.conversation_id;
      const marker = isCur ? '✅ ' : '';
      text += `<b>${num}.</b> ${marker}<b>${escapeHtml(title)}</b>\n   🆔 <code>${item.conversation_id.slice(0, 8)}...</code> • ${item.step_count || 0} turn\n\n`;
      keyboard.text(`${num}. ${title.slice(0, 18)}`, `resume_${item.conversation_id}`);
      if (num % 2 === 0) keyboard.row();
    });

    if (recents.length % 2 !== 0) keyboard.row();

    keyboard
      .text('💻 Lihat Sesi OpenCode', 'btn_resume_oc').row()
      .text('⬅️ Kembali ke Dashboard', 'menu_main');

    return { text, keyboard, engine };
  }
}

/**
 * Render Google AI Studio Dashboard
 */
function renderAisMenu(userId) {
  const session = loadAisSession(userId);
  const webAppUrl = getWebAppUrl();

  if (!session) {
    const kb = new InlineKeyboard()
      .text('🔐 Login Sekarang (/loginais)', 'action_ais_start_login').row()
      .text('📋 Script Bookmarklet', 'action_ais_bookmarklet').row()
      .text('⬅️ Menu Utama', 'action_ais_back_main');

    return {
      text:
        `✨ <b>GOOGLE AI STUDIO DASHBOARD</b>\n` +
        `━━━━━━━━━━━━━━━━━━━━━━━━━\n\n` +
        `⚠️ <b>Akun Google AI Studio Belum Terhubung</b>\n\n` +
        `Anda belum menghubungkan akun Google AI Studio ke bot ini.\n` +
        `Dengan menghubungkan akun, Anda dapat:\n` +
        `• Membuat chat / prompt baru di <code>aistudio.google.com</code>\n` +
        `• Melanjutkan (resume) prompt yang tersimpan di library\n` +
        `• Mengambil preview link prompt\n` +
        `• Chat real-time langsung di akun sendiri tanpa API key!\n\n` +
        `Ketik <code>/loginais</code> atau klik tombol di bawah untuk panduan login.`,
      keyboard: kb
    };
  }

  const promptTitle = session.activePromptTitle || 'New Chat';
  const promptUrl = session.activePromptUrl || 'https://aistudio.google.com/prompts/new_chat';
  const currentModel = session.model || 'gemini-3.5-flash';
  const currentMode = session.mode === 'web' ? '🌐 Web Playground (Google One PRO)' : '⚡ Direct API (Fast & Unlimited)';

  const text =
    `✨ <b>GOOGLE AI STUDIO DASHBOARD</b>\n` +
    `<i>Real-Time Session Controller</i>\n` +
    `━━━━━━━━━━━━━━━━━━━━━━━━━\n\n` +
    `👤 <b>Akun:</b> <code>${escapeHtml(session.email)}</code>\n` +
    `🎛️ <b>Mode Eksekusi:</b> <b>${currentMode}</b>\n` +
    `🚀 <b>Model AIS:</b> <code>${escapeHtml(currentModel)}</code>\n` +
    `📝 <b>Prompt Aktif:</b> <b>${escapeHtml(promptTitle)}</b>\n` +
    `🔗 <b>URL:</b> <code>${escapeHtml(promptUrl)}</code>\n` +
    `⏱️ <b>Terakhir Aktif:</b> <code>${new Date(session.lastActivity || session.updatedAt || Date.now()).toLocaleTimeString('id-ID')}</code>\n\n` +
    `<blockquote>💡 <b>Chat AI Studio:</b> Ketik <code>/ais &lt;prompt&gt;</code> untuk mengirim pesan ke playground real-time.</blockquote>`;

  const keyboard = new InlineKeyboard()
    .text(`🎛️ Ganti Mode (${session.mode === 'web' ? 'Ke API' : 'Ke Web'})`, 'action_ais_toggle_mode').row()
    .text('🚀 Ganti Model AIS', 'action_ais_select_model')
    .text('⚡ Chat Prompt (/ais)', 'action_ais_chat').row()
    .text('💬 New App / Chat', 'action_ais_new')
    .text('📂 Resume Prompts', 'action_ais_resume').row()
    .text('🔗 Link Preview', 'action_ais_preview').row();

  if (promptUrl && promptUrl.startsWith('http')) {
    keyboard.url('🌐 Buka Prompt di Browser', promptUrl).row();
  }

  keyboard
    .text('🔄 Refresh Status', 'action_ais_status')
    .text('🚪 Logout AIS', 'action_ais_logout').row()
    .text('⬅️ Menu Utama', 'action_ais_back_main');

  return { text, keyboard };
}

/**
 * Edit message or caption safely (supports both photo & text messages)
 */
async function editSafeMessageOrCaption(ctx, text, extra = {}) {
  try {
    if (ctx.callbackQuery?.message?.photo) {
      await ctx.editMessageCaption({
        caption: text.slice(0, 1024),
        parse_mode: 'HTML',
        ...extra
      });
      return;
    }
    await ctx.editMessageText(text, {
      parse_mode: 'HTML',
      ...extra
    });
  } catch (err) {
    if (!err.message?.includes('message is not modified')) {
      console.warn('Failed editing message or caption:', err.message);
    }
  }
}

// Command: /menu and /start (Rich HTML Dashboard)
bot.command(['menu', 'start'], async (ctx) => {
  const { text, keyboard } = renderMainMenu(ctx.from.id, ctx.from.first_name);
  await ctx.reply(text, { parse_mode: 'HTML', reply_markup: keyboard });
});

/**
 * Helper to extract prompt text, including replied message text or downloaded media note
 */
async function extractPromptFromMessage(ctx) {
  let prompt = ctx.match?.trim() || '';
  const replyMsg = ctx.message?.reply_to_message;

  if (!replyMsg) {
    return prompt;
  }

  const downloadDir = path.join(getSession(ctx.from.id).cwd, 'telegram_uploads');
  if (!fs.existsSync(downloadDir)) {
    fs.mkdirSync(downloadDir, { recursive: true });
  }

  if (replyMsg.document) {
    try {
      const file = await ctx.api.getFile(replyMsg.document.file_id);
      const fileName = replyMsg.document.file_name || `doc_${Date.now()}.bin`;
      const localFilePath = path.join(downloadDir, fileName);
      const fileUrl = `https://api.telegram.org/file/bot${BOT_TOKEN}/${file.file_path}`;
      const res = await fetch(fileUrl);
      if (res.ok) {
        const ab = await res.arrayBuffer();
        fs.writeFileSync(localFilePath, Buffer.from(ab));
        const fileNote = `\n\n[File dari pesan yang di-reply tersimpan di: ${localFilePath}]`;
        prompt = prompt ? `${prompt}${fileNote}` : `Analisis dan bantu proses file ini:${fileNote}`;
      }
    } catch (e) {
      console.error('Failed downloading replied document:', e);
    }
  } else if (replyMsg.photo && replyMsg.photo.length > 0) {
    try {
      const photo = replyMsg.photo[replyMsg.photo.length - 1];
      const file = await ctx.api.getFile(photo.file_id);
      const localFilePath = path.join(downloadDir, `photo_${Date.now()}.jpg`);
      const fileUrl = `https://api.telegram.org/file/bot${BOT_TOKEN}/${file.file_path}`;
      const res = await fetch(fileUrl);
      if (res.ok) {
        const ab = await res.arrayBuffer();
        fs.writeFileSync(localFilePath, Buffer.from(ab));
        const fileNote = `\n\n[Foto dari pesan yang di-reply tersimpan di: ${localFilePath}]`;
        prompt = prompt ? `${prompt}${fileNote}` : `Analisis foto ini:${fileNote}`;
      }
    } catch (e) {
      console.error('Failed downloading replied photo:', e);
    }
  } else if (replyMsg.text) {
    prompt = prompt ? `${prompt}\n\n[Pesan yang di-reply]:\n${replyMsg.text}` : replyMsg.text;
  }

  return prompt;
}

// Command: /ai (AI Agent execution based on active engine)
bot.command('ai', async (ctx) => {
  const prompt = await extractPromptFromMessage(ctx);
  const session = getSession(ctx.from.id);
  const engine = session.engine || 'antigravity';
  const engineLabel = engine === 'opencode' ? 'OpenCode 💻' : 'Antigravity 🤖';

  if (!prompt) {
    return ctx.reply(
      `🤖 <b>AI Coding &amp; Assistant Agent</b>\n\n` +
      `<blockquote>⚙️ <b>Engine Aktif:</b> <b>${engineLabel}</b>\n` +
      `Kirim pertanyaan atau instruksi coding dengan format:\n` +
      `<code>/ai &lt;instruksi Anda&gt;</code>\n\n` +
      `<b>Tips Dual AI:</b>\n` +
      `• Ganti engine utama: <code>/engine</code>\n` +
      `• Direct OpenCode: <code>/oc &lt;pesan&gt;</code>\n\n` +
      `<b>Contoh:</b>\n` +
      `<code>/ai buatkan bot telegram nodejs</code>\n` +
      `<code>/ai analisis error berikut: [paste error]</code></blockquote>`,
      { parse_mode: 'HTML' }
    );
  }

  handleAgentTurn(ctx, prompt).catch((err) => {
    console.error('Unhandled error in handleAgentTurn:', err);
  });
});

// Command: /oc and /opencode (Direct OpenCode AI execution)
bot.command(['oc', 'opencode'], async (ctx) => {
  const prompt = await extractPromptFromMessage(ctx);

  if (!prompt) {
    return ctx.reply(
      `💻 <b>OpenCode AI Agent</b>\n\n` +
      `<blockquote>Kirim pertanyaan atau instruksi coding langsung ke OpenCode:\n` +
      `<code>/oc &lt;instruksi Anda&gt;</code>\n\n` +
      `<b>Contoh:</b>\n` +
      `<code>/oc buatkan endpoint express js</code>\n` +
      `<code>/oc refactor fungsi login ini</code></blockquote>`,
      { parse_mode: 'HTML' }
    );
  }

  handleAgentTurn(ctx, prompt, 'opencode').catch((err) => {
    console.error('Unhandled error in handleAgentTurn:', err);
  });
});

// Command: /engine (Switch AI Engine: Antigravity vs OpenCode)
bot.command(['engine', 'aiengine'], async (ctx) => {
  const target = ctx.match?.trim().toLowerCase();
  const userId = ctx.from.id;

  if (target) {
    if (['opencode', 'oc', 'open'].includes(target)) {
      updateSession(userId, { engine: 'opencode' });
      return ctx.reply(
        `✅ Engine AI berhasil diubah ke: <b>OpenCode 💻</b>\n\n` +
        `Sekarang perintah <code>/ai &lt;pesan&gt;</code> akan diproses menggunakan OpenCode Agent.`,
        { parse_mode: 'HTML' }
      );
    } else if (['antigravity', 'agy', 'anti', 'gemini'].includes(target)) {
      updateSession(userId, { engine: 'antigravity' });
      return ctx.reply(
        `✅ Engine AI berhasil diubah ke: <b>Antigravity 🤖</b>\n\n` +
        `Sekarang perintah <code>/ai &lt;pesan&gt;</code> akan diproses menggunakan Antigravity Agent.`,
        { parse_mode: 'HTML' }
      );
    } else {
      return ctx.reply(
        `⚠️ Pilihan engine tidak valid. Gunakan:\n` +
        `• <code>/engine agy</code> — Antigravity AI\n` +
        `• <code>/engine opencode</code> — OpenCode AI`,
        { parse_mode: 'HTML' }
      );
    }
  }

  const { text, keyboard } = renderEngineMenu(userId);
  await ctx.reply(text, { parse_mode: 'HTML', reply_markup: keyboard });
});

// Command: /help
bot.command('help', async (ctx) => {
  const helpText =
    `🛠️ <b>Daftar Perintah NanasMuda Bot</b>\n` +
    `━━━━━━━━━━━━━━━━━━━━━\n\n` +
    `🤖 <b>AI Assistant (Dual Engine):</b>\n` +
    `• <code>/ai &lt;pesan&gt;</code> — Tanya AI sesuai engine aktif (Antigravity / OpenCode).\n` +
    `• <code>/oc &lt;pesan&gt;</code> — Tanya langsung ke OpenCode AI (instan tanpa ubah engine).\n` +
    `• <code>/engine [agy|opencode]</code> — Ganti engine AI utama (/ai).\n` +
    `• <code>/stop</code> atau <code>/abort</code> — Hentikan paksa perintah AI yang sedang berjalan (ESC).\n` +
    `• <code>/new [prompt]</code> — Reset sesi percakapan baru (sesuai engine aktif).\n` +
    `• <code>/ocnew [prompt]</code> — Reset sesi baru khusus OpenCode.\n` +
    `• <code>/resume [id]</code> — Lanjutkan sesi sebelumnya (Antigravity / OpenCode).\n` +
    `• <code>/ocresume [id]</code> — Lanjutkan sesi khusus OpenCode.\n\n` +
    `✨ <b>Google AI Studio (Tanpa API Key):</b>\n` +
    `• <code>/menuais</code> — Buka dashboard AI Studio (New App, Resume, Link Preview).\n` +
    `• <code>/loginais [cookies]</code> — Login sesi Google AI Studio real-time.\n` +
    `• <code>/ais &lt;pesan&gt;</code> — Chat langsung ke playground Google AI Studio Anda.\n\n` +
    `📥 <b>Media &amp; Link Tools:</b>\n` +
    `• <code>/remotion</code> — Render video dari file ZIP project Remotion (otomatis hapus file &amp; disk aman).\n` +
    `• <code>/videy &lt;url...&gt;</code> — Ekstrak direct link video Videy &amp; Videyfile (bulk support, instan tanpa download video).\n` +
    `• <code>/tt &lt;url&gt;</code> — Download video TikTok tanpa watermark &amp; MP3.\n` +
    `• <code>/ouo &lt;url...&gt;</code> — Solver / Bypass shortlink OuO (ouo.io &amp; ouo.press, bulk support).\n\n` +
    `⚙️ <b>Pengaturan & Model:</b>\n` +
    `• <code>/menu</code> — Tampilkan Dashboard Kontrol Utama.\n` +
    `• <code>/engine</code> — Pilih AI Engine (Antigravity 🤖 / OpenCode 💻).\n` +
    `• <code>/model [nama]</code> — Ganti model AI (sesuai engine aktif).\n` +
    `• <code>/ocmodel [nama]</code> — Ganti model khusus OpenCode.\n` +
    `• <code>/effort</code> — Atur tingkat reasoning effort (Auto, Low, High, Max).\n` +
    `• <code>/mode</code> — Atur mode eksekusi (Auto, Plan, Accept-Edits).\n` +
    `• <code>/usage</code> — Cek statistik penggunaan token.\n` +
    `• <code>/status</code> — Cek ringkasan sistem & sesi.\n\n` +
    `💻 <b>VPS & Project:</b>\n` +
    `• <code>/backup</code> — Buat file backup ZIP bot & dapatkan link download.\n` +
    `• <code>/cd &lt;path&gt;</code> — Pindah direktori kerja di VPS.\n` +
    `• <code>/pwd</code> — Cek folder kerja saat ini.\n` +
    `• <code>/bash &lt;cmd&gt;</code> — Eksekusi perintah bash langsung di VPS.`;

  await ctx.reply(helpText, {
    parse_mode: 'HTML',
    reply_parameters: { message_id: ctx.message.message_id }
  });
});

// Command: /menuais (Google AI Studio Dashboard)
bot.command('menuais', async (ctx) => {
  const { text, keyboard } = renderAisMenu(ctx.from.id);
  await ctx.reply(text, {
    parse_mode: 'HTML',
    reply_markup: keyboard,
    reply_parameters: { message_id: ctx.message.message_id }
  });
});

// Command: /loginais & /setkey (Login to Google AI Studio via cookies or free API key)
bot.command(['loginais', 'setkey'], async (ctx) => {
  const match = ctx.match?.trim() || '';

  if (match) {
    ctx.react('🔐').catch(() => {});
    const statusMsg = await ctx.reply('⏳ *Memverifikasi kredensial Google AI Studio Anda...*', {
      parse_mode: 'Markdown',
      reply_parameters: { message_id: ctx.message.message_id }
    });

    const result = await verifyAndSaveSession(ctx.from.id, match);
    try { await ctx.api.deleteMessage(ctx.chat.id, statusMsg.message_id); } catch (_) {}

    if (result.success) {
      const keyboard = new InlineKeyboard()
        .text('📱 Buka Menu AI Studio (/menuais)', 'action_ais_menu')
        .row()
        .text('💬 New App / Chat', 'action_ais_new')
        .text('📂 Resume Prompts', 'action_ais_resume');

      const title = result.isApiKey ? 'Google AI Studio Terhubung via API Key!' : 'Login Google AI Studio Berhasil!';
      return ctx.reply(
        `✅ <b>${title}</b>\n\n` +
        `👤 <b>Akun:</b> <code>${escapeHtml(result.email)}</code>\n` +
        `🌐 <b>Status:</b> Terhubung real-time ke Google AI Studio\n` +
        `⚡ <b>Model:</b> <code>Gemini 2.0 Flash</code>\n\n` +
        `Gunakan perintah <code>/menuais</code> untuk mengontrol prompt atau ketik <code>/ais &lt;prompt&gt;</code> untuk langsung bertanya.`,
        {
          parse_mode: 'HTML',
          reply_parameters: { message_id: ctx.message.message_id },
          reply_markup: keyboard
        }
      );
    } else {
      return ctx.reply(
        `❌ <b>Gagal Menghubungkan Google AI Studio:</b>\n\n<blockquote>${escapeHtml(result.error)}</blockquote>\n\n` +
        `💡 <b>Cara Termudah di Android:</b>\n` +
        `1. Buka <code>https://aistudio.google.com/app/apikey</code> di Chrome Android.\n` +
        `2. Tap <b>Create API key</b> ➔ salin kuncinya (<code>AIzaSy...</code>).\n` +
        `3. Kirim ke bot ini: <code>/setkey &lt;kunci&gt;</code>.\n` +
        `<i>(100% Gratis, tanpa kartu kredit, dan langsung terhubung ke akun Anda!)</i>`,
        {
          parse_mode: 'HTML',
          reply_parameters: { message_id: ctx.message.message_id }
        }
      );
    }
  }

  // If no argument, show instructions and options
  const session = loadAisSession(ctx.from.id);
  const webAppUrl = getWebAppUrl();
  const keyboard = new InlineKeyboard();

  if (webAppUrl) {
    keyboard.webApp('🌐 Login via WebApp', `${webAppUrl}#aistudio`).row();
  }

  keyboard
    .text('📋 Salin Script Bookmarklet', 'action_ais_bookmarklet').row();

  if (session) {
    keyboard.text('📱 Buka Dashboard (/menuais)', 'action_ais_menu').row();
  }
  keyboard.text('⬅️ Menu Utama', 'action_ais_back_main');

  const statusText = session
    ? `🟢 <b>Status Saat Ini:</b> Terhubung sebagai <code>${escapeHtml(session.email)}</code>`
    : `⚪ <b>Status Saat Ini:</b> Belum Login`;

  return ctx.reply(
    `🔐 <b>Login Google AI Studio (Real-Time Tanpa API Key)</b>\n` +
    `━━━━━━━━━━━━━━━━━━━━━━━━━\n\n` +
    `${statusText}\n\n` +
    `Bot ini dapat terhubung langsung ke akun Google AI Studio pribadi Anda (<code>aistudio.google.com</code>) tanpa membutuhkan setup API key atau kartu kredit.\n\n` +
    `<b>Cara Menghubungkan Akun:</b>\n\n` +
    `1️⃣ <b>Kirim File Cookies (Paling Mudah):</b>\n` +
    `• Pasang ekstensi <i>Cookie-Editor</i> di browser Chrome/Edge/Firefox.\n` +
    `• Buka <code>https://aistudio.google.com</code> (pastikan sudah login).\n` +
    `• Buka Cookie-Editor &gt; Klik <b>Export</b> &gt; <b>Export as JSON</b>.\n` +
    `• Kirim file <code>cookies.json</code> tersebut ke chat bot ini!\n\n` +
    `2️⃣ <b>Via Perintah Langsung:</b>\n` +
    `Ketik format:\n` +
    `<code>/loginais &lt;paste cookie json atau string&gt;</code>\n\n` +
    `3️⃣ <b>Via Console (1-Klik Salin):</b>\n` +
    `Buka tab <code>aistudio.google.com</code> &gt; tekan <code>F12</code> &gt; Console &gt; ketik:\n` +
    `<code>copy(document.cookie)</code> lalu kirim ke bot: <code>/loginais &lt;paste&gt;</code>.`,
    {
      parse_mode: 'HTML',
      reply_markup: keyboard,
      reply_parameters: { message_id: ctx.message.message_id }
    }
  );
});

// Command: /ais (Chat directly via Google AI Studio real-time session)
bot.command('ais', async (ctx) => {
  const prompt = ctx.match?.trim() || '';
  const userId = ctx.from.id;
  const session = loadAisSession(userId);

  if (!session) {
    return ctx.reply(
      `⚠️ <b>Belum Terhubung ke Google AI Studio!</b>\n\n` +
      `Silakan hubungkan akun Google Anda terlebih dahulu dengan perintah:\n` +
      `<code>/loginais</code>`,
      { parse_mode: 'HTML', reply_parameters: { message_id: ctx.message.message_id } }
    );
  }

  if (!prompt) {
    return ctx.reply(
      `💬 <b>Google AI Studio Real-Time Chat</b>\n\n` +
      `Kirim pesan ke playground AI Studio dengan format:\n` +
      `<code>/ais &lt;pesan Anda&gt;</code>\n\n` +
      `<b>Contoh:</b>\n` +
      `<code>/ais buatkan puisi tentang senja di pantai</code>\n` +
      `<code>/ais jelaskan konsep microservices</code>`,
      { parse_mode: 'HTML', reply_parameters: { message_id: ctx.message.message_id } }
    );
  }

  ctx.react('⚡').catch(() => {});
  ctx.replyWithChatAction('typing').catch(() => {});
  const typingTimer = setInterval(() => {
    ctx.replyWithChatAction('typing').catch(() => {});
  }, 3500);

  let statusMsg = await ctx.reply('⚡ *Menghubungkan ke Google AI Studio playground...*', {
    parse_mode: 'Markdown',
    reply_parameters: { message_id: ctx.message.message_id }
  });

  const updateStatus = async (txt) => {
    try {
      await ctx.api.editMessageText(ctx.chat.id, statusMsg.message_id, `⚡ *AI Studio:* ${txt}`, {
        parse_mode: 'Markdown'
      });
    } catch (_) {}
  };

  const startTime = Date.now();
  const result = await sendPromptToAIStudio(userId, prompt, (status) => updateStatus(status));

  clearInterval(typingTimer);
  try { await ctx.api.deleteMessage(ctx.chat.id, statusMsg.message_id); } catch (_) {}

  if (!result.success) {
    return ctx.reply(`❌ <b>Gagal di AI Studio:</b>\n\n${result.error}`, {
      parse_mode: 'HTML',
      reply_parameters: { message_id: ctx.message.message_id },
      link_preview_options: { is_disabled: false }
    });
  }

  const duration = ((Date.now() - startTime) / 1000).toFixed(1);
  const footer = `\n\n────────────────\n🌐 *Google AI Studio* • ⏱️ \`${duration}s\` • [Buka Prompt](${result.url})`;
  const fullText = result.text + footer;

  await sendSafeMessage(ctx, fullText, {
    reply_parameters: { message_id: ctx.message.message_id }
  });
});

// Command: /aismode (Switch between API Key and Web Playground mode)
bot.command('aismode', async (ctx) => {
  const userId = ctx.from.id;
  const session = loadAisSession(userId);
  if (!session) {
    return ctx.reply('⚠️ Anda belum menghubungkan akun Google AI Studio. Ketik /loginais terlebih dahulu.', {
      reply_parameters: { message_id: ctx.message.message_id }
    });
  }

  const target = ctx.match?.trim()?.toLowerCase();
  let newMode;
  if (target === 'api' || target === 'web') {
    newMode = target;
  } else {
    newMode = session.mode === 'web' ? 'api' : 'web';
  }

  saveAisSession(userId, { mode: newMode });
  const label = newMode === 'web' ? '🌐 Web Playground (Google One PRO Session)' : '⚡ Direct API Key (Fast & Unlimited)';
  return ctx.reply(
    `✅ <b>Mode AI Studio berhasil dialihkan ke:</b>\n<b>${label}</b>\n\n` +
    `• <b>Web Playground:</b> Cocok untuk <code>gemini-4-argon</code> dengan akun Google One PRO.\n` +
    `• <b>Direct API:</b> Super cepat (~1s) & bebas kuota untuk <code>gemini-3.5-flash</code>.\n\n` +
    `Ketik <code>/ais &lt;pesan&gt;</code> untuk mulai bertanya atau <code>/modelais</code> untuk memilih model.`,
    {
      parse_mode: 'HTML',
      reply_parameters: { message_id: ctx.message.message_id }
    }
  );
});

// Command: /modelais (Change Google AI Studio model)
bot.command(['modelais', 'aismodel'], async (ctx) => {
  const userId = ctx.from.id;
  const session = loadAisSession(userId);
  if (!session) {
    return ctx.reply('⚠️ Anda belum menghubungkan akun Google AI Studio. Ketik /loginais terlebih dahulu.', {
      reply_parameters: { message_id: ctx.message.message_id }
    });
  }

  const AIS_MODELS = [
    { id: 'gemini-3.5-flash', label: '⚡ Gemini 3.5 Flash (Cerdas + Reasoning, Cepat ~2s) [Rekomendasi]' },
    { id: 'gemini-3.5-flash-lite', label: '🚀 Gemini 3.5 Flash Lite (Super Cepat <1s, Ringan)' },
    { id: 'gemini-4-argon', label: '🪐 Gemini 4 Argon (Frontier Flagship - Khusus Web Playground PRO)' },
    { id: 'gemini-3.8-flash', label: '⚡ Gemini 3.8 Flash (Multimodal Enterprise)' }
  ];

  const target = ctx.match?.trim();
  if (target) {
    const found = AIS_MODELS.find(m => m.id === target || m.id.toLowerCase().includes(target.toLowerCase()));
    const chosen = found ? found.id : target;
    saveAisSession(userId, { model: chosen });
    return ctx.reply(`✅ <b>Model Google AI Studio berhasil diubah ke:</b>\n<code>${escapeHtml(chosen)}</code>\n\nPrompt berikutnya via <code>/ais</code> akan menggunakan model ini.`, {
      parse_mode: 'HTML',
      reply_parameters: { message_id: ctx.message.message_id }
    });
  }

  const keyboard = new InlineKeyboard();
  AIS_MODELS.forEach(m => {
    const isCurrent = (session.model || 'gemini-3.5-flash') === m.id;
    keyboard.text(`${isCurrent ? '✓ ' : ''}${m.label}`, `ais_model_${m.id}`).row();
  });

  return ctx.reply(
    `🧠 <b>Pilih Model Google AI Studio:</b>\n\n` +
    `Model aktif saat ini: <code>${escapeHtml(session.model || 'gemini-3.5-flash')}</code>\n` +
    `Mode saat ini: <b>${session.mode === 'web' ? '🌐 Web Playground' : '⚡ Direct API'}</b>\n\n` +
    `Pilih model di bawah untuk digunakan pada <code>/ais</code>:`,
    {
      parse_mode: 'HTML',
      reply_markup: keyboard,
      reply_parameters: { message_id: ctx.message.message_id }
    }
  );
});

// Cache for TikTok audio downloads (id -> audio metadata)
const tiktokAudioCache = new Map();

function escapeHtml(str = '') {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

/**
 * Handle TikTok download
 */
async function handleTikTokDownload(ctx, targetUrl) {
  const url = extractTikTokUrl(targetUrl);
  if (!url) {
    return ctx.reply(
      '❌ URL TikTok tidak valid.\n\nContoh penggunaan:\n`/tt https://vt.tiktok.com/xxxxxx/`\n`/tt https://www.tiktok.com/@user/video/xxxxxx`',
      { parse_mode: 'Markdown' }
    );
  }

  let statusMsg;
  try {
    statusMsg = await ctx.reply('⏳ *Mengambil video TikTok tanpa watermark...*', { parse_mode: 'Markdown' });
  } catch (e) {
    statusMsg = await ctx.reply('⏳ Mengambil video TikTok tanpa watermark...');
  }

  try {
    const data = await getTikTokData(url);

    // If it's a photo slide / carousel
    if (data.images && data.images.length > 0) {
      if (statusMsg) {
        try { await ctx.api.deleteMessage(ctx.chat.id, statusMsg.message_id); } catch (e) {}
      }

      const rawTitle = (data.title || 'TikTok Foto Slide').trim();
      const shortTitle = rawTitle.length > 350 ? rawTitle.slice(0, 347) + '...' : rawTitle;

      const htmlSlideCaption =
        `📸 <b>${escapeHtml(shortTitle)}</b>` +
        `\n\n👤 <b>@${escapeHtml(data.author.username)}</b> (${escapeHtml(data.author.nickname)})` +
        `\n❤️ ${(data.stats.likes || 0).toLocaleString()} | 💬 ${(data.stats.comments || 0).toLocaleString()}`;

      const plainSlideCaption =
        `📸 ${shortTitle}` +
        `\n\n👤 @${data.author.username} (${data.author.nickname})` +
        `\n❤️ ${(data.stats.likes || 0).toLocaleString()} | 💬 ${(data.stats.comments || 0).toLocaleString()}`;

      // Telegram media group supports up to 10 photos
      const mediaGroup = data.images.slice(0, 10).map((imgUrl, idx) => ({
        type: 'photo',
        media: imgUrl,
        caption: idx === 0 ? htmlSlideCaption.slice(0, 1024) : undefined,
        parse_mode: 'HTML'
      }));

      try {
        await ctx.replyWithMediaGroup(mediaGroup);
      } catch (mgErr) {
        // Fallback plain caption
        const plainGroup = data.images.slice(0, 10).map((imgUrl, idx) => ({
          type: 'photo',
          media: imgUrl,
          caption: idx === 0 ? plainSlideCaption.slice(0, 1024) : undefined
        }));
        await ctx.replyWithMediaGroup(plainGroup);
      }

      if (data.musicUrl) {
        tiktokAudioCache.set(data.id, {
          musicUrl: data.musicUrl,
          title: data.musicTitle || 'TikTok Audio',
          author: data.musicAuthor || data.author.nickname
        });
        const kb = new InlineKeyboard().text('🎵 Download Audio (MP3)', `tt_audio_${data.id}`);
        await ctx.reply('🎵 Audio latar belakang tersedia:', { reply_markup: kb });
      }
      return;
    }

    // If video
    if (!data.videoUrl) {
      throw new Error('Link video tidak ditemukan atau video bersifat privat.');
    }

    // Download video buffer
    const videoBuffer = await fetchMediaBuffer(data.videoUrl);

    if (data.musicUrl) {
      tiktokAudioCache.set(data.id, {
        musicUrl: data.musicUrl,
        title: data.musicTitle || 'TikTok Audio',
        author: data.musicAuthor || data.author.nickname
      });
    }

    const rawTitle = (data.title || 'TikTok Video').trim();
    const shortTitle = rawTitle.length > 350 ? rawTitle.slice(0, 347) + '...' : rawTitle;

    const htmlCaption =
      `🎬 <b>${escapeHtml(shortTitle)}</b>` +
      `\n\n👤 <b>@${escapeHtml(data.author.username)}</b> (${escapeHtml(data.author.nickname)})` +
      `\n❤️ ${(data.stats.likes || 0).toLocaleString()} | 💬 ${(data.stats.comments || 0).toLocaleString()} | 👁️ ${(data.stats.views || 0).toLocaleString()}` +
      (data.duration ? `\n⏱️ ${data.duration}s` : '') +
      (data.musicTitle ? `\n🎵 <i>${escapeHtml(data.musicTitle)}</i>` : '');

    const plainCaption =
      `🎬 ${shortTitle}` +
      `\n\n👤 @${data.author.username} (${data.author.nickname})` +
      `\n❤️ ${(data.stats.likes || 0).toLocaleString()} | 💬 ${(data.stats.comments || 0).toLocaleString()} | 👁️ ${(data.stats.views || 0).toLocaleString()}` +
      (data.duration ? `\n⏱️ ${data.duration}s` : '') +
      (data.musicTitle ? `\n🎵 ${data.musicTitle}` : '');

    const keyboard = data.musicUrl
      ? new InlineKeyboard().text('🎵 Download Audio (MP3)', `tt_audio_${data.id}`)
      : undefined;

    // Delete progress message
    if (statusMsg) {
      try { await ctx.api.deleteMessage(ctx.chat.id, statusMsg.message_id); } catch (e) {}
    }

    // Send video with HTML parsing and plain-text fallback
    try {
      await ctx.replyWithVideo(new InputFile(videoBuffer, `tiktok_${data.id}.mp4`), {
        caption: htmlCaption.slice(0, 1024),
        parse_mode: 'HTML',
        reply_markup: keyboard
      });
    } catch (sendErr) {
      console.warn('Failed sending video with HTML caption, retrying plain text:', sendErr.message);
      try {
        await ctx.replyWithVideo(new InputFile(videoBuffer, `tiktok_${data.id}.mp4`), {
          caption: plainCaption.slice(0, 1024),
          reply_markup: keyboard
        });
      } catch (fallbackErr) {
        console.warn('Failed sending video with plain caption, sending bare video:', fallbackErr.message);
        await ctx.replyWithVideo(new InputFile(videoBuffer, `tiktok_${data.id}.mp4`), {
          reply_markup: keyboard
        });
        await ctx.reply(plainCaption.slice(0, 4000));
      }
    }
  } catch (err) {
    if (statusMsg) {
      try { await ctx.api.deleteMessage(ctx.chat.id, statusMsg.message_id); } catch (e) {}
    }
    console.error('Error downloading TikTok:', err);
    await ctx.reply(`❌ *Gagal download video TikTok:* ${err.message}`, { parse_mode: 'Markdown' });
  }
}

// Command: /tt and /tiktok
bot.command(['tt', 'tiktok'], async (ctx) => {
  const match = ctx.match?.trim();
  if (!match) {
    return ctx.reply(
      `ℹ️ *Cara Menggunakan Fitur /tt*:
Kirim perintah: \`/tt <link tiktok>\`

Contoh:
\`/tt https://vt.tiktok.com/ZSjR1234/\`
\`/tt https://www.tiktok.com/@user/video/1234567890\`

💡 *Tips*: Anda juga bisa langsung paste link TikTok di obrolan tanpa mengetik \`/tt\`!`,
      { parse_mode: 'Markdown' }
    );
  }

  await handleTikTokDownload(ctx, match);
});

/**
 * Handle OuO Shortlink solver (Supports Single & Bulk links)
 */
async function handleOuoSolver(ctx, rawInput = '') {
  let text = (rawInput || '').trim();

  // If no text provided, check replied message
  if (!text && ctx.message?.reply_to_message) {
    text = (ctx.message.reply_to_message.text || ctx.message.reply_to_message.caption || '').trim();
  }

  const urls = extractOuoUrls(text);
  if (!urls || urls.length === 0) {
    return ctx.reply(
      `ℹ️ <b>Cara Menggunakan Fitur /ouo</b>:\n\n` +
      `Kirim perintah:\n<code>/ouo &lt;link ouo&gt;</code>\n\n` +
      `📦 <b>Mendukung Banyak Link Sekaligus (Bulk):</b>\n` +
      `Anda dapat menempelkan banyak link sekaligus dipisahkan spasi atau baris baru:\n` +
      `<code>/ouo https://ouo.io/HxFVfD\nhttps://ouo.press/Zu7Vs5</code>\n\n` +
      `💡 <b>Fungsi:</b> Melewati iklan countdown dan verifikasi captcha di ouo.io / ouo.press untuk langsung mendapatkan link download / tujuan asli.`,
      { parse_mode: 'HTML' }
    );
  }

  // Cap bulk download to 15 links per batch
  const MAX_BULK = 15;
  const targetUrls = urls.slice(0, MAX_BULK);

  if (urls.length > MAX_BULK) {
    await ctx.reply(
      `⚠️ <i>Ditemukan ${urls.length} link. Untuk menjaga performa, memproses ${MAX_BULK} link pertama terlebih dahulu...</i>`,
      { parse_mode: 'HTML' }
    );
  }

  const total = targetUrls.length;
  let statusMsg;
  try {
    statusMsg = await ctx.reply(
      total > 1
        ? `⏳ <b>Bulk OuO Solver:</b> Memproses <b>${total}</b> tautan shortlink...`
        : `⏳ <b>Sedang memproses bypass OuO shortlink...</b>\n\n<blockquote>🔗 <code>${escapeHtml(targetUrls[0])}</code></blockquote>\n<i>Harap tunggu sekitar 2-5 detik...</i>`,
      { parse_mode: 'HTML' }
    );
  } catch (e) {
    statusMsg = await ctx.reply('⏳ Memproses bypass OuO...');
  }

  let successCount = 0;

  for (let i = 0; i < total; i++) {
    const currentUrl = targetUrls[i];
    const prefix = total > 1 ? `[${i + 1}/${total}] ` : '';

    if (statusMsg && total > 1) {
      try {
        await ctx.api.editMessageText(
          ctx.chat.id,
          statusMsg.message_id,
          `⏳ <b>${prefix}Memproses bypass OuO...</b>\n<code>${escapeHtml(currentUrl.slice(0, 70))}</code>`,
          { parse_mode: 'HTML' }
        );
      } catch (e) {}
    }

    try {
      const result = await solveOuo(currentUrl);

      if (result.success && result.destination_url) {
        const durationSec = result.duration_ms ? (result.duration_ms / 1000).toFixed(2) : '1.5';
        const keyboard = new InlineKeyboard().url('🔗 Buka Link Tujuan', result.destination_url);

        const successText =
          `✅ <b>${prefix}OuO Shortlink Berhasil Di-bypass!</b>\n\n` +
          `<blockquote><b>🔗 Link Awal:</b>\n<code>${escapeHtml(result.original_url || currentUrl)}</code>\n\n` +
          `<b>🎯 Link Tujuan Asli:</b>\n<code>${escapeHtml(result.destination_url)}</code></blockquote>\n\n` +
          `⚡ <i>Waktu proses: ${durationSec} detik</i>`;

        if (total === 1 && statusMsg) {
          await ctx.api.editMessageText(
            ctx.chat.id,
            statusMsg.message_id,
            successText,
            {
              parse_mode: 'HTML',
              reply_markup: keyboard,
              disable_web_page_preview: false
            }
          );
        } else {
          await ctx.reply(successText, {
            parse_mode: 'HTML',
            reply_markup: keyboard,
            disable_web_page_preview: false
          });
        }
        successCount++;
      } else {
        const errorReason = result.error || 'Gagal mem-bypass link. Link mungkin kedaluwarsa atau server OuO sedang proteksi ketat.';
        const failText =
          `❌ <b>${prefix}Gagal Bypass Link OuO</b>\n\n` +
          `<blockquote><b>🔗 Link:</b>\n<code>${escapeHtml(currentUrl)}</code>\n\n` +
          `<b>⚠️ Keterangan:</b>\n${escapeHtml(errorReason)}</blockquote>\n\n` +
          `💡 <i>Tips: Pastikan tautan masih aktif dan bukan halaman dashboard. Anda juga dapat mencoba membuka kembali beberapa saat lagi.</i>`;

        if (total === 1 && statusMsg) {
          await ctx.api.editMessageText(
            ctx.chat.id,
            statusMsg.message_id,
            failText,
            { parse_mode: 'HTML' }
          );
        } else {
          await ctx.reply(failText, { parse_mode: 'HTML' });
        }
      }
    } catch (err) {
      console.error(`Error handling OuO solver [${currentUrl}]:`, err.message);
      const errText =
        `❌ <b>${prefix}Terjadi kesalahan pada solver:</b>\n` +
        `<blockquote>🔗 <code>${escapeHtml(currentUrl)}</code>\n` +
        `⚠️ <code>${escapeHtml(err.message)}</code></blockquote>`;

      if (total === 1 && statusMsg) {
        try {
          await ctx.api.editMessageText(ctx.chat.id, statusMsg.message_id, errText, { parse_mode: 'HTML' });
        } catch (_) {
          await ctx.reply(errText, { parse_mode: 'HTML' });
        }
      } else {
        await ctx.reply(errText, { parse_mode: 'HTML' });
      }
    }
  }

  // Finalize status message for bulk
  if (statusMsg && total > 1) {
    try {
      await ctx.api.editMessageText(
        ctx.chat.id,
        statusMsg.message_id,
        `✅ <b>Bulk OuO Selesai!</b>\nBerhasil memproses <b>${successCount}</b> dari <b>${total}</b> tautan shortlink.`,
        { parse_mode: 'HTML' }
      );
    } catch (e) {}
  }
}

// Command: /ouo
bot.command(['ouo', 'ouoio', 'ouopress'], async (ctx) => {
  const match = ctx.match?.trim() || '';
  await handleOuoSolver(ctx, match);
});

/**
 * Handle Videy & Videyfile Direct Link Extractor
 * Extracts and sends direct CDN / download URLs without sending the heavy video file.
 */
async function handleVideyDownload(ctx, rawInput = '') {
  let text = (rawInput || '').trim();

  // If no text provided, check replied message
  if (!text && ctx.message?.reply_to_message) {
    text = (ctx.message.reply_to_message.text || ctx.message.reply_to_message.caption || '').trim();
  }

  const urls = extractVideyUrls(text);
  if (!urls || urls.length === 0) {
    return ctx.reply(
      `ℹ️ <b>Cara Menggunakan Fitur /videy (Direct Link Extractor)</b>:\n\n` +
      `Kirim perintah:\n<code>/videy &lt;link video&gt;</code>\n\n` +
      `📦 <b>Mendukung Banyak Link Sekaligus (Bulk):</b>\n` +
      `Anda dapat menempelkan banyak link sekaligus dipisahkan spasi atau baris baru:\n` +
      `<code>/videy https://videyfile.top/live/?=ptAwPT\nhttps://videotube.top/v/?id=lsnnJYvm1\nhttps://videy.co/v?id=kFUi1Icg1</code>\n\n` +
      `💡 <i>Fitur ini langsung mengekstrak direct URL video (CDN) tanpa mengunduh file video ke chat Telegram.</i>`,
      { parse_mode: 'HTML' }
    );
  }

  // Cap bulk download to 15 links per batch
  const MAX_BULK = 15;
  const targetUrls = urls.slice(0, MAX_BULK);

  if (urls.length > MAX_BULK) {
    await ctx.reply(
      `⚠️ <i>Ditemukan ${urls.length} link. Untuk menjaga performa, memproses ${MAX_BULK} link pertama terlebih dahulu...</i>`,
      { parse_mode: 'HTML' }
    );
  }

  const total = targetUrls.length;
  let statusMsg;
  try {
    statusMsg = await ctx.reply(
      total > 1
        ? `⏳ <b>Mengekstrak direct link untuk ${total} video...</b>`
        : '⏳ <b>Mengekstrak direct link Videy...</b>',
      { parse_mode: 'HTML' }
    );
  } catch (e) {
    statusMsg = await ctx.reply('⏳ Mengekstrak direct link Videy...');
  }

  let successCount = 0;

  for (let i = 0; i < total; i++) {
    const currentUrl = targetUrls[i];
    const prefix = total > 1 ? `[${i + 1}/${total}] ` : '';

    try {
      const media = await resolveVideyMedia(currentUrl);

      const kb = new InlineKeyboard()
        .url('📥 Buka / Unduh Direct Video', media.videoUrl)
        .row()
        .url('🌐 Tautan Halaman Asli', media.sourceUrl);

      const messageText =
        `🎬 <b>${prefix}Videy Direct Link Extractor</b>\n` +
        `━━━━━━━━━━━━━━━━━━━━━\n` +
        `🆔 <b>ID Video:</b> <code>${escapeHtml(media.id)}</code>\n` +
        `📦 <b>Ukuran:</b> <code>${media.sizeFormatted}</code>\n` +
        `📁 <b>Format:</b> <code>${(media.ext || 'mp4').toUpperCase()}</code>\n\n` +
        `🔗 <b>Direct Link:</b>\n` +
        `<code>${escapeHtml(media.videoUrl)}</code>\n\n` +
        `🌐 <b>Sumber Asli:</b> <a href="${escapeHtml(media.sourceUrl)}">${escapeHtml(media.sourceUrl)}</a>\n\n` +
        `💡 <i>Salin tautan di atas atau klik tombol di bawah untuk memutar/mengunduh video langsung.</i>`;

      await ctx.reply(messageText, {
        parse_mode: 'HTML',
        reply_markup: kb,
        disable_web_page_preview: true
      });

      successCount++;
    } catch (err) {
      console.error(`Error resolving Videy [${currentUrl}]:`, err.message);
      await ctx.reply(
        `❌ <b>${prefix}Gagal Ekstrak Direct Link:</b>\n` +
        `<blockquote>🔗 <code>${escapeHtml(currentUrl)}</code>\n` +
        `⚠️ <b>Error:</b> ${escapeHtml(err.message)}</blockquote>`,
        { parse_mode: 'HTML' }
      );
    }
  }

  // Clean up status message
  if (statusMsg) {
    try {
      await ctx.api.deleteMessage(ctx.chat.id, statusMsg.message_id);
    } catch (e) {
      if (total > 1) {
        try {
          await ctx.api.editMessageText(
            ctx.chat.id,
            statusMsg.message_id,
            `✅ <b>Selesai!</b> Berhasil mengekstrak <b>${successCount}</b> dari <b>${total}</b> tautan video.`,
            { parse_mode: 'HTML' }
          );
        } catch (_) {}
      }
    }
  }
}

// Command: /videy, /videyfile, /videotube
bot.command(['videy', 'videyfile', 'videotube'], async (ctx) => {
  const match = ctx.match?.trim() || '';
  await handleVideyDownload(ctx, match);
});

/**
 * Handle Remotion Video Render from uploaded ZIP file
 * Guaranteed zero residual files (all unzipped folders and rendered mp4 are deleted on completion).
 */
async function handleRemotionRender(ctx, document, targetComposition = '') {
  if (!document) {
    return ctx.reply('❌ File dokumen tidak ditemukan.');
  }

  const fileName = document.file_name || 'project.zip';
  if (!fileName.toLowerCase().endsWith('.zip')) {
    return ctx.reply(
      '❌ <b>Format file tidak didukung!</b>\n\nPastikan Anda mengirim file arsip berformat <code>.zip</code> yang berisi proyek Remotion.',
      { parse_mode: 'HTML' }
    );
  }

  let statusMsg;
  try {
    statusMsg = await ctx.reply('⏳ <b>Mengunduh file zip proyek Remotion...</b>', { parse_mode: 'HTML' });
  } catch (e) {
    statusMsg = await ctx.reply('⏳ Mengunduh file zip...');
  }

  try {
    // Download zip from Telegram
    const file = await ctx.api.getFile(document.file_id);
    const fileUrl = `https://api.telegram.org/file/bot${BOT_TOKEN}/${file.file_path}`;
    const res = await fetch(fileUrl);
    if (!res.ok) {
      throw new Error(`Gagal mengunduh file dari Telegram (HTTP ${res.status})`);
    }

    const arrayBuffer = await res.arrayBuffer();
    const zipBuffer = Buffer.from(arrayBuffer);

    // Render video with live progress updates
    let lastStatusUpdate = 0;
    const renderResult = await processRemotionZip({
      zipBuffer,
      compositionId: targetComposition || undefined,
      onProgress: async (percent, message) => {
        const now = Date.now();
        // Throttle message edits to once every 2 seconds to avoid Telegram rate limits
        if (statusMsg && (now - lastStatusUpdate > 2000 || percent >= 95)) {
          lastStatusUpdate = now;
          try {
            await ctx.api.editMessageText(
              ctx.chat.id,
              statusMsg.message_id,
              `⏳ <b>${escapeHtml(message)}</b>`,
              { parse_mode: 'HTML' }
            );
          } catch (e) {}
        }
      }
    });

    const caption =
      `🎬 <b>Remotion Video Render Sukses!</b>\n` +
      `━━━━━━━━━━━━━━━━━━━━━\n` +
      `🆔 <b>Composition:</b> <code>${escapeHtml(renderResult.compositionId)}</code>\n` +
      `⏱️ <b>Waktu Render:</b> <code>${renderResult.durationSeconds} detik</code>\n` +
      `🧹 <b>Status Disk:</b> <i>Folder zip &amp; file video MP4 di server sudah dihapus bersih otomatis.</i>`;

    // Send video to Telegram
    await ctx.replyWithVideo(new InputFile(renderResult.videoBuffer, renderResult.fileName), {
      caption,
      parse_mode: 'HTML'
    });

    // Delete progress message
    if (statusMsg) {
      try { await ctx.api.deleteMessage(ctx.chat.id, statusMsg.message_id); } catch (e) {}
    }

  } catch (err) {
    console.error('Error rendering Remotion project:', err);
    const shortErr = escapeHtml((err.message || 'Render error').slice(0, 300));
    if (statusMsg) {
      try {
        await ctx.api.editMessageText(
          ctx.chat.id,
          statusMsg.message_id,
          `❌ <b>Gagal Render Video Remotion:</b>\n<blockquote>${shortErr}</blockquote>\n\n💡 <i>Catatan: Folder sementara &amp; file sisa otomatis dibersihkan dari server.</i>`,
          { parse_mode: 'HTML' }
        );
      } catch (e) {
        try { await ctx.reply(`❌ <b>Gagal Render Video Remotion:</b> ${shortErr}`, { parse_mode: 'HTML' }); } catch (_) {}
      }
    } else {
      try { await ctx.reply(`❌ <b>Gagal Render Video Remotion:</b> ${shortErr}`, { parse_mode: 'HTML' }); } catch (_) {}
    }
  }
}

// Command: /remotion
bot.command('remotion', async (ctx) => {
  const match = ctx.match?.trim() || '';
  const replyDoc = ctx.message.reply_to_message?.document;

  if (replyDoc) {
    return handleRemotionRender(ctx, replyDoc, match);
  }

  const helpText =
    `🎬 <b>Cara Menggunakan Fitur /remotion:</b>\n\n` +
    `1. <b>Kirim file .zip</b> project Remotion Anda dengan caption:\n` +
    `<code>/remotion</code> atau <code>/remotion &lt;CompositionId&gt;</code>\n\n` +
    `2. Atau <b>reply</b> pesan file <code>.zip</code> yang sudah dikirim di obrolan dengan perintah:\n` +
    `<code>/remotion</code>\n\n` +
    `📦 <b>Format Project:</b>\n` +
    `• File zip yang berisi folder <code>src/</code> (dengan <code>index.ts</code> / <code>index.js</code> / <code>Root.tsx</code>).\n` +
    `• Bila memiliki lebih dari satu Composition, tentukan nama composition yang ingin dirender (misal: <code>/remotion MyVideo</code>).\n\n` +
    `🧹 <b>Penyimpanan VPS Aman &amp; Bersih:</b>\n` +
    `• Folder hasil ekstrak zip dan file video <code>.mp4</code> <b>otomatis dihapus langsung setelah selesai</b> agar memori storage VPS tidak penuh.`;

  await ctx.reply(helpText, { parse_mode: 'HTML' });
});

// Command: /new
bot.command('new', async (ctx) => {
  const userId = ctx.from.id;
  if (isUserRunning(userId)) {
    return ctx.reply('⚠️ Agent masih menjalankan tugas sebelumnya. Gunakan /abort jika ingin membatalkannya.');
  }

  const session = getSession(userId);
  const isOpencode = session.engine === 'opencode';
  const prompt = ctx.match?.trim();

  if (isOpencode) {
    const oldSes = session.opencodeSessionId;
    updateSession(userId, { opencodeSessionId: null });
    if (prompt) {
      await ctx.reply(`✨ *Sesi baru OpenCode dimulai!* Memproses instruksi Anda...`, { parse_mode: 'Markdown' });
      handleAgentTurn(ctx, prompt, 'opencode').catch(console.error);
    } else {
      await ctx.reply(
        `✨ *Sesi OpenCode baru telah di-reset!*${oldSes ? `\n(Sesi lama \`${oldSes}\` tersimpan di database)` : ''}\n\nSilakan kirim \`/ai <pesan>\` atau \`/oc <pesan>\` untuk memulai percakapan baru.`,
        { parse_mode: 'Markdown' }
      );
    }
  } else {
    const oldId = resetSession(userId);
    if (prompt) {
      await ctx.reply(`✨ *Sesi baru Antigravity dimulai!* Memproses instruksi Anda...`, { parse_mode: 'Markdown' });
      handleAgentTurn(ctx, prompt, 'antigravity').catch(console.error);
    } else {
      await ctx.reply(
        `✨ *Sesi Antigravity baru telah di-reset!*${oldId ? `\n(Sesi lama \`${oldId.slice(0, 8)}...\` tersimpan di database)` : ''}\n\nSilakan kirim pesan atau instruksi coding untuk memulai percakapan baru.`,
        { parse_mode: 'Markdown' }
      );
    }
  }
});

// Command: /ocnew (Explicit OpenCode new session)
bot.command(['ocnew', 'newoc'], async (ctx) => {
  const userId = ctx.from.id;
  if (isUserRunning(userId)) {
    return ctx.reply('⚠️ Agent masih menjalankan tugas sebelumnya. Gunakan /abort jika ingin membatalkannya.');
  }
  const session = getSession(userId);
  const oldSes = session.opencodeSessionId;
  updateSession(userId, { opencodeSessionId: null });
  const prompt = ctx.match?.trim();

  if (prompt) {
    await ctx.reply(`✨ *Sesi baru OpenCode dimulai!* Memproses instruksi Anda...`, { parse_mode: 'Markdown' });
    handleAgentTurn(ctx, prompt, 'opencode').catch(console.error);
  } else {
    await ctx.reply(
      `✨ *Sesi OpenCode baru telah di-reset!*${oldSes ? `\n(Sesi lama \`${oldSes}\` tersimpan di database)` : ''}\n\nSilakan kirim \`/oc <pesan>\` untuk memulai percakapan baru.`,
      { parse_mode: 'Markdown' }
    );
  }
});

// Command: /resume
bot.command('resume', async (ctx) => {
  const targetId = ctx.match?.trim();
  const userId = ctx.from.id;

  if (targetId) {
    if (targetId.startsWith('ses_')) {
      const ocSes = getOpenCodeSessionById(targetId);
      updateSession(userId, { opencodeSessionId: targetId });
      return ctx.reply(
        `🔄 *Sesi OpenCode Berhasil Di-Resume!*\n\n📌 **ID**: \`${targetId}\`\n${ocSes?.title ? `🏷️ **Judul**: ${ocSes.title}` : ''}\n\nSilakan kirim \`/ai <pesan>\` atau \`/oc <pesan>\` untuk melanjutkan percakapan.`,
        { parse_mode: 'Markdown' }
      );
    } else {
      const conv = getConversationById(targetId);
      const resolvedId = conv ? conv.conversation_id : targetId;
      updateSession(userId, { conversationId: resolvedId });
      return ctx.reply(
        `🔄 *Sesi Antigravity Berhasil Di-Resume!*\n\n📌 **ID**: \`${resolvedId}\`\n${conv?.title ? `🏷️ **Judul**: ${conv.title}` : ''}\n${conv?.step_count ? `💬 **Jumlah Langkah**: ${conv.step_count}` : ''}\n\nSilakan kirim pesan lanjutan ke agent.`,
        { parse_mode: 'Markdown' }
      );
    }
  }

  const { text, keyboard } = renderResumeMenu(userId);
  await ctx.reply(text, { parse_mode: 'HTML', reply_markup: keyboard });
});

// Command: /ocresume (Explicit OpenCode resume)
bot.command(['ocresume', 'resumeoc'], async (ctx) => {
  const targetId = ctx.match?.trim();
  const userId = ctx.from.id;

  if (targetId) {
    const ocSes = getOpenCodeSessionById(targetId);
    updateSession(userId, { opencodeSessionId: targetId });
    return ctx.reply(
      `🔄 *Sesi OpenCode Berhasil Di-Resume!*\n\n📌 **ID**: \`${targetId}\`\n${ocSes?.title ? `🏷️ **Judul**: ${ocSes.title}` : ''}\n\nSilakan kirim \`/oc <pesan>\` untuk melanjutkan percakapan.`,
      { parse_mode: 'Markdown' }
    );
  }

  const { text, keyboard } = renderResumeMenu(userId, 'opencode');
  await ctx.reply(text, { parse_mode: 'HTML', reply_markup: keyboard });
});

// Command: /model
bot.command('model', async (ctx) => {
  const session = getSession(ctx.from.id);
  const targetModel = ctx.match?.trim();
  const isOpencode = session.engine === 'opencode';

  if (targetModel) {
    const foundOc = AVAILABLE_OPENCODE_MODELS.find(
      (m) => m.id.toLowerCase().includes(targetModel.toLowerCase()) || m.label.toLowerCase().includes(targetModel.toLowerCase())
    );
    const foundAgy = AVAILABLE_MODELS.find(
      (m) => m.id === targetModel || m.id.toLowerCase().includes(targetModel.toLowerCase())
    );

    if (isOpencode && foundOc) {
      updateSession(ctx.from.id, { opencodeModel: foundOc.id });
      return ctx.reply(`✅ Model OpenCode berhasil diubah ke: \`${foundOc.id}\`\n_${foundOc.label}_`, { parse_mode: 'Markdown' });
    } else if (foundAgy) {
      const mId = foundAgy.id;
      const MODELS_NO_EFFORT = ['claude-sonnet-4-6', 'claude-opus-4-6', 'gpt-oss-120b-medium', 'gpt-4o', 'deepseek-chat'];
      const effortReset = MODELS_NO_EFFORT.some(m => mId.toLowerCase().includes(m.toLowerCase()));
      const updates = { model: mId };
      if (effortReset) updates.effort = 'auto';
      updateSession(ctx.from.id, updates);
      const note = effortReset ? '\n_ℹ️ Effort otomatis direset ke `auto`._' : '';
      return ctx.reply(`✅ Model Antigravity berhasil diubah ke: \`${mId}\`${note}`, { parse_mode: 'Markdown' });
    } else if (foundOc) {
      updateSession(ctx.from.id, { opencodeModel: foundOc.id });
      return ctx.reply(`✅ Model OpenCode berhasil diubah ke: \`${foundOc.id}\`\n_${foundOc.label}_`, { parse_mode: 'Markdown' });
    }
  }

  const { text, keyboard } = renderModelMenu(ctx.from.id);
  await ctx.reply(text, { parse_mode: 'HTML', reply_markup: keyboard });
});

// Command: /ocmodel (Explicit OpenCode model switcher)
bot.command(['ocmodel', 'modeloc'], async (ctx) => {
  const targetModel = ctx.match?.trim();
  const userId = ctx.from.id;

  if (targetModel) {
    const found = AVAILABLE_OPENCODE_MODELS.find(
      (m) => m.id.toLowerCase().includes(targetModel.toLowerCase()) || m.label.toLowerCase().includes(targetModel.toLowerCase())
    );
    const mId = found ? found.id : targetModel;
    updateSession(userId, { opencodeModel: mId });
    return ctx.reply(`✅ Model OpenCode berhasil diubah ke: \`${mId}\``, { parse_mode: 'Markdown' });
  }

  const { text, keyboard } = renderModelMenu(userId, 'opencode');
  await ctx.reply(text, { parse_mode: 'HTML', reply_markup: keyboard });
});

// Command: /usage
bot.command('usage', async (ctx) => {
  const session = getSession(ctx.from.id);
  const sStats = session.sessionStats || {};
  const lStats = session.lifetimeStats || {};

  const usageText =
    `📊 *Statistik Penggunaan Token Antigravity*

💬 *Sesi Saat Ini* (\`${session.conversationId ? session.conversationId.slice(0, 8) + '...' : 'Fresh'}\`):
• 📥 Input Tokens: *${formatTokens(sStats.inputTokens)}* (${(sStats.inputTokens || 0).toLocaleString()})
• 📤 Output Tokens: *${formatTokens(sStats.outputTokens)}* (${(sStats.outputTokens || 0).toLocaleString()})
• 💭 Thinking Tokens: *${formatTokens(sStats.thinkingTokens)}* (${(sStats.thinkingTokens || 0).toLocaleString()})
• 📊 Total Sesi Ini: *${formatTokens(sStats.totalTokens)}* (${(sStats.totalTokens || 0).toLocaleString()})
• 🔄 Jumlah Turn: *${sStats.turns || 0}*

🌐 *Lifetime Bot*:
• 🔄 Total Turn: *${lStats.totalTurns || 0}*
• 📈 Total Tokens: *${formatTokens(lStats.totalTokens)}*`;

  await sendSafeMessage(ctx, usageText);
});

// Command: /status
bot.command('status', async (ctx) => {
  const session = getSession(ctx.from.id);
  const running = isUserRunning(ctx.from.id);
  const engine = session.engine || 'antigravity';
  const engineLabel = engine === 'opencode' ? 'OpenCode 💻' : 'Antigravity 🤖';
  const ocModel = (session.opencodeModel || 'opencode/deepseek-v4.1-flash-free').replace('opencode/', '');

  const statusText =
    `⚙️ *Status Sistem & Sesi Dual AI*

• ⚙️ *Active Engine*: *${engineLabel}*
• 🤖 *Agent Status*: ${running ? '🟡 *Sedang Berjalan*' : '🟢 *Idle (Siap)*'}
• 💬 *Antigravity Conv ID*: \`${session.conversationId || 'Belum ada (Sesi Baru)'}\`
• 💻 *OpenCode Session ID*: \`${session.opencodeSessionId || 'Belum ada (Sesi Baru)'}\`
• 🧠 *Model Antigravity*: \`${session.model}\`
• 💻 *Model OpenCode*: \`${ocModel}\`
• 🎯 *Effort*: \`${session.effort}\`
• 🛠️ *Mode*: \`${session.mode}\`
• 📂 *Workspace (CWD)*: \`${session.cwd}\`
• 📊 *Token Sesi Ini*: *${formatTokens(session.sessionStats?.totalTokens)}*`;

  const keyboard = new InlineKeyboard()
    .text('🔄 Refresh', 'btn_status')
    .text('⚙️ Ganti Engine', 'menu_engine_select').row()
    .text('🧠 Model Antigravity', 'btn_model_agy')
    .text('🧠 Model OpenCode', 'btn_model_oc').row()
    .text('📋 Sesi Antigravity', 'btn_resume_agy')
    .text('📋 Sesi OpenCode', 'btn_resume_oc').row()
    .text('➕ Sesi Baru', 'btn_new');

  await sendSafeMessage(ctx, statusText, { reply_markup: keyboard });
});

// Command: /effort
bot.command('effort', async (ctx) => {
  const session = getSession(ctx.from.id);
  const target = ctx.match?.trim().toLowerCase();

  const found = AVAILABLE_EFFORTS.find((e) => e.id === target);
  if (found) {
    updateSession(ctx.from.id, { effort: found.id });
    return ctx.reply(`🎯 Reasoning effort diubah ke: \`${found.id}\` (${found.label})`, { parse_mode: 'Markdown' });
  }

  const keyboard = new InlineKeyboard();
  AVAILABLE_EFFORTS.forEach((e) => {
    const isCurrent = e.id === (session.effort || 'auto');
    keyboard.text(`${isCurrent ? '✓ ' : ''}${e.label}`, `effort_${e.id}`).row();
  });

  await ctx.reply(
    `🎯 *Atur Reasoning Effort:*
• *Auto*: Cepat langsung jawab saat ngobrol biasa, berpikir mendalam saat coding/tugas penting.
• *Low*: Instan tanpa mikir lama.
• *High / Max*: Berpikir mendalam sebelum bertindak.

Effort aktif saat ini: \`${session.effort || 'auto'}\``,
    { parse_mode: 'Markdown', reply_markup: keyboard }
  );
});

// Command: /mode
bot.command('mode', async (ctx) => {
  const session = getSession(ctx.from.id);
  const target = ctx.match?.trim().toLowerCase();

  const found = AVAILABLE_MODES.find((m) => m.id === target);
  if (found) {
    updateSession(ctx.from.id, { mode: found.id });
    return ctx.reply(`⚙️ Mode agent diubah ke: \`${found.id}\``, { parse_mode: 'Markdown' });
  }

  const keyboard = new InlineKeyboard();
  AVAILABLE_MODES.forEach((m) => {
    const isCurrent = m.id === session.mode;
    keyboard.text(`${isCurrent ? '✓ ' : ''}${m.label}`, `mode_${m.id}`).row();
  });

  await ctx.reply(
    `⚙️ *Atur Mode Eksekusi Agent:*

Mode saat ini: \`${session.mode}\``,
    { parse_mode: 'Markdown', reply_markup: keyboard }
  );
});

// Command: /cd and /pwd
bot.command(['cd', 'dir'], async (ctx) => {
  const session = getSession(ctx.from.id);
  const targetPath = ctx.match?.trim();

  if (!targetPath) {
    return ctx.reply(`📂 *Direktori Kerja Saat Ini:* \`${session.cwd}\``, { parse_mode: 'Markdown' });
  }

  let resolved = targetPath.startsWith('~')
    ? path.join(os.homedir(), targetPath.slice(1))
    : path.resolve(session.cwd, targetPath);

  if (!fs.existsSync(resolved)) {
    return ctx.reply(`❌ Direktori tidak ditemukan: \`${resolved}\``, { parse_mode: 'Markdown' });
  }

  const stat = fs.statSync(resolved);
  if (!stat.isDirectory()) {
    return ctx.reply(`❌ Bukan sebuah direktori: \`${resolved}\``, { parse_mode: 'Markdown' });
  }

  updateSession(ctx.from.id, { cwd: resolved });
  await ctx.reply(`📂 *Direktori kerja dipindah ke:* \`${resolved}\``, { parse_mode: 'Markdown' });
});

bot.command('pwd', async (ctx) => {
  const session = getSession(ctx.from.id);
  await ctx.reply(`📂 *Direktori Kerja:* \`${session.cwd}\``, { parse_mode: 'Markdown' });
});

// Command: /stop or /abort (Cancel running task like ESC)
bot.command(['stop', 'abort'], async (ctx) => {
  const userId = ctx.from.id;
  const running = isUserRunning(userId);

  if (!running) {
    return ctx.reply('ℹ️ Tidak ada tugas agent yang sedang berjalan saat ini.');
  }

  const stopped = abortUserProcess(userId);
  if (stopped) {
    await ctx.reply('🛑 <b>Perintah berhasil dihentikan (ESC).</b>', { parse_mode: 'HTML' });
  } else {
    await ctx.reply('⚠️ Gagal menghentikan proses atau proses sudah selesai.');
  }
});

// Command: /bash (Direct terminal execution)
bot.command('bash', async (ctx) => {
  const cmd = ctx.match?.trim();
  if (!cmd) {
    return ctx.reply('Gunakan: `/bash <perintah>`\nContoh: `/bash uptime` atau `/bash df -h`', { parse_mode: 'Markdown' });
  }

  const session = getSession(ctx.from.id);
  const waitMsg = await ctx.reply(`⏳ Menjalankan: \`${cmd}\`...`, { parse_mode: 'Markdown' });

  exec(cmd, { cwd: session.cwd, timeout: 30000 }, async (err, stdout, stderr) => {
    try {
      await ctx.api.deleteMessage(ctx.chat.id, waitMsg.message_id);
    } catch (e) {}

    let output = (stdout || '') + (stderr ? `\n[STDERR]:\n${stderr}` : '');
    if (!output.trim()) output = '(Tidak ada output)';

    if (err && err.code) {
      output += `\n[Exit Code: ${err.code}]`;
    }

    const formatted = `💻 *Hasil:* \`${cmd}\`\n\`\`\`\n${output.slice(0, 3500)}\n\`\`\``;
    await sendSafeMessage(ctx, formatted);
  });
});

// Helper: Render Hardware & System Specifications Dashboard
function renderSpekDashboard() {
  function makeBar(pct, size = 10) {
    const filled = Math.min(size, Math.max(0, Math.round((pct / 100) * size)));
    return '█'.repeat(filled) + '░'.repeat(size - filled);
  }

  const totalRam = (os.totalmem() / 1024 / 1024 / 1024).toFixed(1);
  const freeRam = (os.freemem() / 1024 / 1024 / 1024).toFixed(1);
  const usedRam = (totalRam - freeRam).toFixed(1);
  const ramPct = Math.round((usedRam / totalRam) * 100);

  let diskTotal = '2.9T', diskUsed = '1.8T', diskAvail = '1.2T', diskPct = 60;
  try {
    const { execSync } = require('node:child_process');
    const df = execSync("df -h / | awk 'NR==2 {print $2, $3, $4, $5}'").toString().trim().split(/\s+/);
    if (df.length >= 4) {
      diskTotal = df[0];
      diskUsed = df[1];
      diskAvail = df[2];
      diskPct = parseInt(df[3].replace('%', '')) || 60;
    }
  } catch (_) {}

  let uptime = 'Active';
  try {
    const { execSync } = require('node:child_process');
    uptime = execSync('uptime -p').toString().trim().replace(/^up\s+/, '');
  } catch (_) {}

  const text =
    `🖥️ <b>SYSTEM &amp; SERVER SPECIFICATIONS</b>\n` +
    `━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n` +
    `🔥 <b>PROSESOR (CPU):</b>\n` +
    `• <b>Model:</b> AMD EPYC 9655P (Zen 5 Enterprise)\n` +
    `• <b>Core / Thread:</b> 48 vCPUs @ 2.60 GHz\n` +
    `• <b>L3 Cache:</b> 768 MiB (Ultra High-Bandwidth)\n` +
    `• <b>Arsitektur:</b> x86_64 (64-bit)\n\n` +
    `🧠 <b>MEMORI (RAM):</b>\n` +
    `• <b>Penggunaan:</b> [<code>${makeBar(ramPct)}</code>] ${ramPct}%\n` +
    `• <b>Terpakai:</b> ${usedRam} GB / ${totalRam} GB\n` +
    `• <b>Tersisa:</b> ${freeRam} GB (Free Memory)\n` +
    `• <b>Swap Memory:</b> 223.6 GB\n\n` +
    `💾 <b>PENYIMPANAN (DISK SSD/NVMe):</b>\n` +
    `• <b>Partisi Root (/):</b> [<code>${makeBar(diskPct)}</code>] ${diskPct}%\n` +
    `• <b>Kapasitas:</b> ${diskUsed} terpakai dari ${diskTotal}\n` +
    `• <b>Tersedia:</b> ${diskAvail} (Free Space)\n\n` +
    `🌐 <b>SISTEM OPERASI:</b>\n` +
    `• <b>Distro:</b> Ubuntu 24.04.5 LTS (Noble Numbat)\n` +
    `• <b>Kernel:</b> 6.18.15+deb13-cloud-amd64\n` +
    `• <b>Virtualisasi:</b> KVM / QEMU Cloud Engine\n` +
    `• <b>Uptime:</b> ${escapeHtml(uptime)}\n` +
    `━━━━━━━━━━━━━━━━━━━━━━━━━━`;

  const keyboard = new InlineKeyboard()
    .text('🔄 Refresh Spek', 'btn_refresh_spek')
    .text('💻 Top Processes', 'btn_top_proc').row()
    .text('⬅️ Menu Utama', 'menu_main');

  return { text, keyboard };
}

// Command: /spek or /vps (Hardware & System Specifications Dashboard)
bot.command(['spek', 'vps'], async (ctx) => {
  const { text, keyboard } = renderSpekDashboard();
  await ctx.reply(text, {
    parse_mode: 'HTML',
    reply_markup: keyboard,
    reply_parameters: { message_id: ctx.message.message_id }
  });
});

// Helper to perform backup action
async function handleBackupAction(ctx) {
  const config = getConfig();
  if (String(config.ownerId) !== String(ctx.from.id)) {
    return ctx.reply('⛔ Hanya bot owner yang dapat membuat backup bot.');
  }

  const waitMsg = await ctx.reply('📦 <b>Sedang membuat file backup bot...</b>', { parse_mode: 'HTML' });

  exec('/home/nanasmuda/antigravity-bot/backup.sh', async (err, stdout, stderr) => {
    try {
      await ctx.api.deleteMessage(ctx.chat.id, waitMsg.message_id);
    } catch (e) {}

    if (err) {
      return ctx.reply(`❌ <b>Gagal membuat backup:</b> ${escapeHtml(err.message)}`, { parse_mode: 'HTML' });
    }

    try {
      const latestUrl = fs.existsSync('/home/nanasmuda/backups/latest_url.txt')
        ? fs.readFileSync('/home/nanasmuda/backups/latest_url.txt', 'utf8').trim()
        : null;

      const backupDir = '/home/nanasmuda/backups';
      const files = fs.readdirSync(backupDir).filter((f) => f.endsWith('.zip')).sort().reverse();
      const latestZip = files.length > 0 ? path.join(backupDir, files[0]) : null;

      if (latestZip && fs.existsSync(latestZip)) {
        await ctx.replyWithDocument(new InputFile(latestZip, path.basename(latestZip)), {
          caption: `✅ <b>Backup Project Bot Selesai!</b>\n\n📁 File: <code>${path.basename(latestZip)}</code>\n🔗 <b>Download Link:</b>\n${latestUrl || '(upload pending)'}`,
          parse_mode: 'HTML'
        });
      } else if (latestUrl) {
        await ctx.reply(`✅ <b>Backup Berhasil!</b>\n\n🔗 <b>URL Download:</b>\n${latestUrl}`, { parse_mode: 'HTML' });
      }
    } catch (sendErr) {
      console.error('Error sending backup file:', sendErr);
      await ctx.reply(`✅ <b>Backup berhasil dibuat!</b>\n\n<pre>${escapeHtml(stdout)}</pre>`, { parse_mode: 'HTML' });
    }
  });
}

// Command: /backup (Create zip backup & upload)
bot.command('backup', async (ctx) => {
  await handleBackupAction(ctx);
});

// Owner commands: /allow and /disallow
bot.command('allow', async (ctx) => {
  const config = getConfig();
  if (String(config.ownerId) !== String(ctx.from.id)) {
    return ctx.reply('⛔ Hanya bot owner yang dapat menambahkan pengguna.');
  }

  const targetId = ctx.match?.trim();
  if (!targetId) {
    return ctx.reply('Gunakan: `/allow <telegram_user_id>`', { parse_mode: 'Markdown' });
  }

  if (allowUser(targetId)) {
    await ctx.reply(`✅ User ID \`${targetId}\` berhasil diizinkan menggunakan bot.`, { parse_mode: 'Markdown' });
  } else {
    await ctx.reply(`ℹ️ User ID \`${targetId}\` sudah ada di daftar izin.`, { parse_mode: 'Markdown' });
  }
});

bot.command('disallow', async (ctx) => {
  const config = getConfig();
  if (String(config.ownerId) !== String(ctx.from.id)) {
    return ctx.reply('⛔ Hanya bot owner yang dapat mencabut izin pengguna.');
  }

  const targetId = ctx.match?.trim();
  if (!targetId) {
    return ctx.reply('Gunakan: `/disallow <telegram_user_id>`', { parse_mode: 'Markdown' });
  }

  if (disallowUser(targetId)) {
    await ctx.reply(`🚫 Izin untuk User ID \`${targetId}\` berhasil dicabut.`, { parse_mode: 'Markdown' });
  } else {
    await ctx.reply(`❌ User tidak ditemukan atau merupakan Owner.`, { parse_mode: 'Markdown' });
  }
});

bot.command('id', async (ctx) => {
  await ctx.reply(`🆔 *Telegram User ID*: \`${ctx.from.id}\``, { parse_mode: 'Markdown' });
});

// Callback Query Handler for Inline Buttons
bot.on('callback_query:data', async (ctx) => {
  const data = ctx.callbackQuery.data;
  const userId = ctx.from.id;
  await ctx.answerCallbackQuery().catch(() => {});

  if (data === 'action_stop_active') {
    const running = isUserRunning(userId);
    if (!running) {
      await ctx.answerCallbackQuery({ text: 'Tidak ada tugas yang berjalan.' });
      return;
    }
    const stopped = abortUserProcess(userId);
    if (stopped) {
      await ctx.answerCallbackQuery({ text: '🛑 Perintah berhasil dihentikan!' });
      await ctx.reply('🛑 <b>Perintah berhasil dihentikan (ESC).</b>', { parse_mode: 'HTML' });
    } else {
      await ctx.answerCallbackQuery({ text: 'Gagal menghentikan proses.' });
    }
    return;
  }

  if (data === 'menu_refresh' || data === 'menu_main') {
    const { text, keyboard } = renderMainMenu(userId, ctx.from?.first_name);
    await editSafeMessageOrCaption(ctx, text, { reply_markup: keyboard });
    return;
  }

  // Engine Selection Callbacks
  if (data === 'menu_engine_select') {
    const { text, keyboard } = renderEngineMenu(userId);
    await editSafeMessageOrCaption(ctx, text, { reply_markup: keyboard });
    return;
  }

  if (data === 'set_engine_antigravity') {
    updateSession(userId, { engine: 'antigravity' });
    await ctx.answerCallbackQuery({ text: '✅ Engine aktif: Antigravity AI (agy)' }).catch(() => {});
    const { text, keyboard } = renderEngineMenu(userId);
    await editSafeMessageOrCaption(ctx, text, { reply_markup: keyboard });
    return;
  }

  if (data === 'set_engine_opencode') {
    updateSession(userId, { engine: 'opencode' });
    await ctx.answerCallbackQuery({ text: '✅ Engine aktif: OpenCode AI (opencode)' }).catch(() => {});
    const { text, keyboard } = renderEngineMenu(userId);
    await editSafeMessageOrCaption(ctx, text, { reply_markup: keyboard });
    return;
  }

  // System Hardware Specs Callbacks
  if (data === 'btn_spek_menu' || data === 'btn_refresh_spek') {
    const { text, keyboard } = renderSpekDashboard();
    await ctx.answerCallbackQuery({ text: '🔄 Spek diperbarui' }).catch(() => {});
    await editSafeMessageOrCaption(ctx, text, { reply_markup: keyboard });
    return;
  }

  if (data === 'btn_top_proc') {
    let topOutput = 'Gagal mengambil proses';
    try {
      const { execSync } = require('node:child_process');
      topOutput = execSync('ps aux --sort=-%mem | head -n 11').toString();
    } catch (_) {}
    const kb = new InlineKeyboard().text('⬅️ Kembali ke Spek', 'btn_spek_menu');
    await editSafeMessageOrCaption(ctx, `📊 <b>TOP 10 PROSES PENGGUNAAN MEMORI:</b>\n<pre>${escapeHtml(topOutput.slice(0, 3000))}</pre>`, { reply_markup: kb });
    return;
  }

  // Google AI Studio Callbacks
  if (data === 'action_ais_menu' || data === 'menu_ais_dashboard') {
    const { text, keyboard } = renderAisMenu(userId);
    await editSafeMessageOrCaption(ctx, text, { reply_markup: keyboard });
    return;
  }

  if (data === 'action_ais_start_login') {
    const webAppUrl = getWebAppUrl();
    const kb = new InlineKeyboard();
    if (webAppUrl) {
      kb.webApp('🌐 Login via WebApp', `${webAppUrl}#aistudio`).row();
    }
    kb.text('📋 Salin Script Bookmarklet', 'action_ais_bookmarklet').row()
      .text('🔙 Kembali ke Dashboard', 'action_ais_menu');

    const loginGuide =
      `🔐 <b>CARA LOGIN GOOGLE AI STUDIO</b>\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━━\n\n` +
      `1️⃣ <b>Kirim File Cookies (Paling Mudah):</b>\n` +
      `• Buka <code>aistudio.google.com</code> di browser PC/laptop Anda.\n` +
      `• Ekspor cookies menggunakan ekstensi <b>Cookie-Editor</b> (Export &gt; JSON).\n` +
      `• Kirim file <code>cookies.json</code> ke bot ini!\n\n` +
      `2️⃣ <b>Via Perintah:</b>\n` +
      `<code>/loginais &lt;paste cookies&gt;</code>\n\n` +
      `3️⃣ <b>Via Bookmarklet / Console:</b>\n` +
      `Klik tombol Bookmarklet di bawah untuk mendapatkan kode 1-klik salin.`;

    await editSafeMessageOrCaption(ctx, loginGuide, { reply_markup: kb });
    return;
  }

  if (data === 'action_ais_bookmarklet') {
    const bookmarklet =
      `javascript:(function(){const c=document.cookie;navigator.clipboard.writeText(c);alert('Cookie AI Studio disalin! Paste ke bot: /loginais <cookie>');})();`;
    await ctx.reply(
      `📋 <b>Kode Bookmarklet Browser (1-Klik Salin Cookie):</b>\n\n` +
      `<blockquote><code>${bookmarklet}</code></blockquote>\n\n` +
      `<b>Cara Pakai:</b>\n` +
      `1. Buka <code>https://aistudio.google.com</code> di browser.\n` +
      `2. Tekan <code>F12</code> &gt; pilih tab <b>Console</b>.\n` +
      `3. Ketik <code>copy(document.cookie)</code> lalu tekan Enter.\n` +
      `4. Kirim ke bot Telegram:\n` +
      `<code>/loginais [paste cookie di sini]</code>`,
      { parse_mode: 'HTML' }
    );
    return;
  }

  if (data === 'action_ais_new') {
    await ctx.answerCallbackQuery({ text: '⏳ Sedang membuat prompt baru di AI Studio...' });
    const waitMsg = await ctx.reply('⏳ *Membuat New Chat di Google AI Studio...*', { parse_mode: 'Markdown' });
    const result = await createNewApp(userId);
    try { await ctx.api.deleteMessage(ctx.chat.id, waitMsg.message_id); } catch (_) {}

    if (result.success) {
      const kb = new InlineKeyboard()
        .url('🌐 Buka Prompt di Browser', result.url).row()
        .text('⚡ Chat di Sini (/ais)', 'action_ais_chat')
        .text('📱 Menu AI Studio', 'action_ais_menu');

      await ctx.reply(
        `✨ <b>New Prompt Berhasil Dibuat di Google AI Studio!</b>\n\n` +
        `📝 <b>Judul:</b> <code>${escapeHtml(result.title)}</code>\n` +
        `🔗 <b>URL:</b> <code>${escapeHtml(result.url)}</code>\n\n` +
        `Ketik <code>/ais &lt;prompt&gt;</code> untuk langsung bertanya atau klik link di atas.`,
        { parse_mode: 'HTML', reply_markup: kb }
      );
    } else {
      await ctx.reply(`❌ <b>Gagal membuat prompt baru:</b>\n${escapeHtml(result.error)}`, { parse_mode: 'HTML' });
    }
    return;
  }

  if (data === 'action_ais_resume') {
    await ctx.answerCallbackQuery({ text: '🔍 Mengambil riwayat prompt dari Library...' });
    const waitMsg = await ctx.reply('🔍 *Mengambil daftar prompt dari Google AI Studio Library...*', { parse_mode: 'Markdown' });
    const result = await listRecentPrompts(userId);
    try { await ctx.api.deleteMessage(ctx.chat.id, waitMsg.message_id); } catch (_) {}

    if (result.success && result.prompts && result.prompts.length > 0) {
      const kb = new InlineKeyboard();
      result.prompts.forEach((p, idx) => {
        kb.url(`📝 ${p.title || `Prompt ${idx + 1}`}`, p.url).row();
      });
      kb.text('📱 Kembali ke Menu AI Studio', 'action_ais_menu');

      await ctx.reply(
        `📂 <b>RIWAYAT PROMPT GOOGLE AI STUDIO</b>\n` +
        `━━━━━━━━━━━━━━━━━━━━━━━━━\n\n` +
        `Ditemukan <b>${result.prompts.length} prompt</b> di Google AI Studio Library Anda:\n\n` +
        `Klik salah satu prompt untuk langsung membuka di browser:`,
        { parse_mode: 'HTML', reply_markup: kb }
      );
    } else {
      const kb = new InlineKeyboard()
        .text('💬 Buat Prompt Baru', 'action_ais_new').row()
        .text('📱 Menu AI Studio', 'action_ais_menu');

      await ctx.reply(
        `📂 <b>Belum ada prompt tersimpan di Library.</b>\n\n` +
        `Buat prompt pertama Anda dengan tombol di bawah atau ketik <code>/ais &lt;pertanyaan&gt;</code>.`,
        { parse_mode: 'HTML', reply_markup: kb }
      );
    }
    return;
  }

  if (data === 'action_ais_preview') {
    const session = loadAisSession(userId);
    if (!session) {
      await ctx.answerCallbackQuery({ text: 'Sesi belum terhubung.' });
      return;
    }
    const promptUrl = session.activePromptUrl || 'https://aistudio.google.com/prompts/new_chat';
    const title = session.activePromptTitle || 'New Chat';

    const kb = new InlineKeyboard()
      .url('🌐 Buka di Browser', promptUrl).row()
      .text('📱 Menu AI Studio', 'action_ais_menu');

    await ctx.reply(
      `🔗 <b>LINK PREVIEW PROMPT GOOGLE AI STUDIO</b>\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━━\n\n` +
      `📝 <b>Judul:</b> <b>${escapeHtml(title)}</b>\n` +
      `👤 <b>Akun:</b> <code>${escapeHtml(session.email)}</code>\n` +
      `🔗 <b>Direct Link:</b>\n<code>${escapeHtml(promptUrl)}</code>\n\n` +
      `<blockquote>Klik tombol di bawah untuk membuka langsung di Google AI Studio browser Anda.</blockquote>`,
      { parse_mode: 'HTML', reply_markup: kb }
    );
    return;
  }

  if (data === 'action_ais_chat') {
    await ctx.reply(
      `💬 <b>Chat Real-Time Google AI Studio</b>\n\n` +
      `Ketik perintah dengan format:\n` +
      `<code>/ais &lt;pesan atau instruksi Anda&gt;</code>\n\n` +
      `Pesan akan otomatis dikirim dan diproses langsung di playground Google AI Studio Anda!`,
      { parse_mode: 'HTML' }
    );
    return;
  }

  if (data === 'action_ais_status') {
    const session = loadAisSession(userId);
    if (session) {
      await ctx.answerCallbackQuery({ text: '🟢 Sesi Aktif!' });
    } else {
      await ctx.answerCallbackQuery({ text: '⚪ Belum login.' });
    }
    const { text, keyboard } = renderAisMenu(userId);
    await editSafeMessageOrCaption(ctx, text, { reply_markup: keyboard });
    return;
  }

  if (data === 'action_ais_toggle_mode') {
    const s = loadAisSession(userId) || {};
    const newMode = s.mode === 'web' ? 'api' : 'web';
    saveAisSession(userId, { mode: newMode });
    await ctx.answerCallbackQuery({ text: `Mode diubah ke: ${newMode.toUpperCase()}` });
    const { text, keyboard } = renderAisMenu(userId);
    return editSafeMessageOrCaption(ctx, text, { reply_markup: keyboard });
  }

  if (data === 'action_ais_select_model') {
    const session = loadAisSession(userId);
    const AIS_MODELS = [
      { id: 'gemini-3.5-flash', label: '⚡ Gemini 3.5 Flash (Cerdas + Reasoning) [Rekomendasi]' },
      { id: 'gemini-3.5-flash-lite', label: '🚀 Gemini 3.5 Flash Lite (Super Cepat <1s)' },
      { id: 'gemini-4-argon', label: '🪐 Gemini 4 Argon (Frontier Flagship PRO)' },
      { id: 'gemini-3.8-flash', label: '⚡ Gemini 3.8 Flash (Multimodal Enterprise)' }
    ];
    const keyboard = new InlineKeyboard();
    AIS_MODELS.forEach(m => {
      const isCurrent = (session?.model || 'gemini-3.5-flash') === m.id;
      keyboard.text(`${isCurrent ? '✓ ' : ''}${m.label}`, `ais_model_${m.id}`).row();
    });
    keyboard.text('⬅️ Kembali ke Dashboard', 'action_ais_menu');
    return editSafeMessageOrCaption(ctx, `🧠 <b>Pilih Model Google AI Studio:</b>\n\nModel aktif saat ini: <code>${escapeHtml(session?.model || 'gemini-3.5-flash')}</code>\nMode saat ini: <b>${session?.mode === 'web' ? '🌐 Web Playground' : '⚡ Direct API'}</b>\n\nModel ini akan digunakan saat Anda mengirim perintah <code>/ais &lt;pesan&gt;</code>.`, {
      reply_markup: keyboard
    });
  }

  if (data.startsWith('ais_model_')) {
    const chosenModel = data.replace('ais_model_', '');
    saveAisSession(userId, { model: chosenModel });
    await ctx.answerCallbackQuery({ text: `Model diubah ke: ${chosenModel}` });
    const { text, keyboard } = renderAisMenu(userId);
    return editSafeMessageOrCaption(ctx, text, { reply_markup: keyboard });
  }

  if (data === 'action_ais_logout') {
    deleteAisSession(userId);
    await ctx.answerCallbackQuery({ text: '🚪 Sesi AI Studio berhasil logout.' });
    const { text, keyboard } = renderAisMenu(userId);
    await editSafeMessageOrCaption(ctx, text, { reply_markup: keyboard });
    return;
  }

  if (data === 'action_ais_back_main') {
    const { text, keyboard } = renderMainMenu(userId, ctx.from?.first_name);
    await editSafeMessageOrCaption(ctx, text, { reply_markup: keyboard });
    return;
  }

  if (data === 'menu_ai_guide') {
    const aiText =
      `🤖 <b>PANDUAN AI ASSISTANT (/ai &amp; /oc)</b>\n` +
      `━━━━━━━━━━━━━━━━━━━━━\n` +
      `<blockquote>Bot mendukung <b>Dual AI Engine</b> (Antigravity &amp; OpenCode). Gunakan <code>/ai</code> untuk engine aktif, atau <code>/oc</code> untuk chat langsung ke OpenCode.</blockquote>\n\n` +
      `💡 <b>Format Penggunaan:</b>\n` +
      `• <code>/ai &lt;instruksi&gt;</code> — Jalankan instruksi pada engine aktif\n` +
      `• <code>/oc &lt;instruksi&gt;</code> — Jalankan instruksi langsung di OpenCode AI\n` +
      `• <code>/engine</code> — Buka switcher engine AI\n\n` +
      `📌 <b>Contoh:</b>\n` +
      `• <code>/ai buatkan script REST API express</code>\n` +
      `• <code>/oc refactor fungsi async ini</code>\n` +
      `• <code>/ai analisis error server [paste error]</code>\n\n` +
      `⚡ <b>Kontrol Sesi:</b>\n` +
      `• <code>/new</code> — Reset topik baru\n` +
      `• <code>/resume</code> — Kembali ke sesi lama\n` +
      `• <code>/engine</code> — Ganti engine AI aktif\n` +
      `• <code>/model</code> — Ganti model Antigravity AI\n` +
      `• <code>/stop</code> — Hentikan tugas yang sedang berjalan (ESC)`;

    const kb = new InlineKeyboard()
      .text('⚙️ Ganti Engine', 'menu_engine_select')
      .text('🧠 Ganti Model', 'btn_model').row()
      .text('➕ Sesi Baru', 'btn_new')
      .text('🔙 Kembali ke Dashboard', 'menu_main');

    await editSafeMessageOrCaption(ctx, aiText, { reply_markup: kb });
    return;
  }

  if (data === 'menu_tools') {
    const toolsText =
      `🛠️ <b>UTILITY TOOLS (REMOTION, VIDEY, TT &amp; OUO)</b>\n` +
      `━━━━━━━━━━━━━━━━━━━━━\n\n` +
      `🎬 <b>1. Remotion Video Renderer:</b>\n` +
      `<code>/remotion</code> (kirim bersama zip atau reply file zip)\n` +
      `<blockquote>Render video MP4 otomatis dari project React Remotion (.zip). Folder ekstrak dan file video MP4 di server langsung dihapus otomatis begitu selesai (zero storage VPS).</blockquote>\n\n` +
      `📹 <b>2. Videy &amp; Videyfile Direct Link Extractor:</b>\n` +
      `<code>/videy &lt;link video atau paste banyak link&gt;</code>\n` +
      `<blockquote>Ekstrak direct download URL video Videy (videyfile.top, videotube.top, videy.co). Mendukung bulk link, instan tanpa download file video ke Telegram.</blockquote>\n\n` +
      `📥 <b>3. TikTok Downloader:</b>\n` +
      `<code>/tt &lt;link video tiktok&gt;</code>\n` +
      `<blockquote>Download video TikTok kualitas asli tanpa watermark + file audio MP3 terpisah.</blockquote>\n\n` +
      `🔗 <b>4. OuO Shortlink Solver:</b>\n` +
      `<code>/ouo &lt;link ouo.io atau ouo.press&gt;</code>\n` +
      `<blockquote>Bypass iklan countdown &amp; captcha untuk dapatkan tautan asli langsung. Mendukung bulk banyak link sekaligus.</blockquote>\n\n` +
      `📌 <b>Contoh Penggunaan:</b>\n` +
      `• Kirim file <code>project.zip</code> dengan caption <code>/remotion</code>\n` +
      `• <code>/videy https://videyfile.top/live/?=ptAwPT</code>\n` +
      `• <code>/tt https://vt.tiktok.com/ZSjR1234/</code>\n` +
      `• <code>/ouo https://ouo.io/HxFVfD</code>`;

    const kb = new InlineKeyboard()
      .text('🔙 Kembali ke Dashboard', 'menu_main');

    await editSafeMessageOrCaption(ctx, toolsText, { reply_markup: kb });
    return;
  }

  if (data === 'menu_effort') {
    const session = getSession(userId);
    const kb = new InlineKeyboard();
    AVAILABLE_EFFORTS.forEach((e) => {
      const isCurrent = e.id === (session.effort || 'auto');
      kb.text(`${isCurrent ? '✓ ' : ''}${e.label}`, `effort_${e.id}`).row();
    });
    kb.text('🔙 Kembali ke Dashboard', 'menu_main');

    const effortText =
      `🎯 <b>ATUR REASONING EFFORT</b>\n` +
      `━━━━━━━━━━━━━━━━━━━━━\n` +
      `<blockquote>Effort mengatur kedalaman proses berpikir model AI sebelum memberikan jawaban.</blockquote>\n\n` +
      `• <b>Auto</b>: Respons instan saat tanya-jawab biasa, mendalam saat koding/tugas berat.\n` +
      `• <b>Low</b>: Super cepat tanpa mikir lama.\n` +
      `• <b>High / Max</b>: Berpikir mendalam sebelum bertindak.\n\n` +
      `Effort aktif saat ini: <code>${session.effort || 'auto'}</code>`;

    await editSafeMessageOrCaption(ctx, effortText, { reply_markup: kb });
    return;
  }

  if (data === 'menu_backup_action') {
    return handleBackupAction(ctx);
  }

  if (data === 'btn_new') {
    const session = getSession(userId);
    if (session.engine === 'opencode') {
      updateSession(userId, { opencodeSessionId: null });
      return ctx.reply('✨ *Sesi baru OpenCode dimulai!* Silakan kirim /ai atau /oc.', { parse_mode: 'Markdown' });
    } else {
      resetSession(userId);
      return ctx.reply('✨ *Sesi baru Antigravity dimulai!* Silakan kirim pesan atau instruksi coding.', { parse_mode: 'Markdown' });
    }
  }

  if (data === 'btn_new_oc') {
    updateSession(userId, { opencodeSessionId: null });
    await ctx.answerCallbackQuery({ text: '✨ Sesi OpenCode baru di-reset' }).catch(() => {});
    return ctx.reply('✨ *Sesi baru OpenCode dimulai!* Silakan kirim /ai atau /oc.', { parse_mode: 'Markdown' });
  }

  if (data === 'btn_resume') {
    const { text, keyboard } = renderResumeMenu(userId);
    await editSafeMessageOrCaption(ctx, text, { reply_markup: keyboard });
    return;
  }

  if (data === 'btn_resume_agy') {
    const { text, keyboard } = renderResumeMenu(userId, 'antigravity');
    await editSafeMessageOrCaption(ctx, text, { reply_markup: keyboard });
    return;
  }

  if (data === 'btn_resume_oc') {
    const { text, keyboard } = renderResumeMenu(userId, 'opencode');
    await editSafeMessageOrCaption(ctx, text, { reply_markup: keyboard });
    return;
  }

  if (data.startsWith('resume_')) {
    const convId = data.replace('resume_', '');
    const conv = getConversationById(convId);
    updateSession(userId, { conversationId: convId });

    return ctx.reply(
      `🔄 *Sesi Antigravity Di-Resume!*\n\n📌 **Judul**: ${conv?.title || 'Sesi'}\n🆔 \`${convId}\`\n\nSilakan kirim pesan untuk melanjutkan percakapan.`,
      { parse_mode: 'Markdown' }
    );
  }

  if (data.startsWith('ocresume_')) {
    const sesId = data.replace('ocresume_', '');
    const ses = getOpenCodeSessionById(sesId);
    updateSession(userId, { opencodeSessionId: sesId });

    return ctx.reply(
      `🔄 *Sesi OpenCode Di-Resume!*\n\n📌 **Judul**: ${ses?.title || 'Sesi'}\n🆔 \`${sesId}\`\n\nSilakan kirim pesan untuk melanjutkan percakapan.`,
      { parse_mode: 'Markdown' }
    );
  }

  if (data === 'btn_model') {
    const { text, keyboard } = renderModelMenu(userId);
    await editSafeMessageOrCaption(ctx, text, { reply_markup: keyboard });
    return;
  }

  if (data === 'btn_model_agy') {
    const { text, keyboard } = renderModelMenu(userId, 'antigravity');
    await editSafeMessageOrCaption(ctx, text, { reply_markup: keyboard });
    return;
  }

  if (data === 'btn_model_oc') {
    const { text, keyboard } = renderModelMenu(userId, 'opencode');
    await editSafeMessageOrCaption(ctx, text, { reply_markup: keyboard });
    return;
  }

  if (data.startsWith('ocmodel_')) {
    const mId = data.replace('ocmodel_', '');
    updateSession(userId, { opencodeModel: mId });
    await ctx.answerCallbackQuery({ text: `✅ Model OpenCode: ${mId}` }).catch(() => {});
    const { text, keyboard } = renderModelMenu(userId, 'opencode');
    await editSafeMessageOrCaption(ctx, text, { reply_markup: keyboard });
    return;
  }

  if (data.startsWith('model_')) {
    const mId = data.replace('model_', '');
    // Models that don't support effort — reset effort to auto on model switch
    const MODELS_NO_EFFORT = ['claude-sonnet-4-6', 'claude-opus-4-6', 'gpt-oss-120b-medium', 'gpt-4o', 'deepseek-chat'];
    const effortReset = MODELS_NO_EFFORT.some(m => mId.toLowerCase().includes(m.toLowerCase()));
    const updates = { model: mId };
    if (effortReset) updates.effort = 'auto';
    updateSession(userId, updates);
    await ctx.answerCallbackQuery({ text: `✅ Model Antigravity: ${mId}` }).catch(() => {});
    const { text, keyboard } = renderModelMenu(userId, 'antigravity');
    await editSafeMessageOrCaption(ctx, text, { reply_markup: keyboard });
    return;
  }

  if (data === 'btn_status') {
    const session = getSession(userId);
    const running = isUserRunning(userId);
    const engine = session.engine || 'antigravity';
    const engineLabel = engine === 'opencode' ? 'OpenCode 💻' : 'Antigravity 🤖';
    const ocModel = (session.opencodeModel || 'opencode/deepseek-v4.1-flash-free').replace('opencode/', '');
    const statusText =
      `⚙️ *Status Sistem & Sesi Dual AI*

• ⚙️ *Active Engine*: *${engineLabel}*
• 🤖 *Agent Status*: ${running ? '🟡 *Sedang Berjalan*' : '🟢 *Idle (Siap)*'}
• 💬 *Antigravity Conv ID*: \`${session.conversationId || 'Belum ada (Sesi Baru)'}\`
• 💻 *OpenCode Session ID*: \`${session.opencodeSessionId || 'Belum ada (Sesi Baru)'}\`
• 🧠 *Model Antigravity*: \`${session.model}\`
• 💻 *Model OpenCode*: \`${ocModel}\`
• 🎯 *Effort*: \`${session.effort}\`
• 🛠️ *Mode*: \`${session.mode}\`
• 📂 *Workspace*: \`${session.cwd}\`
• 📊 *Token Sesi*: *${formatTokens(session.sessionStats?.totalTokens)}*`;

    return sendSafeMessage(ctx, statusText);
  }

  if (data.startsWith('effort_')) {
    const eff = data.replace('effort_', '');
    updateSession(userId, { effort: eff });
    return ctx.reply(`🎯 Effort diubah ke: \`${eff}\``, { parse_mode: 'Markdown' });
  }

  if (data.startsWith('mode_')) {
    const mod = data.replace('mode_', '');
    updateSession(userId, { mode: mod });
    return ctx.reply(`⚙️ Mode agent diubah ke: \`${mod}\``, { parse_mode: 'Markdown' });
  }

  if (data === 'btn_help') {
    return ctx.reply(
      `📖 *Tips Penggunaan*:
1. Chat biasa langsung direspon oleh Antigravity Agent.
2. Gunakan /new jika ingin ganti topik baru.
3. Gunakan /resume untuk melihat atau kembali ke sesi lama.
4. Gunakan /model untuk ganti model AI kapan saja.
5. Gunakan /abort jika ingin membatalkan eksekusi agent yang sedang berjalan.`,
      { parse_mode: 'Markdown' }
    );
  }

  if (data.startsWith('tt_audio_')) {
    const id = data.replace('tt_audio_', '');
    const audioData = tiktokAudioCache.get(id);
    if (!audioData || !audioData.musicUrl) {
      return ctx.reply('⚠️ Link audio sudah kedaluwarsa atau tidak tersedia.');
    }
    const waitMsg = await ctx.reply('🎵 Mengunduh file audio MP3...');
    try {
      const audioBuf = await fetchMediaBuffer(audioData.musicUrl);
      await ctx.replyWithAudio(new InputFile(audioBuf, `${audioData.title || 'tiktok_audio'}.mp3`), {
        title: audioData.title || 'TikTok Audio',
        performer: audioData.author || 'TikTok'
      });
      try {
        await ctx.api.deleteMessage(ctx.chat.id, waitMsg.message_id);
      } catch (e) {}
    } catch (err) {
      await ctx.reply(`❌ Gagal download audio: ${err.message}`);
    }
    return;
  }

  if (data === 'btn_cancel') {
    try {
      await ctx.deleteMessage();
    } catch (e) {}
  }
});

/**
 * Detect whether a prompt is a coding / system task vs casual chat
 * @param {string} prompt 
 * @returns {boolean}
 */
function isCodingOrComplexTask(prompt) {
  if (!prompt) return false;
  const p = prompt.toLowerCase().trim();

  // Code snippets, multi-line blocks, or long structured instructions
  if (prompt.includes('```') || prompt.includes('\n\n') || prompt.length > 180) {
    return true;
  }

  // Keywords that indicate coding, debugging, file manipulation, or system tasks
  const taskKeywords = [
    'buat', 'buatkan', 'bikin', 'create', 'write', 'code', 'coding', 'script', 'program',
    'fungsi', 'function', 'class', 'method', 'api', 'endpoint', 'database', 'sql',
    'query', 'debug', 'error', 'fix', 'perbaiki', 'benerin', 'cek file', 'edit',
    'ubah file', 'tulis file', 'baca file', 'install', 'jalankan', 'run', 'eksekusi',
    'terminal', 'bash', 'command', 'vps', 'server', 'deploy', 'git', 'pm2', 'docker',
    'bot', 'html', 'css', 'javascript', 'python', 'node', 'express', 'react',
    'vue', 'regex', 'algoritma', 'hitung', 'analisis', 'arsitektur', 'refactor',
    'tambah fitur', 'fitur baru', 'modifikasi', 'hapus file', 'buat folder', 'curl'
  ];

  for (const kw of taskKeywords) {
    const regex = new RegExp(`(^|\\s|[^a-zA-Z0-9])${kw}($|\\s|[^a-zA-Z0-9])`, 'i');
    if (regex.test(p)) {
      return true;
    }
  }

  return false;
}

// Core Agent Turn Execution Function
async function handleAgentTurn(ctx, prompt, forceEngine = null) {
  const userId = ctx.from.id;
  const uId = String(userId);
  const session = getSession(userId);
  const activeEngine = forceEngine || session.engine || 'antigravity';
  const isOpencode = activeEngine === 'opencode';
  const engineLabel = isOpencode ? 'OpenCode' : 'Antigravity';
  const engineIcon = isOpencode ? '💻' : '⚡';

  const replyParams = ctx.message ? { reply_parameters: { message_id: ctx.message.message_id } } : {};

  if (isUserRunning(uId)) {
    return ctx.reply('⚠️ Agent masih menjalankan tugas sebelumnya. Kirim /stop jika ingin membatalkan.', replyParams);
  }

  // Register turn immediately
  const turnRecord = { aborted: false, statusMsg: null, chatId: ctx.chat?.id };
  activeUserTurns.set(uId, turnRecord);

  // Telegram visual & haptic reaction to notify user request was acknowledged immediately
  ctx.react(isOpencode ? '💻' : '⚡').catch(() => {});

  const isTask = isCodingOrComplexTask(prompt);
  const stopButton = new InlineKeyboard().text('🛑 Stop Perintah (/stop)', 'action_stop_active');

  // Models that do NOT support --effort flag at all (will error if passed)
  const MODELS_NO_EFFORT = [
    'claude-sonnet-4-6', 'claude-opus-4-6', 'claude-opus-4-6-thinking',
    'gpt-oss-120b-medium', 'gpt-4o', 'deepseek-chat'
  ];

  // Only pass explicit effort if user has manually set it (not 'auto') AND the model supports it.
  // Reason: --effort conflicts with certain models causing empty response → "Tugas selesai tanpa output teks."
  let effectiveEffort = session.effort;
  const modelSupportsEffort = !MODELS_NO_EFFORT.some(m => session.model?.toLowerCase().includes(m.toLowerCase()));
  if (!effectiveEffort || effectiveEffort === 'auto' || !modelSupportsEffort) {
    effectiveEffort = null; // Do not pass --effort flag; let model handle it natively
  }

  let statusMsg = null;
  // Always pulse native typing chat action so Telegram top bar shows "typing..."
  ctx.replyWithChatAction('typing').catch(() => {});
  let typingTimer = setInterval(() => {
    ctx.replyWithChatAction('typing').catch(() => {});
  }, 3500);

  try {
    statusMsg = await ctx.reply(`${engineIcon} *${engineLabel} sedang memproses permintaan Anda...*`, {
      parse_mode: 'Markdown',
      ...replyParams,
      reply_markup: stopButton
    });
    turnRecord.statusMsg = statusMsg;
  } catch (e) {
    try {
      statusMsg = await ctx.reply(`${engineIcon} ${engineLabel} sedang memproses permintaan Anda...`, {
        ...replyParams,
        reply_markup: stopButton
      });
      turnRecord.statusMsg = statusMsg;
    } catch (_) {}
  }

  if (turnRecord.aborted) {
    activeUserTurns.delete(uId);
    if (typingTimer) clearInterval(typingTimer);
    return;
  }

  let lastStatusUpdate = Date.now();
  const updateStatus = async (newText) => {
    if (!statusMsg) return;
    const now = Date.now();
    if (now - lastStatusUpdate < 1500) return;
    lastStatusUpdate = now;

    try {
      await ctx.api.editMessageText(
        ctx.chat.id,
        statusMsg.message_id,
        `${engineIcon} *${engineLabel} Agent*: ${newText}`,
        { parse_mode: 'Markdown', reply_markup: stopButton }
      );
    } catch (e) {}
  };

  const startTime = Date.now();

  try {
    let result;
    if (isOpencode) {
      result = await runOpenCode({
        userId,
        prompt,
        sessionId: session.opencodeSessionId,
        model: session.opencodeModel || 'opencode/deepseek-v4.1-flash-free',
        cwd: session.cwd,
        onProgress: (event) => {
          if (event.type === 'tool_start') {
            const formatted = formatToolNotification(event.tool, event.params);
            updateStatus(`🛠️ Sedang mengeksekusi:\n${formatted}`);
          } else if (event.type === 'init' && event.session_id) {
            if (!session.opencodeSessionId) {
              updateSession(userId, { opencodeSessionId: event.session_id });
            }
          }
        }
      });
    } else {
      result = await runAgy({
        userId,
        prompt,
        conversationId: session.conversationId,
        model: session.model,
        effort: effectiveEffort,
        mode: session.mode,
        cwd: session.cwd,
        onProgress: (event) => {
          if (event.type === 'tool_start') {
            const formatted = formatToolNotification(event.tool, event.params);
            updateStatus(`🛠️ Sedang mengeksekusi:\n${formatted}`);
          } else if (event.type === 'init' && event.conversation_id) {
            // Record conversation ID early
            if (!session.conversationId) {
              updateSession(userId, { conversationId: event.conversation_id });
            }
          }
        }
      });
    }

    if (typingTimer) {
      clearInterval(typingTimer);
      typingTimer = null;
    }

    // Delete progress message
    if (statusMsg) {
      try {
        await ctx.api.deleteMessage(ctx.chat.id, statusMsg.message_id);
      } catch (e) {}
    }

    if (result.aborted) {
      return; // Handled directly by /stop or action_stop_active
    }

    if (!result.success) {
      const errStr = result.error || 'Unknown error';
      // Detect quota exhausted (Antigravity)
      if (!isOpencode && /quota reached|RESOURCE_EXHAUSTED|429/i.test(errStr)) {
        // Auto-switch to gemini-3.8-flash-high
        updateSession(userId, { model: 'gemini-3.8-flash-high', effort: 'auto' });
        return ctx.reply(
          `⚠️ <b>Limit/Quota Model Tercapai!</b>\n\n` +
          `Model <code>${session.model}</code> sedang kehabisan limit quota.\n` +
          `Sistem telah mengalihkan model Anda ke: <code>gemini-3.8-flash-high</code>.\n\n` +
          `Silakan ulangi perintah Anda: <code>/ai ${escapeHtml(prompt.slice(0, 80))}</code>`,
          { parse_mode: 'HTML', ...replyParams }
        );
      }
      return ctx.reply(
        `❌ *Terjadi Kesalahan saat memproses permintaan:*\n\n\`\`\`\n${errStr}\n\`\`\``,
        { parse_mode: 'Markdown', ...replyParams }
      );
    }

    // Update conversation/session ID if newly assigned
    if (isOpencode && result.session_id) {
      updateSession(userId, { opencodeSessionId: result.session_id });
    } else if (!isOpencode && result.conversation_id) {
      updateSession(userId, { conversationId: result.conversation_id });
    }

    // Accumulate stats
    if (result.usage) {
      const u = result.usage;
      const sStats = session.sessionStats || {};
      const lStats = session.lifetimeStats || {};

      sStats.inputTokens = (sStats.inputTokens || 0) + (u.input_tokens || 0);
      sStats.outputTokens = (sStats.outputTokens || 0) + (u.output_tokens || 0);
      sStats.thinkingTokens = (sStats.thinkingTokens || 0) + (u.thinking_tokens || 0);
      sStats.totalTokens = (sStats.totalTokens || 0) + (u.total_tokens || 0);
      sStats.turns = (sStats.turns || 0) + 1;

      lStats.totalTurns = (lStats.totalTurns || 0) + 1;
      lStats.totalTokens = (lStats.totalTokens || 0) + (u.total_tokens || 0);

      updateSession(userId, { sessionStats: sStats, lifetimeStats: lStats });
    }

    // Prepare response
    const responseText = (result.response || '').trim();
    if (!responseText) {
      return ctx.reply('✅ Tugas selesai dieksekusi tanpa output teks.', replyParams);
    }

    // Calculate actual turn duration for this request (NOT entire conversation age)
    const turnDuration = (Date.now() - startTime) / 1000;
    const activeModel = isOpencode ? (session.opencodeModel || 'opencode/deepseek-v4.1-flash-free') : session.model;
    const footer = isTask ? formatMetadataFooter(turnDuration, activeModel, result.usage, activeEngine) : '';
    const finalContent = responseText + footer;

    await sendSafeMessage(ctx, finalContent, replyParams);
  } catch (err) {
    if (typingTimer) {
      clearInterval(typingTimer);
      typingTimer = null;
    }
    if (statusMsg) {
      try {
        await ctx.api.deleteMessage(ctx.chat.id, statusMsg.message_id);
      } catch (e) {}
    }

    console.error('Error during handleAgentTurn:', err);
    await ctx.reply(`💥 *Terjadi error internal:* ${err.message}`, {
      parse_mode: 'Markdown',
      ...replyParams
    });
  } finally {
    activeUserTurns.delete(uId);
    if (typingTimer) {
      clearInterval(typingTimer);
      typingTimer = null;
    }
  }
}

// Handling Normal Text Messages (Ignored unless via /ai or auto-detected cookie/key)
bot.on('message:text', async (ctx) => {
  const text = ctx.message.text.trim();
  if (text.startsWith('/')) return; // ignore unhandled commands

  // Auto-detect pasted Cookie JSON or Raw Cookies without /loginais prefix
  if ((text.startsWith('[') && text.includes('SID')) || (text.includes('__Secure-1PSID') && text.includes('SAPISID'))) {
    ctx.react('🔐').catch(() => {});
    const statusMsg = await ctx.reply('⏳ *Format cookies terdeteksi. Memverifikasi sesi Google AI Studio Anda...*', {
      parse_mode: 'Markdown',
      reply_parameters: { message_id: ctx.message.message_id }
    });

    const result = await verifyAndSaveSession(ctx.from.id, text);
    try { await ctx.api.deleteMessage(ctx.chat.id, statusMsg.message_id); } catch (_) {}

    if (result.success) {
      const keyboard = new InlineKeyboard()
        .text('📱 Buka Menu AI Studio (/menuais)', 'action_ais_menu')
        .row()
        .text('💬 New App / Chat', 'action_ais_new')
        .text('📂 Resume Prompts', 'action_ais_resume');

      return ctx.reply(
        `✅ <b>Login Google AI Studio Berhasil!</b>\n\n` +
        `👤 <b>Akun:</b> <code>${escapeHtml(result.email)}</code>\n` +
        `🌐 <b>Status:</b> Terhubung real-time ke Google AI Studio (Web Playground)\n\n` +
        `Sesi aktif langsung di akun Google Anda tanpa limit API Key!\n` +
        `Ketik <code>/menuais</code> untuk mengontrol AI Studio atau <code>/ais &lt;prompt&gt;</code> untuk langsung chat.`,
        {
          parse_mode: 'HTML',
          reply_parameters: { message_id: ctx.message.message_id },
          reply_markup: keyboard
        }
      );
    } else {
      return ctx.reply(
        `❌ <b>Gagal Login ke Google AI Studio:</b>\n\n<blockquote>${escapeHtml(result.error)}</blockquote>`,
        {
          parse_mode: 'HTML',
          reply_parameters: { message_id: ctx.message.message_id }
        }
      );
    }
  }

  // All normal messages are completely ignored as requested:
  // "untuk seterusnya kamu hanya di menu (/ai) ya selain itu mau pesan apapun gausah di jawab gausah di hiraukan"
  return;
});

// Handling Document / Photo Messages (Attachment inspection)
bot.on(['message:document', 'message:photo'], async (ctx) => {
  const caption = (ctx.message.caption || '').trim();

  // Smart auto-update profile photo if user asked to set it as avatar/profile
  if (/foto\s*profil|profile\s*photo|avatar|setpp/i.test(caption)) {
    try {
      const file = await ctx.getFile();
      const fileName = ctx.message.document?.file_name || `photo_${Date.now()}.jpg`;
      const fileUrl = `https://api.telegram.org/file/bot${BOT_TOKEN}/${file.file_path}`;
      const res = await fetch(fileUrl);
      const arrayBuffer = await res.arrayBuffer();

      const form = new FormData();
      form.append('photo', JSON.stringify({ type: 'static', photo: 'attach://bot_profile_jpg' }));
      form.append('bot_profile_jpg', new Blob([Buffer.from(arrayBuffer)]), fileName);
      const setRes = await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/setMyProfilePhoto`, {
        method: 'POST',
        body: form
      });
      const setJson = await setRes.json();
      if (setJson.ok) {
        return ctx.reply('✨ <b>Foto profil bot berhasil diperbarui!</b>', { parse_mode: 'HTML' });
      }
    } catch (e) {
      console.error('Failed auto-updating bot profile photo:', e);
    }
  }

  // If document with caption starting with /remotion
  if (ctx.message.document && caption.startsWith('/remotion')) {
    const compositionId = caption.replace('/remotion', '').trim();
    return handleRemotionRender(ctx, ctx.message.document, compositionId);
  }

  // Handle cookie file upload for Google AI Studio login
  if (ctx.message.document) {
    const docName = (ctx.message.document.file_name || '').toLowerCase();
    if (caption.startsWith('/loginais') || docName.includes('cookie') || (docName.endsWith('.json') && caption.includes('login'))) {
      ctx.react('🔐').catch(() => {});
      const statusMsg = await ctx.reply('⏳ *File cookies terdeteksi. Memverifikasi sesi Google AI Studio...*', {
        parse_mode: 'Markdown',
        reply_parameters: { message_id: ctx.message.message_id }
      });
      try {
        const file = await ctx.getFile();
        const fileUrl = `https://api.telegram.org/file/bot${BOT_TOKEN}/${file.file_path}`;
        const res = await fetch(fileUrl);
        const text = await res.text();
        const result = await verifyAndSaveSession(ctx.from.id, text);
        try { await ctx.api.deleteMessage(ctx.chat.id, statusMsg.message_id); } catch (_) {}

        if (result.success) {
          const kb = new InlineKeyboard()
            .text('📱 Buka Menu AI Studio (/menuais)', 'action_ais_menu').row()
            .text('💬 New App / Chat', 'action_ais_new')
            .text('📂 Resume Prompts', 'action_ais_resume');

          return ctx.reply(
            `✅ <b>Login Google AI Studio Berhasil via File!</b>\n\n` +
            `👤 <b>Akun:</b> <code>${escapeHtml(result.email)}</code>\n` +
            `🌐 <b>Status:</b> Terhubung real-time ke <code>aistudio.google.com</code>\n\n` +
            `Ketik <code>/menuais</code> untuk membuka dashboard atau <code>/ais &lt;prompt&gt;</code> untuk langsung chat.`,
            { parse_mode: 'HTML', reply_markup: kb, reply_parameters: { message_id: ctx.message.message_id } }
          );
        } else {
          return ctx.reply(
            `❌ <b>Verifikasi Sesi Gagal:</b>\n\n<blockquote>${escapeHtml(result.error)}</blockquote>\n\n` +
            `Pastikan file cookies diekspor saat Anda aktif login di <code>aistudio.google.com</code>.`,
            { parse_mode: 'HTML', reply_parameters: { message_id: ctx.message.message_id } }
          );
        }
      } catch (err) {
        try { await ctx.api.deleteMessage(ctx.chat.id, statusMsg.message_id); } catch (_) {}
        return ctx.reply(`❌ <b>Gagal membaca file:</b> ${escapeHtml(err.message)}`, {
          parse_mode: 'HTML',
          reply_parameters: { message_id: ctx.message.message_id }
        });
      }
    }
  }

  // If caption starts with /ai, pass it to AI Agent
  if (caption.startsWith('/ai')) {
    const prompt = caption.replace('/ai', '').trim() || 'Analisis dan jelaskan file yang saya kirimkan ini.';
    await ctx.reply('📎 Menerima file. Mengunduh ke workspace untuk diproses AI...');
    try {
      const file = await ctx.getFile();
      const downloadDir = path.join(getSession(ctx.from.id).cwd, 'telegram_uploads');
      if (!fs.existsSync(downloadDir)) {
        fs.mkdirSync(downloadDir, { recursive: true });
      }

      const fileName = ctx.message.document?.file_name || `photo_${Date.now()}.jpg`;
      const localFilePath = path.join(downloadDir, fileName);

      const fileUrl = `https://api.telegram.org/file/bot${BOT_TOKEN}/${file.file_path}`;
      const res = await fetch(fileUrl);
      const arrayBuffer = await res.arrayBuffer();
      fs.writeFileSync(localFilePath, Buffer.from(arrayBuffer));

      const promptWithFile = `${prompt}\n\n[File tersimpan di: ${localFilePath}]`;
      await handleAgentTurn(ctx, promptWithFile);
    } catch (err) {
      console.error('File download error:', err);
      await ctx.reply(`❌ Gagal mengunduh file: ${err.message}`);
    }
    return;
  }

  // Otherwise ignore
  return;
});

// WebApp Data Handler (Receives submissions from Telegram Mini App)
bot.on('message:web_app_data', async (ctx) => {
  try {
    const rawData = ctx.message.web_app_data.data;
    const payload = JSON.parse(rawData);
    const userId = ctx.from.id;

    if (payload.type === 'ai_prompt') {
      if (!payload.prompt) return;
      await ctx.reply(
        `🤖 <b>AI Agent:</b> Menjalankan perintah dari WebApp:\n<blockquote>${escapeHtml(payload.prompt)}</blockquote>`,
        { parse_mode: 'HTML' }
      );
      await handleAgentTurn(ctx, payload.prompt);
    } else if (payload.type === 'tiktok') {
      if (!payload.url) return;
      await handleTikTokDownload(ctx, payload.url);
    } else if (payload.type === 'videy') {
      if (!payload.url) return;
      await handleVideyDownload(ctx, payload.url);
    } else if (payload.type === 'ouo') {
      if (!payload.url) return;
      await handleOuoSolver(ctx, payload.url);
    } else if (payload.type === 'new_session') {
      resetSession(userId);
      await ctx.reply('✨ <b>Sesi baru dimulai!</b> Silakan kirim <code>/ai &lt;pesan&gt;</code> untuk mulai.', { parse_mode: 'HTML' });
    } else if (payload.type === 'change_model') {
      updateSession(userId, { model: payload.model });
      await ctx.reply(`✅ <b>Model AI diubah ke:</b> <code>${payload.model}</code>`, { parse_mode: 'HTML' });
    } else if (payload.type === 'stop') {
      const running = isUserRunning(userId);
      if (!running) {
        await ctx.reply('ℹ️ Tidak ada tugas agent yang sedang berjalan saat ini.');
      } else {
        abortUserProcess(userId);
        await ctx.reply('🛑 <b>Perintah berhasil dihentikan (ESC).</b>', { parse_mode: 'HTML' });
      }
    } else if (payload.type === 'backup') {
      await handleBackupAction(ctx);
    } else if (payload.type === 'aistudio_login' && payload.cookies) {
      const statusMsg = await ctx.reply('⏳ *Memverifikasi sesi Google AI Studio dari WebApp...*', { parse_mode: 'Markdown' });
      const result = await verifyAndSaveSession(userId, payload.cookies);
      try { await ctx.api.deleteMessage(ctx.chat.id, statusMsg.message_id); } catch (_) {}
      if (result.success) {
        await ctx.reply(
          `✅ <b>Login Google AI Studio Berhasil via WebApp!</b>\n\n` +
          `👤 <b>Akun:</b> <code>${escapeHtml(result.email)}</code>\n` +
          `🌐 <b>Status:</b> Terhubung real-time ke <code>aistudio.google.com</code>\n\n` +
          `Ketik <code>/menuais</code> untuk mengontrol AI Studio.`,
          { parse_mode: 'HTML' }
        );
      } else {
        await ctx.reply(`❌ <b>Gagal Verifikasi:</b>\n${escapeHtml(result.error)}`, { parse_mode: 'HTML' });
      }
    }
  } catch (err) {
    console.error('Error handling web_app_data:', err);
  }
});

// Error handling
bot.catch((err) => {
  console.error('GrammY Bot Error:', err);
});

// Start WebApp service & Cloudflare quick tunnel
startWebAppService(
  {
    getStatus: () => {
      const config = getConfig();
      const ownerSession = config.ownerId ? getSession(config.ownerId) : null;
      return {
        model: ownerSession?.model || 'gemini-3.8-flash-high',
        effort: ownerSession?.effort || 'auto',
        mode: ownerSession?.mode || 'auto',
        cwd: ownerSession?.cwd || '/home/nanasmuda'
      };
    },
    onAction: async (payload) => {
      const config = getConfig();
      const ownerId = config.ownerId;
      if (!ownerId) return;

      if (payload.type === 'ai_prompt' && payload.prompt) {
        await bot.api.sendMessage(
          ownerId,
          `🤖 <b>AI Agent:</b> Menerima prompt dari WebApp:\n<blockquote>${escapeHtml(payload.prompt)}</blockquote>`,
          { parse_mode: 'HTML' }
        );
        const dummyCtx = {
          from: { id: ownerId, first_name: 'Owner' },
          chat: { id: ownerId },
          reply: (msg, opts) => bot.api.sendMessage(ownerId, msg, opts),
          replyWithChatAction: (action) => bot.api.sendChatAction(ownerId, action)
        };
        await handleAgentTurn(dummyCtx, payload.prompt);
      } else if (payload.type === 'videy' && payload.url) {
        const dummyCtx = {
          from: { id: ownerId, first_name: 'Owner' },
          chat: { id: ownerId },
          reply: (msg, opts) => bot.api.sendMessage(ownerId, msg, opts),
          replyWithVideo: (video, opts) => bot.api.sendVideo(ownerId, video, opts),
          replyWithDocument: (doc, opts) => bot.api.sendDocument(ownerId, doc, opts),
          api: bot.api
        };
        await handleVideyDownload(dummyCtx, payload.url);
      } else if (payload.type === 'tiktok' && payload.url) {
        const dummyCtx = {
          from: { id: ownerId, first_name: 'Owner' },
          chat: { id: ownerId },
          reply: (msg, opts) => bot.api.sendMessage(ownerId, msg, opts),
          replyWithVideo: (video, opts) => bot.api.sendVideo(ownerId, video, opts),
          replyWithDocument: (doc, opts) => bot.api.sendDocument(ownerId, doc, opts),
          api: bot.api
        };
        await handleTikTokDownload(dummyCtx, payload.url);
      } else if (payload.type === 'ouo' && payload.url) {
        const dummyCtx = {
          from: { id: ownerId, first_name: 'Owner' },
          chat: { id: ownerId },
          reply: (msg, opts) => bot.api.sendMessage(ownerId, msg, opts),
          api: bot.api
        };
        await handleOuoSolver(dummyCtx, payload.url);
      } else if (payload.type === 'new_session') {
        resetSession(ownerId);
        await bot.api.sendMessage(ownerId, '✨ <b>Sesi baru dimulai!</b> Silakan kirim <code>/ai &lt;pesan&gt;</code>.', { parse_mode: 'HTML' });
      } else if (payload.type === 'change_model' && payload.model) {
        updateSession(ownerId, { model: payload.model });
        await bot.api.sendMessage(ownerId, `✅ <b>Model AI berhasil diubah ke:</b> <code>${payload.model}</code>`, { parse_mode: 'HTML' });
      } else if (payload.type === 'stop') {
        const running = isUserRunning(ownerId);
        if (running) {
          abortUserProcess(ownerId);
          await bot.api.sendMessage(ownerId, '🛑 <b>Perintah berhasil dihentikan (ESC).</b>', { parse_mode: 'HTML' });
        }
      } else if (payload.type === 'aistudio_login' && payload.cookies) {
        const statusMsg = await bot.api.sendMessage(ownerId, '⏳ <i>Memverifikasi sesi Google AI Studio dari WebApp...</i>', { parse_mode: 'HTML' });
        const result = await verifyAndSaveSession(ownerId, payload.cookies);
        try { await bot.api.deleteMessage(ownerId, statusMsg.message_id); } catch (_) {}
        if (result.success) {
          await bot.api.sendMessage(
            ownerId,
            `✅ <b>Login Google AI Studio Berhasil!</b>\n\n` +
            `👤 <b>Akun:</b> <code>${escapeHtml(result.email)}</code>\n` +
            `🌐 <b>Status:</b> Terhubung real-time ke <code>aistudio.google.com</code>\n\n` +
            `Ketik <code>/menuais</code> untuk mengontrol AI Studio.`,
            { parse_mode: 'HTML' }
          );
        } else {
          await bot.api.sendMessage(
            ownerId,
            `❌ <b>Verifikasi Google AI Studio Gagal:</b>\n\n<blockquote>${escapeHtml(result.error)}</blockquote>`,
            { parse_mode: 'HTML' }
          );
        }
      }
    }
  },
  async (tunnelUrl) => {
    try {
      await bot.api.setChatMenuButton({
        menu_button: {
          type: 'web_app',
          text: '📱 Menu App',
          web_app: { url: tunnelUrl }
        }
      });
      console.log(`✅ Set Telegram Chat Menu Button to: ${tunnelUrl}`);
    } catch (err) {
      console.warn('Failed to set chat menu button:', err.message);
    }
  }
);

// Global process error handlers
process.on('unhandledRejection', (reason, promise) => {
  console.error('Unhandled Rejection at:', promise, 'reason:', reason);
});

process.on('uncaughtException', (err) => {
  console.error('Uncaught Exception:', err);
  process.exit(1); // Exit so PM2 supervisor can immediately restart a healthy instance
});

// Start bot with concurrent runner
console.log('🤖 Menjalankan Antigravity Telegram Bot...');

(async () => {
  try {
    await bot.init();
    const botInfo = bot.botInfo;
    console.log(`✅ Bot berhasil aktif sebagai @${botInfo.username} (${botInfo.first_name})`);

    try {
      await bot.api.setMyCommands([
        { command: 'ai', description: 'Tanya AI / coding (sesuai engine aktif)' },
        { command: 'oc', description: 'Tanya langsung ke OpenCode AI' },
        { command: 'engine', description: 'Pilih AI Engine (Antigravity / OpenCode)' },
        { command: 'ocmodel', description: 'Ganti model OpenCode AI' },
        { command: 'ocresume', description: 'Lanjutkan sesi percakapan OpenCode' },
        { command: 'ocnew', description: 'Reset ke sesi baru OpenCode' },
        { command: 'menuais', description: 'Dashboard Google AI Studio' },
        { command: 'aismode', description: 'Ganti mode AI Studio (API / Web Playground)' },
        { command: 'modelais', description: 'Ganti model AI Studio (Argon / Flash)' },
        { command: 'loginais', description: 'Login Google AI Studio' },
        { command: 'ais', description: 'Chat langsung via Google AI Studio' },
        { command: 'stop', description: 'Hentikan tugas AI yang sedang berjalan (ESC)' },
        { command: 'menu', description: 'Buka Menu Dashboard Control Panel' },
        { command: 'tt', description: 'Download video TikTok tanpa watermark' },
        { command: 'ouo', description: 'Bypass / solver shortlink OuO' },
        { command: 'new', description: 'Reset ke sesi percakapan baru' },
        { command: 'resume', description: 'Lanjutkan sesi percakapan sebelumnya' },
        { command: 'model', description: 'Ganti model Antigravity AI' },
        { command: 'effort', description: 'Atur reasoning effort' },
        { command: 'backup', description: 'Download file backup ZIP project' },
        { command: 'spek', description: 'Cek spesifikasi hardware & server VPS' },
        { command: 'status', description: 'Cek status bot & pemakaian token' },
        { command: 'help', description: 'Bantuan & daftar perintah' }
      ]);
      console.log('✅ Telegram bot commands menu registered successfully!');
    } catch (err) {
      console.warn('Failed registering bot commands:', err.message);
    }

    const runner = runGrammy(bot, {
      runner: {
        fetch: {
          allowed_updates: ['message', 'callback_query']
        }
      }
    });
    console.log('🚀 Grammy Concurrent Runner started successfully!');

    const stopRunner = () => {
      if (runner.isRunning()) {
        runner.stop();
      }
    };
    process.once('SIGINT', stopRunner);
    process.once('SIGTERM', stopRunner);
  } catch (err) {
    console.error('Fatal error starting bot:', err);
    process.exit(1);
  }
})();
