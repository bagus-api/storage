const { spawn } = require('node:child_process');
const fs = require('node:fs');
const path = require('node:path');

const WORKER_SCRIPT = path.join(__dirname, 'remotion-worker.js');

/**
 * Render video from an uploaded ZIP buffer using an isolated child process
 * to guarantee zero memory bloat in bot.js and zero lingering files.
 * @param {object} options
 * @param {Buffer} options.zipBuffer
 * @param {string} [options.compositionId]
 * @param {function} [options.onProgress]
 * @returns {Promise<{videoBuffer: Buffer, fileName: string, compositionId: string, durationSeconds: number}>}
 */
async function processRemotionZip({ zipBuffer, compositionId, onProgress }) {
  const jobId = `remotion_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const jobDir = path.join('/tmp', jobId);
  const zipPath = path.join(jobDir, 'project.zip');

  try {
    fs.mkdirSync(jobDir, { recursive: true });
    fs.writeFileSync(zipPath, zipBuffer);

    if (onProgress) onProgress(3, '📦 Mempersiapkan render worker...');

    const result = await new Promise((resolve, reject) => {
      const child = spawn(
        process.execPath,
        ['--max-old-space-size=280', WORKER_SCRIPT, jobDir, compositionId || ''],
        {
          cwd: __dirname,
          env: {
            ...process.env,
            LD_LIBRARY_PATH: `/home/nanasmuda/.local/lib:${process.env.LD_LIBRARY_PATH || ''}`,
            PATH: `/home/nanasmuda/.local/bin:${process.env.PATH || ''}`
          }
        }
      );

      let lastPercent = 5;
      let errorOutput = '';
      let doneData = null;

      let stdoutBuffer = '';
      child.stdout.on('data', (chunk) => {
        stdoutBuffer += chunk.toString('utf8');
        const lines = stdoutBuffer.split('\n');
        stdoutBuffer = lines.pop(); // keep last incomplete line

        for (const line of lines) {
          if (!line.trim()) continue;
          try {
            const data = JSON.parse(line.trim());
            if (data.type === 'progress' && onProgress) {
              if (data.percent > lastPercent) {
                lastPercent = data.percent;
                onProgress(data.percent, data.msg);
              }
            } else if (data.type === 'done') {
              doneData = data;
            }
          } catch (_) {}
        }
      });

      child.stderr.on('data', (chunk) => {
        errorOutput += chunk.toString('utf8');
      });

      child.on('error', (err) => {
        reject(new Error(`Gagal menjalankan render worker: ${err.message}`));
      });

      child.on('close', (code, signal) => {
        if (code === 0 && doneData && fs.existsSync(doneData.outputPath)) {
          resolve(doneData);
        } else {
          const detail = errorOutput.trim() || `Exit code ${code}, signal ${signal}`;
          reject(new Error(`Render video gagal: ${detail.slice(0, 300)}`));
        }
      });
    });

    const videoBuffer = fs.readFileSync(result.outputPath);

    return {
      videoBuffer,
      fileName: `remotion_${result.compositionId}.mp4`,
      compositionId: result.compositionId,
      durationSeconds: result.durationSeconds
    };
  } finally {
    // CLEANUP GUARANTEE: Delete unzipped folder and rendered mp4 from disk
    try {
      if (fs.existsSync(jobDir)) {
        fs.rmSync(jobDir, { recursive: true, force: true });
        console.log(`[Remotion] Cleaned up temporary directory: ${jobDir}`);
      }
    } catch (cleanErr) {
      console.warn(`[Remotion] Warning cleaning up ${jobDir}:`, cleanErr.message);
    }
  }
}

module.exports = {
  processRemotionZip
};
