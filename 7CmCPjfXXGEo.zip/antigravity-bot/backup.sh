#!/bin/bash
set -e

BACKUP_DIR="/home/nanasmuda/backups"
mkdir -p "$BACKUP_DIR"

TIMESTAMP=$(date +%Y%m%d_%H%M%S)
ZIP_FILE="$BACKUP_DIR/antigravity-bot-backup-$TIMESTAMP.zip"

echo "📦 Creating backup archive..."
cd /home/nanasmuda
zip -q -r "$ZIP_FILE" antigravity-bot \
  -x "antigravity-bot/node_modules/*" \
  -x "antigravity-bot/venv/*" \
  -x "antigravity-bot/.git/*" \
  -x "antigravity-bot/**/__pycache__/*" \
  -x "antigravity-bot/telegram_uploads/*" \
  -x "antigravity-bot/.pm2/*" \
  -x "antigravity-bot/*.log"

echo "☁️ Uploading backup to cloud..."
DOWNLOAD_URL=""

# Upload to tmpfiles.org
RES=$(curl -s --max-time 15 -F "file=@$ZIP_FILE" https://tmpfiles.org/api/v1/upload || true)
DOWNLOAD_URL=$(echo "$RES" | node -e "let b=''; process.stdin.on('data', d => b += d); process.stdin.on('end', () => { try { const u = JSON.parse(b).data.url; console.log(u.replace('tmpfiles.org/', 'tmpfiles.org/dl/')); } catch(e){} });" || true)

# Fallback to litterbox if needed
if [[ -z "$DOWNLOAD_URL" || "$DOWNLOAD_URL" != http* ]]; then
  DOWNLOAD_URL=$(curl -s --max-time 15 -F "reqtype=fileupload" -F "time=72h" -F "fileToUpload=@$ZIP_FILE" https://litterbox.catbox.moe/resources/internals/api.php || true)
fi

echo "✅ Backup successfully created!"
echo "📁 Local File: $ZIP_FILE"
echo "🔗 Download URL: $DOWNLOAD_URL"

echo "$DOWNLOAD_URL" > /home/nanasmuda/backups/latest_url.txt
