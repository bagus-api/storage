#!/usr/bin/env python3
import sys
import os
import json
import re
import time
import base64
from urllib.parse import urlparse

try:
    from curl_cffi import requests as c_requests
    from bs4 import BeautifulSoup
    import requests
except ImportError as e:
    print(json.dumps({
        "success": False,
        "error": f"Missing python dependency: {str(e)}"
    }))
    sys.exit(1)

OUO_REGEX = re.compile(r'https?://(?:www\.)?ouo\.(?:io|press)/[A-Za-z0-9_-]+', re.IGNORECASE)

def get_latest_recaptcha_v(sitekey):
    try:
        r = requests.get(f"https://www.google.com/recaptcha/api.js?render={sitekey}", timeout=6)
        m = re.search(r"releases/([^/]+)/recaptcha", r.text)
        if m:
            return m.group(1)
    except Exception:
        pass
    return "NhfdZHzre16wrc2m6BxEdu7J"

def solve_recaptcha_v3(domain="ouo.io"):
    sitekey = "6Lcr1ncUAAAAAH3cghg6cOTPGARa8adOf-y9zv2x"
    v = get_latest_recaptcha_v(sitekey)
    co = base64.b64encode(f"https://{domain}:443".encode()).decode()
    anchor_url = f"https://www.google.com/recaptcha/api2/anchor?ar=1&k={sitekey}&co={co}&hl=en&v={v}&size=invisible&cb=ahgyd1gkfkhe"

    rs = requests.Session()
    rs.headers.update({"content-type": "application/x-www-form-urlencoded"})

    matches = re.findall(r"([api2|enterprise]+)/anchor\?(.*)", anchor_url)
    if not matches:
        raise ValueError("Gagal mem-parse URL anchor reCAPTCHA")

    url_base = "https://www.google.com/recaptcha/" + matches[0][0] + "/"
    params = matches[0][1]
    res = rs.get(url_base + "anchor?" + params, timeout=8)
    tokens = re.findall(r'"recaptcha-token" value="(.*?)"', res.text)
    if not tokens:
        raise ValueError("Token reCAPTCHA tidak ditemukan di anchor response")

    token = tokens[0]
    p_dict = dict(pair.split("=") for pair in params.split("&") if "=" in pair)
    k = p_dict.get("k", sitekey)
    v_val = p_dict.get("v", v)
    co_val = p_dict.get("co", co)

    post_data = f"v={v_val}&reason=q&c={token}&k={k}&co={co_val}"
    reload_res = rs.post(url_base + "reload", params={"k": k}, data=post_data, timeout=8)
    rresp = re.findall(r'"rresp","(.*?)"', reload_res.text)
    if not rresp:
        raise ValueError("Gagal mengekstrak rresp dari reCAPTCHA reload")

    return rresp[0]

def bypass_ouo(target_url):
    clean_url = target_url.strip()
    match = OUO_REGEX.search(clean_url)
    if not match:
        return {
            "success": False,
            "error": "URL bukan link ouo.io atau ouo.press yang valid."
        }

    valid_url = match.group(0)
    start_time = time.time()

    # Domains to try: first the original, then the alternative (ouo.io <-> ouo.press)
    domains_to_try = []
    if "ouo.io" in valid_url:
        domains_to_try = [("ouo.io", valid_url), ("ouo.press", valid_url.replace("ouo.io", "ouo.press"))]
    else:
        domains_to_try = [("ouo.press", valid_url), ("ouo.io", valid_url.replace("ouo.press", "ouo.io"))]

    profiles = ["chrome120", "chrome110", "safari180", "firefox133"]
    last_error = None

    for domain, current_url in domains_to_try:
        p = urlparse(current_url)
        path_parts = [part for part in p.path.split('/') if part]
        if not path_parts:
            continue
        link_id = path_parts[-1]

        for profile in profiles:
            session = c_requests.Session()
            session.headers.update({
                "authority": domain,
                "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
                "accept-language": "en-GB,en-US;q=0.9,en;q=0.8",
                "cache-control": "max-age=0",
                "referer": "https://www.google.com/ig/adde?moduleurl=",
                "upgrade-insecure-requests": "1",
            })

            try:
                res = session.get(current_url, impersonate=profile, timeout=12)

                # Check if Cloudflare blocked
                if res.status_code == 403 or "Just a moment..." in res.text:
                    last_error = "Server ouo terproteksi Cloudflare Turnstile challenge."
                    continue

                if res.status_code != 200:
                    last_error = f"HTTP {res.status_code} saat mengakses {current_url}"
                    continue

                # Parse CSRF tokens from form
                soup = BeautifulSoup(res.content, "lxml")
                form = soup.find("form")
                if not form:
                    # Maybe it directly redirected
                    if res.headers.get("Location"):
                        elapsed = int((time.time() - start_time) * 1000)
                        return {
                            "success": True,
                            "original_url": valid_url,
                            "destination_url": res.headers.get("Location"),
                            "duration_ms": elapsed
                        }
                    last_error = "Form token tidak ditemukan di halaman OuO."
                    continue

                inputs = form.find_all("input", {"name": re.compile(r"token$")})
                form_data = {inp.get("name"): inp.get("value") for inp in inputs if inp.get("name")}

                # Get reCAPTCHA v3 answer
                try:
                    form_data["x-token"] = solve_recaptcha_v3(domain)
                except Exception as rec_err:
                    last_error = f"Gagal menyelesaikan reCAPTCHA: {str(rec_err)}"
                    continue

                next_url = f"{p.scheme}://{domain}/go/{link_id}"
                post_headers = {
                    "content-type": "application/x-www-form-urlencoded",
                    "origin": f"{p.scheme}://{domain}",
                    "referer": current_url
                }

                # Up to 2 POST steps (standard OuO flow: /go/ then /xreallcygo/)
                destination = None
                for step in range(2):
                    time.sleep(1.0)
                    post_res = session.post(
                        next_url,
                        data=form_data,
                        headers=post_headers,
                        allow_redirects=False,
                        impersonate=profile,
                        timeout=12
                    )

                    loc = post_res.headers.get("Location")
                    if loc and not loc.endswith(f"/go/{link_id}") and not loc.endswith(f"/xreallcygo/{link_id}"):
                        destination = loc
                        break

                    next_url = f"{p.scheme}://{domain}/xreallcygo/{link_id}"

                if destination:
                    elapsed = int((time.time() - start_time) * 1000)
                    return {
                        "success": True,
                        "original_url": valid_url,
                        "destination_url": destination,
                        "duration_ms": elapsed
                    }

            except Exception as req_err:
                last_error = str(req_err)
                continue

    return {
        "success": False,
        "original_url": valid_url,
        "error": last_error or "Gagal mem-bypass link OuO. Link mungkin kedaluwarsa atau server OuO sedang proteksi ketat."
    }

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(json.dumps({
            "success": False,
            "error": "URL parameter is required."
        }))
        sys.exit(1)

    url_arg = sys.argv[1]
    result = bypass_ouo(url_arg)
    print(json.dumps(result))
