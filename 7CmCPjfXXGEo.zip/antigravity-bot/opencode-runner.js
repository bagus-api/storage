const { spawn } = require('node:child_process');
const readline = require('node:readline');
const treeKill = require('tree-kill');
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');

// Path to OpenCode binary
const OPENCODE_BIN = fs.existsSync('/home/nanasmuda/.local/bin/opencode')
  ? '/home/nanasmuda/.local/bin/opencode'
  : (fs.existsSync('/home/nanasmuda/.opencode/bin/opencode')
    ? '/home/nanasmuda/.opencode/bin/opencode'
    : 'opencode');

// List of available OpenCode models
const AVAILABLE_OPENCODE_MODELS = [
  { id: 'opencode/deepseek-v4.1-flash-free', label: '⚡ DeepSeek V4.1 Flash (Rekomendasi)', desc: 'Cepat & cerdas untuk coding & debugging' },
  { id: 'opencode/glm-5.3-flash-free', label: '🚀 GLM 5.3 Flash (Free)', desc: 'Model reasoning cepat & tanggap' },
  { id: 'opencode/nemotron-3.5-lightning-free', label: '🟢 Nemotron 3.5 Lightning (Free)', desc: 'Nvidia Nemotron super cepat' },
  { id: 'opencode/beam-free', label: '🔷 Beam Free (Default)', desc: 'Model standar bawaan OpenCode' },
  { id: 'opencode/big-pickle', label: '🥒 Big Pickle', desc: 'Model reasoning OpenCode' },
  { id: 'opencode/mimo-v2.6-flash-free', label: '💡 Mimo V2.6 Flash (Free)', desc: 'Model ringan hemat token' },
  { id: 'opencode/flint-40b-free', label: '🏛️ Flint 40B (Free)', desc: 'Model 40B open source' }
];

// Map of active processes per userId
const activeProcesses = new Map();

/**
 * Execute OpenCode CLI with prompt and stream output
 * @param {object} options
 * @param {string|number} options.userId
 * @param {string} options.prompt
 * @param {string} [options.sessionId]
 * @param {string} [options.model]
 * @param {string} [options.cwd]
 * @param {function} [options.onProgress]
 * @returns {Promise<{success: boolean, response?: string, session_id?: string, duration_seconds?: number, usage?: object, error?: string, aborted?: boolean}>}
 */
async function runOpenCode({
  userId,
  prompt,
  sessionId,
  model,
  cwd,
  onProgress
}) {
  return new Promise((resolve) => {
    const workDir = (cwd && fs.existsSync(cwd)) ? cwd : os.homedir();

    const args = [
      'run',
      '--auto',
      '--format', 'json'
    ];

    if (sessionId) {
      args.push('-s', sessionId);
    }

    if (model) {
      args.push('-m', model);
    }

    args.push(prompt);

    let accumulatedText = '';
    let capturedSessionId = sessionId || null;
    let isAborted = false;
    let stderrOutput = '';
    let tokenStats = null;
    const startTime = Date.now();

    const proc = spawn(OPENCODE_BIN, args, {
      cwd: workDir,
      stdio: ['ignore', 'pipe', 'pipe'],
      env: {
        ...process.env,
        PATH: `/home/nanasmuda/.local/bin:${process.env.PATH || ''}`
      }
    });

    activeProcesses.set(String(userId), {
      proc,
      kill: () => {
        isAborted = true;
        try {
          treeKill(proc.pid, 'SIGINT', (err) => {
            if (err) {
              try { treeKill(proc.pid, 'SIGKILL'); } catch (e) {}
            }
          });
        } catch (e) {
          try { proc.kill('SIGKILL'); } catch (e2) {}
        }
      }
    });

    const rl = readline.createInterface({ input: proc.stdout });

    rl.on('line', (rawLine) => {
      const line = rawLine.trim();
      if (!line) return;

      try {
        const data = JSON.parse(line);

        if (data.sessionID && !capturedSessionId) {
          capturedSessionId = data.sessionID;
          if (onProgress) {
            onProgress({ type: 'init', session_id: data.sessionID });
          }
        }

        if (data.type === 'tool_use') {
          const tool = data.part?.tool || 'shell';
          const input = data.part?.state?.input || {};
          const status = data.part?.state?.status || 'running';
          if (status === 'completed') {
            if (onProgress) {
              onProgress({
                type: 'tool_done',
                tool,
                params: input
              });
            }
          } else {
            if (onProgress) {
              onProgress({
                type: 'tool_start',
                tool,
                params: input
              });
            }
          }
        } else if (data.type === 'text') {
          const text = data.part?.text || '';
          if (text) {
            accumulatedText += text;
            if (onProgress) {
              onProgress({ type: 'text_delta', delta: text, accumulated: accumulatedText });
            }
          }
        } else if (data.type === 'step_finish') {
          if (data.part?.tokens) {
            tokenStats = data.part.tokens;
          }
        } else if (data.type === 'error') {
          stderrOutput += (data.error?.message || JSON.stringify(data.error));
        }
      } catch (err) {
        // Plain text line
        if (!line.startsWith('{')) {
          stderrOutput += (stderrOutput ? '\n' : '') + line;
        }
      }
    });

    proc.stderr.on('data', (chunk) => {
      stderrOutput += chunk.toString();
    });

    proc.on('error', (err) => {
      activeProcesses.delete(String(userId));
      resolve({
        success: false,
        error: `Gagal menjalankan proses OpenCode: ${err.message}`
      });
    });

    proc.on('close', (code) => {
      activeProcesses.delete(String(userId));
      const durationSeconds = parseFloat(((Date.now() - startTime) / 1000).toFixed(2));

      if (isAborted) {
        return resolve({
          success: false,
          aborted: true,
          error: 'Operasi dihentikan oleh pengguna.'
        });
      }

      if (accumulatedText.trim().length > 0) {
        return resolve({
          success: true,
          session_id: capturedSessionId,
          response: accumulatedText,
          duration_seconds: durationSeconds,
          usage: tokenStats ? {
            input_tokens: tokenStats.input || 0,
            output_tokens: tokenStats.output || 0,
            thinking_tokens: tokenStats.reasoning || 0,
            total_tokens: (tokenStats.input || 0) + (tokenStats.output || 0) + (tokenStats.reasoning || 0)
          } : null
        });
      }

      if (code !== 0) {
        return resolve({
          success: false,
          error: stderrOutput.trim() || `OpenCode CLI keluar dengan kode error ${code}`
        });
      }

      resolve({
        success: false,
        error: 'Tidak ada respons dari OpenCode.'
      });
    });
  });
}

/**
 * Abort active process for a user
 * @param {string|number} userId 
 * @returns {boolean}
 */
function abortOpenCodeProcess(userId) {
  const active = activeProcesses.get(String(userId));
  if (active) {
    active.kill();
    activeProcesses.delete(String(userId));
    return true;
  }
  return false;
}

/**
 * Check if user has an active running process
 * @param {string|number} userId 
 * @returns {boolean}
 */
function isOpenCodeRunning(userId) {
  return activeProcesses.has(String(userId));
}

module.exports = {
  runOpenCode,
  abortOpenCodeProcess,
  isOpenCodeRunning,
  AVAILABLE_OPENCODE_MODELS
};
