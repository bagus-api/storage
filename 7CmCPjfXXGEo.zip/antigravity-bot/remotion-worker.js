const fs = require('node:fs');
const path = require('node:path');
const { execSync } = require('node:child_process');

const LOCAL_LIB_PATH = '/home/nanasmuda/.local/lib';
const LOCAL_BIN_PATH = '/home/nanasmuda/.local/bin';
process.env.LD_LIBRARY_PATH = `${LOCAL_LIB_PATH}:${process.env.LD_LIBRARY_PATH || ''}`;
process.env.PATH = `${LOCAL_BIN_PATH}:${process.env.PATH || ''}`;

// Disable GPU rasterization to fix SwANGLE tile cache / ghost strips artifact
process.env.__RESERVED_IS_INSIDE_REMOTION_LAMBDA = 'true';

const { bundle } = require('@remotion/bundler');
const { getCompositions, renderMedia } = require('@remotion/renderer');

const SHARED_NODE_MODULES = path.join(__dirname, 'node_modules');
const CHROME_EXECUTABLE = '/home/nanasmuda/.remotion/chrome-headless-shell/linux64/chrome-headless-shell-linux64/chrome-headless-shell';

function findEntryPoint(dir) {
  const commonEntries = [
    'src/index.ts',
    'src/index.tsx',
    'src/index.js',
    'src/index.jsx',
    'src/Root.tsx',
    'src/Root.jsx',
    'src/Root.js',
    'index.ts',
    'index.tsx',
    'index.js',
    'index.jsx'
  ];

  for (const entry of commonEntries) {
    const fullPath = path.join(dir, entry);
    if (fs.existsSync(fullPath)) return fullPath;
  }

  const srcDir = path.join(dir, 'src');
  if (fs.existsSync(srcDir)) {
    try {
      const files = fs.readdirSync(srcDir);
      for (const file of files) {
        if (/\.(jsx?|tsx?)$/.test(file)) return path.join(srcDir, file);
      }
    } catch (_) {}
  }

  return null;
}

function findProjectRoot(baseDir) {
  if (fs.existsSync(path.join(baseDir, 'package.json')) || fs.existsSync(path.join(baseDir, 'src'))) {
    return baseDir;
  }
  const items = fs.readdirSync(baseDir, { withFileTypes: true });
  for (const item of items) {
    if (item.isDirectory() && !item.name.startsWith('.') && item.name !== '__MACOSX') {
      const sub = path.join(baseDir, item.name);
      if (fs.existsSync(path.join(sub, 'package.json')) || fs.existsSync(path.join(sub, 'src'))) {
        return sub;
      }
    }
  }
  return baseDir;
}

function sendProgress(percent, msg) {
  process.stdout.write(JSON.stringify({ type: 'progress', percent, msg }) + '\n');
}

async function run() {
  const jobDir = process.argv[2];
  const requestedCompId = process.argv[3] || '';

  if (!jobDir || !fs.existsSync(jobDir)) {
    throw new Error('Invalid job directory: ' + jobDir);
  }

  const zipPath = path.join(jobDir, 'project.zip');
  const extractDir = path.join(jobDir, 'extracted');
  const outputPath = path.join(jobDir, 'output.mp4');

  let bundleLocation = null;
  const startTime = Date.now();

  try {
    fs.mkdirSync(extractDir, { recursive: true });
    sendProgress(5, '📦 Mengekstrak file zip proyek...');

    try {
      execSync(`/usr/bin/unzip -q "${zipPath}" -d "${extractDir}"`, { timeout: 30000 });
    } catch (unzipErr) {
      throw new Error(`Gagal mengekstrak file ZIP: ${unzipErr.message}`);
    }

    const projectRoot = findProjectRoot(extractDir);
    const entryPoint = findEntryPoint(projectRoot);

    if (!entryPoint) {
      throw new Error(
        'Tidak ditemukan file entry point Remotion (contoh: src/index.ts, src/index.js, atau src/Root.tsx).'
      );
    }

    const projectNodeModules = path.join(projectRoot, 'node_modules');
    if (!fs.existsSync(projectNodeModules)) {
      try {
        fs.symlinkSync(SHARED_NODE_MODULES, projectNodeModules, 'junction');
      } catch (_) {}
    }

    sendProgress(15, '⚡ Mem-bundling proyek Remotion (Rspack)...');

    try {
      bundleLocation = await bundle({
        entryPoint,
        rootDir: projectRoot,
        rspack: true
      });
    } catch (rspackErr) {
      console.warn('[Worker] Rspack fallback to Webpack:', rspackErr.message);
      bundleLocation = await bundle({
        entryPoint,
        rootDir: projectRoot,
        rspack: false
      });
    }

    sendProgress(35, '🔍 Mengidentifikasi komposisi video...');

    const browserExecutable = fs.existsSync(CHROME_EXECUTABLE) ? CHROME_EXECUTABLE : undefined;
    const chromiumOptions = {
      gl: 'swangle',
      enableMultiProcessOnLinux: true
    };

    const compositions = await getCompositions(bundleLocation, {
      browserExecutable,
      chromiumOptions
    });

    if (!compositions || compositions.length === 0) {
      throw new Error('Tidak ditemukan <Composition /> yang terdaftar di proyek Remotion.');
    }

    let targetComp = compositions[0];
    if (requestedCompId) {
      const match = compositions.find(c => c.id.toLowerCase() === requestedCompId.toLowerCase());
      if (match) targetComp = match;
    }

    sendProgress(45, `🎬 Memulai render video (${targetComp.id} - ${targetComp.width}x${targetComp.height})...`);

    await renderMedia({
      composition: targetComp,
      serveUrl: bundleLocation,
      codec: 'h264',
      x264Preset: 'ultrafast',
      ffmpegOverride: ({ type, args }) => {
        const out = [...args];
        const lastIdx = Math.max(0, out.length - 1);
        out.splice(lastIdx, 0, '-threads', '1', '-x264-params', 'threads=1:lookahead_threads=1');
        return out;
      },
      outputLocation: outputPath,
      concurrency: 1,
      disallowParallelEncoding: true,
      disableSharedMemoryCapture: true,
      browserExecutable,
      chromiumOptions,
      imageFormat: 'jpeg',
      jpegQuality: 85,
      timeoutInMilliseconds: 60000,
      overwrite: true,
      onProgress: ({ progress }) => {
        const percent = Math.floor(45 + progress * 50);
        sendProgress(percent, `⏳ Rendering frame: ${Math.floor(progress * 100)}%...`);
      }
    });

    if (!fs.existsSync(outputPath)) {
      throw new Error('Hasil render video tidak ditemukan di disk.');
    }

    sendProgress(98, '📤 Menyiapkan pengiriman video...');
    const durationSeconds = ((Date.now() - startTime) / 1000).toFixed(1);

    process.stdout.write(
      JSON.stringify({
        type: 'done',
        compositionId: targetComp.id,
        durationSeconds,
        outputPath
      }) + '\n'
    );
  } finally {
    if (bundleLocation) {
      try {
        if (fs.existsSync(bundleLocation)) {
          fs.rmSync(bundleLocation, { recursive: true, force: true });
        }
      } catch (_) {}
    }
  }
}

run().catch((err) => {
  process.stderr.write(err.stack || err.message);
  process.exit(1);
});
