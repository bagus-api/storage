// Netlify Function v2: proxy gambar dengan cache.
export default async (req) => {
  const target = new URL(req.url).searchParams.get('url');
  if (!target) return new Response('Missing url parameter', { status: 400 });
  let parsed;
  try {
    parsed = new URL(target);
  } catch {
    return new Response('Invalid url', { status: 400 });
  }
  if (!/^https?:$/.test(parsed.protocol)) return new Response('Invalid protocol', { status: 400 });
  try {
    const upstream = await fetch(parsed.href);
    const out = new Headers({ 'Cache-Control': 'public, max-age=604800, immutable' });
    const ct = upstream.headers.get('content-type');
    if (ct) out.set('Content-Type', ct);
    return new Response(upstream.body, { status: upstream.status, headers: out });
  } catch {
    return new Response(null, { status: 502 });
  }
};

export const config = { path: '/api/proxy-image' };
