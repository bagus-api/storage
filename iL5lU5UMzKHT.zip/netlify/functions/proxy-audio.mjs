// Netlify Function: proxy audio dengan streaming + dukungan Range (seek)
const UA =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, HEAD, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Range',
  'Access-Control-Expose-Headers': 'Content-Length, Content-Range, Accept-Ranges, Content-Type',
};

// Netlify v2 Handler (Web Standards Request/Response)
export default async (req) => {
  if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: cors });

  const target = new URL(req.url).searchParams.get('url');
  if (!target) return new Response('Missing url parameter', { status: 400, headers: cors });

  let parsed;
  try {
    parsed = new URL(target);
  } catch {
    return new Response('Invalid url parameter', { status: 400, headers: cors });
  }
  if (!/^https?:$/.test(parsed.protocol)) {
    return new Response('Invalid protocol', { status: 400, headers: cors });
  }

  const headers = { 'User-Agent': UA };
  if (parsed.hostname.includes('vidssave.com') || parsed.hostname.includes('aliyuncs.com')) {
    headers['Referer'] = 'https://vidssave.com/';
    headers['Origin'] = 'https://vidssave.com';
  }
  const range = req.headers.get('range');
  if (range) headers['Range'] = range;

  try {
    const upstream = await fetch(parsed.href, { headers, redirect: 'follow' });
    const out = new Headers(cors);
    for (const h of ['content-type', 'content-length', 'accept-ranges', 'content-range']) {
      const v = upstream.headers.get(h);
      if (v) out.set(h, v);
    }
    if (!out.has('accept-ranges')) out.set('Accept-Ranges', 'bytes');
    return new Response(upstream.body, { status: upstream.status, headers: out });
  } catch (err) {
    // If proxy stream encounters error, redirect client directly to target URL
    return new Response(null, {
      status: 302,
      headers: { ...cors, Location: target }
    });
  }
};

// Netlify v1 Lambda Handler Fallback (jika dipanggil via /.netlify/functions/proxy-audio)
export async function handler(event) {
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 204, headers: cors, body: '' };
  }

  const target = event.queryStringParameters?.url;
  if (!target) {
    return { statusCode: 400, headers: cors, body: 'Missing url parameter' };
  }

  // 302 Redirect directly to target audio stream to avoid Lambda 6MB payload limit & timeout
  return {
    statusCode: 302,
    headers: {
      ...cors,
      'Location': target,
      'Cache-Control': 'public, max-age=3600'
    },
    body: ''
  };
}

export const config = { path: '/api/proxy-audio' };

