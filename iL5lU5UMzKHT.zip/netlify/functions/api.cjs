// Netlify Function: membungkus Express (server.cjs) agar semua /api/* jalan serverless.
const serverless = require('serverless-http');
const app = require('../../server.cjs');

const PREFIX = '/.netlify/functions/api';

module.exports.handler = serverless(app, {
  // Normalisasi path agar selalu menjadi /api/<endpoint>, apa pun bentuk
  // path yang dikirim Netlify:
  //   /api/home                         -> /api/home
  //   /.netlify/functions/api/home      -> /api/home
  //   /.netlify/functions/api/api/home  -> /api/home
  request(req) {
    let url = req.url || '/';
    if (url.startsWith(PREFIX)) url = url.slice(PREFIX.length) || '/';
    if (!url.startsWith('/api/') && url !== '/api') url = '/api' + (url.startsWith('/') ? '' : '/') + url;
    req.url = url;
  },
});
