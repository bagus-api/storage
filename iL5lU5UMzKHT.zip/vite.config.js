import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import fs from 'node:fs'
import path from 'node:path'

const OLD = 'https://hundred-whole-taxi-big.trycloudflare.com'

// Ambil domain otomatis saat build di Netlify (env URL), atau set manual lewat SITE_URL.
// Kalau tidak ada (build lokal), tag/baris yang butuh URL absolut dibuang.
const SITE_URL = (process.env.SITE_URL || process.env.URL || '').replace(/\/$/, '')

function siteUrl() {
  return {
    name: 'site-url',
    transformIndexHtml(html) {
      if (SITE_URL) return html.split(OLD).join(SITE_URL)
      return html
        .replace(/^.*rel="canonical".*\n/m, '')
        .replace(/^.*property="og:url".*\n/m, '')
    },
    closeBundle() {
      const dist = path.resolve('dist')
      for (const f of ['robots.txt', 'sitemap.xml']) {
        const p = path.join(dist, f)
        if (!fs.existsSync(p)) continue
        let t = fs.readFileSync(p, 'utf8')
        if (SITE_URL) t = t.split(OLD).join(SITE_URL)
        else if (f === 'robots.txt') t = t.replace(/^Sitemap:.*\n?/m, '')
        fs.writeFileSync(p, t)
      }
    },
  }
}

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react(), siteUrl()],
  build: {
    cssCodeSplit: true,
    minify: 'esbuild',
    rollupOptions: {
      output: {
        manualChunks: {
          vendor: ['react', 'react-dom']
        }
      }
    }
  },
  server: {
    port: 5173,
    host: true,
    proxy: {
      '/api': {
        target: 'http://localhost:3000',
        changeOrigin: true,
      }
    }
  }
})
