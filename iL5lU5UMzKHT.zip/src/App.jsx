import React, { useState, useEffect } from 'react';
import { usePlayer } from './context/PlayerContext';
import Navbar from './components/Navbar';
import MiniPlayer from './components/MiniPlayer';
import FullPlayer from './components/FullPlayer';
import LyricsOverlay from './components/LyricsOverlay';
import EqualizerModal from './components/EqualizerModal';
import SleepTimerModal from './components/SleepTimerModal';
import SpeedModal from './components/SpeedModal';
import QueueModal from './components/QueueModal';
import AddToPlaylistModal from './components/AddToPlaylistModal';
import ShareCardModal from './components/ShareCardModal';
import CreatePlaylistModal from './components/CreatePlaylistModal';
import AlbumModal from './components/AlbumModal';
import ArtistModal from './components/ArtistModal';
import Toast from './components/Toast';

import LandingView from './views/LandingView';
import HomeView from './views/HomeView';
import SearchView from './views/SearchView';
import LibraryView from './views/LibraryView';
import OfflineView from './views/OfflineView';
import LikedView from './views/LikedView';
import ProfileView from './views/ProfileView';
import ChatView from './views/ChatView';

import { toHDCover, cn } from './utils/helpers';

export default function App() {
    const {
        activeTab,
        setActiveTab,
        setSearchQuery,
        playTrack,
        setIsFullPlayerOpen,
        setActiveAlbum,
        setActiveArtist
    } = usePlayer();

    const [showSplash, setShowSplash] = useState(false);
    const [splashFading, setSplashFading] = useState(false);

    // Sync URL routes on mount and on popstate (Back/Forward buttons)
    useEffect(() => {
        const syncRoute = () => {
            const path = window.location.pathname;
            const searchParams = new URLSearchParams(window.location.search);

            if (path.startsWith('/play/')) {
                const vid = path.split('/play/')[1]?.split('?')[0]?.replace(/\/+$/, '');
                if (vid) {
                    setActiveTab('home');
                    const title = searchParams.get('title') || 'Memuat...';
                    const artist = searchParams.get('artist') || 'NanzMusify';
                    const cover = searchParams.get('cover') || toHDCover('', vid);
                    playTrack({
                        id: vid,
                        videoId: vid,
                        title: cn(title),
                        artist: cn(artist),
                        cover: cover,
                        ytUrl: `https://youtube.com/watch?v=${vid}`
                    });
                    setIsFullPlayerOpen(true);
                }
            } else if (path.startsWith('/album/')) {
                const albumId = path.split('/album/')[1]?.split('?')[0]?.replace(/\/+$/, '');
                if (albumId) {
                    setActiveAlbum({ id: albumId });
                }
            } else if (path.startsWith('/artist/')) {
                const artistId = path.split('/artist/')[1]?.split('?')[0]?.replace(/\/+$/, '');
                if (artistId) {
                    const name = searchParams.get('name') || 'Artist';
                    setActiveArtist({ id: artistId, name: name });
                }
            } else if (path.startsWith('/search')) {
                setActiveTab('search');
                // Support /search/teh_hijau/, /search/teh_hijau, /search?q=teh_hijau, etc.
                const sub = path.replace(/^\/search\/?/, '').replace(/\/+$/, '');
                let q = '';
                if (sub) {
                    try {
                        q = decodeURIComponent(sub).replace(/_/g, ' ').trim();
                    } catch(e) {
                        q = sub.replace(/_/g, ' ').trim();
                    }
                } else if (searchParams.get('q')) {
                    q = searchParams.get('q').trim();
                } else if (searchParams.get('query')) {
                    q = searchParams.get('query').trim();
                }
                if (q) {
                    setSearchQuery(q);
                }
            } else if (/^\/library\/?$/i.test(path)) {
                setActiveTab('library');
            } else if (/^\/offline\/?$/i.test(path)) {
                setActiveTab('offline');
            } else if (/^\/liked\/?$/i.test(path)) {
                setActiveTab('liked');
            } else if (/^\/chat\/?$/i.test(path)) {
                setActiveTab('chat');
            } else if (/^\/(profile|dev)\/?$/i.test(path)) {
                setActiveTab('dev');
            } else if (/^\/(id|home)\/?$/i.test(path)) {
                setActiveTab('home');
            } else if (path === '/' || path === '') {
                setActiveTab('landing');
            }
        };

        syncRoute();
        window.addEventListener('popstate', syncRoute);
        return () => window.removeEventListener('popstate', syncRoute);
    }, []);

    return (
        <div className="h-[100dvh] w-full bg-transparent text-[var(--text-primary)] font-sans overflow-hidden flex flex-col relative select-none">
            {/* Global Smooth App Background */}
            <div className="app-bg"></div>

            {/* Splash Screen */}
            {showSplash && (
                <div id="splash-screen" className={splashFading ? 'hide' : ''}>
                    <div className="splash-logo-wrap">
                        <img src="/logo.webp" alt="logo" className="app-brand-logo" onError={(e) => { e.currentTarget.style.display = 'none'; }} />
                    </div>
                    <div className="splash-title chrome-text">NanzMusify</div>
                    <div className="splash-sub">Menyiapkan musikmu</div>
                    <div className="splash-bar"><i></i></div>
                </div>
            )}

            {/* Main Scrollable Content Area */}
            <div
                className={`flex-1 overflow-x-hidden hide-scrollbar ${
                    activeTab === 'landing'
                        ? 'pb-6 overflow-y-auto'
                        : activeTab === 'chat'
                            ? 'pb-0 overflow-y-hidden flex flex-col'
                            : 'pb-[140px] overflow-y-auto'
                }`}
                id="main-area"
            >
                {activeTab === 'landing' && <LandingView />}
                {activeTab === 'home' && <HomeView />}
                {activeTab === 'search' && <SearchView />}
                {(activeTab === 'library' || activeTab === 'offline' || activeTab === 'liked') && <LibraryView />}
                {activeTab === 'chat' && <ChatView />}
                {activeTab === 'dev' && <ProfileView />}
            </div>

            {/* Bottom Dock Navigation - rendered when in app */}
            {activeTab !== 'landing' && <Navbar />}

            {/* Bottom Floating Mini Player */}
            <MiniPlayer />

            {/* Fullscreen Player View */}
            <FullPlayer />

            {/* Fullscreen Lyrics Overlay */}
            <LyricsOverlay />

            {/* Modals */}
            <EqualizerModal />
            <SleepTimerModal />
            <SpeedModal />
            <QueueModal />
            <AddToPlaylistModal />
            <ShareCardModal />
            <CreatePlaylistModal />
            <AlbumModal />
            <ArtistModal />

            {/* Global Toast */}
            <Toast />
        </div>
    );
}
