/**
 * ChatApi.js - Network service for NanzMusify Global Chat API v2
 * All communication is proxied through internal endpoint /api/chat
 * to ensure origin security, preserve tokens safely, and prevent any domain exposure.
 */

export const CHAT_ENDPOINT = "/api/chat";

const TOKEN_KEY = "nanz_chat_token";
const USER_KEY = "nanz_chat_user";
const ADMIN_KEY_STORAGE = "nanz_chat_admin_key";

// Local storage helpers
export function getStoredToken() {
    try {
        return localStorage.getItem(TOKEN_KEY) || "";
    } catch {
        return "";
    }
}

export function setStoredToken(token) {
    try {
        if (token) {
            localStorage.setItem(TOKEN_KEY, token);
        } else {
            localStorage.removeItem(TOKEN_KEY);
        }
    } catch {}
}

export function getStoredUser() {
    try {
        const raw = localStorage.getItem(USER_KEY);
        if (!raw) return null;
        return JSON.parse(raw);
    } catch {
        return null;
    }
}

export function setStoredUser(user) {
    try {
        if (user) {
            localStorage.setItem(USER_KEY, JSON.stringify(user));
        } else {
            localStorage.removeItem(USER_KEY);
        }
    } catch {}
}

export function clearStoredAuth() {
    try {
        localStorage.removeItem(TOKEN_KEY);
        localStorage.removeItem(USER_KEY);
    } catch {}
}

export function getStoredAdminKey() {
    try {
        return sessionStorage.getItem(ADMIN_KEY_STORAGE) || localStorage.getItem(ADMIN_KEY_STORAGE) || "";
    } catch {
        return "";
    }
}

export function setStoredAdminKey(key) {
    try {
        if (key) {
            sessionStorage.setItem(ADMIN_KEY_STORAGE, key);
            localStorage.setItem(ADMIN_KEY_STORAGE, key);
        } else {
            sessionStorage.removeItem(ADMIN_KEY_STORAGE);
            localStorage.removeItem(ADMIN_KEY_STORAGE);
        }
    } catch {}
}

export function clearStoredAdminKey() {
    try {
        sessionStorage.removeItem(ADMIN_KEY_STORAGE);
        localStorage.removeItem(ADMIN_KEY_STORAGE);
    } catch {}
}

/**
 * Execute request to internal chat proxy endpoint
 */
async function callApi(options = {}) {
    const {
        method = "GET",
        params = {},
        body = null,
        token = null,
        adminKey = null,
        timeoutMs = 15000
    } = options;

    const activeToken = token || getStoredToken();
    const activeAdminKey = adminKey || getStoredAdminKey();

    const headers = {
        "Accept": "application/json"
    };

    if (activeToken) {
        headers["Authorization"] = `Bearer ${activeToken}`;
    }
    if (activeAdminKey) {
        headers["X-Admin-Key"] = activeAdminKey;
    }

    const searchParams = new URLSearchParams();
    for (const [k, v] of Object.entries(params)) {
        if (v !== undefined && v !== null) {
            searchParams.append(k, String(v));
        }
    }

    if (activeAdminKey && !searchParams.has("key") && (params.action || "").startsWith("admin")) {
        searchParams.append("key", activeAdminKey);
    }

    let url = CHAT_ENDPOINT;
    const qs = searchParams.toString();
    if (qs) {
        url += `?${qs}`;
    }

    let reqBody = null;
    if (method === "POST") {
        headers["Content-Type"] = "application/json";
        const payload = { ...(body || {}) };
        if (activeToken && !payload.token) {
            payload.token = activeToken;
        }
        if (activeAdminKey && !payload.key) {
            payload.key = activeAdminKey;
        }
        reqBody = JSON.stringify(payload);
    }

    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);

    try {
        const res = await fetch(url, {
            method,
            headers,
            body: reqBody,
            signal: controller.signal
        });
        clearTimeout(timer);

        const data = await res.json().catch(() => null);

        if (!res.ok) {
            const errorMsg = data?.error || `Terjadi kesalahan (Kode: ${res.status})`;
            if (res.status === 401) {
                clearStoredAuth();
            }
            throw new Error(errorMsg);
        }

        if (data && data.success === false) {
            if (data.error && (data.error.includes("Token") || data.error.includes("login"))) {
                clearStoredAuth();
            }
            throw new Error(data.error || "Gagal memproses permintaan chat.");
        }

        return data;
    } catch (err) {
        clearTimeout(timer);
        if (err.name === "AbortError") {
            throw new Error("Koneksi timeout. Silakan periksa jaringan Anda.");
        }
        throw err;
    }
}

export const ChatApi = {
    CHAT_ENDPOINT,
    getStoredToken,
    setStoredToken,
    getStoredUser,
    setStoredUser,
    clearStoredAuth,
    getStoredAdminKey,
    setStoredAdminKey,
    clearStoredAdminKey,

    /**
     * Get API Info
     */
    async getInfo() {
        return callApi({
            method: "GET",
            params: { action: "info" }
        });
    },

    /**
     * Register new user (returns user and token)
     */
    async register({ nickname, password, photo_url = "" }) {
        const cleanNick = (nickname || "").trim();
        const cleanPass = (password || "").trim();
        const cleanPhoto = (photo_url || "").trim();

        if (cleanNick.length < 3 || cleanNick.length > 20) {
            throw new Error("Nama panggilan harus antara 3 - 20 karakter.");
        }
        if (cleanPass.length < 6 || cleanPass.length > 72) {
            throw new Error("Katasandi minimal 6 karakter.");
        }

        const data = await callApi({
            method: "POST",
            body: {
                action: "register",
                nickname: cleanNick,
                password: cleanPass,
                photo_url: cleanPhoto
            }
        });

        if (data?.success && data?.token && data?.user) {
            setStoredToken(data.token);
            setStoredUser(data.user);
        }
        return data;
    },

    /**
     * Login user (returns user and token)
     */
    async login({ nickname, password }) {
        const cleanNick = (nickname || "").trim();
        const cleanPass = (password || "").trim();

        if (!cleanNick) {
            throw new Error("Nama panggilan tidak boleh kosong.");
        }
        if (!cleanPass) {
            throw new Error("Katasandi tidak boleh kosong.");
        }

        const data = await callApi({
            method: "POST",
            body: {
                action: "login",
                nickname: cleanNick,
                password: cleanPass
            }
        });

        if (data?.success && data?.token && data?.user) {
            setStoredToken(data.token);
            setStoredUser(data.user);
        }
        return data;
    },

    /**
     * Logout current session
     */
    async logout() {
        const token = getStoredToken();
        try {
            if (token) {
                await callApi({
                    method: "POST",
                    body: { action: "logout" }
                });
            }
        } finally {
            clearStoredAuth();
        }
        return { success: true };
    },

    /**
     * Get current logged-in user profile
     */
    async getMe() {
        const data = await callApi({
            method: "GET",
            params: { action: "me" }
        });
        if (data?.success && data?.user) {
            setStoredUser(data.user);
        }
        return data;
    },

    /**
     * Update profile (photo_url or password)
     */
    async updateMe({ photo_url, old_password, new_password }) {
        const payload = { action: "update_me" };
        if (photo_url !== undefined) payload.photo_url = photo_url.trim();
        if (old_password) payload.old_password = old_password;
        if (new_password) payload.new_password = new_password;

        const data = await callApi({
            method: "POST",
            body: payload
        });

        if (data?.success && data?.user) {
            setStoredUser(data.user);
        }
        return data;
    },

    /**
     * Send message to global chat
     */
    async sendMessage(message) {
        const cleanMsg = (message || "").trim();
        if (!cleanMsg) {
            throw new Error("Pesan tidak boleh kosong.");
        }
        if (cleanMsg.length > 500) {
            throw new Error("Pesan maksimal 500 karakter.");
        }

        return callApi({
            method: "POST",
            body: {
                action: "send",
                message: cleanMsg
            }
        });
    },

    /**
     * Fetch messages with polling
     */
    async getMessages(afterId = 0, limit = 50) {
        const token = getStoredToken();
        if (!token) {
            return { success: false, messages: [], count: 0, last_id: 0 };
        }

        return callApi({
            method: "GET",
            params: {
                action: "messages",
                after_id: afterId,
                limit
            }
        });
    },

    /**
     * Get currently active / online users
     */
    async getOnline() {
        const token = getStoredToken();
        if (!token) {
            return { success: false, users: [], count: 0 };
        }

        return callApi({
            method: "GET",
            params: { action: "online" }
        });
    },

    // ---------------------------------------------------------
    // ADMIN ACTIONS (Require Admin Key)
    // ---------------------------------------------------------

    /**
     * List all registered user accounts
     * ?action=admin_list&q={query}&key={key}
     */
    async adminList(q = "", key = null) {
        const adminKey = key || getStoredAdminKey();
        if (!adminKey) {
            throw new Error("Admin key diperlukan.");
        }

        const params = { action: "admin_list", key: adminKey };
        if (q && q.trim()) {
            params.q = q.trim();
        }

        return callApi({
            method: "POST",
            body: params,
            adminKey
        });
    },

    /**
     * Create user account directly from admin panel
     */
    async adminCreate({ nickname, password, photo_url = "" }, key = null) {
        const adminKey = key || getStoredAdminKey();
        if (!adminKey) {
            throw new Error("Admin key diperlukan.");
        }

        const cleanNick = (nickname || "").trim();
        const cleanPass = (password || "").trim();
        const cleanPhoto = (photo_url || "").trim();

        if (!cleanNick) throw new Error("Nickname wajib diisi.");
        if (!cleanPass) throw new Error("Password wajib diisi.");

        return callApi({
            method: "POST",
            body: {
                action: "admin_create",
                nickname: cleanNick,
                password: cleanPass,
                photo_url: cleanPhoto,
                key: adminKey
            },
            adminKey
        });
    },

    /**
     * Update user account (photo_url or set new_password)
     */
    async adminUpdate({ nickname, photo_url, new_password }, key = null) {
        const adminKey = key || getStoredAdminKey();
        if (!adminKey) {
            throw new Error("Admin key diperlukan.");
        }

        const cleanNick = (nickname || "").trim();
        if (!cleanNick) throw new Error("Nickname target wajib diisi.");

        const payload = {
            action: "admin_update",
            nickname: cleanNick,
            key: adminKey
        };
        if (photo_url !== undefined) payload.photo_url = photo_url.trim();
        if (new_password) payload.new_password = new_password;

        return callApi({
            method: "POST",
            body: payload,
            adminKey
        });
    },

    /**
     * Delete user account and revoke all sessions
     */
    async adminDelete(nickname, key = null) {
        const adminKey = key || getStoredAdminKey();
        if (!adminKey) {
            throw new Error("Admin key diperlukan.");
        }

        const cleanNick = (nickname || "").trim();
        if (!cleanNick) throw new Error("Nickname target wajib diisi.");

        return callApi({
            method: "POST",
            body: {
                action: "admin_delete",
                nickname: cleanNick,
                key: adminKey
            },
            adminKey
        });
    },

    /**
     * Reset chat messages (Admin)
     */
    async reset(key = null) {
        const adminKey = key || getStoredAdminKey();
        if (!adminKey) {
            throw new Error("Admin Secret Key wajib diisi.");
        }

        return callApi({
            method: "POST",
            body: {
                action: "reset",
                key: adminKey
            },
            adminKey
        });
    }
};

export default ChatApi;
