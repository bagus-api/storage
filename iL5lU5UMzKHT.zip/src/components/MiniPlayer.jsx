import React, { useState, useEffect } from 'react';
import { Play, Pause, Heart } from 'lucide-react';
import { usePlayer } from '../context/PlayerContext';
import { isLikedSong, toggleLikeSong, toHDCover, FI, handleImgError } from '../utils/helpers';

export default function MiniPlayer() {
    const {
        currentTrack,
        isPlaying,
        isLoading,
        currentTime,
        duration,
        togglePlay,
        isFullPlayerOpen,
        setIsFullPlayerOpen,
        accentColors,
        showToast,
        theme
    } = usePlayer();

    const [isLiked, setIsLiked] = useState(false);

    useEffect(() => {
        if (currentTrack) {
            setIsLiked(isLikedSong(currentTrack));
        }
    }, [currentTrack]);

    if (!currentTrack || isFullPlayerOpen) return null;

    const progress = duration > 0 ? (currentTime / duration) * 100 : 0;
    const circumference = 131.95;
    const strokeDashoffset = circumference - (progress / 100) * circumference;

    const primaryColor = accentColors[0] || '#f43f5e';
    const tertiaryColor = accentColors[2] || '#2563eb';

    const bgGradient = theme === 'light'
        ? `linear-gradient(to right, color-mix(in srgb, ${tertiaryColor} 22%, #ffffff), #ffffff 88%)`
        : `linear-gradient(to right, color-mix(in srgb, ${tertiaryColor} 30%, #12131b), #12131b 80%)`;

    const handleToggleLike = (e) => {
        e.stopPropagation();
        const added = toggleLikeSong(currentTrack);
        setIsLiked(added);
        showToast(added ? 'Ditambahkan ke Lagu Disukai' : 'Dihapus dari Lagu Disukai');
    };

    return (
        <div
            id="mini-player"
            className="fixed left-4 right-4 sm:left-auto sm:right-6 sm:w-96 z-[160] transition-transform duration-300 ease-out"
            style={{ bottom: '88px' }}
        >
            <div
                onClick={() => setIsFullPlayerOpen(true)}
                className="rounded-2xl px-3.5 py-2.5 flex items-center gap-3 cursor-pointer active:scale-[0.98] transition-all relative overflow-hidden border border-[var(--border-color)] shadow-2xl group"
                style={{ background: bgGradient }}
            >
                {/* Thumbnail Bulat Berputar + Circular Progress Bar */}
                <div
                    className="relative w-11 h-11 shrink-0 flex items-center justify-center z-10"
                    onClick={(e) => {
                        e.stopPropagation();
                        setIsFullPlayerOpen(true);
                    }}
                >
                    <svg className="w-11 h-11 -rotate-90 pointer-events-none absolute inset-0 z-10" viewBox="0 0 48 48">
                        <circle cx="24" cy="24" r="21" fill="none" stroke="rgba(128,128,128,0.2)" strokeWidth="2.5"></circle>
                        <circle
                            cx="24"
                            cy="24"
                            r="21"
                            fill="none"
                            stroke={primaryColor}
                            strokeWidth="2.5"
                            strokeDasharray={circumference}
                            strokeDashoffset={strokeDashoffset}
                            strokeLinecap="round"
                            className="transition-all duration-150"
                        ></circle>
                    </svg>
                    <div className="w-[34px] h-[34px] rounded-full overflow-hidden z-0 border border-[var(--border-color)] relative">
                        <img
                            src={toHDCover(currentTrack.cover, currentTrack.videoId || currentTrack.id)}
                            alt={currentTrack.title || 'Cover Lagu'}
                            width="34"
                            height="34"
                            loading="lazy"
                            decoding="async"
                            className="w-full h-full object-cover rounded-full"
                            onError={handleImgError}
                        />
                        {isLoading && (
                            <div className="absolute inset-0 bg-black/50 backdrop-blur-[1px] flex items-center justify-center">
                                <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                            </div>
                        )}
                    </div>
                </div>

                {/* Meta Info Judul & Artis */}
                <div className="flex-1 min-w-0 z-10">
                    <div className="font-bold text-xs sm:text-sm text-[var(--text-primary)] truncate drop-shadow-sm flex items-center gap-1.5">
                        <span className="truncate">{currentTrack.title || 'Pilih lagu'}</span>
                        {isLoading && (
                            <span className="shrink-0 text-xs px-1.5 py-0.2 bg-white/10 text-white font-semibold rounded-full border border-white/15 animate-pulse">
                                Memuat...
                            </span>
                        )}
                    </div>
                    <div className="text-[var(--text-secondary)] text-xs truncate mt-0.5">
                        {currentTrack.artist || 'Unknown Artist'}
                    </div>
                </div>

                {/* Controls: Play/Pause and Heart */}
                <div className="flex items-center gap-1.5 z-10 shrink-0">
                    <button
                        onClick={(e) => {
                            e.stopPropagation();
                            togglePlay();
                        }}
                        aria-label={isPlaying ? "Jeda Lagu" : "Putar Lagu"}
                        className="text-[var(--text-primary)] active:scale-90 p-0.5 cursor-pointer"
                        title="Putar/Jeda"
                    >
                        <div
                            className="w-9 h-9 rounded-full flex items-center justify-center transition-all bg-[var(--card-hover)] border border-[var(--border-color)] hover:opacity-80"
                            style={{ borderColor: `color-mix(in srgb, ${primaryColor} 40%, transparent)` }}
                        >
                            {isLoading ? (
                                <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                            ) : isPlaying ? (
                                <Pause className="w-4 h-4 fill-current" />
                            ) : (
                                <Play className="w-4 h-4 fill-current ml-0.5" />
                            )}
                        </div>
                    </button>
                    <button
                        onClick={handleToggleLike}
                        aria-label="Sukai Lagu"
                        className={`active:scale-90 p-1.5 cursor-pointer transition-colors ${
                            isLiked ? 'text-white' : 'text-[var(--text-secondary)] hover:text-white'
                        }`}
                        title="Sukai Lagu"
                    >
                        <Heart className={`w-5 h-5 ${isLiked ? 'fill-current' : ''}`} />
                    </button>
                </div>
            </div>
        </div>
    );
}
