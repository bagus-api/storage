import React, { useRef, useEffect } from 'react';

export default function GooeyNav({
  items = [],
  activeTab = 'home',
  onTabChange,
  animationTime = 600,
  particleCount = 35,
  particleDistances = [90, 10],
  particleR = 500,
  timeVariance = 500,
  colors = [1, 2, 3, 1, 2, 3, 1, 4]
}) {
  const containerRef = useRef(null);
  const navRef = useRef(null);
  const effectRef = useRef(null);

  const activeIndex = Math.max(0, items.findIndex(t => t.id === activeTab));

  const noise = (n = 1) => n / 2 - Math.random() * n;

  const getXY = (distance, pointIndex, totalPoints) => {
    const angle = ((360 + noise(8)) / totalPoints) * pointIndex * (Math.PI / 180);
    return [distance * Math.cos(angle), distance * Math.sin(angle)];
  };

  const createParticle = (i, t, d, r) => {
    let rotate = noise(r / 10);
    return {
      start: getXY(d[0], particleCount - i, particleCount),
      end: getXY(d[1] + noise(7), particleCount - i, particleCount),
      time: t,
      scale: 1 + noise(0.2),
      rotate: rotate > 0 ? (rotate + r / 20) * 10 : (rotate - r / 20) * 10
    };
  };

  const makeParticles = element => {
    if (!element) return;
    const d = particleDistances;
    const r = particleR;
    const bubbleTime = animationTime * 2 + timeVariance;
    element.style.setProperty('--time', `${bubbleTime}ms`);

    for (let i = 0; i < particleCount; i++) {
      const t = animationTime * 2 + noise(timeVariance * 2);
      const p = createParticle(i, t, d, r);

      setTimeout(() => {
        const particle = document.createElement('span');
        const point = document.createElement('span');
        particle.classList.add('particle');
        particle.style.setProperty('--start-x', `${p.start[0]}px`);
        particle.style.setProperty('--start-y', `${p.start[1]}px`);
        particle.style.setProperty('--end-x', `${p.end[0]}px`);
        particle.style.setProperty('--end-y', `${p.end[1]}px`);
        particle.style.setProperty('--time', `${p.time}ms`);
        particle.style.setProperty('--scale', `${p.scale}`);
        particle.style.setProperty('--rotate', `${p.rotate}deg`);

        point.classList.add('point');
        particle.appendChild(point);
        element.appendChild(particle);

        setTimeout(() => {
          try {
            if (particle.parentNode === element) {
              element.removeChild(particle);
            }
          } catch {}
        }, t);
      }, 30);
    }
  };

  const updateEffectPosition = element => {
    if (!containerRef.current || !effectRef.current || !element) return;
    const containerRect = containerRef.current.getBoundingClientRect();
    const pos = element.getBoundingClientRect();

    const left = pos.x - containerRect.x;
    const top = pos.y - containerRect.y;
    const width = pos.width;
    const height = pos.height;

    effectRef.current.style.left = `${left}px`;
    effectRef.current.style.top = `${top}px`;
    effectRef.current.style.width = `${width}px`;
    effectRef.current.style.height = `${height}px`;

    effectRef.current.classList.remove('active');
    void effectRef.current.offsetWidth;
    effectRef.current.classList.add('active');
  };

  const handleClick = (e, index) => {
    const liEl = e.currentTarget;
    if (onTabChange && items[index]) {
      onTabChange(items[index].id);
    }

    updateEffectPosition(liEl);

    if (effectRef.current) {
      const oldParticles = effectRef.current.querySelectorAll('.particle');
      oldParticles.forEach(p => {
        try { effectRef.current.removeChild(p); } catch {}
      });
      makeParticles(effectRef.current);
    }
  };

  useEffect(() => {
    if (!navRef.current || !containerRef.current) return;
    const activeLi = navRef.current.querySelectorAll('li')[activeIndex];
    if (activeLi) {
      updateEffectPosition(activeLi);
    }

    const resizeObserver = new ResizeObserver(() => {
      const currentActiveLi = navRef.current?.querySelectorAll('li')[activeIndex];
      if (currentActiveLi) {
        updateEffectPosition(currentActiveLi);
      }
    });

    resizeObserver.observe(containerRef.current);
    return () => resizeObserver.disconnect();
  }, [activeIndex]);

  return (
    <>
      {/* SVG Gooey Filter - 100% transparan, tanpa kotak hitam sama sekali */}
      <svg style={{ position: 'absolute', width: 0, height: 0, pointerEvents: 'none' }} aria-hidden="true">
        <defs>
          <filter id="gooey-nav-filter" x="-100%" y="-100%" width="300%" height="300%">
            <feGaussianBlur in="SourceGraphic" stdDeviation="6" result="blur" />
            <feColorMatrix in="blur" mode="matrix" values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 20 -8" result="goo" />
            <feBlend in="SourceGraphic" in2="goo" />
          </filter>
        </defs>
      </svg>

      <style>{`
        .gooey-nav-container {
          position: relative;
        }
        .gooey-nav-container .effect {
          position: absolute;
          pointer-events: none;
          display: grid;
          place-items: center;
          z-index: 1;
          filter: url(#gooey-nav-filter);
          transition: left 0.28s cubic-bezier(0.4, 0, 0.2, 1), top 0.28s ease, width 0.28s cubic-bezier(0.4, 0, 0.2, 1), height 0.28s ease;
        }
        .gooey-nav-container .effect::after {
          content: "";
          position: absolute;
          inset: 0;
          background: var(--nav-active-pill, #ffffff);
          transform: scale(0);
          opacity: 0;
          z-index: -1;
          border-radius: 9999px;
          box-shadow: 0 0 15px var(--nav-pill-shadow, rgba(255, 255, 255, 0.4));
        }
        .gooey-nav-container .effect.active::after {
          animation: gooey-pill 0.3s ease both;
        }
        @keyframes gooey-pill {
          to {
            transform: scale(1);
            opacity: 1;
          }
        }
        .gooey-nav-container .particle,
        .gooey-nav-container .point {
          display: block;
          opacity: 0;
          width: 20px;
          height: 20px;
          border-radius: 9999px;
          transform-origin: center;
        }
        .gooey-nav-container .particle {
          --time: 5s;
          position: absolute;
          top: calc(50% - 10px);
          left: calc(50% - 10px);
          animation: particle calc(var(--time)) ease 1 -350ms;
        }
        .gooey-nav-container .point {
          background: var(--nav-active-pill, #ffffff);
          opacity: 1;
          animation: point calc(var(--time)) ease 1 -350ms;
        }
        @keyframes particle {
          0% {
            transform: rotate(0deg) translate(calc(var(--start-x)), calc(var(--start-y)));
            opacity: 1;
            animation-timing-function: cubic-bezier(0.55, 0, 1, 0.45);
          }
          70% {
            transform: rotate(calc(var(--rotate) * 0.5)) translate(calc(var(--end-x) * 1.2), calc(var(--end-y) * 1.2));
            opacity: 1;
            animation-timing-function: ease;
          }
          85% {
            transform: rotate(calc(var(--rotate) * 0.66)) translate(calc(var(--end-x)), calc(var(--end-y)));
            opacity: 1;
          }
          100% {
            transform: rotate(calc(var(--rotate) * 1.2)) translate(calc(var(--end-x) * 0.5), calc(var(--end-y) * 0.5));
            opacity: 1;
          }
        }
        @keyframes point {
          0% {
            transform: scale(0);
            opacity: 0;
            animation-timing-function: cubic-bezier(0.55, 0, 1, 0.45);
          }
          25% {
            transform: scale(calc(var(--scale) * 0.25));
          }
          38% {
            opacity: 1;
          }
          65% {
            transform: scale(var(--scale));
            opacity: 1;
            animation-timing-function: ease;
          }
          85% {
            transform: scale(var(--scale));
            opacity: 1;
          }
          100% {
            transform: scale(0);
            opacity: 0;
          }
        }
        .gooey-nav-container ul li.active {
          color: var(--nav-active-icon, #000000) !important;
        }
        .gooey-nav-container ul li.active svg {
          stroke: var(--nav-active-icon, #000000) !important;
          color: var(--nav-active-icon, #000000) !important;
        }
        .gooey-nav-container ul li.active span {
          color: var(--nav-active-icon, #000000) !important;
        }
        .gooey-nav-container .nav-inactive-item {
          color: var(--nav-inactive-icon, rgba(255, 255, 255, 0.6));
        }
        .gooey-nav-container .nav-inactive-item:hover {
          color: var(--nav-inactive-hover, #ffffff);
        }
        .gooey-nav-container .nav-inactive-item svg {
          stroke: currentColor;
          color: currentColor;
        }
        .gooey-nav-container .nav-inactive-item span {
          color: currentColor;
        }
      `}</style>

      <div className="gooey-nav-container select-none" ref={containerRef}>
        <nav className="flex relative z-[3]" style={{ transform: 'translate3d(0,0,0.01px)' }}>
          <ul
            ref={navRef}
            className="flex gap-1.5 sm:gap-2 md:gap-3 list-none p-0 m-0 relative items-center"
          >
            {items.map((item, index) => {
              const isItemActive = activeIndex === index;
              return (
                <li
                  key={item.id || index}
                  onClick={e => handleClick(e, index)}
                  className={`rounded-full relative cursor-pointer transition-colors duration-200 flex items-center justify-center ${
                    isItemActive ? 'active' : 'nav-inactive-item'
                  }`}
                >
                  <a
                    href={`#${item.id}`}
                    onClick={e => e.preventDefault()}
                    className="outline-none px-3.5 py-2.5 sm:px-5 sm:py-3 inline-flex items-center justify-center gap-2 cursor-pointer select-none touch-manipulation transition-colors duration-300"
                    aria-label={item.label || item.id}
                    title={item.label || item.id}
                  >
                    <span className="inline-flex items-center justify-center pointer-events-none">
                      {item.icon}
                    </span>
                    <span className={`font-black text-xs sm:text-sm tracking-wide pointer-events-none select-none ${
                      isItemActive ? 'inline-block' : 'hidden md:inline-block'
                    }`}>
                      {item.label}
                    </span>
                  </a>
                </li>
              );
            })}
          </ul>
        </nav>
        <span className="effect" ref={effectRef} />
      </div>
    </>
  );
}
