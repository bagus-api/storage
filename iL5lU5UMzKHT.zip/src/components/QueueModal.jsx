import React from 'react';
import { Play, Pause } from 'lucide-react';
import { usePlayer } from '../context/PlayerContext';
import { toHDCover, FI, handleImgError } from '../utils/helpers';

export default function QueueModal() {
    const {
        isQueueOpen,
        setIsQueueOpen,
        playlist,
        playlistIndex,
        currentTrack,
        isPlaying,
        playTrack
    } = usePlayer();

    if (!isQueueOpen) return null;

    return (
        <div
            onClick={() => setIsQueueOpen(false)}
            className="fixed inset-0 z-[300] flex items-end justify-center bg-black/60"
        >
            <div
                onClick={(e) => e.stopPropagation()}
                className="bg-[#181922] w-full max-w-md max-h-[75vh] flex flex-col rounded-t-3xl p-6 border-t border-white/10 animate-slide-up-modal"
            >
                <div className="w-10 h-1 bg-white/20 rounded-full mx-auto mb-3 shrink-0"></div>
                <div className="flex items-center justify-between pb-3 border-b border-white/10 shrink-0 mb-3">
                    <h3 className="text-white font-bold text-base">Antrean Putar (Queue)</h3>
                    <span className="text-xs text-white/60">{playlist.length} lagu</span>
                </div>

                <div className="flex-1 overflow-y-auto hide-scrollbar space-y-2">
                    {playlist.map((track, idx) => {
                        const isCur = idx === playlistIndex;
                        return (
                            <div
                                key={idx}
                                onClick={() => playTrack(track, playlist, idx, 'queue')}
                                className={`flex items-center gap-3 p-2.5 rounded-2xl cursor-pointer active:scale-98 transition-all ${
                                    isCur
                                        ? 'bg-[#343a4e] border border-white/40 shadow-xl'
                                        : 'bg-[#20222c] border border-white/10 hover:bg-[#282b38]'
                                }`}
                            >
                                <span className="w-5 text-center text-xs font-bold text-white/60">{idx + 1}</span>
                                <img
                                    src={toHDCover(track.cover, track.videoId || track.id)}
                                    className="w-11 h-11 rounded-xl object-cover shrink-0"
                                    alt=""
                                    onError={handleImgError}
                                />
                                <div className="flex-1 min-w-0">
                                    <p className={`text-sm truncate ${isCur ? 'text-white font-bold' : 'text-white/90 font-medium'}`}>
                                        {track.title}
                                    </p>
                                    <p className="text-xs text-white/60 truncate mt-0.5">{track.artist}</p>
                                </div>
                                {isCur && (
                                    <div className="shrink-0 p-1">
                                        {isPlaying ? (
                                            <div className="flex items-end justify-center gap-[2px] w-4 h-4 pb-0.5">
                                                <span className="w-[2px] bg-white rounded-full animate-eq-1"></span>
                                                <span className="w-[2px] bg-white rounded-full animate-eq-2"></span>
                                                <span className="w-[2px] bg-white rounded-full animate-eq-3"></span>
                                            </div>
                                        ) : (
                                            <Pause className="w-4 h-4 fill-current text-white" />
                                        )}
                                    </div>
                                )}
                            </div>
                        );
                    })}
                </div>

                <button
                    onClick={() => setIsQueueOpen(false)}
                    className="w-full mt-3 py-3 bg-white/10 text-white font-bold rounded-full border border-white/10 active:scale-95 transition shrink-0"
                >
                    Tutup
                </button>
            </div>
        </div>
    );
}
