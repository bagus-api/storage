import React, { useState, useEffect } from 'react';
import { usePlayer } from '../context/PlayerContext';
import { getUserPlaylists, addSongToPlaylist, FI, handleImgError } from '../utils/helpers';

export default function AddToPlaylistModal() {
    const { isAddToPlaylistOpen, setIsAddToPlaylistOpen, currentTrack, showToast, setIsCreatePlaylistOpen } = usePlayer();
    const [playlists, setPlaylists] = useState([]);

    useEffect(() => {
        if (isAddToPlaylistOpen) {
            setPlaylists(getUserPlaylists());
        }
    }, [isAddToPlaylistOpen]);

    if (!isAddToPlaylistOpen || !currentTrack) return null;

    const handleSelect = (plId) => {
        const added = addSongToPlaylist(plId, currentTrack);
        setIsAddToPlaylistOpen(false);
        showToast(added ? 'Lagu ditambahkan ke Playlist' : 'Lagu sudah ada di Playlist ini');
    };

    return (
        <div
            onClick={() => setIsAddToPlaylistOpen(false)}
            className="fixed inset-0 z-[300] flex items-end justify-center bg-black/60"
        >
            <div
                onClick={(e) => e.stopPropagation()}
                className="bg-[#181922] w-full max-w-md max-h-[75vh] flex flex-col rounded-t-3xl p-6 border-t border-white/10 animate-slide-up-modal"
            >
                <div className="w-10 h-1 bg-white/20 rounded-full mx-auto mb-3 shrink-0"></div>
                <h3 className="text-white font-bold text-base mb-3 shrink-0">Tambahkan ke Playlist</h3>

                <button
                    onClick={() => {
                        setIsAddToPlaylistOpen(false);
                        setIsCreatePlaylistOpen(true);
                    }}
                    className="w-full py-3 mb-3 bg-white/10 hover:bg-white/15 border border-white/15 text-white font-bold rounded-2xl active:scale-95 transition text-xs shrink-0 flex items-center justify-center gap-2"
                >
                    + Buat Playlist Baru
                </button>

                <div className="flex-1 overflow-y-auto hide-scrollbar space-y-2">
                    {playlists.length === 0 ? (
                        <p className="text-center text-white/50 text-xs py-6">Belum ada playlist</p>
                    ) : (
                        playlists.map((pl) => (
                            <div
                                key={pl.id}
                                onClick={() => handleSelect(pl.id)}
                                className="flex items-center gap-3 p-3 rounded-2xl bg-white/5 hover:bg-white/10 cursor-pointer active:scale-98 transition"
                            >
                                <img
                                    src={pl.image || (pl.songs.length > 0 ? pl.songs[0].cover : FI)}
                                    className="w-12 h-12 rounded-xl object-cover shrink-0"
                                    alt=""
                                    onError={handleImgError}
                                />
                                <div className="flex-1 min-w-0">
                                    <h4 className="text-white font-bold text-sm truncate">{pl.name}</h4>
                                    <p className="text-white/60 text-xs mt-0.5">{pl.songs.length} lagu</p>
                                </div>
                            </div>
                        ))
                    )}
                </div>

                <button
                    onClick={() => setIsAddToPlaylistOpen(false)}
                    className="w-full mt-3 py-3 bg-white/10 text-white font-bold rounded-full border border-white/10 active:scale-95 transition shrink-0"
                >
                    Batal
                </button>
            </div>
        </div>
    );
}
