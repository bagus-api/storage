import React, { useState } from 'react';
import { usePlayer } from '../context/PlayerContext';
import { createPlaylist } from '../utils/helpers';

export default function CreatePlaylistModal({ onCreated }) {
    const { isCreatePlaylistOpen, setIsCreatePlaylistOpen, showToast } = usePlayer();
    const [name, setName] = useState('');
    const [imagePreview, setImagePreview] = useState('');

    if (!isCreatePlaylistOpen) return null;

    const handleFileChange = (e) => {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = (event) => setImagePreview(event.target.result);
            reader.readAsDataURL(file);
        }
    };

    const handleCreate = () => {
        const finalName = name.trim() || 'Playlist Baru';
        createPlaylist(finalName, imagePreview);
        setIsCreatePlaylistOpen(false);
        setName('');
        setImagePreview('');
        showToast(`Playlist "${finalName}" berhasil dibuat`);
        if (onCreated) onCreated();
    };

    return (
        <div
            onClick={() => setIsCreatePlaylistOpen(false)}
            className="fixed inset-0 z-[300] flex items-end justify-center bg-black/60"
        >
            <div
                onClick={(e) => e.stopPropagation()}
                className="glass-strong w-full max-w-md rounded-t-3xl p-6 border-t border-white/10 animate-slide-up-modal space-y-4"
                style={{ background: 'var(--bg-color)' }}
            >
                <div className="w-10 h-1 bg-white/20 rounded-full mx-auto mb-2"></div>
                <h3 className="font-bold text-white mb-2">Buat Playlist Baru</h3>

                <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full glass-input text-white rounded-xl px-4 py-3 focus:outline-none text-sm placeholder:text-white/40"
                    placeholder="Nama Playlist"
                    autoFocus
                />

                <div>
                    <label className="text-xs text-white/60 block mb-1">Sampul (Opsional)</label>
                    <input
                        type="file"
                        accept="image/*"
                        onChange={handleFileChange}
                        className="w-full text-xs text-white/70"
                    />
                </div>

                <div className="flex gap-3 pt-2">
                    <button
                        onClick={handleCreate}
                        className="flex-1 btn-chrome font-bold py-3 rounded-full text-xs active:scale-95 transition"
                    >
                        Buat
                    </button>
                    <button
                        onClick={() => setIsCreatePlaylistOpen(false)}
                        className="px-6 py-3 glass glass-hover text-white rounded-full text-xs font-bold active:scale-95 transition"
                    >
                        Batal
                    </button>
                </div>
            </div>
        </div>
    );
}
