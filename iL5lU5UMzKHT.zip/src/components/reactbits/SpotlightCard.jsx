import React, { useRef } from 'react';

/**
 * SpotlightCard component inspired by reactbits.dev/components/spotlight-card
 * Monochrome interactive radial spotlight glow tracking cursor with 0 React state re-renders.
 */
export default function SpotlightCard({
    children,
    className = '',
    spotlightColor = 'var(--spotlight-color, rgba(255, 255, 255, 0.08))'
}) {
    const divRef = useRef(null);
    const overlayRef = useRef(null);

    const handleMouseMove = (e) => {
        if (!divRef.current || !overlayRef.current) return;
        const rect = divRef.current.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        overlayRef.current.style.background = `radial-gradient(350px circle at ${x}px ${y}px, ${spotlightColor}, transparent 80%)`;
    };

    const handleMouseEnter = () => {
        if (overlayRef.current) overlayRef.current.style.opacity = '1';
    };
    const handleMouseLeave = () => {
        if (overlayRef.current) overlayRef.current.style.opacity = '0';
    };

    return (
        <div
            ref={divRef}
            onMouseMove={handleMouseMove}
            onMouseEnter={handleMouseEnter}
            onMouseLeave={handleMouseLeave}
            className={`relative rounded-3xl overflow-hidden border border-[var(--border-color)] bg-[var(--card-bg)] transition-colors duration-200 ${className}`}
        >
            <div
                ref={overlayRef}
                className="pointer-events-none absolute -inset-px transition-opacity duration-300 opacity-0"
            />
            <div className="relative z-10 w-full h-full">{children}</div>
        </div>
    );
}
