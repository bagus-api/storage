import React from 'react';

/**
 * ShinyText component inspired by reactbits.dev/text-animations/shiny-text
 * Pure CSS text shimmer effect with dark/light mode compatibility.
 */
export default function ShinyText({
    text = '',
    disabled = false,
    speed = 3,
    className = ''
}) {
    const animationDuration = `${speed}s`;

    return (
        <span
            className={`relative inline-block bg-clip-text text-transparent font-medium ${className}`}
            style={{
                backgroundImage: 'linear-gradient(120deg, var(--text-secondary) 25%, var(--text-primary) 50%, var(--text-secondary) 75%)',
                backgroundSize: '200% 100%',
                animation: disabled ? 'none' : `shiny-text-shine ${animationDuration} linear infinite`,
            }}
        >
            {text}
        </span>
    );
}
