import React, { useEffect, useState } from 'react';

/**
 * BlurText component inspired by reactbits.dev/text-animations/blur-text
 * Clean staggered blur fade-in text animation.
 */
export default function BlurText({
    text = '',
    delay = 60,
    className = '',
    animateBy = 'words' // 'words' or 'letters'
}) {
    const elements = animateBy === 'words' ? text.split(' ') : text.split('');
    const [inView, setInView] = useState(false);

    useEffect(() => {
        const timer = setTimeout(() => setInView(true), 20);
        return () => clearTimeout(timer);
    }, []);

    return (
        <span className={`inline-block ${className}`}>
            {elements.map((el, i) => (
                <span
                    key={i}
                    className="inline-block transition-all duration-700 ease-out"
                    style={{
                        opacity: inView ? 1 : 0,
                        filter: inView ? 'blur(0px)' : 'blur(8px)',
                        transform: inView ? 'translateY(0)' : 'translateY(8px)',
                        transitionDelay: `${i * delay}ms`,
                        marginRight: animateBy === 'words' ? '0.3em' : '0'
                    }}
                >
                    {el}
                </span>
            ))}
        </span>
    );
}
