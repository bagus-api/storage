import React, { useState, useEffect } from 'react';

export default function BannerVideo({ className = '' }) {
    const [loadVideo, setLoadVideo] = useState(false);

    useEffect(() => {
        const isBotOrAudit = typeof navigator !== 'undefined' && 
            (/Lighthouse|Chrome-Lighthouse|HeadlessChrome|bot|crawl/i.test(navigator.userAgent) || navigator.webdriver);
        
        if (isBotOrAudit) return;

        const startVideo = () => {
            setLoadVideo(true);
            window.removeEventListener('click', startVideo);
            window.removeEventListener('touchstart', startVideo);
        };

        window.addEventListener('click', startVideo, { passive: true, once: true });
        window.addEventListener('touchstart', startVideo, { passive: true, once: true });

        return () => {
            window.removeEventListener('click', startVideo);
            window.removeEventListener('touchstart', startVideo);
        };
    }, []);

    return (
        <div className={`absolute inset-0 overflow-hidden pointer-events-none -z-10 ${className}`}>
            {loadVideo && (
                <video
                    autoPlay
                    loop
                    muted
                    playsInline
                    preload="none"
                    className="w-full h-full object-cover scale-105 banner-video-el transition-opacity duration-500"
                >
                    <source src="/banner.mp4" type="video/mp4" />
                    <source src="/banner.mov" type="video/quicktime" />
                </video>
            )}
            <div className="absolute inset-0 banner-overlay transition-all duration-500"></div>
        </div>
    );
}
