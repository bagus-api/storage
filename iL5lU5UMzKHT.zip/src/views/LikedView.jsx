import React, { useState, useEffect } from 'react';
import { Heart, Play, Pause } from 'lucide-react';
import { usePlayer } from '../context/PlayerContext';
import { getLikedSongs, toggleLikeSong, FI, handleImgError } from '../utils/helpers';
import BannerVideo from '../components/BannerVideo';

export default function LikedView() {
    const {
        playTrack,
        currentTrack,
        isPlaying,
        isLoading,
        togglePlay,
        showToast
    } = usePlayer();

    const [liked, setLiked] = useState([]);

    const reload = () => {
        setLiked(getLikedSongs());
    };

    useEffect(() => {
        reload();
    }, []);

    const handleToggleLike = (song) => {
        toggleLikeSong(song);
        reload();
        showToast('Lagu dihapus dari Lagu Disukai');
    };

    return (
        <div id="view-liked" className="animate-fade-in pb-12">
            {/* Sticky Header */}
            <div className="pt-3.5 pb-2 px-4 sticky top-0 z-30 border-b border-[var(--header-border)] shadow-2xl transition-all flex justify-between items-center relative overflow-hidden backdrop-blur-md bg-[var(--header-bg)]">
                <BannerVideo />
                <h1 className="text-2xl font-black text-[var(--text-primary)] tracking-tight drop-shadow-md">Liked Songs</h1>
                <div className="w-10 h-10 rounded-2xl bg-black/25 dark:bg-black/40 backdrop-blur-md border border-[var(--border-color)] flex items-center justify-center text-white shadow-lg">
                    <Heart className="w-5 h-5 fill-current" />
                </div>
            </div>

            {/* Content */}
            <div className="px-4 mt-4 space-y-3">
                {liked.length > 0 ? (
                    <>
                        <div className="flex items-center justify-between mb-2">
                            <span className="text-xs font-semibold text-white/60 uppercase tracking-wider">
                                {liked.length} Lagu Tersimpan
                            </span>
                            <button
                                onClick={() => playTrack(liked[0], liked, 0, 'liked')}
                                className="text-xs text-white font-bold hover:underline flex items-center gap-1 cursor-pointer"
                            >
                                <Play className="w-3.5 h-3.5 fill-current" /> Putar Semua
                            </button>
                        </div>

                        <div className="space-y-2.5">
                            {liked.map((s, i) => {
                                const isCur = currentTrack && (
                                    currentTrack.id === s.id ||
                                    currentTrack.videoId === s.videoId ||
                                    (currentTrack.title === s.title && currentTrack.artist === s.artist)
                                );
                                const isPlay = isCur && isPlaying;
                                const isLoad = isCur && isLoading;

                                const cardBg = isPlay
                                    ? 'bg-[#343a4e] border border-white/40 shadow-xl'
                                    : isCur
                                    ? 'bg-[#2e3344] border border-white/30'
                                    : 'bg-[#20222c] border border-white/10 hover:bg-[#282b38]';

                                return (
                                    <div
                                        key={i}
                                        className={`rounded-2xl ${cardBg} p-2.5 flex items-center gap-3 active:scale-[0.98] transition-all duration-300 group shadow-lg shadow-black/25`}
                                    >
                                        <div
                                            onClick={() => {
                                                if (isCur) togglePlay();
                                                else playTrack(s, liked, i, 'liked');
                                            }}
                                            className="flex items-center gap-3 flex-1 min-w-0 cursor-pointer"
                                        >
                                            <img
                                                src={s.cover}
                                                className="w-14 h-14 rounded-xl object-cover shrink-0 shadow-md border border-white/10"
                                                alt=""
                                                onError={handleImgError}
                                            />
                                            <div className="min-w-0 flex-1">
                                                <h3 className="font-semibold text-sm text-white truncate">{s.title}</h3>
                                                <p className="text-xs text-white/60 truncate mt-0.5">{s.artist}</p>
                                            </div>
                                        </div>

                                        <button
                                            onClick={() => handleToggleLike(s)}
                                            className="w-9 h-9 rounded-2xl bg-white/10 text-white border border-white/20 flex items-center justify-center shrink-0 hover:bg-white/20 active:scale-90 transition-all cursor-pointer"
                                            title="Hapus dari Disukai"
                                        >
                                            <Heart className="w-4 h-4 fill-current" />
                                        </button>

                                        <button
                                            onClick={() => {
                                                if (isCur) togglePlay();
                                                else playTrack(s, liked, i, 'liked');
                                            }}
                                            className="w-9 h-9 rounded-2xl bg-white/10 text-white flex items-center justify-center shrink-0 hover:bg-white/20 active:scale-90 transition-all cursor-pointer"
                                        >
                                            {isLoad ? (
                                                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                                            ) : isPlay ? (
                                                <div className="flex items-end justify-center gap-[2px] w-4 h-4 pb-0.5">
                                                    <span className="w-[2px] bg-white rounded-full animate-eq-1"></span>
                                                    <span className="w-[2px] bg-white rounded-full animate-eq-2"></span>
                                                    <span className="w-[2px] bg-white rounded-full animate-eq-3"></span>
                                                </div>
                                            ) : isCur ? (
                                                <Pause className="w-4 h-4 fill-current text-white" />
                                            ) : (
                                                <Play className="w-4 h-4 fill-current text-white ml-0.5" />
                                            )}
                                        </button>
                                    </div>
                                );
                            })}
                        </div>
                    </>
                ) : (
                    <div className="text-center py-16 rounded-3xl bg-white/[0.04] border border-white/10 px-4">
                        <div className="w-16 h-16 rounded-full bg-white/10 border border-white/20 flex items-center justify-center mx-auto mb-3">
                            <Heart className="w-8 h-8 text-white" />
                        </div>
                        <h3 className="text-white font-bold text-base mb-1">Belum ada lagu disukai</h3>
                        <p className="text-white/60 text-xs max-w-xs mx-auto">
                            Klik ikon hati pada lagu favoritmu untuk menyimpannya di sini.
                        </p>
                    </div>
                )}
            </div>
        </div>
    );
}
