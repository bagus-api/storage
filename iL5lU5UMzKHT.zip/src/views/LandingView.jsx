import React from 'react';
import { Play, Sparkles, Sliders, WifiOff, ArrowRight, Sun, Moon, ShieldCheck, Radio, Music2 } from 'lucide-react';
import { usePlayer } from '../context/PlayerContext';

export default function LandingView() {
    const { navigateToTab, theme, toggleTheme } = usePlayer();

    const handleStartApp = () => {
        if (navigateToTab) {
            navigateToTab('home', true);
        } else if (typeof window !== 'undefined') {
            window.location.href = '/id/';
        }
    };

    const handleExploreSearch = () => {
        if (navigateToTab) {
            navigateToTab('search', true);
        }
    };

    return (
        <div id="view-landing" className="min-h-full flex flex-col justify-between px-4 sm:px-6 py-6 max-w-4xl mx-auto animate-fade-in text-[var(--text-primary)]">
            {/* Top Navigation Bar */}
            <header className="flex items-center justify-between py-2 border-b border-[var(--border-color)]">
                <div className="flex items-center gap-3">
                    <img
                        src="/logo.webp"
                        alt="NanzMusify Logo"
                        width="36"
                        height="36"
                        fetchPriority="high"
                        loading="eager"
                        decoding="async"
                        className="w-9 h-9 rounded-xl object-contain app-brand-logo shadow-md transition-all duration-300"
                        onError={(e) => { e.currentTarget.style.display = 'none'; }}
                    />
                    <div>
                        <span className="text-xl font-black text-[var(--text-primary)] tracking-tight">
                            NanzMusify
                        </span>
                        <span className="hidden sm:inline-block ml-2 text-xs font-semibold px-2 py-0.5 rounded-full bg-white/10 text-zinc-300 border border-white/15">
                            v2.0
                        </span>
                    </div>
                </div>

                <div className="flex items-center gap-2">
                    <button
                        onClick={toggleTheme}
                        aria-label={theme === 'dark' ? 'Ganti ke Tema Terang' : 'Ganti ke Tema Gelap'}
                        className="w-9 h-9 rounded-xl bg-[var(--card-bg)] border border-[var(--border-color)] flex items-center justify-center text-[var(--text-primary)] hover:opacity-80 active:scale-95 transition-all shadow-sm cursor-pointer"
                        title={theme === 'dark' ? 'Ganti ke Tema Terang' : 'Ganti ke Tema Gelap'}
                    >
                        {theme === 'dark' ? <Sun className="w-4 h-4 text-white" /> : <Moon className="w-4 h-4 text-black" />}
                    </button>
                    <button
                        onClick={handleStartApp}
                        className="px-4 py-1.5 rounded-xl bg-white text-black hover:bg-zinc-200 dark:bg-white dark:text-black font-bold text-xs sm:text-sm active:scale-95 transition-all shadow-md flex items-center gap-1.5 cursor-pointer"
                    >
                        <span>Buka Player</span>
                        <ArrowRight className="w-4 h-4" />
                    </button>
                </div>
            </header>

            {/* Hero Section */}
            <main className="my-auto py-8 sm:py-12 flex flex-col items-center text-center">
                <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[var(--card-bg)] border border-[var(--border-color)] text-xs font-semibold text-[var(--text-secondary)] shadow-sm mb-5">
                    <Sparkles className="w-3.5 h-3.5 text-white" />
                    <span>Web Music Player Modern & Monokrom</span>
                </div>

                <h1 className="text-3xl sm:text-5xl md:text-6xl font-black text-[var(--text-primary)] tracking-tight leading-tight max-w-2xl">
                    Streaming Musik YouTube Tanpa Batas.
                </h1>

                <p className="mt-4 text-sm sm:text-base text-[var(--text-secondary)] max-w-lg leading-relaxed">
                    Nikmati jutaan lagu dari YouTube Music Indonesia dengan lirik sinkron otomatis, equalizer audio kustom, dan mode pemutar offline PWA.
                </p>

                {/* Primary CTA Buttons */}
                <div className="mt-8 flex flex-col sm:flex-row items-center gap-3 w-full max-w-md justify-center">
                    <button
                        onClick={handleStartApp}
                        className="w-full sm:w-auto px-7 py-3.5 rounded-2xl bg-white text-black hover:bg-zinc-200 active:scale-95 font-bold text-sm sm:text-base shadow-xl shadow-black/40 transition-all flex items-center justify-center gap-2 cursor-pointer border border-white/20"
                    >
                        <Play className="w-5 h-5 fill-current" />
                        <span>Mulai Dengarkan Sekarang</span>
                    </button>
                    <button
                        onClick={handleExploreSearch}
                        className="w-full sm:w-auto px-6 py-3.5 rounded-2xl bg-[var(--card-bg)] hover:bg-[var(--card-hover)] border border-[var(--border-color)] active:scale-95 text-[var(--text-primary)] font-semibold text-sm sm:text-base shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
                    >
                        <Music2 className="w-5 h-5 text-white" />
                        <span>Jelajahi Musik</span>
                    </button>
                </div>

                {/* Features Grid */}
                <div className="mt-12 sm:mt-16 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3.5 w-full text-left">
                    <div className="p-4 rounded-2xl bg-[var(--card-bg)] border border-[var(--border-color)] shadow-sm hover:border-white/30 transition-all">
                        <div className="w-9 h-9 rounded-xl bg-white/10 text-white flex items-center justify-center mb-3 border border-white/10">
                            <Radio className="w-5 h-5" />
                        </div>
                        <h2 className="font-bold text-sm text-[var(--text-primary)]">YouTube Music ID</h2>
                        <p className="text-xs text-[var(--text-secondary)] mt-1">
                            Akses tangga lagu trending, album terpopuler, dan playlist pilihan Indonesia.
                        </p>
                    </div>

                    <div className="p-4 rounded-2xl bg-[var(--card-bg)] border border-[var(--border-color)] shadow-sm hover:border-white/30 transition-all">
                        <div className="w-9 h-9 rounded-xl bg-white/10 text-white flex items-center justify-center mb-3 border border-white/10">
                            <Sparkles className="w-5 h-5" />
                        </div>
                        <h2 className="font-bold text-sm text-[var(--text-primary)]">Lirik Sinkron</h2>
                        <p className="text-xs text-[var(--text-secondary)] mt-1">
                            Lirik real-time yang bergulir otomatis sesuai detik irama alunan lagu.
                        </p>
                    </div>

                    <div className="p-4 rounded-2xl bg-[var(--card-bg)] border border-[var(--border-color)] shadow-sm hover:border-white/30 transition-all">
                        <div className="w-9 h-9 rounded-xl bg-white/10 text-white flex items-center justify-center mb-3 border border-white/10">
                            <Sliders className="w-5 h-5" />
                        </div>
                        <h2 className="font-bold text-sm text-[var(--text-primary)]">Equalizer Audio</h2>
                        <p className="text-xs text-[var(--text-secondary)] mt-1">
                            Atur frekuensi suara, boost bass, dan vokal dengan preset siap pakai.
                        </p>
                    </div>

                    <div className="p-4 rounded-2xl bg-[var(--card-bg)] border border-[var(--border-color)] shadow-sm hover:border-white/30 transition-all">
                        <div className="w-9 h-9 rounded-xl bg-white/10 text-white flex items-center justify-center mb-3 border border-white/10">
                            <WifiOff className="w-5 h-5" />
                        </div>
                        <h2 className="font-bold text-sm text-[var(--text-primary)]">Offline PWA</h2>
                        <p className="text-xs text-[var(--text-secondary)] mt-1">
                            Pasang di HP atau desktop dan simpan lagu favorit untuk diputar offline.
                        </p>
                    </div>
                </div>
            </main>

            {/* Lightweight Footer */}
            <footer className="pt-6 border-t border-[var(--border-color)] flex flex-col sm:flex-row items-center justify-between text-xs text-[var(--text-muted)] gap-2">
                <p>&copy; 2026 NanzMusify. Dibuat dengan cinta untuk pecinta musik.</p>
                <div className="flex items-center gap-4">
                    <span className="flex items-center gap-1 text-[var(--text-secondary)] font-medium">
                        <ShieldCheck className="w-4 h-4 text-white" />
                        <span>Bebas Iklan</span>
                    </span>
                    <button
                        onClick={handleStartApp}
                        className="text-white hover:underline font-semibold cursor-pointer"
                    >
                        Buka Aplikasi &rarr;
                    </button>
                </div>
            </footer>
        </div>
    );
}
