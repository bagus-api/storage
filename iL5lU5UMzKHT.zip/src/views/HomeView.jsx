import React, { useState, useEffect } from 'react';
import {
    Search, User, Zap, Disc, Users, Code, Coffee, Brain, Car,
    Gamepad2, Smile, Heart, Dumbbell, Moon, CloudRain, Sun, Guitar,
    Music, Flame, Play, Pause, X, MessageSquare, Info, TrendingUp, Sparkles
} from 'lucide-react';
import { usePlayer } from '../context/PlayerContext';
import { toHDCover, toThumbCover, toWebp, cn, FI, handleImgError } from '../utils/helpers';
import BannerVideo from '../components/BannerVideo';

export default function HomeView() {
    const {
        playTrack,
        currentTrack,
        isPlaying,
        isLoading,
        togglePlay,
        setActiveTab,
        navigateToTab,
        setActiveAlbum,
        setActiveArtist,
        showToast,
        devProfile,
        theme,
        toggleTheme
    } = usePlayer();

    const [activeCategory, setActiveCategory] = useState('Semua');
    const [quickPicks, setQuickPicks] = useState([]);
    const [trending, setTrending] = useState([]);
    const [playlists, setPlaylists] = useState([]);
    const [albums, setAlbums] = useState([]);
    const [artists, setArtists] = useState([]);

    const [categorySongs, setCategorySongs] = useState([]);
    const [categoryPlaylists, setCategoryPlaylists] = useState([]);
    const [categoryArtists, setCategoryArtists] = useState([]);
    const [loadingCat, setLoadingCat] = useState(false);
    const [loadingDefault, setLoadingDefault] = useState(true);

    const categories = [
        { name: 'Semua' },
        { name: 'Developer Profile', icon: Code },
        { name: 'Chill', icon: Coffee },
        { name: 'Focus', icon: Brain },
        { name: 'Commute', icon: Car },
        { name: 'Gaming', icon: Gamepad2 },
        { name: 'Energize', icon: Zap },
        { name: 'Party', icon: Zap },
        { name: 'Feel good', icon: Smile },
        { name: 'Romance', icon: Heart },
        { name: 'Workout', icon: Dumbbell },
        { name: 'Sleep', icon: Moon },
        { name: 'Sad', icon: CloudRain },
        { name: 'Happy', icon: Sun },
        { name: 'Nostalgia', icon: Disc },
        { name: 'Acoustic', icon: Guitar },
        { name: 'Pop', icon: Music },
        { name: 'Rock', icon: Flame }
    ];

    // Load default home data directly from YouTube Music Indonesia origin scraper (/api/home)
    useEffect(() => {
        setLoadingDefault(true);
        fetch('/api/home')
            .then(res => res.json())
            .then(data => {
                if (data.status && data.result) {
                    if (data.result.quickPicks) {
                        setQuickPicks(data.result.quickPicks.map(s => ({
                            id: s.videoId || s.id,
                            videoId: s.videoId || s.id,
                            title: cn(s.title),
                            artist: cn(s.artist),
                            artistId: s.artistId || '',
                            cover: toThumbCover(s.cover || s.thumbnail, s.videoId || s.id),
                            ytUrl: s.url || `https://music.youtube.com/watch?v=${s.videoId || s.id}`
                        })));
                    }
                    if (data.result.trending) {
                        setTrending(data.result.trending.map(s => ({
                            id: s.videoId || s.id,
                            videoId: s.videoId || s.id,
                            title: cn(s.title),
                            artist: cn(s.artist),
                            artistId: s.artistId || '',
                            cover: toThumbCover(s.cover || s.thumbnail, s.videoId || s.id),
                            ytUrl: s.url || `https://music.youtube.com/watch?v=${s.videoId || s.id}`
                        })));
                    }
                    if (data.result.playlists) setPlaylists(data.result.playlists);
                    if (data.result.albums) setAlbums(data.result.albums);
                    if (data.result.artists) setArtists(data.result.artists);
                }
                setLoadingDefault(false);
            })
            .catch(() => {
                // Fallback to /api/search if /api/home network error
                fetch('/api/search?query=' + encodeURIComponent('Trend Indonesia') + '&type=all')
                    .then(res => res.json())
                    .then(data => {
                        if (data.status && data.result) {
                            if (data.result.songs) {
                                setQuickPicks(data.result.songs.map(s => ({
                                    id: s.videoId,
                                    videoId: s.videoId,
                                    title: cn(s.title),
                                    artist: cn(s.artist),
                                    artistId: s.artistId || '',
                                    cover: toThumbCover(s.thumbnail, s.videoId),
                                    ytUrl: s.url
                                })));
                            }
                            const plist = [].concat(data.result.playlists || []).concat(data.result.albums || []);
                            setPlaylists(plist);
                            if (data.result.artists) setArtists(data.result.artists);
                        }
                        setLoadingDefault(false);
                    })
                    .catch(() => setLoadingDefault(false));
            });
    }, []);

    // Load category data
    const handleSelectCategory = async (catName) => {
        if (catName === activeCategory && catName !== 'Semua') {
            setActiveCategory('Semua');
            return;
        }
        setActiveCategory(catName);

        if (catName === 'Semua') {
            return;
        }

        setLoadingCat(true);

        if (catName === 'Developer Profile') {
            const queryTarget = devProfile?.favorites?.artistSearchQuery || 'XXXTENTACION';
            try {
                const res = await fetch('/api/search?query=' + encodeURIComponent(queryTarget) + '&type=all');
                const data = await res.json();
                if (data.status && data.result) {
                    const fetchedSongs = (data.result.songs || []).map(s => ({
                        id: s.videoId,
                        videoId: s.videoId,
                        title: cn(s.title),
                        artist: cn(s.artist),
                        artistId: s.artistId || '',
                        cover: toHDCover(s.thumbnail, s.videoId),
                        ytUrl: s.url
                    }));

                    const configSongs = (devProfile?.favorites?.songs || []).map(s => ({
                        id: s.videoId || s.id,
                        videoId: s.videoId || s.id,
                        title: cn(s.title),
                        artist: cn(s.artist),
                        artistId: s.artistId || '',
                        cover: s.cover || toHDCover('', s.videoId || s.id),
                        ytUrl: s.ytUrl || `https://youtube.com/watch?v=${s.videoId || s.id}`
                    }));

                    const allSongs = [...configSongs];
                    fetchedSongs.forEach(fs => {
                        if (!allSongs.some(item => item.videoId === fs.videoId)) {
                            allSongs.push(fs);
                        }
                    });

                    setCategorySongs(allSongs);
                    setCategoryPlaylists([].concat(data.result.albums || []).concat(data.result.playlists || []));
                }
            } catch(e){
                if (devProfile?.favorites?.songs) {
                    setCategorySongs(devProfile.favorites.songs);
                }
            }
            setLoadingCat(false);
            return;
        }

        let query = `${catName} Music Indonesia`;
        if (catName === 'Acoustic') query = 'Acoustic Songs Indonesia Hits';
        else if (catName === 'Chill') query = 'Chill Vibes Lofi Indonesia';
        else if (catName === 'Focus') query = 'Focus Deep Work Music';
        else if (catName === 'Commute') query = 'Lagu Roadtrip Perjalanan Indonesia';
        else if (catName === 'Gaming') query = 'Gaming EDM Hype Songs';
        else if (catName === 'Energize') query = 'Energetic Workout Beats';
        else if (catName === 'Party') query = 'Party Dance Hits Indonesia';
        else if (catName === 'Feel good') query = 'Feel Good Happy Songs Indonesia';
        else if (catName === 'Romance') query = 'Lagu Romantis Indonesia Cinta';
        else if (catName === 'Workout') query = 'Gym Workout Motivation Music';
        else if (catName === 'Sleep') query = 'Lagu Tidur Pengantar Tidur Calming';
        else if (catName === 'Sad') query = 'Lagu Galau Sedih Indonesia';
        else if (catName === 'Happy') query = 'Lagu Ceria Senang Upbeat';
        else if (catName === 'Nostalgia') query = 'Lagu Kenangan Nostalgia 2000an Indonesia';

        try {
            const res = await fetch('/api/search?query=' + encodeURIComponent(query) + '&type=all');
            const data = await res.json();
            if (data.status && data.result) {
                setCategorySongs((data.result.songs || []).map(s => ({
                    id: s.videoId,
                    videoId: s.videoId,
                    title: cn(s.title),
                    artist: cn(s.artist),
                    artistId: s.artistId || '',
                    cover: toHDCover(s.thumbnail, s.videoId),
                    ytUrl: s.url
                })));
                setCategoryPlaylists([].concat(data.result.playlists || []).concat(data.result.albums || []));
                setCategoryArtists(data.result.artists || []);
            }
        } catch(e){}
        setLoadingCat(false);
    };

    return (
        <div id="view-home" className="animate-fade-in pb-12">
            {/* Sticky Banner Header */}
            <div className="pt-3.5 pb-2 px-4 sticky top-0 z-30 border-b border-[var(--header-border)] shadow-2xl transition-all relative overflow-hidden backdrop-blur-md bg-[var(--header-bg)]">
                <BannerVideo />
                <div className="flex justify-between items-center mb-1.5 relative z-10">
                    <div className="flex items-center gap-2.5">
                        <img
                            src="/logo.webp"
                            alt="NanzMusify Logo"
                            width="32"
                            height="32"
                            loading="eager"
                            fetchPriority="high"
                            decoding="async"
                            className="w-8 h-8 rounded-xl object-contain app-brand-logo shadow-md transition-all duration-300"
                            onError={handleImgError}
                        />
                        <h1 className="text-2xl font-black text-[var(--text-primary)] tracking-tight drop-shadow-md">
                            NanzMusify
                        </h1>
                    </div>
                    <div className="flex items-center gap-2">
                        {/* Theme Toggle Button */}
                        <button
                            onClick={toggleTheme}
                            aria-label={theme === 'dark' ? 'Ganti ke Tema Terang' : 'Ganti ke Tema Gelap'}
                            className="w-8 h-8 rounded-xl bg-[var(--card-bg)] border border-[var(--border-color)] flex items-center justify-center text-[var(--text-primary)] hover:opacity-80 active:scale-95 transition-all shadow-md cursor-pointer"
                            title={theme === 'dark' ? 'Ganti ke Tema Terang' : 'Ganti ke Tema Gelap'}
                        >
                            {theme === 'dark' ? <Sun className="w-4 h-4 text-white" /> : <Moon className="w-4 h-4 text-black" />}
                        </button>

                        {/* Global Chat Button */}
                        <button
                            onClick={() => navigateToTab ? navigateToTab('chat') : setActiveTab('chat')}
                            aria-label="Global Chat"
                            className="w-8 h-8 rounded-xl bg-[var(--card-bg)] border border-[var(--border-color)] flex items-center justify-center text-[var(--text-primary)] hover:opacity-80 active:scale-95 transition-all shadow-md cursor-pointer"
                            title="Global Chat"
                        >
                            <MessageSquare className="w-4 h-4" />
                        </button>

                        <button
                            onClick={() => navigateToTab ? navigateToTab('search') : setActiveTab('search')}
                            aria-label="Cari Lagu"
                            className="w-8 h-8 rounded-xl bg-[var(--card-bg)] border border-[var(--border-color)] flex items-center justify-center text-[var(--text-primary)] hover:opacity-80 active:scale-95 transition-all shadow-md cursor-pointer"
                            title="Cari"
                        >
                            <Search className="w-4 h-4" />
                        </button>
                        <button
                            onClick={() => navigateToTab ? navigateToTab('dev') : setActiveTab('dev')}
                            aria-label="Profil Pengembang"
                            className="w-8 h-8 rounded-xl bg-[var(--card-bg)] border border-[var(--border-color)] flex items-center justify-center text-[var(--text-primary)] hover:opacity-80 active:scale-95 transition-all shadow-md cursor-pointer"
                            title="Profil"
                        >
                            <User className="w-4 h-4" />
                        </button>
                    </div>
                </div>

                {/* Category Slider Chips */}
                <div id="home-category-bar" className="flex gap-2 overflow-x-auto hide-scrollbar -mx-4 px-4 py-1 scroll-smooth">
                    {categories.map((c) => {
                        const Icon = c.icon;
                        const isAct = activeCategory === c.name || (!activeCategory && c.name === 'Semua');
                        return (
                            <button
                                key={c.name}
                                onClick={() => handleSelectCategory(c.name)}
                                className={`home-chip-btn px-4 py-2 rounded-full text-xs whitespace-nowrap transition-all duration-300 ease-out flex items-center gap-1.5 cursor-pointer shrink-0 ${
                                    isAct
                                        ? 'bg-[var(--chip-active-bg)] text-[var(--chip-active-text)] font-extrabold shadow-lg border border-[var(--chip-active-bg)] scale-105'
                                        : 'bg-[var(--chip-bg)] backdrop-blur-md text-[var(--chip-text)] hover:opacity-90 border border-[var(--chip-border)] font-medium shadow-sm'
                                }`}
                            >
                                {Icon && <Icon className="w-3.5 h-3.5" />}
                                <span>{c.name}</span>
                            </button>
                        );
                    })}
                </div>
            </div>

            {/* Main Content Area */}
            <div className="px-4 mt-4" id="home-main-content">
                {activeCategory === 'Semua' ? (
                    <div className="space-y-7">
                        {/* 1. Quick Picks (Pilihan Cepat Indonesia) */}
                        <div>
                            <div className="flex items-center justify-between mb-3">
                                <h2 className="text-lg font-bold text-[var(--text-primary)] tracking-wide flex items-center gap-2">
                                    <Zap className="w-5 h-5 text-white fill-white/20" />
                                    <span>Pilihan Cepat</span>
                                </h2>
                                <span className="text-xs font-semibold text-[var(--text-secondary)] bg-[var(--card-bg)] px-2.5 py-0.5 rounded-full border border-[var(--border-color)]">
                                    YT Music ID
                                </span>
                            </div>
                            {loadingDefault ? (
                                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                                    {Array(6).fill(0).map((_, i) => (
                                        <div key={i} className="glass-card rounded-xl flex items-center gap-3 p-2 animate-pulse">
                                            <div className="w-14 h-14 rounded-lg bg-[var(--text-primary)]/5"></div>
                                            <div className="flex-grow space-y-2">
                                                <div className="h-3.5 bg-[var(--text-primary)]/10 rounded w-3/4"></div>
                                                <div className="h-2.5 bg-[var(--text-primary)]/5 rounded w-1/2"></div>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            ) : (
                                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                                    {quickPicks.slice(0, 8).map((t, i) => {
                                        const isCur = currentTrack && (
                                            currentTrack.id === t.id ||
                                            currentTrack.videoId === t.id ||
                                            (currentTrack.title === t.title && currentTrack.artist === t.artist)
                                        );
                                        const isPlay = isCur && isPlaying;
                                        const isLoad = isCur && isLoading;

                                        return (
                                            <div
                                                key={i}
                                                onClick={() => {
                                                    if (isCur) togglePlay();
                                                    else playTrack(t, quickPicks, i, 'home');
                                                }}
                                                className={`home-grid-card glass-card rounded-2xl p-2.5 flex items-center gap-3 cursor-pointer active:scale-[0.98] transition-all duration-300 group shadow-lg ${
                                                    isPlay ? 'ring-2 ring-white' : ''
                                                }`}
                                            >
                                                <img
                                                    src={t.cover}
                                                    width="56"
                                                    height="56"
                                                    loading="lazy"
                                                    decoding="async"
                                                    className="w-14 h-14 rounded-xl object-cover shrink-0 shadow-md border border-[var(--border-color)]"
                                                    alt={t.title || 'Lagu'}
                                                    onError={handleImgError}
                                                />
                                                <div className="min-w-0 flex-1">
                                                    <h3 className={`font-semibold text-sm truncate text-[var(--text-primary)] ${isCur ? 'font-bold text-white' : ''}`}>
                                                        {t.title}
                                                    </h3>
                                                    <p className="text-xs text-[var(--text-secondary)] truncate mt-0.5">{t.artist}</p>
                                                </div>
                                                <div className="shrink-0">
                                                    {isLoad ? (
                                                        <div className="w-7 h-7 rounded-full flex items-center justify-center shrink-0">
                                                            <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                                                        </div>
                                                    ) : isPlay ? (
                                                        <div className="w-7 h-7 rounded-full bg-white text-black flex items-center justify-center shrink-0 shadow-md scale-105">
                                                            <div className="flex items-end justify-center gap-[2px] w-3.5 h-3.5 pb-0.5">
                                                                <span className="w-[2px] bg-black rounded-full animate-eq-1"></span>
                                                                <span className="w-[2px] bg-black rounded-full animate-eq-2"></span>
                                                                <span className="w-[2px] bg-black rounded-full animate-eq-3"></span>
                                                            </div>
                                                        </div>
                                                    ) : isCur ? (
                                                        <div className="w-7 h-7 rounded-full bg-[var(--text-primary)] text-[var(--bg-color)] flex items-center justify-center shrink-0">
                                                            <Pause className="w-3.5 h-3.5 fill-current" />
                                                        </div>
                                                    ) : null}
                                                </div>
                                            </div>
                                        );
                                    })}
                                </div>
                            )}
                        </div>

                        {/* 2. Trending di Indonesia */}
                        {trending.length > 0 && (
                            <div className="cv-auto">
                                <div className="flex items-center justify-between mb-3">
                                    <h2 className="text-lg font-bold text-[var(--text-primary)] tracking-wide flex items-center gap-2">
                                        <TrendingUp className="w-5 h-5 text-white" />
                                        <span>Trending di Indonesia</span>
                                    </h2>
                                    <span className="text-xs font-semibold text-[var(--text-secondary)] bg-[var(--card-bg)] px-2.5 py-0.5 rounded-full border border-[var(--border-color)]">
                                        Populer Sekarang
                                    </span>
                                </div>
                                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5">
                                    {trending.slice(0, 6).map((t, i) => {
                                        const isCur = currentTrack && (currentTrack.id === t.id || currentTrack.videoId === t.id);
                                        const isPlay = isCur && isPlaying;
                                        return (
                                            <div
                                                key={i}
                                                onClick={() => playTrack(t, trending, i, 'home-trending')}
                                                className={`glass-card rounded-2xl p-2.5 flex items-center gap-3 cursor-pointer active:scale-[0.98] transition-all group ${
                                                    isPlay ? 'ring-2 ring-white' : ''
                                                }`}
                                            >
                                                <div className="w-6 text-center text-xs font-black text-[var(--text-secondary)] shrink-0">
                                                    #{i + 1}
                                                </div>
                                                <img
                                                    src={t.cover}
                                                    width="48"
                                                    height="48"
                                                    loading="lazy"
                                                    decoding="async"
                                                    className="w-12 h-12 rounded-xl object-cover shrink-0 shadow-md border border-[var(--border-color)]"
                                                    alt={t.title || 'Trending'}
                                                    onError={handleImgError}
                                                />
                                                <div className="min-w-0 flex-1">
                                                    <h3 className={`font-semibold text-xs sm:text-sm truncate text-[var(--text-primary)] ${isCur ? 'font-bold text-white' : ''}`}>
                                                        {t.title}
                                                    </h3>
                                                    <p className="text-xs text-[var(--text-secondary)] truncate mt-0.5">{t.artist}</p>
                                                </div>
                                                <div className="shrink-0 p-1">
                                                    <Play className="w-4 h-4 text-[var(--text-muted)] group-hover:text-white transition-colors" />
                                                </div>
                                            </div>
                                        );
                                    })}
                                </div>
                            </div>
                        )}

                        {/* 3. Hits & Playlist Indonesia */}
                        {playlists.length > 0 && (
                            <div className="cv-auto">
                                <h2 className="text-lg font-bold text-[var(--text-primary)] mb-3 tracking-wide flex items-center gap-2">
                                    <Disc className="w-5 h-5 text-white" />
                                    <span>Hits & Playlist Indonesia</span>
                                </h2>
                                <div className="flex gap-4 overflow-x-auto hide-scrollbar pb-3">
                                    {playlists.slice(0, 10).map((p, i) => (
                                        <div
                                            key={i}
                                            onClick={() => setActiveAlbum({ id: p.id, cover: p.cover || FI })}
                                            className="flex-shrink-0 w-36 md:w-44 cursor-pointer active:scale-95 transition-all group"
                                        >
                                            <div className="p-2.5 rounded-2xl glass-card flex flex-col">
                                                <div className="w-full aspect-square rounded-xl overflow-hidden relative shadow-md mb-2">
                                                    <img
                                                        src={toThumbCover(p.cover || FI)}
                                                        width="160"
                                                        height="160"
                                                        loading="lazy"
                                                        decoding="async"
                                                        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                                                        alt={p.title || 'Playlist'}
                                                        onError={handleImgError}
                                                    />
                                                    <div className="absolute bottom-2 right-2 bg-black/60 dark:bg-white/20 backdrop-blur-md rounded-full p-2 opacity-0 group-hover:opacity-100 transition-all">
                                                        <Play className="w-4 h-4 text-white fill-current ml-0.5" />
                                                    </div>
                                                </div>
                                                <h3 className="font-semibold text-xs sm:text-sm text-[var(--text-primary)] truncate px-0.5">{p.title}</h3>
                                                <p className="text-xs text-[var(--text-secondary)] truncate mt-0.5 px-0.5">{p.artist}</p>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        )}

                        {/* 4. Album & Single Terbaru */}
                        {albums.length > 0 && (
                            <div className="cv-auto">
                                <h2 className="text-lg font-bold text-[var(--text-primary)] mb-3 tracking-wide flex items-center gap-2">
                                    <Sparkles className="w-5 h-5 text-white" />
                                    <span>Album & Single Terbaru</span>
                                </h2>
                                <div className="flex gap-4 overflow-x-auto hide-scrollbar pb-3">
                                    {albums.slice(0, 10).map((al, i) => (
                                        <div
                                            key={i}
                                            onClick={() => setActiveAlbum({ id: al.id, cover: al.cover || FI })}
                                            className="flex-shrink-0 w-36 md:w-44 cursor-pointer active:scale-95 transition-all group"
                                        >
                                            <div className="p-2.5 rounded-2xl glass-card flex flex-col">
                                                <div className="w-full aspect-square rounded-xl overflow-hidden relative shadow-md mb-2">
                                                    <img
                                                        src={toThumbCover(al.cover || FI)}
                                                        width="160"
                                                        height="160"
                                                        loading="lazy"
                                                        decoding="async"
                                                        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                                                        alt={al.title || 'Album'}
                                                        onError={handleImgError}
                                                    />
                                                    <div className="absolute bottom-2 right-2 bg-black/60 dark:bg-white/20 backdrop-blur-md rounded-full p-2 opacity-0 group-hover:opacity-100 transition-all">
                                                        <Play className="w-4 h-4 text-white fill-current ml-0.5" />
                                                    </div>
                                                </div>
                                                <h3 className="font-semibold text-xs sm:text-sm text-[var(--text-primary)] truncate px-0.5">{al.title}</h3>
                                                <p className="text-xs text-[var(--text-secondary)] truncate mt-0.5 px-0.5">{al.artist}</p>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        )}

                        {/* 5. Top Artists Indonesia */}
                        {artists.length > 0 && (
                            <div className="cv-auto">
                                <h2 className="text-lg font-bold text-[var(--text-primary)] mb-3 tracking-wide flex items-center gap-2">
                                    <Users className="w-5 h-5 text-cyan-400" />
                                    <span>Artis Teratas Indonesia</span>
                                </h2>
                                <div className="flex gap-4 overflow-x-auto hide-scrollbar pb-4">
                                    {artists.slice(0, 15).map((a, i) => (
                                        <div
                                            key={i}
                                            onClick={() => setActiveArtist({ id: a.id, name: a.name || a.title, cover: a.cover })}
                                            className="flex-shrink-0 w-28 sm:w-32 cursor-pointer active:scale-95 transition-all group"
                                        >
                                            <div className="p-2.5 rounded-2xl glass-card flex flex-col items-center text-center">
                                                <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-full overflow-hidden relative shadow-md mb-2 border-2 border-[var(--border-color)] group-hover:scale-105 transition-transform duration-300">
                                                    <img
                                                        src={toThumbCover(a.cover || FI)}
                                                        width="96"
                                                        height="96"
                                                        loading="lazy"
                                                        decoding="async"
                                                        className="w-full h-full object-cover"
                                                        alt={a.name || a.title || 'Artis'}
                                                        onError={handleImgError}
                                                    />
                                                </div>
                                                <h3 className="font-semibold text-xs text-[var(--text-primary)] truncate w-full px-0.5">
                                                    {a.name || a.title}
                                                </h3>
                                                <p className="text-[var(--text-muted)] text-xs mt-0.5 uppercase tracking-wider font-semibold">
                                                    {a.artist || 'Artis'}
                                                </p>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        )}
                    </div>
                ) : activeCategory === 'Developer Profile' ? (
                    /* Developer Profile Custom View */
                    <div className="space-y-6 pb-6">
                        <div className="glass-strong rounded-3xl p-5 border border-[var(--border-color)] bg-gradient-to-br from-white/10 via-white/5 to-transparent relative overflow-hidden">
                            <div className="flex flex-col sm:flex-row items-center sm:items-start gap-4 text-center sm:text-left relative z-10">
                                <div className="relative w-20 h-20 rounded-2xl overflow-hidden border-2 border-[var(--border-color)] shrink-0 glass">
                                    <img src={devProfile?.developer?.avatar || '/logo.webp'} className="w-full h-full object-cover app-brand-logo" alt="" onError={handleImgError} />
                                </div>
                                <div className="flex-1">
                                    <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[var(--card-bg)] border border-[var(--border-color)] text-[var(--text-primary)] text-xs font-bold uppercase tracking-wider mb-2">
                                        <Code className="w-3 h-3 text-white" /> Developer Profile
                                    </div>
                                    <h2 className="text-2xl font-black text-[var(--text-primary)]">{devProfile?.developer?.name || 'Nanzz'}</h2>
                                    <p className="text-xs text-[var(--text-secondary)] mt-1 leading-relaxed">
                                        {devProfile?.developer?.bio || 'Pengembang & Pembuat NanzMusify. Selamat menikmati streaming musik favorit tanpa gangguan!'}
                                    </p>
                                    <div className="flex flex-wrap items-center gap-2 mt-3.5 justify-center sm:justify-start">
                                        {devProfile?.developer?.channelUrl && (
                                            <a
                                                href={devProfile.developer.channelUrl}
                                                target="_blank"
                                                rel="noreferrer"
                                                className="btn-chrome px-3.5 py-1.5 rounded-full text-xs font-bold flex items-center gap-1.5 shadow-md active:scale-95 transition-all text-[var(--text-primary)]"
                                            >
                                                <MessageSquare className="w-3.5 h-3.5 text-white" /> {devProfile.developer.channelLabel || 'Channel WA'}
                                            </a>
                                        )}
                                        <button
                                            onClick={() => navigateToTab ? navigateToTab('dev') : setActiveTab('dev')}
                                            className="glass hover:opacity-90 px-3.5 py-1.5 rounded-full text-xs font-medium text-[var(--text-primary)] flex items-center gap-1.5 active:scale-95 transition-all cursor-pointer"
                                        >
                                            <Info className="w-3.5 h-3.5" /> Detail Info
                                        </button>
                                        <button
                                            onClick={() => handleSelectCategory('Semua')}
                                            className="glass hover:opacity-90 px-3 py-1.5 rounded-full text-xs text-[var(--text-muted)] hover:text-[var(--text-primary)] flex items-center gap-1 cursor-pointer"
                                        >
                                            <X className="w-3.5 h-3.5" /> Reset
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* Songs */}
                        <div>
                            <div className="mb-3">
                                <h2 className="text-base font-bold flex items-center gap-2 text-[var(--text-primary)]">
                                    <Heart className="w-4 h-4 text-white fill-current" />
                                    <span>Lagu Yang Disukai</span>
                                </h2>
                                <p className="text-xs text-[var(--text-secondary)] ml-6 mt-0.5">({devProfile?.favorites?.likedSongsLabel || 'Semua lagu favorit'})</p>
                            </div>
                            <div className="grid grid-rows-4 grid-flow-col auto-cols-[calc(50vw-24px)] sm:auto-cols-[300px] gap-2.5 overflow-x-auto hide-scrollbar pb-3 snap-x">
                                {categorySongs.map((t, i) => (
                                    <div
                                        key={i}
                                        onClick={() => playTrack(t, categorySongs, i, 'cat')}
                                        className="snap-start rounded-2xl flex items-center gap-3 p-2.5 cursor-pointer active:scale-95 transition-all w-full shadow-lg glass-card"
                                    >
                                        <img src={t.cover} width="48" height="48" loading="lazy" decoding="async" className="w-12 h-12 rounded-xl object-cover shrink-0" alt={t.title || 'Lagu'} onError={handleImgError} />
                                        <div className="truncate flex-1 min-w-0">
                                            <h3 className="font-semibold text-xs sm:text-sm truncate text-[var(--text-primary)]">{t.title}</h3>
                                            <p className="text-[var(--text-secondary)] text-xs truncate mt-0.5">{t.artist}</p>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                ) : (
                    /* General Category View */
                    <div className="space-y-6 pb-6">
                        <div className="flex justify-between items-center bg-[var(--card-bg)] p-3.5 rounded-2xl border border-[var(--border-color)]">
                            <div className="flex items-center gap-2">
                                <span className="text-xs text-[var(--text-muted)]">Kategori:</span>
                                <span className="font-bold text-sm text-[var(--text-primary)] bg-[var(--card-hover)] px-3 py-1 rounded-full border border-[var(--border-color)]">
                                    {activeCategory}
                                </span>
                            </div>
                            <button
                                onClick={() => handleSelectCategory('Semua')}
                                className="text-xs px-3.5 py-1.5 rounded-full btn-chrome text-[var(--text-primary)] transition-all flex items-center gap-1 active:scale-95 cursor-pointer"
                            >
                                <X className="w-3.5 h-3.5" /> Reset / Semua
                            </button>
                        </div>

                        {loadingCat ? (
                            <div className="text-center py-12">
                                <div className="w-10 h-10 border-3 border-white border-t-transparent rounded-full animate-spin mx-auto mb-3"></div>
                                <p className="text-xs text-[var(--text-secondary)]">Memuat musik {activeCategory}...</p>
                            </div>
                        ) : (
                            <>
                                {/* Songs */}
                                <div>
                                    <h2 className="text-base font-bold mb-3 flex items-center gap-2 text-[var(--text-primary)]">
                                        <Music className="w-4 h-4 text-white" />
                                        <span>Lagu Populer - {activeCategory}</span>
                                    </h2>
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                                        {categorySongs.map((t, i) => (
                                            <div
                                                key={i}
                                                onClick={() => playTrack(t, categorySongs, i, 'cat')}
                                                className="rounded-2xl flex items-center gap-3 p-2.5 cursor-pointer active:scale-95 transition-all w-full shadow-lg glass-card"
                                            >
                                                <img src={t.cover} width="48" height="48" loading="lazy" decoding="async" className="w-12 h-12 rounded-xl object-cover shrink-0" alt={t.title || 'Lagu'} onError={handleImgError} />
                                                <div className="truncate flex-1 min-w-0">
                                                    <h3 className="font-semibold text-sm truncate text-[var(--text-primary)]">{t.title}</h3>
                                                    <p className="text-[var(--text-secondary)] text-xs truncate mt-0.5">{t.artist}</p>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </div>

                                {/* Playlists */}
                                {categoryPlaylists.length > 0 && (
                                    <div>
                                        <h2 className="text-base font-bold mb-3 flex items-center gap-2 text-[var(--text-primary)]">
                                            <Disc className="w-4 h-4 text-white" />
                                            <span>Playlist & Album {activeCategory}</span>
                                        </h2>
                                        <div className="flex gap-3 overflow-x-auto hide-scrollbar pb-3">
                                            {categoryPlaylists.slice(0, 10).map((p, i) => (
                                                <div
                                                    key={i}
                                                    onClick={() => setActiveAlbum({ id: p.id, cover: p.cover || FI })}
                                                    className="flex-shrink-0 w-36 cursor-pointer active:scale-95 group p-2.5 rounded-2xl glass-card transition-all flex flex-col"
                                                >
                                                    <div className="w-full aspect-square mb-2 relative rounded-xl overflow-hidden shadow-md">
                                                        <img src={toThumbCover(p.cover || FI)} width="144" height="144" loading="lazy" decoding="async" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" alt={p.title || 'Playlist'} onError={handleImgError} />
                                                    </div>
                                                    <h3 className="font-semibold text-xs truncate text-[var(--text-primary)] px-0.5">{p.title}</h3>
                                                    <p className="text-[var(--text-secondary)] text-xs truncate mt-0.5 px-0.5">{p.artist}</p>
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                )}
                            </>
                        )}
                    </div>
                )}
            </div>
        </div>
    );
}
