import React from 'react';
import { Smartphone, Code, Heart, Disc, Download, MessageCircle, Music, Play, Sun, Moon, Palette } from 'lucide-react';
import { usePlayer } from '../context/PlayerContext';
import { handleImgError } from '../utils/helpers';
import BannerVideo from '../components/BannerVideo';

export default function ProfileView() {
    const { showToast, devProfile, playTrack, theme, toggleTheme } = usePlayer();

    const handleClearCache = () => {
        if ('caches' in window) {
            caches.keys().then((names) => {
                names.forEach((name) => caches.delete(name));
            });
        }
        localStorage.removeItem('pwa_lyrics_cache');
        localStorage.removeItem('pwa_audio_cache');
        showToast('Cache offline PWA berhasil dibersihkan');
    };

    const dev = devProfile?.developer || {};
    const fav = devProfile?.favorites || {};

    return (
        <div id="view-dev" className="animate-fade-in pb-16">
            {/* Sticky Header */}
            <div className="pt-3.5 pb-2 px-4 sticky top-0 z-30 border-b border-[var(--header-border)] shadow-2xl transition-all relative overflow-hidden backdrop-blur-md bg-[var(--header-bg)]">
                <BannerVideo />
                <div className="flex justify-between items-center relative z-10">
                    <h1 className="text-2xl font-black text-[var(--text-primary)] tracking-tight drop-shadow-md">Profil</h1>
                    <button
                        onClick={toggleTheme}
                        className="w-8 h-8 rounded-xl bg-black/25 dark:bg-black/40 border border-[var(--border-color)] flex items-center justify-center text-[var(--text-primary)] hover:opacity-80 active:scale-95 transition-all shadow-md cursor-pointer"
                        title={theme === 'dark' ? 'Ganti ke Tema Terang' : 'Ganti ke Tema Gelap'}
                    >
                        {theme === 'dark' ? <Sun className="w-4 h-4 text-white" /> : <Moon className="w-4 h-4 text-black" />}
                    </button>
                </div>
            </div>

            <div className="pt-6 px-4 text-center">
                {/* Logo and title */}
                <div className="relative w-24 h-24 rounded-full mx-auto mb-5 glass-strong shine-sweep flex items-center justify-center overflow-hidden shadow-xl border-2 border-[var(--border-color)]">
                    <Music className="w-12 h-12 text-[var(--text-muted)] absolute" />
                    <img src={dev.avatar || '/logo.webp'} className="absolute inset-0 w-full h-full object-cover app-brand-logo transition-all duration-300" alt="" onError={handleImgError} />
                </div>
                <h1 className="text-3xl font-black text-[var(--text-primary)] tracking-tight mb-1">NanzMusify</h1>
                <p className="text-[var(--text-secondary)] text-sm mb-6">{dev.tagline || 'Streaming Musik YouTube dengan Lirik'}</p>

                {/* Card 0: Tema Tampilan (Dark vs Light) */}
                <div className="glass-card rounded-2xl p-5 max-w-sm mx-auto space-y-3.5 text-left mb-6 shadow-xl">
                    <div className="flex items-center justify-between border-b border-[var(--border-color)] pb-3">
                        <h3 className="text-[var(--text-primary)] font-bold text-sm uppercase tracking-wider flex items-center gap-2">
                            <Palette className="w-4 h-4 text-white" />
                            <span>Tema Tampilan</span>
                        </h3>
                        <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-[var(--card-hover)] border border-[var(--border-color)] text-[var(--text-primary)]">
                            {theme === 'dark' ? 'Gelap (Default)' : 'Terang'}
                        </span>
                    </div>

                    <div className="flex items-center justify-between gap-3 pt-1">
                        <button
                            onClick={() => theme !== 'dark' && toggleTheme()}
                            className={`flex-1 py-2.5 px-3 rounded-xl border flex items-center justify-center gap-2 text-xs font-bold transition-all cursor-pointer ${
                                theme === 'dark'
                                    ? 'bg-white text-black border-white shadow-md scale-[1.02]'
                                    : 'bg-[var(--card-bg)] text-[var(--text-secondary)] border-[var(--border-color)] hover:text-[var(--text-primary)]'
                            }`}
                        >
                            <Moon className="w-3.5 h-3.5" />
                            <span>Gelap (Default)</span>
                        </button>
                        <button
                            onClick={() => theme !== 'light' && toggleTheme()}
                            className={`flex-1 py-2.5 px-3 rounded-xl border flex items-center justify-center gap-2 text-xs font-bold transition-all cursor-pointer ${
                                theme === 'light'
                                    ? 'bg-white text-black border-white shadow-md scale-[1.02]'
                                    : 'bg-[var(--card-bg)] text-[var(--text-secondary)] border-[var(--border-color)] hover:text-[var(--text-primary)]'
                            }`}
                        >
                            <Sun className="w-3.5 h-3.5" />
                            <span>Terang</span>
                        </button>
                    </div>

                    <div className="text-[11px] text-[var(--text-muted)] bg-[var(--card-hover)] p-2.5 rounded-xl border border-[var(--border-color)] leading-relaxed">
                        {theme === 'dark' ? (
                            <span>Efek aktif: Banner pembalikan warna diaktifkan, logo tetap normal.</span>
                        ) : (
                            <span>Efek aktif: Banner tetap normal, logo diberi efek pembalikan warna.</span>
                        )}
                    </div>
                </div>

                {/* Card 1: App & PWA Info */}
                <div className="glass-card rounded-2xl p-5 max-w-sm mx-auto space-y-3 text-left mb-6 shadow-xl">
                    <h3 className="text-[var(--text-primary)] font-bold text-sm uppercase tracking-wider mb-2 flex items-center gap-2">
                        <Smartphone className="w-4 h-4 text-white" />
                        <span>Aplikasi & PWA</span>
                    </h3>
                    <div className="flex justify-between">
                        <span className="text-[var(--text-secondary)] text-sm">Nama</span>
                        <span className="text-[var(--text-primary)] font-medium text-sm">NanzMusify</span>
                    </div>
                    <div className="flex justify-between">
                        <span className="text-[var(--text-secondary)] text-sm">Versi</span>
                        <span className="text-[var(--text-primary)] font-medium text-sm">{dev.appVersion || 'v2.0.0 (React Vite)'}</span>
                    </div>
                    <div className="flex justify-between">
                        <span className="text-[var(--text-secondary)] text-sm">Mode Offline PWA</span>
                        <span className="text-[var(--text-primary)] font-bold text-sm flex items-center gap-1.5">
                            <span className="w-2 h-2 rounded-full bg-white animate-pulse"></span>
                            Aktif
                        </span>
                    </div>
                    <div className="flex justify-between">
                        <span className="text-[var(--text-secondary)] text-sm">Service Worker</span>
                        <span className="text-[var(--text-primary)] font-medium text-sm">
                            {typeof navigator !== 'undefined' && 'serviceWorker' in navigator ? 'Didukung' : 'Tidak didukung'}
                        </span>
                    </div>
                    <div className="pt-2 border-t border-[var(--border-color)] flex items-center justify-between">
                        <span className="text-[var(--text-secondary)] text-xs">Cache PWA tersimpan</span>
                        <button
                            onClick={handleClearCache}
                            className="text-xs text-zinc-400 hover:text-white font-semibold underline active:scale-95 cursor-pointer"
                        >
                            Bersihkan Cache
                        </button>
                    </div>
                </div>

                {/* Card 2: Developer Profile */}
                <div className="glass-card rounded-2xl p-5 max-w-sm mx-auto space-y-4 text-left mb-6 shadow-xl">
                    <h3 className="text-[var(--text-primary)] font-bold text-sm uppercase tracking-wider mb-2 border-b border-[var(--border-color)] pb-2 flex items-center gap-2">
                        <Code className="w-4 h-4 text-white" />
                        <span>Developer Profile</span>
                    </h3>
                    <div className="flex justify-between items-center">
                        <span className="text-[var(--text-secondary)] text-sm font-medium">Developed by</span>
                        <div className="flex items-center gap-2">
                            <img src={dev.avatar || '/logo.webp'} className="w-6 h-6 rounded-full object-cover border border-[var(--border-color)] app-brand-logo" alt="" onError={handleImgError} />
                            <span className="text-[var(--text-primary)] font-bold text-sm">{dev.name || 'Nanzz'}</span>
                        </div>
                    </div>

                    {dev.bio && (
                        <p className="text-xs text-[var(--text-secondary)] leading-relaxed bg-[var(--card-hover)] p-2.5 rounded-xl border border-[var(--border-color)]">
                            {dev.bio}
                        </p>
                    )}

                    <div className="pt-1">
                        <div className="text-xs font-semibold text-[var(--text-muted)] uppercase tracking-wide mb-1 flex items-center gap-1.5">
                            <Heart className="w-3.5 h-3.5 text-white" />
                            <span>Artis Favorit</span>
                        </div>
                        <div className="text-sm font-bold text-[var(--text-primary)]">
                            {fav.artistName || 'XXXTENTACION'}
                        </div>
                    </div>

                    {/* Developer favorite songs list */}
                    {fav.songs && fav.songs.length > 0 && (
                        <div className="pt-2 border-t border-[var(--border-color)]">
                            <div className="text-xs font-semibold text-[var(--text-muted)] uppercase tracking-wide mb-2 flex items-center gap-1.5">
                                <Disc className="w-3.5 h-3.5 text-white" />
                                <span>Lagu Pilihan Developer</span>
                            </div>
                            <div className="space-y-1.5">
                                {fav.songs.map((song, idx) => (
                                    <button
                                        key={song.id || idx}
                                        onClick={() => playTrack(song, fav.songs, idx, 'dev-fav')}
                                        className="w-full text-left p-2 rounded-xl bg-[var(--card-hover)] hover:opacity-90 border border-[var(--border-color)] flex items-center justify-between text-xs transition-all active:scale-95 cursor-pointer"
                                    >
                                        <div className="truncate flex-1 pr-2">
                                            <span className="font-semibold text-[var(--text-primary)] block truncate">{song.title}</span>
                                            <span className="text-[var(--text-secondary)] text-[10px] block truncate">{song.artist}</span>
                                        </div>
                                        <Play className="w-3.5 h-3.5 text-white shrink-0" />
                                    </button>
                                ))}
                            </div>
                        </div>
                    )}

                    {dev.channelUrl && (
                        <div className="pt-2">
                            <a
                                href={dev.channelUrl}
                                target="_blank"
                                rel="noreferrer"
                                className="btn-chrome w-full py-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-2 active:scale-95 transition-all shadow-md text-[var(--text-primary)]"
                            >
                                <MessageCircle className="w-4 h-4 text-white" />
                                <span>{dev.channelLabel || 'Gabung Channel WhatsApp'}</span>
                            </a>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}
