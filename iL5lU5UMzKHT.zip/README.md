# NanzMusify (React + Vite Edition)

Versi modern **NanzMusify** yang dimigrasikan ke **React 18 + Vite + Tailwind CSS** dengan **100% desain, tata letak, animasi, dan fitur identik** tanpa mengubah tampilan aslinya.

---

## 🚀 Fitur yang Dimigrasikan

1. **Player Audio Native & YouTube Stream**:
   - Streaming cepat melalui `/api/ytplay` dan `/api/proxy-audio`.
   - MediaSession API: Kontrol navigasi musik langsung dari lockscreen & notifikasi Android/desktop.
   - Circular SVG rotating progress ring pada MiniPlayer.
2. **Apple Music Style Moving Artwork & Ambient Glow Drift**:
   - Efek latar belakang dinamis yang mengekstrak warna aksen dari cover lagu (`--glow-c1`, `--glow-c2`, `--glow-c3`) dengan animasi `glowDrift`.
   - Tombol toggle untuk mengaktifkan/menonaktifkan latar bergerak.
3. **Lirik Real-time & Sinkronisasi**:
   - Inline Lyrics di FullPlayer + Fullscreen Lyrics Modal (`#lyrics-overlay`).
   - Penyesuaian Offset Sinkronisasi (`+` / `-`).
   - Teks terjemahan lirik bilingual.
4. **Equalizer Audio (Web Audio API)**:
   - 3-Band BiquadFilter (Bass, Mid, Treble) dan Preset Musik: *Normal, Bass Boost, Treble, Vocal, Electronic, Rock, Pop*.
5. **Navigasi Tab Lengkap**:
   - **Home**: Banner, Kategori Musik (Semua, Developer Profile, Chill, Focus, Gaming, dll.), Quick Picks, Popular Playlists, Top Artists.
   - **Search**: Pencarian instan, autocomplete suggestions, tab filter (*Musik, Playlist, Artis*), rekomendasi rilis baru.
   - **Library**: Buat playlist kustom, edit nama playlist, hapus playlist, daftar artis favorit.
   - **Offline Mode**: Penyimpanan lagu offline PWA di memori lokal.
   - **Liked Songs**: Daftar lagu disukai dengan shuffle & play all.
   - **Profile**: Informasi aplikasi & developer Nanzz, tautan WhatsApp Channel.
6. **Utilitas Tambahan**:
   - Sleep Timer (15, 30, 45, 60 menit).
   - Pengatur kecepatan putar audio (0.75x, 1x, 1.25x, 1.5x, 2x).
   - Antrean lagu (Queue).
   - Bagikan lagu / album / artis dengan direct link parsing.

---

## 🛠️ Cara Menjalankan

### 1. Mode Development (Vite HMR)
Jalankan backend server API (port 3000):
```bash
node server.cjs
```
Di terminal lain, jalankan Vite dev server (port 5173):
```bash
npm run dev
```
Buka browser di `http://localhost:5173`. Semua request `/api/*` otomatis diproxy ke port 3000.

### 2. Mode Produksi (Full-Stack)
Build frontend:
```bash
npm run build
```
Jalankan server Node.js:
```bash
npm start
```
Buka browser di `http://localhost:3000`. Server Express akan otomatis menyajikan file statis dari folder `dist/` dan menangani seluruh rute API.

---

## ☁️ Deploy ke Netlify

1. Push folder ini ke GitHub/GitLab, lalu di Netlify pilih **Add new site → Import an existing project**.
2. Setelan build sudah otomatis dari `netlify.toml` (build: `npm run build`, publish: `dist`, functions: `netlify/functions`, Node 20).
3. Klik **Deploy**. Atau via CLI:
   ```bash
   npm i -g netlify-cli
   netlify deploy --build --prod
   ```
4. URL canonical, `og:url`, `robots.txt`, dan `sitemap.xml` otomatis memakai domain Netlify saat build (env `URL`). Untuk domain kustom, set env `SITE_URL` di Netlify.

Catatan: `/api/proxy-audio` & `/api/proxy-image` ditangani function tersendiri, sedangkan endpoint `/api/*` lain dijalankan lewat `netlify/functions/api.cjs` (membungkus `server.cjs`). Batas waktu function Netlify default 10–30 detik, jadi lagu yang sangat panjang bisa terputus saat streaming via proxy.
