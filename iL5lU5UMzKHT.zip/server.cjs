const express = require('express');
const path = require('path');
const https = require('https');
const http = require('http');
const fs = require('fs');
const compression = require('compression');

const app = express();

// High performance Gzip compression for all text, json, html, js, css
app.use(compression({
    level: 6,
    threshold: 1024,
    filter: (req, res) => {
        if (req.headers['x-no-compression']) return false;
        // Do not compress audio streaming proxy chunks or video assets
        if (req.path.startsWith('/api/proxy-audio')) return false;
        if (/\.(mp4|mov|webm)$/i.test(req.path)) return false;
        return compression.filter(req, res);
    }
}));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Security & best practices headers for Google PageSpeed / WebPageTest
app.use((req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'SAMEORIGIN');
    res.setHeader('Referrer-Policy', 'no-referrer');
    next();
});

// Function to validate and return allowed origin matching current domain/host
function getAllowedOrigin(req) {
    const origin = req.headers.origin || req.headers.referer;
    const host = req.headers['x-forwarded-host'] || req.headers.host;
    if (origin) {
        try {
            const originUrl = new URL(origin);
            if (host && originUrl.host === host) {
                return originUrl.origin;
            }
            if (originUrl.port === '5173') {
                return originUrl.origin;
            }
            return originUrl.origin;
        } catch (e) {
            return null;
        }
    }
    if (host) {
        const proto = req.headers['x-forwarded-proto'] || req.protocol || 'https';
        return `${proto}://${host}`;
    }
    return '*';
}

// CORS middleware
app.use((req, res, next) => {
    const allowedOrigin = getAllowedOrigin(req) || '*';
    res.setHeader('Access-Control-Allow-Origin', allowedOrigin);
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS, PATCH, HEAD');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Requested-With');
    res.setHeader('Access-Control-Expose-Headers', '*');
    res.setHeader('Vary', 'Origin');

    if (req.method === 'OPTIONS') {
        return res.sendStatus(200);
    }
    next();
});

// API Routes
app.all('/api/home', require('./api/home.js'));
app.all('/api/search', require('./api/search.js'));
app.all('/api/lyrics', require('./api/lyrics.js'));
app.all('/api/lyrics1', require('./api/lyrics1.js'));
app.all('/api/lyrics2', require('./api/lyrics2.js'));
app.all('/api/artist', require('./api/artist.js'));
app.all('/api/album', require('./api/album.js'));
app.all('/api/suggest', require('./api/suggest.js'));
app.all('/api/ytplay', require('./api/ytplay.js'));
app.all('/api/translate', require('./api/translate.js'));
app.all('/api/transcribe', require('./api/transcribe.js'));
app.all('/api/chat', require('./api/chat.js'));
app.all('/api/chat-proxy', require('./api/chat.js'));

// robots.txt & sitemap.xml for SEO & PageSpeed 100%
app.get('/robots.txt', (req, res) => {
    res.setHeader('Content-Type', 'text/plain; charset=UTF-8');
    res.setHeader('Cache-Control', 'public, max-age=86400');
    res.send("User-agent: *\nAllow: /\n\nSitemap: https://hundred-whole-taxi-big.trycloudflare.com/sitemap.xml\n");
});

app.get('/sitemap.xml', (req, res) => {
    res.setHeader('Content-Type', 'application/xml; charset=UTF-8');
    res.setHeader('Cache-Control', 'public, max-age=86400');
    res.send('<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"><url><loc>https://hundred-whole-taxi-big.trycloudflare.com/</loc><changefreq>daily</changefreq><priority>1.0</priority></url></urlset>');
});

// Profile configuration endpoint
app.get('/profile.json', (req, res) => {
    const pubFile = path.join(__dirname, 'public', 'profile.json');
    const distFile = path.join(__dirname, 'dist', 'profile.json');
    const target = fs.existsSync(pubFile) ? pubFile : distFile;
    res.setHeader('Content-Type', 'application/json');
    res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
    if (fs.existsSync(target)) {
        res.sendFile(target);
    } else {
        res.status(404).json({ error: 'profile.json not found' });
    }
});

// Proxy audio streaming with Range support
function streamAudioProxy(currentUrl, req, res, redirectCount = 0) {
    if (redirectCount > 5) {
        return res.status(502).send('Too many redirects from audio upstream');
    }
    let parsed;
    try {
        parsed = new URL(currentUrl);
    } catch (e) {
        return res.status(400).send('Invalid url parameter');
    }

    const options = {
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/149.0.0.0 Safari/537.36'
        }
    };
    if (req.headers.range) {
        options.headers['Range'] = req.headers.range;
    }
    if (parsed.hostname.includes('vidssave.com') || parsed.hostname.includes('aliyuncs.com')) {
        options.headers['Referer'] = 'https://vidssave.com/';
        options.headers['Origin'] = 'https://vidssave.com';
    }

    const client = parsed.protocol === 'https:' ? https : http;
    const proxyReq = client.get(parsed, options, (proxyRes) => {
        if (proxyRes.statusCode >= 300 && proxyRes.statusCode < 400 && proxyRes.headers.location) {
            proxyRes.resume();
            const nextUrl = new URL(proxyRes.headers.location, currentUrl).href;
            return streamAudioProxy(nextUrl, req, res, redirectCount + 1);
        }

        res.status(proxyRes.statusCode);
        const allowedOrigin = getAllowedOrigin(req) || '*';
        res.setHeader('Access-Control-Allow-Origin', allowedOrigin);
        res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, HEAD');
        res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Range, Authorization, X-Requested-With');
        res.setHeader('Access-Control-Expose-Headers', 'Content-Range, Content-Length, Accept-Ranges, Content-Type');

        const passthrough = ['content-type', 'content-length', 'accept-ranges', 'content-range'];
        passthrough.forEach(h => {
            if (proxyRes.headers[h]) res.setHeader(h, proxyRes.headers[h]);
        });
        if (!res.getHeader('accept-ranges')) res.setHeader('Accept-Ranges', 'bytes');

        proxyRes.pipe(res);

        req.on('close', () => {
            proxyRes.destroy();
        });
    });

    proxyReq.on('error', (err) => {
        if (!res.headersSent) {
            res.status(502).send('Proxy error: ' + err.message);
        }
    });

    req.on('close', () => {
        proxyReq.destroy();
    });
}

app.get('/api/proxy-audio', (req, res) => {
    const targetUrl = req.query.url;
    if (!targetUrl) return res.status(400).send('Missing url parameter');
    streamAudioProxy(targetUrl, req, res);
});

// Proxy image route with caching
app.get('/api/proxy-image', (req, res) => {
    const targetUrl = req.query.url;
    if (!targetUrl) return res.status(400).send('Missing url parameter');
    try {
        const parsed = new URL(targetUrl);
        const client = parsed.protocol === 'https:' ? https : http;
        client.get(targetUrl, (proxyRes) => {
            res.status(proxyRes.statusCode);
            if (proxyRes.headers['content-type']) res.setHeader('Content-Type', proxyRes.headers['content-type']);
            res.setHeader('Cache-Control', 'public, max-age=604800, immutable');
            proxyRes.pipe(res);
        }).on('error', () => {
            res.status(500).end();
        });
    } catch(e) {
        res.status(400).end();
    }
});

// Serve dist directory with caching rules for PageSpeed
const distDir = path.join(__dirname, 'dist');
const publicDir = path.join(__dirname, 'public');
const staticDir = fs.existsSync(distDir) ? distDir : publicDir;

app.use(express.static(staticDir, {
    maxAge: '1y',
    immutable: true,
    setHeaders: (res, pathUrl) => {
        if (pathUrl.endsWith('.html')) {
            // HTML files should never be cached permanently
            res.setHeader('Cache-Control', 'public, max-age=0, must-revalidate');
        } else if (pathUrl.includes('/assets/')) {
            // Hashed Vite assets are immutable
            res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
        } else if (/\.(mp4|mov|webm)$/i.test(pathUrl)) {
            // Video assets
            res.setHeader('Cache-Control', 'public, max-age=604800');
            res.setHeader('Accept-Ranges', 'bytes');
        } else {
            // Icons, images, manifest
            res.setHeader('Cache-Control', 'public, max-age=86400');
        }
    }
}));

app.use(express.static(publicDir, {
    setHeaders: (res, pathUrl) => {
        if (/\.(mp4|mov|webm)$/i.test(pathUrl)) {
            res.setHeader('Cache-Control', 'public, max-age=604800');
            res.setHeader('Accept-Ranges', 'bytes');
        }
    }
}));

app.use((req, res) => {
    const indexPath = fs.existsSync(path.join(distDir, 'index.html'))
        ? path.join(distDir, 'index.html')
        : path.join(__dirname, 'index.html');
    res.setHeader('Cache-Control', 'public, max-age=0, must-revalidate');
    if (fs.existsSync(indexPath)) {
        res.sendFile(indexPath);
    } else {
        res.sendFile(path.join(publicDir, 'index.html'));
    }
});

if (require.main === module) {
    const port = process.env.PORT || 3000;
    app.listen(port, () => {
        console.log(`NanzMusify running on http://localhost:${port}`);
    });
}

module.exports = app;
