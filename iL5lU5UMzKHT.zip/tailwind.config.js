/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        'nm-bg': '#1a1b22',
        'nm-card': '#20222c',
        'nm-dock': '#1c1e26',
      }
    },
  },
  plugins: [],
}
