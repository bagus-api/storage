const https = require('https');
const vm = require('vm');

const UPSTREAM_HOST = 'akungamedb.gamer.free';
const UPSTREAM_PATH = '/meki/api.php';
const AES_PATH = '/aes.js';

let cachedCookie = '';
let aesScriptCache = null;

function requestUpstream(options, body = '') {
    return new Promise((resolve, reject) => {
        const req = https.request({
            hostname: UPSTREAM_HOST,
            port: 443,
            rejectUnauthorized: false,
            ...options
        }, res => {
            let data = '';
            res.on('data', chunk => data += chunk);
            res.on('end', () => resolve({
                statusCode: res.statusCode,
                headers: res.headers,
                body: data
            }));
        });
        req.on('error', reject);
        if (body) {
            req.write(body);
        }
        req.end();
    });
}

async function solveChallenge(challengeHtml) {
    try {
        if (!aesScriptCache) {
            const aesRes = await requestUpstream({
                path: AES_PATH,
                method: 'GET',
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
                }
            });
            aesScriptCache = aesRes.body;
        }

        const match = challengeHtml.match(/<script>(.*?)<\/script>/s);
        if (!match) return false;

        let cookieVal = '';
        const sandbox = {
            document: {
                set cookie(val) {
                    cookieVal = val.split(';')[0].trim();
                }
            },
            location: { href: '' }
        };
        vm.createContext(sandbox);
        vm.runInContext(aesScriptCache, sandbox);
        vm.runInContext(match[1], sandbox);

        if (cookieVal) {
            cachedCookie = cookieVal;
            return true;
        }
        return false;
    } catch (e) {
        console.error('[CHAT_PROXY] Error solving challenge:', e.message);
        return false;
    }
}

async function forwardRequest(method, queryParams, bodyData, token, adminKey) {
    // Build query params
    const q = new URLSearchParams();
    for (const [k, v] of Object.entries(queryParams || {})) {
        if (v !== undefined && v !== null) {
            q.append(k, String(v));
        }
    }

    // Merge token into params if present
    if (token && !q.has('token')) {
        q.append('token', token);
    }
    if (adminKey && !q.has('key')) {
        q.append('key', adminKey);
    }

    const path = UPSTREAM_PATH + (q.toString() ? '?' + q.toString() : '');

    const headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'application/json, text/html, */*'
    };

    if (cachedCookie) {
        headers['Cookie'] = cachedCookie;
    }
    if (token) {
        headers['Authorization'] = `Bearer ${token}`;
    }
    if (adminKey) {
        headers['X-Admin-Key'] = adminKey;
    }

    let postPayload = '';
    if (method === 'POST') {
        const payloadObj = { ...(bodyData || {}) };
        if (token && !payloadObj.token) payloadObj.token = token;
        if (adminKey && !payloadObj.key) payloadObj.key = adminKey;
        postPayload = JSON.stringify(payloadObj);
        headers['Content-Type'] = 'application/json';
        headers['Content-Length'] = Buffer.byteLength(postPayload);
    }

    let res = await requestUpstream({
        path,
        method,
        headers
    }, postPayload);

    // If challenge detected, solve and retry
    if (res.body.includes('slowAES.decrypt') || res.body.includes('/aes.js')) {
        const solved = await solveChallenge(res.body);
        if (solved) {
            headers['Cookie'] = cachedCookie;
            res = await requestUpstream({
                path,
                method,
                headers
            }, postPayload);
        }
    }

    return res;
}

module.exports = async (req, res) => {
    if (req.method === 'OPTIONS') {
        res.status(200).end();
        return;
    }

    try {
        // Extract token from header or query or body
        let token = '';
        const authHeader = req.headers['authorization'] || '';
        if (authHeader.startsWith('Bearer ')) {
            token = authHeader.slice(7).trim();
        } else if (req.query?.token) {
            token = String(req.query.token).trim();
        } else if (req.body?.token) {
            token = String(req.body.token).trim();
        }

        // Extract admin key from header or query or body
        let adminKey = req.headers['x-admin-key'] || req.query?.key || req.body?.key || '';

        const method = req.method === 'POST' ? 'POST' : 'GET';
        const queryParams = req.query || {};
        const bodyData = req.body || {};

        const upstreamRes = await forwardRequest(method, queryParams, bodyData, token, adminKey);

        let parsed;
        try {
            parsed = JSON.parse(upstreamRes.body);
        } catch {
            // If failed to parse as JSON, challenge may have expired; retry once
            const solved = await solveChallenge(upstreamRes.body);
            if (solved) {
                const retryRes = await forwardRequest(method, queryParams, bodyData, token, adminKey);
                parsed = JSON.parse(retryRes.body);
            } else {
                throw new Error('Respon upstream bukan JSON valid');
            }
        }

        const statusCode = upstreamRes.statusCode && upstreamRes.statusCode >= 200 && upstreamRes.statusCode < 600
            ? upstreamRes.statusCode
            : (parsed && parsed.success ? 200 : 400);

        res.status(statusCode).json(parsed);
    } catch (err) {
        console.error('[CHAT_PROXY_ERR]', err.message);
        res.status(500).json({ success: false, error: err.message || 'Gagal memproses request chat' });
    }
};
