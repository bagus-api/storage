# shellcheck disable=SC2034
SKIPUNZIP=1

DEBUG=false
SONAME=nifujiv2
SUPPORTED_ABIS="arm 86 arm64 x64"

if [ "$BOOTMODE" ] && [ "$KSU" ]; then
  ui_print "- Installing from KernelSU app"
  ui_print "- KernelSU version: $KSU_KERNEL_VER_CODE (kernel) + $KSU_VER_CODE (ksud)"
elif [ "$BOOTMODE" ] && [ "$MAGISK_VER_CODE" ]; then
  ui_print "- Installing from Magisk app"
else
  ui_print "*********************************************************"
  ui_print "! Install from recovery is not supported"
  ui_print "! Please install from KernelSU or Magisk app"
  abort    "*********************************************************"
fi

VERSION=$(grep_prop version "${TMPDIR}/module.prop")
ui_print "- Module version: $VERSION"

support=false
for abi in $SUPPORTED_ABIS
do
  if [ "$ARCH" == "$abi" ]; then
    support=true
  fi
done

if [ "$support" == "false" ]; then
  abort "! Unsupported platform: $ARCH"
else
  ui_print "- Device platform: $ARCH"
fi

ui_print "- Extracting verify.sh"
unzip -o "$ZIPFILE" 'verify.sh' -d "$TMPDIR" >&2
if [ ! -f "$TMPDIR/verify.sh" ]; then
  abort "! Unable to extract verify.sh!"
fi

. "$TMPDIR/verify.sh"

mkdir -p "$TMPDIR/.vunzip"
extract "$ZIPFILE" 'customize.sh'  "$TMPDIR/.vunzip"
extract "$ZIPFILE" 'verify.sh'     "$TMPDIR/.vunzip"

ui_print "- Extracting module files"
extract "$ZIPFILE" 'module.prop'     "$MODPATH"
extract "$ZIPFILE" 'post-fs-data.sh' "$MODPATH"
extract "$ZIPFILE" 'service.sh'      "$MODPATH"
extract "$ZIPFILE" 'sepolicy.rule'   "$MODPATH"

mkdir -p "$MODPATH/zygisk"

for abi in $SUPPORTED_ABIS; do
  arch=$abi
  if [ "$abi" = "arm64" ]; then
    arch="arm64-v8a"
  elif [ "$abi" = "arm" ]; then
    arch="armeabi-v7a"
  elif [ "$abi" = "x64" ]; then
    arch="x86_64"
  elif [ "$abi" = "86" ]; then
    arch="x86"
  fi

  ui_print "- Installing library for $arch"
  extract "$ZIPFILE" "lib/$arch/lib$SONAME.so" "$MODPATH/zygisk/"
  mv "$MODPATH/zygisk/lib$SONAME.so" "$MODPATH/zygisk/$arch.so"
done