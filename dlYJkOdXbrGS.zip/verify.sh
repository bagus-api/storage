#!/system/bin/sh

# Function to verify and extract
extract() {
  local zip=$1
  local part=$2
  local target=$3
  local nosha=$4

  local tmp_file="$TMPDIR/.vunzip/$part"
  mkdir -p "$(dirname "$tmp_file")"

  # Extract the main file
  unzip -o "$zip" "$part" -d "$TMPDIR/.vunzip" >&2

  if [ "$nosha" != "true" ]; then
    # EXTRA: Also extract the .sha256 hash file
    unzip -o "$zip" "$part.sha256" -d "$TMPDIR/.vunzip" >&2

    if [ -f "$tmp_file.sha256" ]; then
      local expected=$(cat "$tmp_file.sha256" | awk '{print $1}')
      local actual=$(sha256sum "$tmp_file" | awk '{print $1}')
      
      if [ "$expected" != "$actual" ]; then
        ui_print "! Integrity verification failed: $part"
        abort "! File modified or corrupted."
      fi
    else
      ui_print "! Error: SHA256 hash not found for $part"
      abort "! The module is incomplete or has been tampered with."
    fi
  fi

  # If target is a directory, ensure it exists
  [ -d "$target" ] || mkdir -p "$target"

  cp -af "$tmp_file" "$target"
}

ui_print "- Integrity system active"
