import fetch from 'node-fetch'
import FormData from 'form-data'
import { fileTypeFromBuffer } from 'file-type'

let handler = async (m, { conn }) => {
  let q = m.quoted || m
  let mime = (q.msg || q).mimetype || ''

  if (!mime) return m.reply('❌ Reply media yang mau di-upload!')

  try {
    await m.react('✨')

    let buffer = await q.download()
    let type = await fileTypeFromBuffer(buffer) || { ext: 'bin' }

    let form = new FormData()
    form.append('fileToUpload', buffer, `file.${type.ext}`)
    form.append('reqtype', 'fileupload')

    let res = await fetch('https://catbox.moe/user/api.php', {
      method: 'POST',
      body: form,
      headers: form.getHeaders()
    })

    let url = await res.text()
    if (!url.startsWith('http')) throw 'Upload gagal'

    m.reply(url.trim())
  } catch (e) {
    console.error(e)
    m.reply('❌ Gagal upload media!')
  }
}

handler.help = ['tourl']
handler.tags = ['tools']
handler.command = /^tourl$/i
handler.limit = true

export default handler