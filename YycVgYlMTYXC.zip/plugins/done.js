// plugins/done.js

let handler = async (m, { conn, args }) => {
  let text = args.join(' ')
  
  if (!text) {
    return m.reply('Contoh penggunaan:\n.done Jasa Install Panel\n\nMasukkan keterangan transaksi ya.')
  }

  let doneMessage = `
╭━━〔 ✅ TRANSAKSI SELESAI 〕━━⬣
┃ 📦 Produk : ${text}
┃ 💬 Status : Sukses & Done
┃ 📆 Tanggal : ${new Date().toLocaleDateString('id-ID')}
┃ ⏰ Jam : ${new Date().toLocaleTimeString('id-ID')}
╰━━━━━━━━━━━━━━━━━━⬣

Terima kasih sudah order di RAA4YOUU MD 🙏
Jika ada kendala silakan hubungi owner.
`.trim()

  await conn.sendMessage(m.chat, {
    text: doneMessage
  }, { quoted: m })
}

handler.help = ['done <keterangan>']
handler.tags = ['store']
handler.command = /^done$/i

module.exports = handler