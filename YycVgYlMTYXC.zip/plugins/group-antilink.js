let handler = async (m, { conn, args }) => {
  let o = args[0] || ""

  if (!["--on", "--off"].includes(o))
    return m.reply("😹 ʟᴜ ᴛᴏʟᴏʟ ᴀᴘᴀ ɢɪᴍᴀɴᴀ? ᴘɪʟɪʜ ᴏғ ᴀᴛᴀᴜ ᴏɴ ʟᴏʟᴏɴᴛ:\n\n• --on\n• --off")

  if (!db.data.chats[m.chat]) {
    db.data.chats[m.chat] = { antilink: false }
  }

  switch (o) {
    case "--on":
      db.data.chats[m.chat].antilink = true
      m.reply("✅ sɪᴀᴘ ᴀᴅᴍɪɴ ᴋɪᴋɪʀ, ɴᴛᴀʀ ᴋᴀʟᴏ ᴀᴅᴀ ʏᴀɴɢ sʜᴇʀᴇʟɪɴᴋ ɴᴀɴᴛɪ sᴀxʀᴀ-ᴍᴅ ʙᴀᴋᴀʟ ʜᴀᴘᴜs, ᴀᴛᴍɪɴ ᴛᴇɴᴀɴɢ ᴀᴊᴀ ᴅᴀʜ sᴀɴᴀ sᴀɴᴛᴀɪ ʟᴀɢɪ")
      break

    case "--off":
      db.data.chats[m.chat].antilink = false
      m.reply("❌ ɴᴀʜʜ ɢɪᴛᴜ ᴅᴏɴɢ ɴɢɢᴀ ᴋɪᴋɪʀ, ᴀɴᴛɪʟɪɴᴋ ʙᴇʀʜᴀsɪʟ ᴅɪ ɴᴏɴᴀᴋᴛɪғᴋᴀɴ ʙʏ sᴀxʀᴀ-ᴍᴅ")
      break
  }
}

handler.before = async (m, { conn, isAdmin, isBotAdmin }) => {
  if (!m.isGroup) return
  if (!m.text) return
  if (!isBotAdmin) return

  const chat = db?.data?.chats?.[m.chat]
  if (!chat?.antilink) return
  if (isAdmin) return

  const linkRegex = /(chat\.whatsapp\.com\/|wa\.me\/chat)/i
  if (!linkRegex.test(m.text)) return

  try {
    const groupInvite = await conn.groupInviteCode(m.chat)
    const ownLink = `https://chat.whatsapp.com/${groupInvite}`

    if (m.text.includes(ownLink)) return

    await conn.sendMessage(m.chat, {
      delete: {
        remoteJid: m.chat,
        fromMe: false,
        id: m.key.id,
        participant: m.sender
      }
    })

    await conn.reply(
      m.chat,
      `*–𐚁ᴡᴋᴡᴋᴡᴋ sᴏʀʏ ʏᴀ ʙᴀɴɢ sᴇxʀᴀ ʜᴀᴘᴜs –*\nᴀᴛᴍɪɴʏᴀ ᴋɪᴋɪʀ sɪʜ ɴʏᴀʟᴀɪɴ ᴀɴᴛɪʟɪɴᴋ ᴊᴀᴅɪ ᴛᴇʀᴘᴀᴋsᴀ sᴀxʀᴀ-ᴍᴅ ʜᴀᴘᴜss ᴍᴡʜᴇʜᴇʜᴇ\n*©sᴀxʀᴀ-ᴍᴅ*`,
      m
    )
  } catch (e) {
    console.error("Antilink error:", e)
  }
}

handler.help = ["antilink --on", "antilink --off"]
handler.tags = ["group"]
handler.command = /^antilink$/i
handler.group = true
handler.admin = true
handler.botAdmin = true

export default handler