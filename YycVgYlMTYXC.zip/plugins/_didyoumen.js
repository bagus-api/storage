import didyoumean from 'didyoumean'
import similarity from 'similarity'
import fetch from 'node-fetch'

let handler = m => m
let cachedThumb

async function getThumbnail() {
  if (cachedThumb) return cachedThumb
  try {
    let res = await fetch("https://raw.githubusercontent.com/bagus-api/storage/master/kUgDY.jpeg")
    cachedThumb = Buffer.from(await res.arrayBuffer())
    return cachedThumb
  } catch {
    return null
  }
}

handler.before = async function (m, { match, usedPrefix }) {
  if (!m.text) return

  if ((usedPrefix = (match[0] || '')[0])) {
    let noPrefix = m.text.slice(1).trim()
    if (!noPrefix) return

    let alias = Object.values(global.plugins)
      .filter(v => v.help && !v.disabled)
      .flatMap(v => v.help)

    if (!alias.length) return

    let mean = didyoumean(noPrefix, alias)
    if (!mean) return
    if (noPrefix.toLowerCase() === mean.toLowerCase()) return

    let sim = similarity(noPrefix.toLowerCase(), mean.toLowerCase())
    let percent = Math.round(sim * 100)
    let thumbnail = await getThumbnail()

    let text = `
🕰️ *ᴋᴇᴋ ɴʏᴀ ʟᴜ ᴛʏᴘᴏ ᴅᴇʜ, sᴇʀᴠɪs ᴅᴜʟᴜ ᴋᴇʏʙᴏᴀʀᴅ ʟᴜ, ᴍᴜɴɢᴋɪɴ ʏᴀɴɢ ʟᴜ ᴍᴀᴋsᴜᴅ ɪɴɪ ᴋᴀɴ?...*

ɪɴɪ ʙᴜᴋᴀɴ ᴡᴏɪ ʜᴀᴅᴇʜᴋ:
➤ *${usedPrefix + mean}*
🎯 Akurasi: *${percent}%*
`.trim()

    await this.sendMessage(m.chat, {
      text,
      footer: 'Saxra - MD',
      contextInfo: {
        externalAdReply: {
          title: "Xyraa4Sx",
          mediaType: 1,
          renderLargerThumbnail: false,
          thumbnail
        }
      }
    }, { quoted: m })
  }
}

export default handler