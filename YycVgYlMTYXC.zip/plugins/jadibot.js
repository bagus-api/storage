import makeWASocket, {
  useMultiFileAuthState,
  fetchLatestBaileysVersion,
  DisconnectReason
} from "@whiskeysockets/baileys"

import P from "pino"
import qrcode from "qrcode"
import fs from "fs"
import path from "path"


let bots = {}

let handler = async (m, { conn, text }) => {
  if (!text) return m.reply("Masukkan nomor!\nContoh: .jadibot 628xxxx")

  let nomor = text.replace(/[^0-9]/g, "")
  if (bots[nomor]) return m.reply("Nomor sudah aktif jadi bot!")

  let sessionPath = path.join("./lib/jadibot/session/", nomor)
  if (!fs.existsSync(sessionPath)) {
    fs.mkdirSync(sessionPath, { recursive: true })
  }

  const { state, saveCreds } = await useMultiFileAuthState(sessionPath)
  const { version } = await fetchLatestBaileysVersion()

  const sock = makeWASocket({
    logger: P({ level: "silent" }),
    auth: state,
    version,
    printQRInTerminal: false
  })

  bots[nomor] = sock

  sock.ev.on("creds.update", saveCreds)

  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect, qr } = update

    if (qr) {
      let qrImage = await qrcode.toBuffer(qr)
      await conn.sendMessage(m.chat, {
        image: qrImage,
        caption: `Scan QR untuk nomor ${nomor}`
      }, { quoted: m })
    }

    if (connection === "open") {
      await conn.sendMessage(m.chat, {
        text: `✅ Berhasil jadi bot: ${nomor}`
      }, { quoted: m })
    }

    if (connection === "close") {
      let reason = lastDisconnect?.error?.output?.statusCode
      if (reason !== DisconnectReason.loggedOut) {
        m.reply(`Bot ${nomor} terputus, mencoba reconnect...`)
      } else {
        delete bots[nomor]
        fs.rmSync(sessionPath, { recursive: true, force: true })
        m.reply(`Session ${nomor} logout & dihapus.`)
      }
    }
  })
}

handler.command = ["jadibot"]
handler.command = /^(limit)$/i

export default handler