// plugins/owner.js

import fetch from 'node-fetch'

const ownerNumber = '85567744255@s.whatsapp.net' // ubah 08 -> 62

let handler = async (m, { conn }) => {
  let pp = "https://qu.ax/G2t8z"

  let caption = `
👑 *OWNER BOT ARDIANSAH*

📱 Nomor : +85567744255
🛠 Status : Owner Resmi
🌐 Bot Active 24 Jam

Butuh bantuan? Chat langsung Ardi yaa.
`

  await conn.sendMessage(m.chat, {
    image: { url: pp },
    caption: caption,
    contextInfo: {
      mentionedJid: [ownerNumber],
      externalAdReply: {
        title: "ARDI - MD OWNER",
        body: "Klik untuk menghubungi owner",
        thumbnailUrl: pp,
        sourceUrl: "https://wa.me/85567744255",
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
  }, { quoted: m })
}

handler.help = ['owner']
handler.tags = ['info']
handler.command = /^(owner|creator)$/i

export default handler