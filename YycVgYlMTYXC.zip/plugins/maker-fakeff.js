import fetch from "node-fetch"

let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) {
    return m.reply(
      `🎮 *FAKE LOBBY FREE FIRE*\n\nContoh:\n${usedPrefix + command} ArdiGaming`
    )
  }

  try {
    await m.react("⏳")

    const apiUrl = `https://api.nexray.web.id/maker/fakelobyff?nickname=${encodeURIComponent(text)}`

    const res = await fetch(apiUrl, {
      headers: {
        Accept: "image/*"
      }
    })

    if (!res.ok) throw new Error("Fetch gagal")

    const contentType = res.headers.get("content-type")
    if (!contentType || !contentType.startsWith("image/")) {
      throw new Error("Response bukan gambar")
    }

    const buffer = Buffer.from(await res.arrayBuffer())

    await conn.sendMessage(
      m.chat,
      {
        image: buffer,
        caption: `🎮 *FAKE LOBBY FREE FIRE*\n👤 Nickname: ${text}`
      },
      { quoted: m }
    )

    await m.react("✅")
  } catch (e) {
    console.error(e)
    await m.react("❌")
    m.reply("❌ Gagal membuat Fake Lobby FF")
  }
}

handler.help = ["fakeff"]
handler.tags = ["maker"]
handler.command = /^(fakeff|fakelobbyff)$/i
handler.limit = true
handler.register = true

export default handler
