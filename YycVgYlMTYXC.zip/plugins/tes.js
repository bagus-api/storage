let handler = async (m, { conn }) => {
  try {
    let url = 'https://files.catbox.moe/3ep6dn.pngg'
    
    // kirim stiker
    await conn.sendFile(m.chat, url, 'stiker.webp', '', m, { asSticker: true })

    // kirim balasan text
    await conn.reply(
      m.chat,
      `haii bot saxra - md disini. aku udahh on kok tenang aja
©𝖱𝖺𝖺𝟦𝖸𝗈𝗎𝗎 - 𝖬𝖣`,
      m
    )

  } catch (e) {
    m.reply('Gagal mengirim stiker.')
  }
}

handler.customPrefix = /^(tes|bot|test)$/i
handler.command = new RegExp

export default handler