const delay = ms => new Promise(resolve => setTimeout(resolve, ms))

let handler = async (m, { conn, text, isOwner }) => {
  if (!isOwner) return m.reply('Fitur khusus Owner!')
  if (!text) return m.reply('Masukkan teks yang ingin di broadcast!')

  if (!global.db.data.blacklistgc)
    global.db.data.blacklistgc = []

  let blacklist = global.db.data.blacklistgc

  let groups = Object.entries(await conn.groupFetchAllParticipating())
    .map(entry => entry[1])

  let filteredGroups = groups.filter(g => !blacklist.includes(g.id))

  m.reply(`📢 Mengirim hidetag ke ${filteredGroups.length} grup...`)

  for (let group of filteredGroups) {
    try {
      let metadata = await conn.groupMetadata(group.id)
      let members = metadata.participants.map(p => p.id)

      await conn.sendMessage(group.id, {
        text: `📢 *BROADCAST DARI RAA4YOUU MD*\n\n${text}`,
        mentions: members
      })

      await delay(2000)
    } catch (e) {
      console.log(`Gagal kirim ke ${group.subject}`)
    }
  }

  m.reply('✅ Broadcast hidetag selesai!')
}

handler.help = ['bcgc <teks>']
handler.tags = ['owner']
handler.command = /^(bcgc|broadcastgc)$/i
handler.owner = true

export default handler