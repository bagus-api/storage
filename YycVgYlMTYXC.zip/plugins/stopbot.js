import fs from "fs"
import path from "path"

let handler = async (m, { text }) => {
  if (!text) return m.reply("Masukkan nomor yang mau dihentikan")

  let nomor = text.replace(/[^0-9]/g, "")
  let sessionPath = path.join("./lib/jadibot/session/", nomor)

  if (!fs.existsSync(sessionPath)) return m.reply("Session tidak ditemukan")

  fs.rmSync(sessionPath, { recursive: true, force: true })
  m.reply(`Session ${nomor} berhasil dihapus.`)
}

handler.command = ["stopbot"]
handler.owner = true

export default handler