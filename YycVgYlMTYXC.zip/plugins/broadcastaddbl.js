let handler = async (m, { conn, args, isOwner }) => {
  if (!isOwner) return m.reply('Fitur khusus Owner!')
  if (!m.isGroup) return m.reply('Perintah ini hanya bisa digunakan di dalam grup!')

  if (!global.db.data.blacklistgc)
    global.db.data.blacklistgc = []

  let blacklist = global.db.data.blacklistgc
  let groupId = m.chat

  if (!args[0]) {
    return m.reply(`Gunakan:
.addbl  → Tambah grup ke blacklist
.delbl  → Hapus grup dari blacklist
.listbl → Lihat daftar blacklist`)
  }

  let cmd = args[0].toLowerCase()

  if (cmd === 'add') {
    if (blacklist.includes(groupId))
      return m.reply('❌ Grup ini sudah ada di blacklist.')

    blacklist.push(groupId)
    m.reply('✅ Grup berhasil ditambahkan ke blacklist.')
  }

  else if (cmd === 'del') {
    if (!blacklist.includes(groupId))
      return m.reply('❌ Grup ini tidak ada di blacklist.')

    global.db.data.blacklistgc =
      blacklist.filter(id => id !== groupId)

    m.reply('✅ Grup berhasil dihapus dari blacklist.')
  }

  else if (cmd === 'list') {
    if (blacklist.length === 0)
      return m.reply('Blacklist grup kosong.')

    let teks = '*📛 Daftar Blacklist Grup:*\n\n'
    for (let id of blacklist) {
      let metadata = await conn.groupMetadata(id).catch(() => null)
      teks += `• ${metadata ? metadata.subject : id}\n`
    }

    m.reply(teks)
  }

  else {
    m.reply('Perintah tidak dikenal.')
  }
}

handler.help = ['addbl add/del/list']
handler.tags = ['owner']
handler.command = /^(addbl|blacklistgc)$/i
handler.owner = true

export default handler