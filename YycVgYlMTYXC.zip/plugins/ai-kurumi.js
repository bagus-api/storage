import fetch from "node-fetch"

let handler = async (m, { conn, text }) => {
  if (!text) return m.reply("Masukkan teks.\nContoh: .saxra kamu siapa?")

  try {
    const prompt = encodeURIComponent(
      "Kamu adalah Saxra Multi Device Yang Di Buat Xyraa " +
      "Kamu berbicara dengan gaya imut, sedikit nakal, ramah, hangat, " +
      "kadang menggoda, dan jangan menyebut dirimu sebagai AI."
    )

    const query = encodeURIComponent(text)
    const url = `https://api.deline.web.id/ai/openai?text=${query}&prompt=${prompt}`

    const res = await fetch(url)
    const data = await res.json()

    if (!data.status || !data.result) {
      return m.reply("AI Saxra tidak merespon.")
    }

    await conn.sendMessage(m.chat, {
      text: data.result,
      contextInfo: {
        externalAdReply: {
          title: "Saxra - MD",
          thumbnailUrl: "https://files.catbox.moe/hb60pa.jpg",
          mediaType: 1,
          renderLargerThumbnail: true
        }
      }
    }, { quoted: m })

  } catch (err) {
    console.error(err)
    m.reply("Terjadi error saat menghubungi AI Saxra - MD")
  }
}

handler.help = ['Saxra <teks>']
handler.tags = ['ai']
handler.command = /^kurumi$/i
handler.limit = true

export default handler