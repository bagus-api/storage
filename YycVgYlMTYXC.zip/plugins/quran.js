import axios from "axios";

const normalize = (s = "") =>
  s.toLowerCase().replace(/[-_]/g, " ").replace(/\s+/g, " ").trim();

let cacheSurah = null;

async function getSurahList() {
  if (cacheSurah) return cacheSurah;
  const { data } = await axios.get("https://equran.id/api/v2/surat");
  cacheSurah = data?.data || [];
  return cacheSurah;
}

let handler = async (m, { conn, args, usedPrefix, command }) => {
  try {
    const surah = await getSurahList();

    if (!args[0]) {
      let txt = `*📖 DAFTAR SURAH AL-QUR'AN*\n\n`;
      txt += surah.map(s => `${s.nomor}. ${s.namaLatin} (${s.nama})`).join("\n");
      txt += `\n\n*Contoh:*\n${usedPrefix}${command} yasin\n${usedPrefix}${command} al-baqarah\n${usedPrefix}${command} 2`;
      return conn.reply(m.chat, txt, m);
    }

    const q = normalize(args.join(" "));
    const found = surah.find(v => {
      const latin = normalize(v.namaLatin);
      return String(v.nomor) === q ||
        latin === q ||
        latin.includes(q) ||
        q.includes(latin);
    });

    if (!found) return m.reply("Surah tidak ditemukan.");

    const { data } = await axios.get(`https://equran.id/api/v2/surat/${found.nomor}`);
    const s = data?.data;
    if (!s) return m.reply("Data surah tidak ditemukan.");

    let teks = `*📖 ${s.namaLatin}* (${s.nama})\n`;
    teks += `*Arti:* ${s.arti}\n`;
    teks += `*Jumlah Ayat:* ${s.jumlahAyat}\n`;
    teks += `*Turun:* ${s.tempatTurun}\n\n`;

    for (const a of s.ayat.slice(0, 10)) {
      teks += `*${a.nomorAyat}.* ${a.teksArab}\n`;
      teks += `${a.teksLatin}\n`;
      teks += `_${a.teksIndonesia}_\n\n`;
    }

    const audio = s.audioFull?.["05"] || Object.values(s.audioFull || {})[0];

    if (audio) {
      await conn.sendMessage(m.chat, {
        audio: { url: audio },
        mimetype: "audio/mpeg",
        ptt: false
      }, { quoted: m });
    }

    return conn.reply(m.chat, teks, m);
  } catch (e) {
    console.error(e);
    return m.reply("Error mengambil data Quran. Coba lagi.");
  }
};

handler.help = ["quran [nama/nomor]"];
handler.tags = ["islami"];
handler.command = /^(quran|alquran)$/i;

export default handler;
