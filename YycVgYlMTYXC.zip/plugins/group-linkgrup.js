let handler = async (m, { conn }) => {
  if (!m.isGroup) return m.reply("Fitur ini hanya bisa digunakan di grup.")

  let code = await conn.groupInviteCode(m.chat)
  let gcLink = `https://chat.whatsapp.com/${code}`

  let text = `
*– 𐚁ᴡᴀɴᴊᴀʏ ʙᴇʀʜᴀsɪʟ ᴍᴇɴᴅᴀᴘᴀᴛᴋᴀɴ ʟɪɴᴋ ɢʀᴜᴘ ɴɪʜ –*
${gcLink}

ɴᴏʜʜ ʟɪɴᴋ ɴʏᴀ, ᴊᴀɴɢᴀɴ ʟᴜᴘᴀ ʙɪʟᴀɴɢ ᴍᴀᴋᴀsɪʜ ʏᴀᴀ ʙᴀɴɢɢ ᴍᴡʜᴇʜᴇʜᴇ
©sᴀxʀᴀ-ᴍᴅ
`.trim()

  await conn.reply(m.chat, text, m)
}

handler.help = ["linkgrup"]
handler.tags = ["group"]
handler.command = /^linkgrup$/i
handler.group = true
handler.botAdmin = true

export default handler