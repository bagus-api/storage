let handler = async (m, { conn }) => {
  let teks = `
𐚁 *INFORMASI BOT*

▢ *Nama Bot* : Ardi - MD
▢ *Versi Bot* : 2.1.0

▢ *Developer* : Ardiansah
▢ *Nomor Developer 1* : 85567744255
▢ *Nomor Developer 2* : 6285706677239

▢ *Website* :
https://ardibaik.biz.id

▢ *Channel WhatsApp Developer* :
https://whatsapp.com/channel/0029Vb7ZTDjiOWD491Wi44

────────────────────

Hai Saya Ardi MD, Saya Di Buat Oleh Ardiansah Untuk Memudahkan Kalian Mencari Atau Membantu Dalam Hal Apapun. Ketik .menu Untuk Melihat Fitur Apa Saja Yang Saya Miliki.
  `.trim()

  conn.reply(m.chat, teks, m)
}

handler.help = ['infobot', 'botinfo']
handler.tags = ['info']
handler.command = /^(infobot|botinfo)$/i

export default handler