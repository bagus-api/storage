import React, { useState, useEffect } from 'react';
import {
    ListMusic, User, Plus, MoreVertical, Play, Pause, Trash2,
    Pencil, Share2, ArrowLeft, Shuffle, X, Heart, WifiOff
} from 'lucide-react';
import { usePlayer } from '../context/PlayerContext';
import {
    getUserPlaylists, getLikedArtists, deleteUserPlaylist, updateUserPlaylist,
    getLikedSongs, toggleLikeSong, getOfflineSongs, toggleOfflineSong,
    FI, handleImgError
} from '../utils/helpers';
import BannerVideo from '../components/BannerVideo';

export default function LibraryView() {
    const {
        playTrack,
        currentTrack,
        isPlaying,
        isLoading,
        togglePlay,
        activeTab: playerActiveTab,
        setActiveTab,
        navigateToTab,
        setActiveArtist,
        setIsCreatePlaylistOpen,
        showToast
    } = usePlayer();

    const [activeTabInternal, setActiveTabInternal] = useState(() => {
        if (playerActiveTab === 'liked') return 'liked';
        if (playerActiveTab === 'offline') return 'offline';
        return 'playlists';
    });

    const [playlists, setPlaylists] = useState([]);
    const [likedArtists, setLikedArtists] = useState([]);
    const [likedSongs, setLikedSongs] = useState([]);
    const [offlineSongs, setOfflineSongs] = useState([]);

    // Playlist detail modal
    const [openPlaylist, setOpenPlaylist] = useState(null);
    const [actionPlaylist, setActionPlaylist] = useState(null);
    const [editPlaylistModal, setEditPlaylistModal] = useState(null);
    const [editName, setEditName] = useState('');

    const reloadData = () => {
        setPlaylists(getUserPlaylists());
        setLikedArtists(getLikedArtists());
        setLikedSongs(getLikedSongs());
        setOfflineSongs(getOfflineSongs());
    };

    useEffect(() => {
        reloadData();
    }, []);

    // Sync subtab saat playerActiveTab berubah dari luar (misal URL /liked atau /offline)
    useEffect(() => {
        if (playerActiveTab === 'liked') {
            setActiveTabInternal('liked');
        } else if (playerActiveTab === 'offline') {
            setActiveTabInternal('offline');
        }
    }, [playerActiveTab]);

    const handleSwitchSubTab = (tab) => {
        setActiveTabInternal(tab);
        if (tab === 'liked') {
            if (navigateToTab) navigateToTab('liked', false);
        } else if (tab === 'offline') {
            if (navigateToTab) navigateToTab('offline', false);
        } else {
            if (navigateToTab) navigateToTab('library', false);
        }
    };

    const handlePlayPlaylistSong = (pl, idx) => {
        if (!pl.songs || !pl.songs[idx]) return;
        playTrack(pl.songs[idx], pl.songs, idx, 'playlist');
    };

    const handleShufflePlaylist = (pl) => {
        if (!pl.songs || pl.songs.length === 0) return;
        const randomIdx = Math.floor(Math.random() * pl.songs.length);
        playTrack(pl.songs[randomIdx], pl.songs, randomIdx, 'playlist');
    };

    const handleDeletePlaylist = (id) => {
        deleteUserPlaylist(id);
        reloadData();
        if (openPlaylist && openPlaylist.id === id) setOpenPlaylist(null);
        setActionPlaylist(null);
        showToast('Playlist dihapus');
    };

    const handleSaveEdit = (id) => {
        if (!editName.trim()) return;
        updateUserPlaylist(id, editName.trim(), null);
        reloadData();
        if (openPlaylist && openPlaylist.id === id) {
            setOpenPlaylist(prev => ({ ...prev, name: editName.trim() }));
        }
        setEditPlaylistModal(null);
        showToast('Playlist diperbarui');
    };

    const handleRemoveSongFromPlaylist = (pl, songIdx) => {
        const updated = [...pl.songs];
        updated.splice(songIdx, 1);
        const list = getUserPlaylists();
        const target = list.find(p => p.id === pl.id);
        if (target) target.songs = updated;
        try { localStorage.setItem('user_playlists', JSON.stringify(list)); } catch(e){}
        reloadData();
        setOpenPlaylist({ ...pl, songs: updated });
        showToast('Lagu dihapus dari playlist');
    };

    const handleToggleLike = (song) => {
        toggleLikeSong(song);
        reloadData();
        showToast('Lagu dihapus dari Disukai');
    };

    const handleRemoveOffline = (song) => {
        toggleOfflineSong(song);
        reloadData();
        showToast('Lagu dihapus dari Mode Offline');
    };

    return (
        <div id="view-library" className="animate-fade-in pb-12">
            {/* Sticky Header */}
            <div className="pt-3.5 pb-2 px-4 sticky top-0 z-30 border-b border-[var(--header-border)] shadow-2xl transition-all relative overflow-hidden backdrop-blur-md bg-[var(--header-bg)]">
                <BannerVideo />
                <div className="flex items-center justify-between mb-2">
                    <h1 className="text-2xl font-black text-[var(--text-primary)] tracking-tight drop-shadow-md">Library</h1>
                </div>

                {/* Tabs Navigation: Playlists, Liked, Offline, Artists */}
                <div className="flex gap-1.5 p-1 bg-[var(--card-bg)] backdrop-blur-md rounded-2xl border border-[var(--border-color)]">
                    <button
                        onClick={() => handleSwitchSubTab('playlists')}
                        className={`flex-1 py-2 px-2 sm:px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                            activeTabInternal === 'playlists' ? 'bg-[var(--chip-active-bg)] text-[var(--chip-active-text)] shadow-md' : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
                        }`}
                    >
                        <ListMusic className="w-4 h-4 shrink-0" />
                        <span>Playlists</span>
                    </button>
                    <button
                        onClick={() => handleSwitchSubTab('liked')}
                        className={`flex-1 py-2 px-2 sm:px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                            activeTabInternal === 'liked' ? 'bg-[var(--chip-active-bg)] text-[var(--chip-active-text)] shadow-md' : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
                        }`}
                    >
                        <Heart className="w-4 h-4 shrink-0" />
                        <span>Disukai</span>
                    </button>
                    <button
                        onClick={() => handleSwitchSubTab('offline')}
                        className={`flex-1 py-2 px-2 sm:px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                            activeTabInternal === 'offline' ? 'bg-[var(--chip-active-bg)] text-[var(--chip-active-text)] shadow-md' : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
                        }`}
                    >
                        <WifiOff className="w-4 h-4 shrink-0" />
                        <span>Offline</span>
                    </button>
                    <button
                        onClick={() => handleSwitchSubTab('artists')}
                        className={`flex-1 py-2 px-2 sm:px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                            activeTabInternal === 'artists' ? 'bg-[var(--chip-active-bg)] text-[var(--chip-active-text)] shadow-md' : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
                        }`}
                    >
                        <User className="w-4 h-4 shrink-0" />
                        <span>Artis</span>
                    </button>
                </div>
            </div>

            {/* Content Area */}
            <div className="px-4 mt-4 pb-12">
                {/* 1. PLAYLISTS TAB */}
                {activeTabInternal === 'playlists' && (
                    <>
                        <button
                            onClick={() => setIsCreatePlaylistOpen(true)}
                            className="w-full bg-white/15 hover:bg-white/20 border border-white/20 font-bold py-3.5 rounded-2xl active:scale-95 mb-5 flex items-center justify-center gap-2 text-white shadow-lg transition-all cursor-pointer"
                        >
                            + Buat Playlist Baru
                        </button>

                        {playlists.length === 0 ? (
                            <div className="text-center text-white/70 py-16 px-4 bg-white/[0.04] backdrop-blur-xl rounded-3xl border border-white/10 mt-2">
                                <ListMusic className="w-16 h-16 mx-auto mb-4 opacity-30 text-white" />
                                <h3 className="text-white font-bold text-lg mb-1">Belum Ada Playlist</h3>
                                <p className="text-xs text-white/70 max-w-xs mx-auto mb-5">
                                    Buat playlist pertamamu dan kumpulkan lagu-lagu favoritmu di satu tempat.
                                </p>
                            </div>
                        ) : (
                            <div className="grid grid-cols-2 gap-3">
                                {playlists.map((p) => (
                                    <div
                                        key={p.id}
                                        onClick={() => setOpenPlaylist(p)}
                                        className="p-2.5 rounded-2xl bg-[#20222c] border border-white/10 shadow-xl hover:bg-[#282b38] cursor-pointer active:scale-95 transition-all group flex flex-col"
                                    >
                                        <div className="relative w-full aspect-square mb-2.5 rounded-xl overflow-hidden shadow-md">
                                            <img
                                                src={p.image || (p.songs.length > 0 ? p.songs[0].cover : FI)}
                                                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                                                alt=""
                                                onError={handleImgError}
                                            />
                                            <button
                                                onClick={(e) => {
                                                    e.stopPropagation();
                                                    setActionPlaylist(p);
                                                }}
                                                className="absolute top-2 right-2 bg-black/60 hover:bg-black/80 backdrop-blur-md rounded-full p-2 active:scale-90 transition-all cursor-pointer"
                                                title="Opsi"
                                            >
                                                <MoreVertical className="w-4 h-4 text-white" />
                                            </button>
                                            {p.songs.length > 0 && (
                                                <button
                                                    onClick={(e) => {
                                                        e.stopPropagation();
                                                        handlePlayPlaylistSong(p, 0);
                                                    }}
                                                    className="absolute bottom-2 right-2 bg-white/20 backdrop-blur-md border border-white/30 rounded-full p-2.5 shadow-black/40 active:scale-90 cursor-pointer"
                                                    title="Putar"
                                                >
                                                    <Play className="w-4 h-4 text-white fill-current ml-0.5" />
                                                </button>
                                            )}
                                        </div>
                                        <h3 className="font-semibold text-sm truncate text-white px-0.5">{p.name}</h3>
                                        <p className="text-white/60 text-xs mt-0.5 px-0.5">{p.songs.length} lagu</p>
                                    </div>
                                ))}
                            </div>
                        )}
                    </>
                )}

                {/* 2. LIKED SONGS TAB */}
                {activeTabInternal === 'liked' && (
                    <div className="space-y-3">
                        {likedSongs.length > 0 ? (
                            <>
                                <div className="flex items-center justify-between mb-2">
                                    <span className="text-xs font-semibold text-white/60 uppercase tracking-wider">
                                        {likedSongs.length} Lagu Disukai
                                    </span>
                                    <button
                                        onClick={() => playTrack(likedSongs[0], likedSongs, 0, 'liked')}
                                        className="text-xs text-white font-bold hover:underline flex items-center gap-1 cursor-pointer"
                                    >
                                        <Play className="w-3.5 h-3.5 fill-current" /> Putar Semua
                                    </button>
                                </div>

                                <div className="space-y-2.5">
                                    {likedSongs.map((s, i) => {
                                        const isCur = currentTrack && (
                                            currentTrack.id === s.id ||
                                            currentTrack.videoId === s.videoId ||
                                            (currentTrack.title === s.title && currentTrack.artist === s.artist)
                                        );
                                        const isPlay = isCur && isPlaying;

                                        const cardBg = isPlay
                                            ? 'bg-[#343a4e] border border-white/40 shadow-xl'
                                            : isCur
                                            ? 'bg-[#2e3344] border border-white/30'
                                            : 'bg-[#20222c] border border-white/10 hover:bg-[#282b38]';

                                        return (
                                            <div
                                                key={i}
                                                className={`rounded-2xl ${cardBg} p-2.5 flex items-center gap-3 active:scale-[0.98] transition-all duration-300 group shadow-lg shadow-black/25`}
                                            >
                                                <div
                                                    onClick={() => {
                                                        if (isCur) togglePlay();
                                                        else playTrack(s, likedSongs, i, 'liked');
                                                    }}
                                                    className="flex items-center gap-3 flex-1 min-w-0 cursor-pointer"
                                                >
                                                    <img
                                                        src={s.cover}
                                                        className="w-14 h-14 rounded-xl object-cover shrink-0 shadow-md border border-white/10"
                                                        alt=""
                                                        onError={handleImgError}
                                                    />
                                                    <div className="min-w-0 flex-1">
                                                        <h3 className="font-semibold text-sm text-white truncate">{s.title}</h3>
                                                        <p className="text-xs text-white/60 truncate mt-0.5">{s.artist}</p>
                                                    </div>
                                                </div>

                                                <button
                                                    onClick={() => handleToggleLike(s)}
                                                    className="p-2.5 rounded-full hover:bg-white/10 active:scale-90 text-white cursor-pointer transition-all"
                                                    title="Hapus dari Disukai"
                                                >
                                                    <Heart className="w-5 h-5 fill-current" />
                                                </button>
                                            </div>
                                        );
                                    })}
                                </div>
                            </>
                        ) : (
                            <div className="text-center text-white/70 py-16 px-4 bg-white/[0.04] backdrop-blur-xl rounded-3xl border border-white/10 mt-2">
                                <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-white/10 flex items-center justify-center border border-white/20">
                                    <Heart className="w-8 h-8 text-white fill-current opacity-80" />
                                </div>
                                <h3 className="text-white font-bold text-lg mb-1">Belum Ada Lagu Disukai</h3>
                                <p className="text-xs text-white/70 max-w-xs mx-auto mb-6">
                                    Tekan ikon hati pada pemutar lagu untuk mengumpulkannya di sini.
                                </p>
                                <button
                                    onClick={() => setActiveTab('search')}
                                    className="bg-white/10 hover:bg-white/20 px-6 py-3 font-bold rounded-full text-xs active:scale-95 inline-flex items-center gap-1.5 text-white border border-white/20 transition-all cursor-pointer"
                                >
                                    Cari Lagu
                                </button>
                            </div>
                        )}
                    </div>
                )}

                {/* 3. OFFLINE SONGS TAB */}
                {activeTabInternal === 'offline' && (
                    <div className="space-y-3">
                        {offlineSongs.length > 0 ? (
                            <>
                                <div className="flex items-center justify-between mb-2">
                                    <span className="text-xs font-semibold text-white/60 uppercase tracking-wider">
                                        {offlineSongs.length} Lagu Offline
                                    </span>
                                    <button
                                        onClick={() => playTrack(offlineSongs[0], offlineSongs, 0, 'offline')}
                                        className="text-xs text-white font-bold hover:underline flex items-center gap-1 cursor-pointer"
                                    >
                                        <Play className="w-3.5 h-3.5 fill-current" /> Putar Semua
                                    </button>
                                </div>

                                <div className="space-y-2.5">
                                    {offlineSongs.map((s, i) => {
                                        const isCur = currentTrack && (
                                            currentTrack.id === s.id ||
                                            currentTrack.videoId === s.videoId ||
                                            (currentTrack.title === s.title && currentTrack.artist === s.artist)
                                        );
                                        const isPlay = isCur && isPlaying;

                                        const cardBg = isPlay
                                            ? 'bg-[#343a4e] border border-white/40 shadow-xl'
                                            : isCur
                                            ? 'bg-[#2e3344] border border-white/30'
                                            : 'bg-[#20222c] border border-white/10 hover:bg-[#282b38]';

                                        return (
                                            <div
                                                key={i}
                                                className={`rounded-2xl ${cardBg} p-2.5 flex items-center gap-3 active:scale-[0.98] transition-all duration-300 group shadow-lg shadow-black/25`}
                                            >
                                                <div
                                                    onClick={() => {
                                                        if (isCur) togglePlay();
                                                        else playTrack(s, offlineSongs, i, 'offline');
                                                    }}
                                                    className="flex items-center gap-3 flex-1 min-w-0 cursor-pointer"
                                                >
                                                    <img
                                                        src={s.cover}
                                                        className="w-14 h-14 rounded-xl object-cover shrink-0 shadow-md border border-white/10"
                                                        alt=""
                                                        onError={handleImgError}
                                                    />
                                                    <div className="min-w-0 flex-1">
                                                        <h3 className="font-semibold text-sm text-white truncate">{s.title}</h3>
                                                        <p className="text-xs text-white/60 truncate mt-0.5">{s.artist}</p>
                                                    </div>
                                                </div>

                                                <button
                                                    onClick={() => handleRemoveOffline(s)}
                                                    className="p-2.5 rounded-full hover:bg-red-500/20 text-white/70 hover:text-red-400 active:scale-90 cursor-pointer transition-all"
                                                    title="Hapus dari Mode Offline"
                                                >
                                                    <Trash2 className="w-5 h-5" />
                                                </button>
                                            </div>
                                        );
                                    })}
                                </div>
                            </>
                        ) : (
                            <div className="text-center text-white/70 py-16 px-4 bg-white/[0.04] backdrop-blur-xl rounded-3xl border border-white/10 mt-2">
                                <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-white/10 flex items-center justify-center border border-white/20">
                                    <WifiOff className="w-8 h-8 text-white opacity-80" />
                                </div>
                                <h3 className="text-white font-bold text-lg mb-1">Belum Ada Lagu Tersimpan Offline</h3>
                                <p className="text-xs text-white/70 max-w-xs mx-auto">
                                    Buka player lagu dan tekan ikon unduh/offline untuk menyimpannya ke memori perangkat.
                                </p>
                            </div>
                        )}
                    </div>
                )}

                {/* 4. ARTISTS TAB */}
                {activeTabInternal === 'artists' && (
                    likedArtists.length === 0 ? (
                        <div className="text-center text-white/70 py-16 px-4 bg-white/[0.04] backdrop-blur-xl rounded-3xl border border-white/10 mt-2">
                            <div className="w-20 h-20 mx-auto mb-4 rounded-full bg-white/10 flex items-center justify-center border border-white/20">
                                <User className="w-10 h-10 text-white opacity-80" />
                            </div>
                            <h3 className="text-white font-bold text-lg mb-1">Belum Ada Artist Disukai</h3>
                            <p className="text-xs text-white/70 max-w-xs mx-auto mb-6">Sukai artist favoritmu untuk melihatnya di sini.</p>
                            <button
                                onClick={() => setActiveTab('search')}
                                className="bg-white/10 hover:bg-white/20 px-6 py-3 font-bold rounded-full text-xs active:scale-95 inline-flex items-center gap-1.5 text-white border border-white/20 transition-all cursor-pointer"
                            >
                                Cari Artist
                            </button>
                        </div>
                    ) : (
                        <div className="grid grid-cols-2 gap-3">
                            {likedArtists.map((a, i) => (
                                <div
                                    key={i}
                                    onClick={() => setActiveArtist({ id: a.artistId, name: a.name, cover: a.thumbnail })}
                                    className="p-3.5 rounded-2xl bg-[#20222c] border border-white/10 shadow-xl hover:bg-[#282b38] cursor-pointer active:scale-95 transition-all text-center flex flex-col items-center justify-center group"
                                >
                                    <div className="relative w-20 h-20 mb-3 rounded-full overflow-hidden border-2 border-white/10 shadow-md group-hover:scale-105 transition-transform duration-300">
                                        <img src={a.thumbnail || FI} className="w-full h-full object-cover" alt="" onError={handleImgError} />
                                    </div>
                                    <h3 className="font-bold text-sm truncate text-white w-full px-1">{a.name}</h3>
                                    <p className="text-white/60 text-[10px] mt-0.5 uppercase tracking-wider font-semibold">Artist</p>
                                </div>
                            ))}
                        </div>
                    )
                )}
            </div>

            {/* Open Playlist Detail Modal */}
            {openPlaylist && (
                <div className="playlist-detail-modal fixed inset-0 bg-[#050507] flex flex-col z-[100] animate-slide-up-modal overflow-hidden text-white">
                    <div className="flex items-center gap-3 p-4 pt-safe bg-transparent absolute top-0 left-0 w-full z-[100]">
                        <button
                            onClick={() => setOpenPlaylist(null)}
                            className="glass glass-hover rounded-full text-white p-3 active:scale-90 shadow-md bg-black/80 cursor-pointer"
                        >
                            <ArrowLeft className="w-6 h-6" />
                        </button>
                        <div className="flex-1"></div>
                        <div className="flex items-center gap-1 bg-black/80 rounded-full shadow-md">
                            <button
                                onClick={() => {
                                    setEditName(openPlaylist.name);
                                    setEditPlaylistModal(openPlaylist);
                                }}
                                className="text-white hover:text-white p-2.5 active:scale-90 cursor-pointer"
                                title="Edit Playlist"
                            >
                                <Pencil className="w-5 h-5" />
                            </button>
                            <button
                                onClick={() => handleDeletePlaylist(openPlaylist.id)}
                                className="text-red-400 hover:text-red-300 p-2.5 active:scale-90 cursor-pointer"
                                title="Hapus Playlist"
                            >
                                <Trash2 className="w-5 h-5" />
                            </button>
                        </div>
                    </div>

                    <div className="flex-1 overflow-y-auto hide-scrollbar pb-36 relative">
                        <div className="relative w-full aspect-square md:aspect-video max-h-[50vh] overflow-hidden -mt-2 mb-6">
                            <img
                                src={openPlaylist.image || (openPlaylist.songs.length > 0 ? openPlaylist.songs[0].cover : FI)}
                                className="w-full h-full object-cover"
                                alt=""
                                onError={handleImgError}
                            />
                            <div className="absolute inset-0 bg-gradient-to-t from-[#050507] via-[#050507]/60 to-transparent"></div>
                            <div className="absolute bottom-6 left-6 right-6 flex flex-col justify-end items-center text-center z-10">
                                <img
                                    src={openPlaylist.image || (openPlaylist.songs.length > 0 ? openPlaylist.songs[0].cover : FI)}
                                    className="w-32 h-32 md:w-48 md:h-48 rounded-xl object-cover border border-white/10 mb-4 shadow-2xl"
                                    alt=""
                                    onError={handleImgError}
                                />
                                <div>
                                    <p className="text-[10px] font-bold text-white uppercase tracking-[0.2em] mb-1">PLAYLIST LOKAL</p>
                                    <h1 className="text-3xl md:text-5xl font-black text-white mb-2 leading-tight line-clamp-2">
                                        {openPlaylist.name}
                                    </h1>
                                    <p className="text-white text-xs md:text-sm line-clamp-2">{openPlaylist.songs.length} lagu</p>
                                </div>
                            </div>
                        </div>

                        <div className="px-6 mb-6 flex items-center gap-4">
                            {openPlaylist.songs.length > 0 && (
                                <>
                                    <button
                                        onClick={() => handlePlayPlaylistSong(openPlaylist, 0)}
                                        className="bg-white hover:bg-gray-200 text-black w-14 h-14 rounded-full flex items-center justify-center active:scale-95 transition-all shadow-white/20 cursor-pointer"
                                    >
                                        <Play className="w-7 h-7 fill-current ml-1" />
                                    </button>
                                    <button
                                        onClick={() => handleShufflePlaylist(openPlaylist)}
                                        className="text-white/70 hover:text-white p-3 rounded-full active:scale-95 bg-white/5 transition-all cursor-pointer"
                                        title="Acak (Shuffle)"
                                    >
                                        <Shuffle className="w-6 h-6" />
                                    </button>
                                </>
                            )}
                        </div>

                        {openPlaylist.songs.length === 0 ? (
                            <div className="text-center text-white/70 mt-10"><p>Belum ada lagu di playlist ini</p></div>
                        ) : (
                            <div className="space-y-1 px-4">
                                {openPlaylist.songs.map((s, idx) => {
                                    const isCur = currentTrack && (
                                        currentTrack.id === s.videoId ||
                                        currentTrack.videoId === s.videoId ||
                                        (currentTrack.title === s.title && currentTrack.artist === s.artist)
                                    );
                                    const isPlay = isCur && isPlaying;

                                    return (
                                        <div
                                            key={idx}
                                            className={`flex items-center gap-2 p-2 rounded-lg active:scale-[0.98] ${
                                                isPlay ? 'bg-white/15 border border-white/30' : isCur ? 'bg-white/10 border border-white/20' : 'hover:bg-white/5 border border-transparent'
                                            }`}
                                        >
                                            <div
                                                onClick={() => handlePlayPlaylistSong(openPlaylist, idx)}
                                                className="flex items-center gap-3 flex-1 cursor-pointer overflow-hidden"
                                            >
                                                <img src={s.cover} className="w-10 h-10 rounded object-cover shrink-0" alt="" onError={handleImgError} />
                                                <div className="truncate flex-1 min-w-0">
                                                    <p className={`text-sm truncate ${isCur ? 'text-white font-bold' : 'text-white font-medium'}`}>
                                                        {s.title}
                                                    </p>
                                                    <p className="text-white/70 text-xs truncate">{s.artist}</p>
                                                </div>
                                            </div>
                                            <button
                                                onClick={() => handleRemoveSongFromPlaylist(openPlaylist, idx)}
                                                className="text-white/70 hover:text-red-400 p-2 active:scale-90 shrink-0 cursor-pointer"
                                                title="Hapus dari playlist"
                                            >
                                                <X className="w-5 h-5" />
                                            </button>
                                        </div>
                                    );
                                })}
                            </div>
                        )}
                    </div>
                </div>
            )}

            {/* Actions sheet for playlist */}
            {actionPlaylist && (
                <div
                    onClick={() => setActionPlaylist(null)}
                    className="fixed inset-0 z-[300] flex items-end justify-center bg-black/60"
                >
                    <div
                        onClick={(e) => e.stopPropagation()}
                        className="w-full max-w-md rounded-t-3xl p-6 border-t border-white/10 glass-strong"
                        style={{ background: 'var(--bg-color)' }}
                    >
                        <div className="w-10 h-1 bg-white/20 rounded-full mx-auto mb-4"></div>
                        <h3 className="font-bold text-white mb-4">{actionPlaylist.name}</h3>

                        <button
                            onClick={() => {
                                setEditName(actionPlaylist.name);
                                setEditPlaylistModal(actionPlaylist);
                                setActionPlaylist(null);
                            }}
                            className="w-full text-left p-4 rounded-xl hover:bg-white/5 flex items-center gap-3 mb-1 text-white font-medium cursor-pointer"
                        >
                            <Pencil className="w-5 h-5" /> Edit Playlist
                        </button>
                        <button
                            onClick={() => handleDeletePlaylist(actionPlaylist.id)}
                            className="w-full text-left p-4 rounded-xl hover:bg-red-500/10 flex items-center gap-3 text-red-400 font-medium cursor-pointer"
                        >
                            <Trash2 className="w-5 h-5" /> Hapus Playlist
                        </button>
                    </div>
                </div>
            )}

            {/* Edit Playlist Modal */}
            {editPlaylistModal && (
                <div
                    onClick={() => setEditPlaylistModal(null)}
                    className="fixed inset-0 z-[300] flex items-end justify-center bg-black/60"
                >
                    <div
                        onClick={(e) => e.stopPropagation()}
                        className="glass-strong w-full max-w-md rounded-t-3xl p-6 border-t border-white/10 animate-slide-up-modal space-y-4"
                        style={{ background: 'var(--bg-color)' }}
                    >
                        <div className="w-10 h-1 bg-white/20 rounded-full mx-auto mb-2"></div>
                        <h3 className="font-bold text-white mb-2">Edit Playlist</h3>

                        <input
                            type="text"
                            value={editName}
                            onChange={(e) => setEditName(e.target.value)}
                            className="w-full glass-input text-white rounded-xl px-4 py-3 focus:outline-none text-sm"
                            placeholder="Nama Playlist"
                        />

                        <div className="flex gap-3 pt-2">
                            <button
                                onClick={() => handleSaveEdit(editPlaylistModal.id)}
                                className="flex-1 btn-chrome font-bold py-3 rounded-full text-xs active:scale-95 transition"
                            >
                                Simpan
                            </button>
                            <button
                                onClick={() => setEditPlaylistModal(null)}
                                className="px-6 py-3 glass glass-hover text-white rounded-full text-xs font-bold active:scale-95 transition"
                            >
                                Batal
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}
