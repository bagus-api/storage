import React, { useEffect, useRef } from 'react';
import { ChevronDown, AudioWaveform, Minus, Plus } from 'lucide-react';
import { usePlayer } from '../context/PlayerContext';
import { toHDCover, handleImgError } from '../utils/helpers';
import LightPillar from './reactbits/LightPillar';

export default function LyricsOverlay() {
    const {
        currentTrack,
        isLyricsOverlayOpen,
        setIsLyricsOverlayOpen,
        lyrics,
        currentLyricIndex,
        lyricOffset,
        lyricSyncPrev,
        lyricSyncNext,
        seek,
        bgGlowEnabled,
        toggleBgGlow,
        theme
    } = usePlayer();

    const scrollContainerRef = useRef(null);

    useEffect(() => {
        if (isLyricsOverlayOpen && scrollContainerRef.current && currentLyricIndex >= 0) {
            const activeEl = scrollContainerRef.current.querySelector(`.lyric-line-${currentLyricIndex}`);
            if (activeEl) {
                activeEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }
        }
    }, [currentLyricIndex, isLyricsOverlayOpen]);

    if (!isLyricsOverlayOpen || !currentTrack) return null;

    const coverUrl = toHDCover(currentTrack.cover, currentTrack.videoId || currentTrack.id);

    return (
        <div
            id="lyrics-overlay"
            className={`fixed inset-0 flex flex-col z-[200] text-white overflow-hidden transition-transform duration-300 ease-out ${
                bgGlowEnabled ? 'bg-pillar-active' : 'bg-standard-active'
            }`}
        >
            {/* Background (Light Pillar when enabled, standard blurred cover when disabled) */}
            <div className="player-bg-container">
                {bgGlowEnabled ? (
                    <LightPillar
                        key={`lyrics-pillar-${theme}`}
                        topColor={theme === 'light' ? 'c7c7d5' : '020202'}
                        bottomColor={theme === 'light' ? 'f5f4f2' : '201f1b'}
                        pillarRotation={0}
                        preset="spectre"
                        glowAmount={0.0018}
                        bloom={0.35}
                        pillarWidth={8}
                        quality="low"
                        lightMode={theme === 'light'}
                        mixBlendMode={theme === 'light' ? 'normal' : 'screen'}
                        style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }}
                    />
                ) : (
                    <img src={coverUrl} className="player-bg-blur-img" alt="" onError={handleImgError} />
                )}
                <div className="player-bg-vignette"></div>
            </div>

            {/* Mobile Header */}
            <div className="md:hidden flex justify-between items-center p-4 pt-safe flex-shrink-0 bg-black/30 backdrop-blur-md border-b border-white/10 relative z-20">
                <div className="flex items-center gap-3 overflow-hidden">
                    <img
                        src={coverUrl}
                        alt=""
                        className="w-12 h-12 rounded-md object-cover shadow-md flex-shrink-0 bg-white/5"
                        onError={handleImgError}
                    />
                    <div className="flex flex-col min-w-0">
                        <span className="font-bold text-white text-base truncate">{currentTrack.title}</span>
                        <span className="text-white/70 text-sm truncate">{currentTrack.artist}</span>
                    </div>
                </div>
                <button
                    onClick={() => setIsLyricsOverlayOpen(false)}
                    className="text-white/70 hover:text-white p-2 rounded-full active:scale-90 flex-shrink-0 transition-all bg-white/10 ml-3"
                >
                    <ChevronDown className="w-6 h-6" />
                </button>
            </div>

            {/* Floating Toggle & Sync Controls */}
            <button
                onClick={toggleBgGlow}
                aria-label={bgGlowEnabled ? 'Ubah ke Background Biasa' : 'Ubah ke Background Pillar'}
                className={`md:hidden absolute top-[100px] left-6 z-30 w-9 h-9 rounded-full border border-white/10 flex items-center justify-center active:scale-90 transition-all cursor-pointer ${
                    bgGlowEnabled ? 'bg-white/25 text-white shadow-lg ring-1 ring-white/30' : 'bg-black/40 text-white/70 hover:text-white'
                }`}
                title={bgGlowEnabled ? 'Background Pillar Aktif (Klik untuk Background Biasa)' : 'Background Biasa (Klik untuk Background Pillar)'}
            >
                <AudioWaveform className="w-4 h-4" />
            </button>

            <div className="md:hidden absolute top-[100px] right-6 z-30 flex items-center gap-2 bg-black/40 backdrop-blur-md px-3 py-1.5 rounded-full border border-white/10">
                <button
                    onClick={lyricSyncPrev}
                    className="text-white/70 hover:text-white bg-white/10 hover:bg-white/20 w-8 h-8 rounded-full active:scale-90 flex items-center justify-center transition-all cursor-pointer"
                >
                    <Minus className="w-4 h-4" />
                </button>
                {lyricOffset !== 0 && (
                    <p className="text-xs font-bold text-white tracking-wide">
                        {lyricOffset > 0 ? `+${lyricOffset}` : lyricOffset}s
                    </p>
                )}
                <button
                    onClick={lyricSyncNext}
                    className="text-white/70 hover:text-white bg-white/10 hover:bg-white/20 w-8 h-8 rounded-full active:scale-90 flex items-center justify-center transition-all cursor-pointer"
                >
                    <Plus className="w-4 h-4" />
                </button>
            </div>

            {/* Desktop Actions */}
            <div className="hidden md:flex items-center gap-2 absolute top-8 right-8 z-50">
                <button
                    onClick={toggleBgGlow}
                    aria-label={bgGlowEnabled ? 'Ubah ke Background Biasa' : 'Ubah ke Background Pillar'}
                    className={`bg-black/40 hover:bg-white/10 backdrop-blur-md p-3 rounded-full active:scale-90 transition-all cursor-pointer border border-white/10 ${
                        bgGlowEnabled ? 'text-white bg-white/20 ring-1 ring-white/30' : 'text-white/70'
                    }`}
                    title={bgGlowEnabled ? 'Background Pillar Aktif (Klik untuk Background Biasa)' : 'Background Biasa (Klik untuk Background Pillar)'}
                >
                    <AudioWaveform className="w-6 h-6" />
                </button>
                <button
                    onClick={() => setIsLyricsOverlayOpen(false)}
                    className="bg-white/10 hover:bg-white/20 backdrop-blur-md text-white p-3 rounded-full active:scale-90 transition-all cursor-pointer"
                    title="Tutup Lirik"
                >
                    <ChevronDown className="w-8 h-8" />
                </button>
            </div>

            {/* Lyrics Scrollable Container */}
            <div className="flex-1 flex flex-col md:flex-row w-full h-full overflow-hidden relative z-10">
                <div
                    ref={scrollContainerRef}
                    id="lyrics-scroll-container"
                    className="w-full md:w-3/5 h-full overflow-y-auto px-6 md:px-16 hide-scrollbar z-10 relative scroll-smooth"
                >
                    <div className="pt-[30vh] pb-[60vh] w-full max-w-3xl mx-auto md:mx-0">
                        {lyrics.type === 'loading' ? (
                            <div className="flex justify-center items-center h-[30vh] w-full">
                                <div className="w-10 h-10 border-4 border-[#cfd3d8] border-t-transparent rounded-full animate-spin"></div>
                            </div>
                        ) : (!lyrics.lines || lyrics.lines.length === 0) ? (
                            <div className="flex justify-center items-center h-[30vh] w-full text-white/50 text-center">
                                <div>
                                    <p className="text-lg font-bold mb-1">Lirik tidak tersedia</p>
                                    <p className="text-sm">Tidak dapat menemukan lirik untuk lagu ini</p>
                                </div>
                            </div>
                        ) : (
                            lyrics.lines.map((line, idx) => {
                                const isActive = idx === currentLyricIndex;
                                const isPast = idx < currentLyricIndex;
                                return (
                                    <div
                                        key={idx}
                                        onClick={() => seek(line.time)}
                                        className={`lyric-line lyric-line-${idx} ${
                                            isActive ? 'active-lyric' : isPast ? 'past-lyric' : ''
                                        }`}
                                    >
                                        <div>{line.text}</div>
                                        {line.translation && (
                                            <span className="lyric-translation">({line.translation.replace(/^\(|\)$/g, '').trim()})</span>
                                        )}
                                    </div>
                                );
                            })
                        )}
                    </div>
                </div>

                {/* Right side artwork on desktop */}
                <div className="hidden md:flex md:w-2/5 h-full items-center justify-center p-8 z-10">
                    <div className="w-80 h-80 rounded-3xl overflow-hidden shadow-2xl border border-white/10">
                        <img src={coverUrl} alt="" className="w-full h-full object-cover" onError={handleImgError} />
                    </div>
                </div>
            </div>
        </div>
    );
}
