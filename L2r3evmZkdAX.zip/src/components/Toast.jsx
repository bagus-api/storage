import React from 'react';
import { usePlayer } from '../context/PlayerContext';

export default function Toast() {
    const { toastMessage } = usePlayer();

    if (!toastMessage) return null;

    return (
        <div data-preserve-white="true" className="fixed top-4 left-1/2 -translate-x-1/2 z-[600] bg-zinc-900/95 text-white text-xs font-semibold px-4 py-2.5 rounded-full border border-white/15 shadow-2xl backdrop-blur-md flex items-center space-x-2 transition-all duration-300 animate-slide-up">
            <span>{toastMessage}</span>
        </div>
    );
}
