import React, { useState, useEffect, useRef, memo, useCallback } from 'react';
import {
    MessageSquare,
    Send,
    LogOut,
    User,
    Lock,
    Key,
    Trash2,
    RefreshCw,
    X,
    Sparkles,
    Smile,
    ShieldAlert,
    ShieldCheck,
    AlertCircle,
    CheckCircle2,
    Users,
    Settings,
    Image as ImageIcon,
    Clock,
    Search,
    UserPlus,
    Edit3,
    AlertTriangle
} from 'lucide-react';
import ChatApi, {
    getStoredToken,
    getStoredUser,
    clearStoredAuth,
    getStoredAdminKey,
    setStoredAdminKey,
    clearStoredAdminKey
} from '../services/ChatApi';
import { usePlayer } from '../context/PlayerContext';
import ShinyText from '../components/reactbits/ShinyText';

// Monochromatic Avatar component with image support and fallback initials
const Avatar = memo(function Avatar({ name = 'U', photoUrl = '', size = 'md' }) {
    const [imgErr, setImgErr] = useState(false);

    const sizeClasses = {
        xs: 'w-6 h-6 text-[10px]',
        sm: 'w-7 h-7 text-[11px]',
        md: 'w-8 h-8 text-xs',
        lg: 'w-14 h-14 text-xl'
    };

    const initials = (name || 'U')
        .split(' ')
        .map(n => n[0])
        .slice(0, 2)
        .join('')
        .toUpperCase() || 'U';

    if (photoUrl && !imgErr) {
        return (
            <img
                src={photoUrl}
                alt={name}
                onError={() => setImgErr(true)}
                className={`${sizeClasses[size]} rounded-full object-cover shrink-0 border border-white/20 shadow-md shadow-black/50 select-none`}
            />
        );
    }

    return (
        <div
            className={`${sizeClasses[size]} rounded-full bg-zinc-800 text-zinc-100 font-bold flex items-center justify-center shrink-0 shadow-md shadow-black/50 border border-white/15 select-none`}
        >
            {initials}
        </div>
    );
});

// Memoized monochromatic message bubble
const MessageBubble = memo(function MessageBubble({ msg, isOwn }) {
    return (
        <div className={`flex items-end gap-2 my-2 transition-all ${isOwn ? 'justify-end' : 'justify-start'}`}>
            {!isOwn && (
                <div className="shrink-0 mb-1">
                    <Avatar name={msg.name} photoUrl={msg.photo_url} size="sm" />
                </div>
            )}

            <div className={`flex flex-col max-w-[85%] sm:max-w-[72%] md:max-w-[60%] ${isOwn ? 'items-end' : 'items-start'}`}>
                {/* Bubble Container */}
                <div
                    className={`relative px-3.5 py-2 sm:px-4 sm:py-2.5 rounded-2xl break-words text-[13.5px] sm:text-sm leading-relaxed shadow-md backdrop-blur-md select-text ${
                        isOwn
                            ? 'bg-white text-zinc-950 rounded-tr-xs border border-white shadow-black/20'
                            : 'bg-zinc-900/90 text-zinc-100 rounded-tl-xs border border-white/10 shadow-black/30'
                    }`}
                >
                    {!isOwn && (
                        <div className="text-[11px] font-bold text-zinc-300 tracking-tight mb-1 flex items-center gap-1.5">
                            <span>{msg.name || 'Anonim'}</span>
                        </div>
                    )}
                    <p className="whitespace-pre-wrap">{msg.message}</p>
                    <div className={`text-[10px] mt-1 float-right ml-2.5 flex items-center gap-1 select-none font-mono ${
                        isOwn ? 'text-zinc-500 font-medium' : 'text-zinc-400'
                    }`}>
                        <span>{msg.time || ''}</span>
                        {isOwn && <span className="font-sans font-bold text-[11px] text-zinc-700">✓✓</span>}
                    </div>
                </div>
            </div>

            {isOwn && (
                <div className="shrink-0 mb-1">
                    <Avatar name={msg.name} photoUrl={msg.photo_url} size="xs" />
                </div>
            )}
        </div>
    );
});

export default function ChatView() {
    const { currentTrack, isFullPlayerOpen } = usePlayer();
    const hasMiniPlayer = Boolean(currentTrack && !isFullPlayerOpen);

    // Auth state (User)
    const [user, setUser] = useState(() => getStoredUser());
    const [token, setToken] = useState(() => getStoredToken());
    const [authTab, setAuthTab] = useState('login'); // 'login' or 'register'
    const [nicknameInput, setNicknameInput] = useState('');
    const [passwordInput, setPasswordInput] = useState('');
    const [photoUrlInput, setPhotoUrlInput] = useState('');
    const [authLoading, setAuthLoading] = useState(false);
    const [authError, setAuthError] = useState('');

    // Messages state
    const [messages, setMessages] = useState([]);
    const [lastId, setLastId] = useState(0);
    const [inputText, setInputText] = useState('');
    const [sending, setSending] = useState(false);
    const [refreshing, setRefreshing] = useState(false);
    const [showEmojiPicker, setShowEmojiPicker] = useState(false);
    const [toast, setToast] = useState(null);

    // Online users state
    const [onlineUsers, setOnlineUsers] = useState([]);
    const [onlineCount, setOnlineCount] = useState(0);
    const [showOnlineModal, setShowOnlineModal] = useState(false);

    // Profile & Settings modal (User)
    const [showProfileModal, setShowProfileModal] = useState(false);
    const [newPhotoUrl, setNewPhotoUrl] = useState('');
    const [oldPassword, setOldPassword] = useState('');
    const [newPassword, setNewPassword] = useState('');
    const [profileLoading, setProfileLoading] = useState(false);

    // -------------------------------------------------------------
    // ADMIN PANEL STATE
    // -------------------------------------------------------------
    const [showAdminPanel, setShowAdminPanel] = useState(false);
    const [adminKey, setAdminKey] = useState(() => getStoredAdminKey());
    const [isAdminAuthed, setIsAdminAuthed] = useState(false);
    const [adminKeyInput, setAdminKeyInput] = useState('');
    const [adminAuthLoading, setAdminAuthLoading] = useState(false);
    const [adminAuthError, setAdminAuthError] = useState('');
    const [adminTab, setAdminTab] = useState('users'); // 'users' or 'reset'

    // Admin Users Management
    const [adminUsers, setAdminUsers] = useState([]);
    const [adminUsersLoading, setAdminUsersLoading] = useState(false);
    const [adminSearchQuery, setAdminSearchQuery] = useState('');

    // Admin Create User Modal
    const [showCreateModal, setShowCreateModal] = useState(false);
    const [createNickname, setCreateNickname] = useState('');
    const [createPassword, setCreatePassword] = useState('');
    const [createPhotoUrl, setCreatePhotoUrl] = useState('');
    const [createLoading, setCreateLoading] = useState(false);

    // Admin Edit User Modal
    const [userToEdit, setUserToEdit] = useState(null);
    const [editPhotoUrl, setEditPhotoUrl] = useState('');
    const [editNewPassword, setEditNewPassword] = useState('');
    const [editLoading, setEditLoading] = useState(false);

    // Admin Delete User Modal
    const [userToDelete, setUserToDelete] = useState(null);
    const [deleteLoading, setDeleteLoading] = useState(false);

    // Admin Reset Chat
    const [resetLoading, setResetLoading] = useState(false);
    const [resetConfirm, setResetConfirm] = useState(false);

    // Scroll helpers
    const messagesEndRef = useRef(null);
    const messageContainerRef = useRef(null);
    const isUserScrolledUp = useRef(false);
    const lastIdRef = useRef(0);
    const isPollingActive = useRef(false);

    const showToast = useCallback((msg, type = 'info') => {
        setToast({ msg, type });
        setTimeout(() => setToast(null), 3500);
    }, []);

    // Auto-scroll logic
    const scrollToBottom = useCallback((smooth = true) => {
        if (messagesEndRef.current) {
            messagesEndRef.current.scrollIntoView({ behavior: smooth ? 'smooth' : 'auto' });
        }
    }, []);

    const handleScroll = useCallback(() => {
        if (!messageContainerRef.current) return;
        const { scrollTop, scrollHeight, clientHeight } = messageContainerRef.current;
        const distanceFromBottom = scrollHeight - scrollTop - clientHeight;
        isUserScrolledUp.current = distanceFromBottom > 120;
    }, []);

    // Fetch messages incrementally with after_id
    const fetchMessages = useCallback(async (isInitial = false) => {
        if (!token) return;
        try {
            const currentAfterId = isInitial ? 0 : lastIdRef.current;
            const res = await ChatApi.getMessages(currentAfterId);

            if (res && res.success) {
                if (Array.isArray(res.messages) && res.messages.length > 0) {
                    setMessages(prev => {
                        if (isInitial) {
                            return res.messages;
                        }
                        const existingIds = new Set(prev.map(m => m.id));
                        const uniqueNew = res.messages.filter(m => !existingIds.has(m.id));
                        if (uniqueNew.length === 0) return prev;
                        return [...prev, ...uniqueNew];
                    });

                    if (res.last_id) {
                        lastIdRef.current = res.last_id;
                        setLastId(res.last_id);
                    }

                    if (!isUserScrolledUp.current) {
                        setTimeout(() => scrollToBottom(true), 50);
                    }
                }
            }
        } catch (err) {
            if (err.message.includes('Token') || err.message.includes('login') || err.message.includes('401')) {
                clearStoredAuth();
                setToken('');
                setUser(null);
                showToast('Sesi Anda telah kedaluwarsa. Silakan login kembali.', 'error');
            }
        }
    }, [token, scrollToBottom, showToast]);

    // Fetch online users
    const fetchOnlineUsers = useCallback(async () => {
        if (!token) return;
        try {
            const res = await ChatApi.getOnline();
            if (res && res.success) {
                setOnlineUsers(res.users || []);
                setOnlineCount(res.count || (res.users ? res.users.length : 0));
            }
        } catch {}
    }, [token]);

    // Polling setup: fetch messages every 2.5s and online users every 15s
    useEffect(() => {
        if (!token) return;

        isPollingActive.current = true;
        lastIdRef.current = 0;
        setMessages([]);
        fetchMessages(true);
        fetchOnlineUsers();

        const msgInterval = setInterval(() => {
            if (isPollingActive.current) {
                fetchMessages(false);
            }
        }, 2500);

        const onlineInterval = setInterval(() => {
            if (isPollingActive.current) {
                fetchOnlineUsers();
            }
        }, 15000);

        return () => {
            isPollingActive.current = false;
            clearInterval(msgInterval);
            clearInterval(onlineInterval);
        };
    }, [token, fetchMessages, fetchOnlineUsers]);

    // Initial scroll on load
    useEffect(() => {
        if (messages.length > 0 && !isUserScrolledUp.current) {
            scrollToBottom(false);
        }
    }, [messages.length, scrollToBottom]);

    // Handle Login / Register Submit
    const handleAuthSubmit = async (e) => {
        e.preventDefault();
        setAuthError('');
        setAuthLoading(true);

        try {
            let res;
            if (authTab === 'login') {
                res = await ChatApi.login({
                    nickname: nicknameInput,
                    password: passwordInput
                });
                showToast(`Selamat datang kembali, ${res.user.nickname}!`, 'success');
            } else {
                res = await ChatApi.register({
                    nickname: nicknameInput,
                    password: passwordInput,
                    photo_url: photoUrlInput
                });
                showToast(`Akun berhasil dibuat! Selamat datang, ${res.user.nickname}!`, 'success');
            }

            setToken(res.token);
            setUser(res.user);
            setNicknameInput('');
            setPasswordInput('');
            setPhotoUrlInput('');
        } catch (err) {
            setAuthError(err.message || 'Terjadi kesalahan saat autentikasi.');
        } finally {
            setAuthLoading(false);
        }
    };

    // Handle Send Message
    const handleSendMessage = async (e) => {
        e?.preventDefault();
        const text = inputText.trim();
        if (!text || sending) return;

        setSending(true);
        setInputText('');
        setShowEmojiPicker(false);

        try {
            const res = await ChatApi.sendMessage(text);
            if (res && res.success && res.message) {
                setMessages(prev => {
                    const exists = prev.some(m => m.id === res.message.id);
                    if (exists) return prev;
                    return [...prev, res.message];
                });
                if (res.message.id) {
                    lastIdRef.current = Math.max(lastIdRef.current, res.message.id);
                    setLastId(lastIdRef.current);
                }
                setTimeout(() => scrollToBottom(true), 40);
            }
        } catch (err) {
            showToast(err.message || 'Gagal mengirim pesan.', 'error');
            setInputText(text);
        } finally {
            setSending(false);
        }
    };

    // Handle Manual Refresh
    const handleManualRefresh = async () => {
        setRefreshing(true);
        await Promise.all([fetchMessages(false), fetchOnlineUsers()]);
        setRefreshing(false);
        showToast('Obrolan diperbarui', 'info');
    };

    // Handle Logout User
    const handleLogout = async () => {
        try {
            await ChatApi.logout();
        } catch {}
        setToken('');
        setUser(null);
        setMessages([]);
        setShowProfileModal(false);
        showToast('Berhasil keluar dari chat.', 'info');
    };

    // Handle Update Profile User
    const handleUpdateProfile = async (e) => {
        e.preventDefault();
        setProfileLoading(true);
        try {
            const res = await ChatApi.updateMe({
                photo_url: newPhotoUrl,
                old_password: oldPassword || undefined,
                new_password: newPassword || undefined
            });
            if (res && res.success) {
                setUser(res.user);
                showToast('Profil berhasil diperbarui.', 'success');
                setShowProfileModal(false);
                setOldPassword('');
                setNewPassword('');
            }
        } catch (err) {
            showToast(err.message || 'Gagal memperbarui profil.', 'error');
        } finally {
            setProfileLoading(false);
        }
    };

    // -------------------------------------------------------------
    // ADMIN FUNCTIONS
    // -------------------------------------------------------------

    // Fetch Admin Users List
    const fetchAdminUsers = useCallback(async (query = '', key = null) => {
        setAdminUsersLoading(true);
        try {
            const res = await ChatApi.adminList(query, key || adminKey);
            if (res && res.success) {
                setAdminUsers(res.users || []);
            }
        } catch (err) {
            showToast(err.message || 'Gagal memuat daftar pengguna.', 'error');
        } finally {
            setAdminUsersLoading(false);
        }
    }, [adminKey, showToast]);

    // Verify Admin Key Login
    const handleAdminLogin = async (e) => {
        e.preventDefault();
        const key = adminKeyInput.trim();
        if (!key) return;

        setAdminAuthLoading(true);
        setAdminAuthError('');

        try {
            const res = await ChatApi.adminList('', key);
            if (res && res.success) {
                setAdminKey(key);
                setStoredAdminKey(key);
                setIsAdminAuthed(true);
                setAdminUsers(res.users || []);
                showToast('Login Admin berhasil!', 'success');
            } else {
                throw new Error(res?.error || 'Admin key tidak valid');
            }
        } catch (err) {
            setAdminAuthError(err.message || 'Admin key salah.');
        } finally {
            setAdminAuthLoading(false);
        }
    };

    // Admin Logout
    const handleAdminLogout = () => {
        clearStoredAdminKey();
        setAdminKey('');
        setIsAdminAuthed(false);
        setAdminUsers([]);
        setAdminKeyInput('');
        setShowAdminPanel(false);
        showToast('Keluar dari sesi Admin.', 'info');
    };

    // Admin Search Users
    const handleAdminSearch = (e) => {
        e.preventDefault();
        fetchAdminUsers(adminSearchQuery);
    };

    // Admin Create User Submit
    const handleAdminCreateUser = async (e) => {
        e.preventDefault();
        if (!createNickname.trim() || !createPassword.trim()) return;

        setCreateLoading(true);
        try {
            const res = await ChatApi.adminCreate({
                nickname: createNickname,
                password: createPassword,
                photo_url: createPhotoUrl
            }, adminKey);

            if (res && res.success) {
                showToast(`Akun ${createNickname} berhasil dibuat!`, 'success');
                setShowCreateModal(false);
                setCreateNickname('');
                setCreatePassword('');
                setCreatePhotoUrl('');
                fetchAdminUsers(adminSearchQuery);
            }
        } catch (err) {
            showToast(err.message || 'Gagal membuat akun.', 'error');
        } finally {
            setCreateLoading(false);
        }
    };

    // Admin Update User Submit
    const handleAdminUpdateUser = async (e) => {
        e.preventDefault();
        if (!userToEdit) return;

        setEditLoading(true);
        try {
            const res = await ChatApi.adminUpdate({
                nickname: userToEdit.nickname,
                photo_url: editPhotoUrl,
                new_password: editNewPassword || undefined
            }, adminKey);

            if (res && res.success) {
                showToast(`Akun ${userToEdit.nickname} berhasil diperbarui!`, 'success');
                setUserToEdit(null);
                setEditPhotoUrl('');
                setEditNewPassword('');
                fetchAdminUsers(adminSearchQuery);
            }
        } catch (err) {
            showToast(err.message || 'Gagal memperbarui akun.', 'error');
        } finally {
            setEditLoading(false);
        }
    };

    // Admin Delete User Submit
    const handleAdminDeleteUser = async () => {
        if (!userToDelete) return;

        setDeleteLoading(true);
        try {
            const res = await ChatApi.adminDelete(userToDelete.nickname, adminKey);
            if (res && res.success) {
                showToast(`Akun ${userToDelete.nickname} berhasil dihapus!`, 'success');
                setUserToDelete(null);
                fetchAdminUsers(adminSearchQuery);
            }
        } catch (err) {
            showToast(err.message || 'Gagal menghapus akun.', 'error');
        } finally {
            setDeleteLoading(false);
        }
    };

    // Admin Reset Chat Submit
    const handleAdminResetChat = async () => {
        setResetLoading(true);
        try {
            const res = await ChatApi.reset(adminKey);
            showToast(res.message || 'Seluruh riwayat chat berhasil direset.', 'success');
            setMessages([]);
            lastIdRef.current = 0;
            setLastId(0);
            setResetConfirm(false);
        } catch (err) {
            showToast(err.message || 'Gagal mereset chat. Periksa admin key.', 'error');
        } finally {
            setResetLoading(false);
        }
    };

    // Auto-check stored admin key on modal open
    const openAdminPanel = () => {
        setShowAdminPanel(true);
        const storedKey = getStoredAdminKey();
        if (storedKey) {
            setAdminKey(storedKey);
            ChatApi.adminList('', storedKey)
                .then(res => {
                    if (res && res.success) {
                        setIsAdminAuthed(true);
                        setAdminUsers(res.users || []);
                    } else {
                        setIsAdminAuthed(false);
                    }
                })
                .catch(() => setIsAdminAuthed(false));
        } else {
            setIsAdminAuthed(false);
        }
    };

    const emojis = ['👍', '🔥', '❤️', '🎵', '😂', '✨', '🎧', '🙌', '😎', '👏', '🚀', '💯'];

    // -------------------------------------------------------------
    // RENDER: Not logged in (Login / Register view)
    // -------------------------------------------------------------
    if (!token) {
        return (
            <div className={`flex-1 w-full flex flex-col items-center justify-center p-4 py-8 overflow-y-auto hide-scrollbar animate-fadeIn transition-all duration-300 ${
                hasMiniPlayer ? 'pb-44 sm:pb-48' : 'pb-24 sm:pb-28'
            }`}>
                {/* Toast Notification */}
                {toast && (
                    <div
                        className={`fixed top-4 left-1/2 -translate-x-1/2 z-[300] px-4 py-2 rounded-2xl text-xs font-semibold shadow-2xl backdrop-blur-xl border flex items-center gap-2 animate-bounce-short ${
                            toast.type === 'error'
                                ? 'bg-red-950/90 text-red-100 border-red-500/40'
                                : toast.type === 'success'
                                    ? 'bg-zinc-900/90 text-white border-white/30'
                                    : 'bg-black/90 text-zinc-200 border-white/20'
                        }`}
                    >
                        {toast.type === 'error' ? (
                            <AlertCircle className="w-4 h-4 text-red-400" />
                        ) : (
                            <CheckCircle2 className="w-4 h-4 text-zinc-300" />
                        )}
                        <span>{toast.msg}</span>
                    </div>
                )}

                <div className="w-full max-w-md bg-zinc-950/90 backdrop-blur-2xl border border-white/15 rounded-3xl p-6 sm:p-8 shadow-2xl relative overflow-hidden">
                    {/* Background glow monochromatic */}
                    <div className="absolute -top-24 -left-24 w-48 h-48 bg-white/5 rounded-full blur-3xl pointer-events-none"></div>
                    <div className="absolute -bottom-24 -right-24 w-48 h-48 bg-white/5 rounded-full blur-3xl pointer-events-none"></div>

                    {/* Header */}
                    <div className="text-center mb-6 relative z-10">
                        <div className="w-14 h-14 rounded-2xl bg-zinc-900 border border-white/20 flex items-center justify-center mx-auto mb-3 shadow-xl shadow-black/50">
                            <MessageSquare className="w-7 h-7 text-white" />
                        </div>
                        <h2 className="text-2xl font-black text-white tracking-tight">
                            <ShinyText text="Global Chat v2" speed={3} className="text-white font-extrabold" />
                        </h2>
                        <p className="text-xs text-zinc-400 mt-1.5 leading-relaxed">
                            Ruang obrolan publik NanzMusify. Masuk atau daftar akun untuk mulai berinteraksi dengan pendengar lainnya.
                        </p>
                        <div className="inline-flex items-center gap-1.5 px-3 py-1 mt-3 rounded-full bg-white/5 border border-white/10 text-[11px] text-zinc-400 font-mono">
                            <Clock className="w-3.5 h-3.5 text-zinc-300" />
                            <span>Reset otomatis tiap 00:00 WIB</span>
                        </div>
                    </div>

                    {/* Auth Tab Switcher */}
                    <div className="flex p-1 bg-zinc-900 border border-white/10 rounded-2xl mb-5 relative z-10">
                        <button
                            type="button"
                            onClick={() => { setAuthTab('login'); setAuthError(''); }}
                            className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer ${
                                authTab === 'login'
                                    ? 'bg-white text-black shadow-md'
                                    : 'text-zinc-400 hover:text-white'
                            }`}
                        >
                            Masuk (Login)
                        </button>
                        <button
                            type="button"
                            onClick={() => { setAuthTab('register'); setAuthError(''); }}
                            className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer ${
                                authTab === 'register'
                                    ? 'bg-white text-black shadow-md'
                                    : 'text-zinc-400 hover:text-white'
                            }`}
                        >
                            Daftar Akun
                        </button>
                    </div>

                    {/* Error Banner */}
                    {authError && (
                        <div className="mb-4 p-3 bg-red-950/40 border border-red-500/30 rounded-2xl flex items-center gap-2.5 text-xs text-red-200 animate-shake relative z-10">
                            <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
                            <span>{authError}</span>
                        </div>
                    )}

                    {/* Auth Form */}
                    <form onSubmit={handleAuthSubmit} className="space-y-3.5 relative z-10">
                        <div>
                            <label className="block text-xs font-semibold text-zinc-300 mb-1.5">
                                Nama Panggilan (Nickname)
                            </label>
                            <div className="relative">
                                <User className="w-4 h-4 text-zinc-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
                                <input
                                    type="text"
                                    value={nicknameInput}
                                    onChange={(e) => setNicknameInput(e.target.value)}
                                    placeholder="Contoh: Budi, MusicFan, Alex"
                                    required
                                    minLength={3}
                                    maxLength={20}
                                    className="w-full pl-10 pr-4 py-2.5 bg-zinc-900/80 border border-white/15 focus:border-white rounded-xl text-white placeholder-zinc-500 text-sm focus:outline-none focus:ring-2 focus:ring-white/20 transition-all font-medium"
                                />
                            </div>
                        </div>

                        <div>
                            <label className="block text-xs font-semibold text-zinc-300 mb-1.5">
                                Katasandi (Password)
                            </label>
                            <div className="relative">
                                <Lock className="w-4 h-4 text-zinc-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
                                <input
                                    type="password"
                                    value={passwordInput}
                                    onChange={(e) => setPasswordInput(e.target.value)}
                                    placeholder="Minimal 6 karakter"
                                    required
                                    minLength={6}
                                    maxLength={72}
                                    className="w-full pl-10 pr-4 py-2.5 bg-zinc-900/80 border border-white/15 focus:border-white rounded-xl text-white placeholder-zinc-500 text-sm focus:outline-none focus:ring-2 focus:ring-white/20 transition-all font-medium"
                                />
                            </div>
                        </div>

                        {authTab === 'register' && (
                            <div>
                                <label className="block text-xs font-semibold text-zinc-300 mb-1.5">
                                    URL Foto Profil <span className="text-zinc-500 font-normal">(Opsional)</span>
                                </label>
                                <div className="relative">
                                    <ImageIcon className="w-4 h-4 text-zinc-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
                                    <input
                                        type="url"
                                        value={photoUrlInput}
                                        onChange={(e) => setPhotoUrlInput(e.target.value)}
                                        placeholder="https://example.com/avatar.jpg"
                                        maxLength={300}
                                        className="w-full pl-10 pr-4 py-2.5 bg-zinc-900/80 border border-white/15 focus:border-white rounded-xl text-white placeholder-zinc-500 text-sm focus:outline-none focus:ring-2 focus:ring-white/20 transition-all font-medium"
                                    />
                                </div>
                            </div>
                        )}

                        <button
                            type="submit"
                            disabled={authLoading || !nicknameInput.trim() || !passwordInput.trim()}
                            className="w-full mt-2 py-3 bg-white text-black hover:bg-zinc-200 disabled:opacity-40 disabled:cursor-not-allowed font-bold rounded-2xl shadow-xl shadow-black/40 active:scale-98 transition-all flex items-center justify-center gap-2 cursor-pointer border border-white"
                        >
                            {authLoading ? (
                                <>
                                    <RefreshCw className="w-4 h-4 animate-spin text-black" />
                                    <span>Memproses...</span>
                                </>
                            ) : (
                                <>
                                    <span>{authTab === 'login' ? 'Masuk ke Chat' : 'Daftar & Masuk Sekarang'}</span>
                                    <Sparkles className="w-4 h-4 text-black" />
                                </>
                            )}
                        </button>
                    </form>

                    {/* Bottom Links: Info & Admin Access */}
                    <div className="mt-5 pt-4 border-t border-white/10 flex items-center justify-between text-[11px] text-zinc-500">
                        <span>Akun aman & privat</span>
                        <button
                            type="button"
                            onClick={openAdminPanel}
                            className="text-zinc-400 hover:text-white flex items-center gap-1 font-semibold transition cursor-pointer"
                        >
                            <ShieldAlert className="w-3.5 h-3.5 text-zinc-400" />
                            <span>Admin Panel</span>
                        </button>
                    </div>
                </div>

                {/* Render Admin Panel Modal when opened from login view */}
                {showAdminPanel && renderAdminPanelModal()}
            </div>
        );
    }

    // -------------------------------------------------------------
    // RENDER: Logged in (Active Chat Room)
    // -------------------------------------------------------------
    return (
        <div className={`flex-1 flex flex-col w-full h-full max-w-4xl mx-auto px-2 sm:px-4 pt-1.5 relative overflow-hidden transition-all duration-300 ${
            hasMiniPlayer ? 'pb-[164px] sm:pb-[172px]' : 'pb-20 sm:pb-24'
        }`}>
            {/* Toast Notification */}
            {toast && (
                <div
                    className={`fixed top-4 left-1/2 -translate-x-1/2 z-[300] px-4 py-2 rounded-2xl text-xs font-semibold shadow-2xl backdrop-blur-xl border flex items-center gap-2 animate-bounce-short ${
                        toast.type === 'error'
                            ? 'bg-red-950/90 text-red-100 border-red-500/40'
                            : toast.type === 'success'
                                ? 'bg-zinc-900/90 text-white border-white/30'
                                : 'bg-black/90 text-zinc-200 border-white/20'
                    }`}
                >
                    {toast.type === 'error' ? (
                        <AlertCircle className="w-4 h-4 text-red-400" />
                    ) : (
                        <CheckCircle2 className="w-4 h-4 text-zinc-300" />
                    )}
                    <span>{toast.msg}</span>
                </div>
            )}

            {/* Chat Room Header */}
            <header className="flex items-center justify-between px-3.5 py-2.5 bg-zinc-950/80 backdrop-blur-xl border border-white/10 rounded-2xl shadow-xl shrink-0 mb-2 gap-2">
                {/* User info & Online badge */}
                <div className="flex items-center gap-2.5 min-w-0">
                    <button
                        type="button"
                        onClick={() => {
                            setNewPhotoUrl(user?.photo_url || '');
                            setShowProfileModal(true);
                        }}
                        className="flex items-center gap-2.5 p-1 pr-3 rounded-full hover:bg-white/10 transition-all text-left group cursor-pointer border border-white/10 bg-white/5"
                        title="Profil & Pengaturan Akun"
                    >
                        <div className="relative">
                            <Avatar name={user?.nickname} photoUrl={user?.photo_url} size="sm" />
                            <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-emerald-400 border-2 border-black rounded-full"></span>
                        </div>
                        <div className="min-w-0 truncate">
                            <p className="text-xs font-bold text-white truncate group-hover:text-zinc-200">
                                {user?.nickname || 'Pengguna'}
                            </p>
                            <p className="text-[10px] text-zinc-400 truncate">Atur Profil</p>
                        </div>
                    </button>

                    <button
                        type="button"
                        onClick={() => setShowOnlineModal(true)}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-semibold text-zinc-300 transition-all cursor-pointer"
                        title="Daftar Pengguna Online"
                    >
                        <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                        <span>{onlineCount > 0 ? `${onlineCount} Online` : 'Online'}</span>
                    </button>
                </div>

                {/* Action buttons */}
                <div className="flex items-center gap-1.5 shrink-0">
                    <button
                        type="button"
                        onClick={handleManualRefresh}
                        disabled={refreshing}
                        className="p-2 rounded-xl text-zinc-400 hover:text-white hover:bg-white/10 active:scale-95 transition cursor-pointer border border-transparent hover:border-white/10"
                        title="Perbarui Pesan"
                    >
                        <RefreshCw className={`w-4 h-4 ${refreshing ? 'animate-spin text-white' : ''}`} />
                    </button>

                    {/* Admin Panel Button */}
                    <button
                        type="button"
                        onClick={openAdminPanel}
                        className="p-2 rounded-xl text-zinc-400 hover:text-white hover:bg-white/10 active:scale-95 transition cursor-pointer border border-transparent hover:border-white/10"
                        title="Admin Panel"
                    >
                        <ShieldAlert className="w-4 h-4" />
                    </button>

                    <button
                        type="button"
                        onClick={handleLogout}
                        className="p-2 rounded-xl text-zinc-400 hover:text-white hover:bg-white/10 active:scale-95 transition cursor-pointer border border-transparent hover:border-white/10"
                        title="Keluar (Logout)"
                    >
                        <LogOut className="w-4 h-4" />
                    </button>
                </div>
            </header>

            {/* Message Stream Area */}
            <div
                ref={messageContainerRef}
                onScroll={handleScroll}
                className="flex-1 w-full overflow-y-auto px-3 sm:px-4 py-3 space-y-2.5 rounded-3xl bg-zinc-950/40 border border-white/10 backdrop-blur-xl shadow-inner hide-scrollbar"
            >
                {/* Date / Reset notice pill */}
                <div className="flex justify-center my-2">
                    <span className="px-3.5 py-1 rounded-full bg-zinc-900/90 border border-white/10 text-[11px] text-zinc-400 font-medium shadow-md backdrop-blur-md">
                        🔒 Chat Publik · Reset otomatis tiap 00:00 WIB
                    </span>
                </div>

                {messages.length === 0 ? (
                    <div className="h-full min-h-[220px] flex flex-col items-center justify-center text-center p-6 text-zinc-500 space-y-3">
                        <div className="w-14 h-14 rounded-3xl bg-zinc-900/90 border border-white/10 flex items-center justify-center text-zinc-300 shadow-xl">
                            <MessageSquare className="w-7 h-7" />
                        </div>
                        <div>
                            <p className="text-sm font-bold text-white">Belum ada obrolan hari ini</p>
                            <p className="text-xs text-zinc-400 max-w-xs mt-1 leading-relaxed">
                                Jadilah yang pertama menyapa di Global Chat! Obrolan direset setiap tengah malam (00:00 WIB).
                            </p>
                        </div>
                        <div className="flex flex-wrap justify-center gap-2 pt-1">
                            {['Halo semua! 👋', 'Lagi dengerin apa nih? 🎵', 'Mantap lagunya! 🔥'].map((sug, idx) => (
                                <button
                                    key={idx}
                                    type="button"
                                    onClick={() => setInputText(sug)}
                                    className="px-3 py-1.5 rounded-full bg-white/5 hover:bg-white/15 border border-white/10 text-[11px] text-zinc-300 transition active:scale-95 cursor-pointer"
                                >
                                    {sug}
                                </button>
                            ))}
                        </div>
                    </div>
                ) : (
                    messages.map((msg) => {
                        const isOwn = !!msg.mine || (user && msg.name?.toLowerCase() === user.nickname?.toLowerCase());
                        return <MessageBubble key={msg.id} msg={msg} isOwn={isOwn} />;
                    })
                )}
                <div ref={messagesEndRef} className="h-1"></div>
            </div>

            {/* Emoji Quick Picker Drawer */}
            {showEmojiPicker && (
                <div className="mt-1.5 p-2 bg-zinc-950/95 border border-white/15 rounded-2xl shadow-2xl flex items-center justify-around gap-1 shrink-0 backdrop-blur-2xl animate-fadeIn">
                    {emojis.map((emoji) => (
                        <button
                            key={emoji}
                            type="button"
                            onClick={() => setInputText(prev => prev + emoji)}
                            className="p-2 text-base hover:bg-white/10 rounded-xl active:scale-90 transition cursor-pointer"
                        >
                            {emoji}
                        </button>
                    ))}
                    <button
                        type="button"
                        onClick={() => setShowEmojiPicker(false)}
                        className="p-2 text-zinc-400 hover:text-white rounded-xl cursor-pointer"
                    >
                        <X className="w-4 h-4" />
                    </button>
                </div>
            )}

            {/* Input Bar Form */}
            <form onSubmit={handleSendMessage} className="shrink-0 mt-2">
                <div className="bg-zinc-950/90 backdrop-blur-2xl border border-white/15 rounded-full p-1.5 sm:p-2 shadow-2xl flex items-center gap-1.5 sm:gap-2">
                    <button
                        type="button"
                        onClick={() => setShowEmojiPicker(!showEmojiPicker)}
                        className="w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-white/5 hover:bg-white/15 text-zinc-400 hover:text-white flex items-center justify-center transition active:scale-95 cursor-pointer shrink-0"
                        title="Pilih Emoji"
                    >
                        <Smile className="w-5 h-5" />
                    </button>

                    <input
                        type="text"
                        value={inputText}
                        onChange={(e) => setInputText(e.target.value)}
                        placeholder="Ketik pesan ke chat global..."
                        maxLength={500}
                        className="flex-1 bg-transparent border-0 text-white placeholder-zinc-500 text-sm focus:outline-none px-2 font-normal"
                    />

                    {inputText && (
                        <button
                            type="button"
                            onClick={() => setInputText('')}
                            className="p-1.5 text-zinc-500 hover:text-zinc-200 rounded-full hover:bg-white/5 cursor-pointer shrink-0"
                        >
                            <X className="w-4 h-4" />
                        </button>
                    )}

                    <button
                        type="submit"
                        disabled={sending || !inputText.trim()}
                        className="w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-white text-black hover:bg-zinc-200 disabled:opacity-30 disabled:cursor-not-allowed font-semibold flex items-center justify-center transition active:scale-95 shadow-lg shadow-white/20 cursor-pointer shrink-0 border border-white"
                        title="Kirim Pesan"
                    >
                        {sending ? (
                            <RefreshCw className="w-4 h-4 animate-spin text-black" />
                        ) : (
                            <Send className="w-4 h-4 text-black ml-0.5" />
                        )}
                    </button>
                </div>
            </form>

            {/* Online Users Modal */}
            {showOnlineModal && (
                <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
                    <div className="w-full max-w-sm bg-zinc-900 border border-white/20 rounded-3xl p-6 shadow-2xl relative">
                        <button
                            onClick={() => setShowOnlineModal(false)}
                            className="absolute top-4 right-4 text-zinc-400 hover:text-white p-1.5 rounded-full hover:bg-white/10 cursor-pointer"
                        >
                            <X className="w-5 h-5" />
                        </button>

                        <div className="flex items-center gap-3 mb-4">
                            <div className="w-10 h-10 rounded-2xl bg-white/10 border border-white/20 flex items-center justify-center text-white">
                                <Users className="w-5 h-5" />
                            </div>
                            <div>
                                <h3 className="text-base font-bold text-white">Pengguna Online</h3>
                                <p className="text-xs text-zinc-400">Aktif dalam 60 detik terakhir</p>
                            </div>
                        </div>

                        <div className="max-h-60 overflow-y-auto space-y-2 py-2 pr-1 hide-scrollbar">
                            {onlineUsers.length === 0 ? (
                                <p className="text-xs text-zinc-500 text-center py-4">Tidak ada pengguna lain yang sedang aktif.</p>
                            ) : (
                                onlineUsers.map((u, i) => (
                                    <div
                                        key={i}
                                        className="flex items-center gap-3 p-2.5 rounded-2xl bg-white/5 border border-white/10"
                                    >
                                        <Avatar name={u.nickname} photoUrl={u.photo_url} size="sm" />
                                        <div className="min-w-0 flex-1">
                                            <p className="text-xs font-bold text-white truncate">{u.nickname}</p>
                                            <p className="text-[10px] text-zinc-400">Online</p>
                                        </div>
                                        <span className="w-2 h-2 rounded-full bg-white animate-pulse"></span>
                                    </div>
                                ))
                            )}
                        </div>

                        <button
                            type="button"
                            onClick={() => setShowOnlineModal(false)}
                            className="w-full mt-4 py-2.5 bg-white text-black font-bold rounded-xl text-xs hover:bg-zinc-200 transition cursor-pointer"
                        >
                            Tutup
                        </button>
                    </div>
                </div>
            )}

            {/* Profile & Settings Modal */}
            {showProfileModal && (
                <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
                    <div className="w-full max-w-sm bg-zinc-900 border border-white/20 rounded-3xl p-6 shadow-2xl relative">
                        <button
                            onClick={() => setShowProfileModal(false)}
                            className="absolute top-4 right-4 text-zinc-400 hover:text-white p-1.5 rounded-full hover:bg-white/10 cursor-pointer"
                        >
                            <X className="w-5 h-5" />
                        </button>

                        <div className="flex items-center gap-3 mb-5">
                            <Avatar name={user?.nickname} photoUrl={user?.photo_url} size="lg" />
                            <div className="min-w-0 flex-1">
                                <h3 className="text-lg font-bold text-white truncate">{user?.nickname}</h3>
                                <p className="text-xs text-zinc-400">Akun Terverifikasi</p>
                            </div>
                        </div>

                        <form onSubmit={handleUpdateProfile} className="space-y-3.5">
                            <div>
                                <label className="block text-xs font-medium text-zinc-300 mb-1">
                                    URL Foto Profil Baru
                                </label>
                                <input
                                    type="url"
                                    value={newPhotoUrl}
                                    onChange={(e) => setNewPhotoUrl(e.target.value)}
                                    placeholder="https://example.com/avatar.jpg"
                                    className="w-full px-3 py-2 bg-white/5 border border-white/15 focus:border-white rounded-xl text-white placeholder-zinc-500 text-xs focus:outline-none focus:ring-2 focus:ring-white/20"
                                />
                                <span className="text-[10px] text-zinc-500 block mt-1">Kosongkan untuk menghapus foto profil</span>
                            </div>

                            <div className="pt-2 border-t border-white/10">
                                <p className="text-xs font-semibold text-white mb-2">Ganti Katasandi (Opsional)</p>
                                <div className="space-y-2">
                                    <input
                                        type="password"
                                        value={oldPassword}
                                        onChange={(e) => setOldPassword(e.target.value)}
                                        placeholder="Katasandi Lama"
                                        className="w-full px-3 py-2 bg-white/5 border border-white/15 focus:border-white rounded-xl text-white placeholder-zinc-500 text-xs focus:outline-none focus:ring-2 focus:ring-white/20"
                                    />
                                    <input
                                        type="password"
                                        value={newPassword}
                                        onChange={(e) => setNewPassword(e.target.value)}
                                        placeholder="Katasandi Baru (min. 6 karakter)"
                                        className="w-full px-3 py-2 bg-white/5 border border-white/15 focus:border-white rounded-xl text-white placeholder-zinc-500 text-xs focus:outline-none focus:ring-2 focus:ring-white/20"
                                    />
                                </div>
                            </div>

                            <div className="flex items-center gap-2 pt-3">
                                <button
                                    type="button"
                                    onClick={handleLogout}
                                    className="flex-1 py-2.5 rounded-xl border border-white/15 text-zinc-300 text-xs font-semibold hover:bg-white/10 transition cursor-pointer"
                                >
                                    Keluar
                                </button>
                                <button
                                    type="submit"
                                    disabled={profileLoading}
                                    className="flex-1 py-2.5 rounded-xl bg-white text-black font-bold text-xs hover:bg-zinc-200 transition shadow-lg flex items-center justify-center gap-1 cursor-pointer"
                                >
                                    {profileLoading ? <RefreshCw className="w-3.5 h-3.5 animate-spin text-black" /> : 'Simpan'}
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}

            {/* Admin Panel Modal */}
            {showAdminPanel && renderAdminPanelModal()}
        </div>
    );

    // -------------------------------------------------------------
    // RENDER: ADMIN CONTROL PANEL MODAL (Users Management & Reset)
    // -------------------------------------------------------------
    function renderAdminPanelModal() {
        return (
            <div className="fixed inset-0 z-[200] flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-md animate-fadeIn">
                <div className="w-full max-w-2xl bg-zinc-950 border border-white/20 rounded-3xl shadow-2xl flex flex-col max-h-[90vh] overflow-hidden relative">
                    {/* Header */}
                    <div className="flex items-center justify-between px-5 py-4 border-b border-white/10 shrink-0 bg-zinc-900/60">
                        <div className="flex items-center gap-2.5">
                            <div className="w-9 h-9 rounded-xl bg-white/10 border border-white/20 flex items-center justify-center text-white">
                                <ShieldAlert className="w-5 h-5" />
                            </div>
                            <div>
                                <h3 className="text-base font-bold text-white flex items-center gap-2">
                                    <span>Admin Control Panel</span>
                                    {isAdminAuthed && (
                                        <span className="px-2 py-0.5 rounded-full bg-white text-black text-[10px] font-black uppercase tracking-wider">
                                            Admin
                                        </span>
                                    )}
                                </h3>
                                <p className="text-[11px] text-zinc-400">
                                    {isAdminAuthed ? 'Kelola akun user & reset database pesan' : 'Masukkan Secret Key untuk membuka kontrol penuh'}
                                </p>
                            </div>
                        </div>

                        <div className="flex items-center gap-2">
                            {isAdminAuthed && (
                                <button
                                    type="button"
                                    onClick={handleAdminLogout}
                                    className="px-3 py-1.5 rounded-xl border border-white/15 text-zinc-300 hover:text-white text-xs font-semibold hover:bg-white/10 transition cursor-pointer flex items-center gap-1.5"
                                    title="Keluar Admin"
                                >
                                    <LogOut className="w-3.5 h-3.5" />
                                    <span className="hidden sm:inline">Keluar</span>
                                </button>
                            )}
                            <button
                                type="button"
                                onClick={() => setShowAdminPanel(false)}
                                className="text-zinc-400 hover:text-white p-1.5 rounded-full hover:bg-white/10 cursor-pointer"
                            >
                                <X className="w-5 h-5" />
                            </button>
                        </div>
                    </div>

                    {/* CONTENT BODY */}
                    {!isAdminAuthed ? (
                        /* Admin Key Login Form */
                        <div className="p-6 sm:p-8 flex flex-col items-center justify-center text-center">
                            <div className="w-14 h-14 rounded-2xl bg-white/5 border border-white/15 flex items-center justify-center mb-4 text-white">
                                <Key className="w-7 h-7" />
                            </div>
                            <h4 className="text-lg font-bold text-white mb-1">Verifikasi Akses Admin</h4>
                            <p className="text-xs text-zinc-400 max-w-sm mb-6 leading-relaxed">
                                Fitur admin memungkinkan Anda mengelola seluruh akun pengguna (buat, ubah, hapus) serta mengosongkan riwayat obrolan publik.
                            </p>

                            {adminAuthError && (
                                <div className="w-full max-w-md mb-4 p-3 bg-red-950/40 border border-red-500/30 rounded-xl flex items-center gap-2 text-xs text-red-200">
                                    <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
                                    <span>{adminAuthError}</span>
                                </div>
                            )}

                            <form onSubmit={handleAdminLogin} className="w-full max-w-md space-y-4">
                                <div className="text-left">
                                    <label className="block text-xs font-semibold text-zinc-300 mb-1.5">
                                        Admin Secret Key
                                    </label>
                                    <input
                                        type="password"
                                        value={adminKeyInput}
                                        onChange={(e) => setAdminKeyInput(e.target.value)}
                                        placeholder="Masukkan KEY_KAMU..."
                                        autoFocus
                                        required
                                        className="w-full px-4 py-2.5 bg-zinc-900 border border-white/15 focus:border-white rounded-xl text-white placeholder-zinc-500 text-sm focus:outline-none focus:ring-2 focus:ring-white/20 transition-all font-mono"
                                    />
                                </div>

                                <button
                                    type="submit"
                                    disabled={adminAuthLoading || !adminKeyInput.trim()}
                                    className="w-full py-3 bg-white text-black hover:bg-zinc-200 disabled:opacity-40 disabled:cursor-not-allowed font-bold rounded-xl shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer border border-white"
                                >
                                    {adminAuthLoading ? (
                                        <>
                                            <RefreshCw className="w-4 h-4 animate-spin text-black" />
                                            <span>Memverifikasi...</span>
                                        </>
                                    ) : (
                                        <>
                                            <span>Buka Kontrol Admin</span>
                                            <ShieldCheck className="w-4 h-4 text-black" />
                                        </>
                                    )}
                                </button>
                            </form>
                        </div>
                    ) : (
                        /* Authenticated Admin Dashboard */
                        <div className="flex-1 flex flex-col min-h-0 overflow-hidden">
                            {/* Tabs Switcher: Users vs Reset */}
                            <div className="flex items-center px-5 pt-3 pb-2 gap-2 border-b border-white/10 shrink-0 bg-zinc-900/30">
                                <button
                                    type="button"
                                    onClick={() => setAdminTab('users')}
                                    className={`px-4 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                                        adminTab === 'users'
                                            ? 'bg-white text-black shadow-md'
                                            : 'text-zinc-400 hover:text-white hover:bg-white/5'
                                    }`}
                                >
                                    <Users className="w-3.5 h-3.5" />
                                    <span>Kelola User ({adminUsers.length})</span>
                                </button>

                                <button
                                    type="button"
                                    onClick={() => setAdminTab('reset')}
                                    className={`px-4 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                                        adminTab === 'reset'
                                            ? 'bg-white text-black shadow-md'
                                            : 'text-zinc-400 hover:text-white hover:bg-white/5'
                                    }`}
                                >
                                    <Trash2 className="w-3.5 h-3.5" />
                                    <span>Reset Obrolan</span>
                                </button>
                            </div>

                            {/* TAB 1: USERS MANAGEMENT */}
                            {adminTab === 'users' && (
                                <div className="flex-1 flex flex-col min-h-0 p-4 sm:p-5 overflow-hidden">
                                    {/* Action Bar: Search & Add User */}
                                    <div className="flex items-center justify-between gap-2.5 mb-3 shrink-0">
                                        <form onSubmit={handleAdminSearch} className="flex-1 relative">
                                            <Search className="w-4 h-4 text-zinc-500 absolute left-3 top-1/2 -translate-y-1/2" />
                                            <input
                                                type="text"
                                                value={adminSearchQuery}
                                                onChange={(e) => setAdminSearchQuery(e.target.value)}
                                                placeholder="Cari berdasarkan nickname..."
                                                className="w-full pl-9 pr-3 py-2 bg-zinc-900 border border-white/10 focus:border-white rounded-xl text-xs text-white placeholder-zinc-500 focus:outline-none"
                                            />
                                        </form>

                                        <button
                                            type="button"
                                            onClick={() => fetchAdminUsers(adminSearchQuery)}
                                            disabled={adminUsersLoading}
                                            className="p-2 bg-zinc-900 hover:bg-zinc-800 text-zinc-300 hover:text-white border border-white/10 rounded-xl transition cursor-pointer"
                                            title="Segarkan data user"
                                        >
                                            <RefreshCw className={`w-4 h-4 ${adminUsersLoading ? 'animate-spin' : ''}`} />
                                        </button>

                                        <button
                                            type="button"
                                            onClick={() => setShowCreateModal(true)}
                                            className="px-3.5 py-2 bg-white text-black hover:bg-zinc-200 text-xs font-bold rounded-xl transition flex items-center gap-1.5 shadow-md shrink-0 cursor-pointer"
                                        >
                                            <UserPlus className="w-4 h-4 text-black" />
                                            <span>Tambah User</span>
                                        </button>
                                    </div>

                                    {/* Users List Container */}
                                    <div className="flex-1 overflow-y-auto space-y-2 pr-1 hide-scrollbar min-h-0 border border-white/10 rounded-2xl p-2 bg-zinc-900/30">
                                        {adminUsersLoading ? (
                                            <div className="py-12 flex flex-col items-center justify-center text-zinc-400 gap-2">
                                                <RefreshCw className="w-6 h-6 animate-spin" />
                                                <span className="text-xs">Memuat akun pengguna...</span>
                                            </div>
                                        ) : adminUsers.length === 0 ? (
                                            <div className="py-12 flex flex-col items-center justify-center text-zinc-500 text-center">
                                                <Users className="w-8 h-8 mb-2 opacity-50" />
                                                <p className="text-xs font-semibold text-zinc-400">Tidak ada pengguna ditemukan</p>
                                                <p className="text-[11px] text-zinc-500">Coba ubah kata kunci pencarian atau tambah akun baru.</p>
                                            </div>
                                        ) : (
                                            adminUsers.map((u) => {
                                                const createdAtDate = u.created_at
                                                    ? new Date(u.created_at * 1000).toLocaleString('id-ID', {
                                                          dateStyle: 'short',
                                                          timeStyle: 'short'
                                                      })
                                                    : '-';
                                                return (
                                                    <div
                                                        key={u.nickname}
                                                        className="flex items-center justify-between p-3 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 transition-all gap-3"
                                                    >
                                                        <div className="flex items-center gap-3 min-w-0 flex-1">
                                                            <Avatar name={u.nickname} photoUrl={u.photo_url} size="md" />
                                                            <div className="min-w-0 flex-1">
                                                                <p className="text-xs font-bold text-white truncate">{u.nickname}</p>
                                                                <p className="text-[10px] text-zinc-400 truncate">
                                                                    Dibuat: {createdAtDate}
                                                                </p>
                                                            </div>
                                                        </div>

                                                        {/* Action Buttons */}
                                                        <div className="flex items-center gap-1.5 shrink-0">
                                                            <button
                                                                type="button"
                                                                onClick={() => {
                                                                    setUserToEdit(u);
                                                                    setEditPhotoUrl(u.photo_url || '');
                                                                    setEditNewPassword('');
                                                                }}
                                                                className="p-2 rounded-lg bg-white/10 hover:bg-white/20 text-zinc-200 hover:text-white transition cursor-pointer"
                                                                title="Ubah Foto / Katasandi"
                                                            >
                                                                <Edit3 className="w-3.5 h-3.5" />
                                                            </button>

                                                            <button
                                                                type="button"
                                                                onClick={() => setUserToDelete(u)}
                                                                className="p-2 rounded-lg bg-red-950/40 hover:bg-red-900/60 border border-red-500/20 text-red-200 hover:text-red-100 transition cursor-pointer"
                                                                title="Hapus Akun"
                                                            >
                                                                <Trash2 className="w-3.5 h-3.5" />
                                                            </button>
                                                        </div>
                                                    </div>
                                                );
                                            })
                                        )}
                                    </div>
                                </div>
                            )}

                            {/* TAB 2: RESET CHAT */}
                            {adminTab === 'reset' && (
                                <div className="p-6 flex flex-col items-center justify-center text-center flex-1">
                                    <div className="w-14 h-14 rounded-2xl bg-red-950/30 border border-red-500/30 flex items-center justify-center mb-4 text-red-300">
                                        <AlertTriangle className="w-7 h-7" />
                                    </div>

                                    <h4 className="text-lg font-bold text-white mb-1">Reset Database Obrolan</h4>
                                    <p className="text-xs text-zinc-400 max-w-sm mb-6 leading-relaxed">
                                        Aksi ini akan menghapus **semua pesan obrolan global** saat ini secara permanen. Akun pengguna tidak akan terhapus.
                                    </p>

                                    {!resetConfirm ? (
                                        <button
                                            type="button"
                                            onClick={() => setResetConfirm(true)}
                                            className="px-6 py-3 bg-red-600 hover:bg-red-500 text-white font-bold rounded-xl text-xs shadow-lg transition active:scale-95 cursor-pointer flex items-center gap-2"
                                        >
                                            <Trash2 className="w-4 h-4" />
                                            <span>Mulai Proses Reset Obrolan</span>
                                        </button>
                                    ) : (
                                        <div className="w-full max-w-sm p-4 bg-zinc-900 border border-red-500/40 rounded-2xl space-y-3">
                                            <p className="text-xs font-semibold text-red-300">
                                                Apakah Anda yakin ingin menghapus seluruh pesan sekarang?
                                            </p>
                                            <div className="flex items-center gap-2">
                                                <button
                                                    type="button"
                                                    onClick={() => setResetConfirm(false)}
                                                    className="flex-1 py-2 rounded-xl border border-white/15 text-zinc-300 text-xs font-semibold hover:bg-white/5 cursor-pointer"
                                                >
                                                    Batal
                                                </button>
                                                <button
                                                    type="button"
                                                    onClick={handleAdminResetChat}
                                                    disabled={resetLoading}
                                                    className="flex-1 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-bold transition shadow-lg flex items-center justify-center gap-1 cursor-pointer"
                                                >
                                                    {resetLoading ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : 'Ya, Hapus Semua'}
                                                </button>
                                            </div>
                                        </div>
                                    )}
                                </div>
                            )}
                        </div>
                    )}
                </div>

                {/* MODAL: ADMIN CREATE USER */}
                {showCreateModal && (
                    <div className="fixed inset-0 z-[250] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
                        <div className="w-full max-w-sm bg-zinc-900 border border-white/20 rounded-3xl p-6 shadow-2xl relative">
                            <button
                                onClick={() => setShowCreateModal(false)}
                                className="absolute top-4 right-4 text-zinc-400 hover:text-white p-1 rounded-full hover:bg-white/10 cursor-pointer"
                            >
                                <X className="w-4 h-4" />
                            </button>

                            <h4 className="text-base font-bold text-white mb-1 flex items-center gap-2">
                                <UserPlus className="w-4 h-4" />
                                <span>Tambah User Baru</span>
                            </h4>
                            <p className="text-xs text-zinc-400 mb-4">Buat akun secara langsung dari panel admin.</p>

                            <form onSubmit={handleAdminCreateUser} className="space-y-3">
                                <div>
                                    <label className="block text-xs font-medium text-zinc-300 mb-1">Nickname</label>
                                    <input
                                        type="text"
                                        value={createNickname}
                                        onChange={(e) => setCreateNickname(e.target.value)}
                                        placeholder="Nama panggilan..."
                                        required
                                        className="w-full px-3 py-2 bg-white/5 border border-white/15 focus:border-white rounded-xl text-white text-xs focus:outline-none"
                                    />
                                </div>

                                <div>
                                    <label className="block text-xs font-medium text-zinc-300 mb-1">Password</label>
                                    <input
                                        type="password"
                                        value={createPassword}
                                        onChange={(e) => setCreatePassword(e.target.value)}
                                        placeholder="Katasandi..."
                                        required
                                        className="w-full px-3 py-2 bg-white/5 border border-white/15 focus:border-white rounded-xl text-white text-xs focus:outline-none"
                                    />
                                </div>

                                <div>
                                    <label className="block text-xs font-medium text-zinc-300 mb-1">URL Foto Profil (Opsional)</label>
                                    <input
                                        type="url"
                                        value={createPhotoUrl}
                                        onChange={(e) => setCreatePhotoUrl(e.target.value)}
                                        placeholder="https://..."
                                        className="w-full px-3 py-2 bg-white/5 border border-white/15 focus:border-white rounded-xl text-white text-xs focus:outline-none"
                                    />
                                </div>

                                <div className="flex items-center gap-2 pt-2">
                                    <button
                                        type="button"
                                        onClick={() => setShowCreateModal(false)}
                                        className="flex-1 py-2.5 rounded-xl border border-white/15 text-zinc-300 text-xs font-semibold hover:bg-white/5 cursor-pointer"
                                    >
                                        Batal
                                    </button>
                                    <button
                                        type="submit"
                                        disabled={createLoading || !createNickname.trim() || !createPassword.trim()}
                                        className="flex-1 py-2.5 rounded-xl bg-white text-black font-bold text-xs hover:bg-zinc-200 transition shadow-lg flex items-center justify-center gap-1 cursor-pointer"
                                    >
                                        {createLoading ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : 'Buat Akun'}
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                )}

                {/* MODAL: ADMIN EDIT USER */}
                {userToEdit && (
                    <div className="fixed inset-0 z-[250] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
                        <div className="w-full max-w-sm bg-zinc-900 border border-white/20 rounded-3xl p-6 shadow-2xl relative">
                            <button
                                onClick={() => setUserToEdit(null)}
                                className="absolute top-4 right-4 text-zinc-400 hover:text-white p-1 rounded-full hover:bg-white/10 cursor-pointer"
                            >
                                <X className="w-4 h-4" />
                            </button>

                            <h4 className="text-base font-bold text-white mb-1 flex items-center gap-2">
                                <Edit3 className="w-4 h-4" />
                                <span>Edit Akun: {userToEdit.nickname}</span>
                            </h4>
                            <p className="text-xs text-zinc-400 mb-4">Ubah foto profil atau atur ulang katasandi.</p>

                            <form onSubmit={handleAdminUpdateUser} className="space-y-3">
                                <div>
                                    <label className="block text-xs font-medium text-zinc-300 mb-1">URL Foto Profil Baru</label>
                                    <input
                                        type="url"
                                        value={editPhotoUrl}
                                        onChange={(e) => setEditPhotoUrl(e.target.value)}
                                        placeholder="https://... (kosongkan untuk hapus)"
                                        className="w-full px-3 py-2 bg-white/5 border border-white/15 focus:border-white rounded-xl text-white text-xs focus:outline-none"
                                    />
                                </div>

                                <div>
                                    <label className="block text-xs font-medium text-zinc-300 mb-1">Katasandi Baru (Opsional)</label>
                                    <input
                                        type="password"
                                        value={editNewPassword}
                                        onChange={(e) => setEditNewPassword(e.target.value)}
                                        placeholder="Kosongkan jika tidak ingin mengubah..."
                                        className="w-full px-3 py-2 bg-white/5 border border-white/15 focus:border-white rounded-xl text-white text-xs focus:outline-none"
                                    />
                                    <span className="text-[10px] text-zinc-500 block mt-1">
                                        Catatan: Jika katasandi diisi, sesi login user ini otomatis di-logout.
                                    </span>
                                </div>

                                <div className="flex items-center gap-2 pt-2">
                                    <button
                                        type="button"
                                        onClick={() => setUserToEdit(null)}
                                        className="flex-1 py-2.5 rounded-xl border border-white/15 text-zinc-300 text-xs font-semibold hover:bg-white/5 cursor-pointer"
                                    >
                                        Batal
                                    </button>
                                    <button
                                        type="submit"
                                        disabled={editLoading}
                                        className="flex-1 py-2.5 rounded-xl bg-white text-black font-bold text-xs hover:bg-zinc-200 transition shadow-lg flex items-center justify-center gap-1 cursor-pointer"
                                    >
                                        {editLoading ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : 'Simpan'}
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                )}

                {/* MODAL: ADMIN DELETE USER CONFIRMATION */}
                {userToDelete && (
                    <div className="fixed inset-0 z-[250] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
                        <div className="w-full max-w-sm bg-zinc-900 border border-red-500/30 rounded-3xl p-6 shadow-2xl relative text-center">
                            <div className="w-12 h-12 rounded-2xl bg-red-950/40 border border-red-500/30 flex items-center justify-center mx-auto mb-3 text-red-300">
                                <Trash2 className="w-6 h-6" />
                            </div>

                            <h4 className="text-base font-bold text-white mb-1">Hapus Pengguna?</h4>
                            <p className="text-xs text-zinc-400 mb-5 leading-relaxed">
                                Akun <span className="font-bold text-white">{userToDelete.nickname}</span> beserta semua sesi aktifnya akan dihapus permanen.
                            </p>

                            <div className="flex items-center gap-2">
                                <button
                                    type="button"
                                    onClick={() => setUserToDelete(null)}
                                    className="flex-1 py-2.5 rounded-xl border border-white/15 text-zinc-300 text-xs font-semibold hover:bg-white/5 cursor-pointer"
                                >
                                    Batal
                                </button>
                                <button
                                    type="button"
                                    onClick={handleAdminDeleteUser}
                                    disabled={deleteLoading}
                                    className="flex-1 py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold text-xs shadow-lg transition flex items-center justify-center gap-1 cursor-pointer"
                                >
                                    {deleteLoading ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : 'Hapus Sekarang'}
                                </button>
                            </div>
                        </div>
                    </div>
                )}
            </div>
        );
    }
}
