const { exec } = require('node:child_process');

const TIKTOK_REGEX = /https?:\/\/(?:(?:www|vt|vm|m|t)\.)?tiktok\.com\/(?:@[\w.-]+\/video\/\d+|[\w.-]+|\S+)/i;

/**
 * Extract TikTok URL from text
 * @param {string} text 
 * @returns {string|null}
 */
function extractTikTokUrl(text) {
  if (!text) return null;
  const match = text.match(TIKTOK_REGEX);
  return match ? match[0] : null;
}

/**
 * Fetch media buffer with proper headers to bypass TikTok CDN 503
 * @param {string} url 
 * @returns {Promise<Buffer>}
 */
async function fetchMediaBuffer(url) {
  const res = await fetch(url, {
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      'Referer': 'https://www.tiktok.com/'
    }
  });

  if (!res.ok) {
    throw new Error(`Gagal download media (HTTP ${res.status})`);
  }

  const arrayBuf = await res.arrayBuffer();
  return Buffer.from(arrayBuf);
}

/**
 * Fetch TikTok metadata and direct download URLs
 * @param {string} url 
 * @returns {Promise<object>}
 */
async function getTikTokData(url) {
  // Method 1: TikWM API
  try {
    const apiUrl = `https://tikwm.com/api/?url=${encodeURIComponent(url)}&hd=1`;
    const res = await fetch(apiUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0'
      }
    });

    if (res.ok) {
      const json = await res.json();
      if (json && json.code === 0 && json.data) {
        const d = json.data;
        return {
          success: true,
          id: d.id,
          title: d.title || 'TikTok Video',
          author: {
            nickname: d.author?.nickname || 'Creator',
            username: d.author?.unique_id || 'tiktok'
          },
          stats: {
            likes: d.digg_count || 0,
            comments: d.comment_count || 0,
            shares: d.share_count || 0,
            views: d.play_count || 0
          },
          duration: d.duration || 0,
          videoUrl: d.hdplay || d.play,
          musicUrl: d.music,
          musicTitle: d.music_info?.title || 'Original Sound',
          musicAuthor: d.music_info?.author || d.author?.nickname,
          images: Array.isArray(d.images) && d.images.length > 0 ? d.images : null
        };
      }
    }
  } catch (err) {
    console.error('TikWM API error:', err.message);
  }

  // Method 2: yt-dlp fallback
  return new Promise((resolve, reject) => {
    const cmd = `/home/nanasmuda/.local/bin/yt-dlp -j --no-warnings "${url}"`;
    exec(cmd, { timeout: 25000 }, (err, stdout, stderr) => {
      if (err || !stdout) {
        return reject(new Error('Gagal mengambil video TikTok. Pastikan link publik dan valid.'));
      }
      try {
        const d = JSON.parse(stdout);
        resolve({
          success: true,
          id: d.id,
          title: d.title || d.description || 'TikTok Video',
          author: {
            nickname: d.uploader || d.channel || 'Creator',
            username: d.uploader_id || 'tiktok'
          },
          stats: {
            likes: d.like_count || 0,
            comments: d.comment_count || 0,
            shares: d.repost_count || 0,
            views: d.view_count || 0
          },
          duration: d.duration || 0,
          videoUrl: d.url,
          musicUrl: null,
          musicTitle: null,
          musicAuthor: null,
          images: null
        });
      } catch (parseErr) {
        reject(new Error('Gagal memproses data video TikTok.'));
      }
    });
  });
}

module.exports = {
  extractTikTokUrl,
  getTikTokData,
  fetchMediaBuffer
};
