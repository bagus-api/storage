require('dotenv').config();
const { Bot, InlineKeyboard, InputFile } = require('grammy');
const { exec } = require('node:child_process');
const path = require('node:path');
const fs = require('node:fs');
const os = require('node:os');

const { runAgy, abortUserProcess, isUserRunning } = require('./agy-runner');
const {
  getSession,
  updateSession,
  resetSession,
  isAllowed,
  setOwner,
  allowUser,
  disallowUser,
  getConfig
} = require('./session-store');
const { getRecentConversations, getConversationById } = require('./conversation-db');
const {
  sendSafeMessage,
  formatToolNotification,
  formatTokens,
  formatMetadataFooter
} = require('./formatter');
const { extractTikTokUrl, getTikTokData, fetchMediaBuffer } = require('./tiktok');

const BOT_TOKEN = process.env.BOT_TOKEN;
if (!BOT_TOKEN) {
  console.error('Error: BOT_TOKEN is required in .env!');
  process.exit(1);
}

const bot = new Bot(BOT_TOKEN);

// List of available models
const AVAILABLE_MODELS = [
  { id: 'gemini-3.8-flash-high', label: '⚡ Gemini 3.8 Flash (High) - Cepat & Cerdas' },
  { id: 'gemini-3.8-flash-medium', label: '⚡ Gemini 3.8 Flash (Medium)' },
  { id: 'gemini-3.8-flash-low', label: '⚡ Gemini 3.8 Flash (Low)' },
  { id: 'claude-sonnet-4-6', label: '🧠 Claude Sonnet 4.6 (Thinking)' },
  { id: 'claude-opus-4-6-thinking', label: '🧠 Claude Opus 4.6 (Thinking)' },
  { id: 'gpt-oss-120b-medium', label: '🤖 GPT-OSS 120B (Medium)' }
];

const AVAILABLE_EFFORTS = [
  { id: 'auto', label: '⚡ Auto (Cepat di chat, Dalam saat coding)' },
  { id: 'low', label: '🟢 Low (Super Cepat, Tanpa Mikir)' },
  { id: 'medium', label: '🟡 Medium (Seimbang)' },
  { id: 'high', label: '🟠 High (Mikir Mendalam)' },
  { id: 'max', label: '🔴 Max (Maksimal Thinking)' }
];
const AVAILABLE_MODES = [
  { id: 'auto', label: '🤖 Auto (Full Agentic + Tools)' },
  { id: 'accept-edits', label: '✏️ Accept Edits' },
  { id: 'plan', label: '📋 Plan Mode (Perencanaan)' }
];

// Helper to check user permission
function checkAuth(ctx) {
  const userId = ctx.from?.id;
  if (!userId) return false;
  return isAllowed(userId);
}

// Security Auth Middleware
bot.use(async (ctx, next) => {
  const userId = ctx.from?.id;
  if (!userId) return;

  const config = getConfig();
  // Auto-register first user as Owner
  if (!config.ownerId && (!config.allowedUsers || config.allowedUsers.length === 0)) {
    setOwner(userId);
    console.log(`[AUTH] User ${userId} (${ctx.from.username || ctx.from.first_name}) registered as OWNER.`);
  }

  if (!checkAuth(ctx)) {
    if (ctx.message?.text?.startsWith('/id')) {
      return ctx.reply(`🆔 ID Telegram Anda: \`${userId}\``, { parse_mode: 'Markdown' });
    }
    return ctx.reply(
      `⛔ *Akses Ditolak*\n\nBot Antigravity ini terhubung ke VPS server dan diproteksi demi keamanan.\n\nID Anda: \`${userId}\`\nHubungi pemilik server untuk menambahkan ID Anda.`,
      { parse_mode: 'Markdown' }
    );
  }

  return next();
});

// Command: /start
bot.command('start', async (ctx) => {
  const session = getSession(ctx.from.id);
  const config = getConfig();
  const isOwner = String(config.ownerId) === String(ctx.from.id);

  const welcomeText =
    `🚀 *Halo ${ctx.from.first_name || 'Bos'}! Selamat datang di Antigravity Telegram.*

Saya adalah interface untuk mengendalikan **Antigravity AI Agent** di VPS Anda tanpa perlu buka terminal atau SSH session!

💬 *Langsung Chat Biasa*:
Ketik apa saja untuk bertanya, coding, debug error, membaca/mengedit file, atau menjalankan perintah di VPS.

📌 *Status Anda Saat Ini*:
• Model: \`${session.model}\`
• Mode: \`${session.mode}\` | Effort: \`${session.effort}\`
• Workspace: \`${session.cwd}\`
• Sesi: \`${session.conversationId ? session.conversationId.slice(0, 8) + '...' : 'Sesi Baru'}\`
${isOwner ? '👑 _Status: Bot Owner_' : ''}

Silakan gunakan tombol di bawah atau ketik perintah:`;

  const keyboard = new InlineKeyboard()
    .text('➕ Sesi Baru', 'btn_new')
    .text('📋 Resume Sesi', 'btn_resume').row()
    .text('🧠 Ganti Model', 'btn_model')
    .text('📊 Status & Usage', 'btn_status').row()
    .text('📖 Panduan Perintah', 'btn_help');

  await sendSafeMessage(ctx, welcomeText, { reply_markup: keyboard });
});

// Command: /help
bot.command('help', async (ctx) => {
  const helpText =
    `🛠️ *Daftar Perintah Antigravity Bot*

💬 *Penggunaan Normal*:
Cukup kirim teks biasa kapan saja! Agent akan membaca, berpikir, menggunakan tools (bash, edit file, search), dan merespon langsung.

📥 *Download Media*:
• \`/tt <url>\` — Download video TikTok tanpa watermark (+ opsi audio MP3).
_Tips: Anda juga bisa langsung kirim link TikTok tanpa mengetik /tt._

⚡ *Perintah Kontrol*:
• \`/new [prompt]\` — Mulai sesi percakapan baru. Opsional sertakan pesan pertama.
• \`/resume [id]\` — Lanjutkan sesi sebelumnya (tampilkan daftar sesi terakhir atau masukkan ID).
• \`/model [nama]\` — Pilih model AI (Gemini Flash, Claude Sonnet, Opus, dll).
• \`/usage\` — Lihat statistik penggunaan token (input, output, thinking).
• \`/status\` — Cek konfigurasi sesi aktif, model, direktori kerja, & memori.
• \`/abort\` atau \`/stop\` — Hentikan paksa proses agent yang sedang berjalan.
• \`/cd <path>\` — Pindah folder kerja tempat agent membuat/mengedit file.
• \`/pwd\` — Lihat direktori kerja saat ini.
• \`/effort [low|medium|high|xhigh|max]\` — Atur tingkat reasoning effort.
• \`/mode [auto|plan|accept-edits]\` — Atur mode eksekusi agent.
• \`/bash <perintah>\` — Jalankan perintah terminal langsung di VPS.

🔐 *Khusus Owner*:
• \`/allow <user_id>\` — Berikan izin ke user Telegram lain.
• \`/disallow <user_id>\` — Cabut izin user lain.
• \`/id\` — Cek ID Telegram Anda.`;

  await sendSafeMessage(ctx, helpText);
});

// Cache for TikTok audio downloads (id -> audio metadata)
const tiktokAudioCache = new Map();

function escapeHtml(str = '') {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

/**
 * Handle TikTok download
 */
async function handleTikTokDownload(ctx, targetUrl) {
  const url = extractTikTokUrl(targetUrl);
  if (!url) {
    return ctx.reply(
      '❌ URL TikTok tidak valid.\n\nContoh penggunaan:\n`/tt https://vt.tiktok.com/xxxxxx/`\n`/tt https://www.tiktok.com/@user/video/xxxxxx`',
      { parse_mode: 'Markdown' }
    );
  }

  let statusMsg;
  try {
    statusMsg = await ctx.reply('⏳ *Mengambil video TikTok tanpa watermark...*', { parse_mode: 'Markdown' });
  } catch (e) {
    statusMsg = await ctx.reply('⏳ Mengambil video TikTok tanpa watermark...');
  }

  try {
    const data = await getTikTokData(url);

    // If it's a photo slide / carousel
    if (data.images && data.images.length > 0) {
      if (statusMsg) {
        try { await ctx.api.deleteMessage(ctx.chat.id, statusMsg.message_id); } catch (e) {}
      }

      const rawTitle = (data.title || 'TikTok Foto Slide').trim();
      const shortTitle = rawTitle.length > 350 ? rawTitle.slice(0, 347) + '...' : rawTitle;

      const htmlSlideCaption =
        `📸 <b>${escapeHtml(shortTitle)}</b>` +
        `\n\n👤 <b>@${escapeHtml(data.author.username)}</b> (${escapeHtml(data.author.nickname)})` +
        `\n❤️ ${(data.stats.likes || 0).toLocaleString()} | 💬 ${(data.stats.comments || 0).toLocaleString()}`;

      const plainSlideCaption =
        `📸 ${shortTitle}` +
        `\n\n👤 @${data.author.username} (${data.author.nickname})` +
        `\n❤️ ${(data.stats.likes || 0).toLocaleString()} | 💬 ${(data.stats.comments || 0).toLocaleString()}`;

      // Telegram media group supports up to 10 photos
      const mediaGroup = data.images.slice(0, 10).map((imgUrl, idx) => ({
        type: 'photo',
        media: imgUrl,
        caption: idx === 0 ? htmlSlideCaption.slice(0, 1024) : undefined,
        parse_mode: 'HTML'
      }));

      try {
        await ctx.replyWithMediaGroup(mediaGroup);
      } catch (mgErr) {
        // Fallback plain caption
        const plainGroup = data.images.slice(0, 10).map((imgUrl, idx) => ({
          type: 'photo',
          media: imgUrl,
          caption: idx === 0 ? plainSlideCaption.slice(0, 1024) : undefined
        }));
        await ctx.replyWithMediaGroup(plainGroup);
      }

      if (data.musicUrl) {
        tiktokAudioCache.set(data.id, {
          musicUrl: data.musicUrl,
          title: data.musicTitle || 'TikTok Audio',
          author: data.musicAuthor || data.author.nickname
        });
        const kb = new InlineKeyboard().text('🎵 Download Audio (MP3)', `tt_audio_${data.id}`);
        await ctx.reply('🎵 Audio latar belakang tersedia:', { reply_markup: kb });
      }
      return;
    }

    // If video
    if (!data.videoUrl) {
      throw new Error('Link video tidak ditemukan atau video bersifat privat.');
    }

    // Download video buffer
    const videoBuffer = await fetchMediaBuffer(data.videoUrl);

    if (data.musicUrl) {
      tiktokAudioCache.set(data.id, {
        musicUrl: data.musicUrl,
        title: data.musicTitle || 'TikTok Audio',
        author: data.musicAuthor || data.author.nickname
      });
    }

    const rawTitle = (data.title || 'TikTok Video').trim();
    const shortTitle = rawTitle.length > 350 ? rawTitle.slice(0, 347) + '...' : rawTitle;

    const htmlCaption =
      `🎬 <b>${escapeHtml(shortTitle)}</b>` +
      `\n\n👤 <b>@${escapeHtml(data.author.username)}</b> (${escapeHtml(data.author.nickname)})` +
      `\n❤️ ${(data.stats.likes || 0).toLocaleString()} | 💬 ${(data.stats.comments || 0).toLocaleString()} | 👁️ ${(data.stats.views || 0).toLocaleString()}` +
      (data.duration ? `\n⏱️ ${data.duration}s` : '') +
      (data.musicTitle ? `\n🎵 <i>${escapeHtml(data.musicTitle)}</i>` : '');

    const plainCaption =
      `🎬 ${shortTitle}` +
      `\n\n👤 @${data.author.username} (${data.author.nickname})` +
      `\n❤️ ${(data.stats.likes || 0).toLocaleString()} | 💬 ${(data.stats.comments || 0).toLocaleString()} | 👁️ ${(data.stats.views || 0).toLocaleString()}` +
      (data.duration ? `\n⏱️ ${data.duration}s` : '') +
      (data.musicTitle ? `\n🎵 ${data.musicTitle}` : '');

    const keyboard = data.musicUrl
      ? new InlineKeyboard().text('🎵 Download Audio (MP3)', `tt_audio_${data.id}`)
      : undefined;

    // Delete progress message
    if (statusMsg) {
      try { await ctx.api.deleteMessage(ctx.chat.id, statusMsg.message_id); } catch (e) {}
    }

    // Send video with HTML parsing and plain-text fallback
    try {
      await ctx.replyWithVideo(new InputFile(videoBuffer, `tiktok_${data.id}.mp4`), {
        caption: htmlCaption.slice(0, 1024),
        parse_mode: 'HTML',
        reply_markup: keyboard
      });
    } catch (sendErr) {
      console.warn('Failed sending video with HTML caption, retrying plain text:', sendErr.message);
      try {
        await ctx.replyWithVideo(new InputFile(videoBuffer, `tiktok_${data.id}.mp4`), {
          caption: plainCaption.slice(0, 1024),
          reply_markup: keyboard
        });
      } catch (fallbackErr) {
        console.warn('Failed sending video with plain caption, sending bare video:', fallbackErr.message);
        await ctx.replyWithVideo(new InputFile(videoBuffer, `tiktok_${data.id}.mp4`), {
          reply_markup: keyboard
        });
        await ctx.reply(plainCaption.slice(0, 4000));
      }
    }
  } catch (err) {
    if (statusMsg) {
      try { await ctx.api.deleteMessage(ctx.chat.id, statusMsg.message_id); } catch (e) {}
    }
    console.error('Error downloading TikTok:', err);
    await ctx.reply(`❌ *Gagal download video TikTok:* ${err.message}`, { parse_mode: 'Markdown' });
  }
}

// Command: /tt and /tiktok
bot.command(['tt', 'tiktok'], async (ctx) => {
  const match = ctx.match?.trim();
  if (!match) {
    return ctx.reply(
      `ℹ️ *Cara Menggunakan Fitur /tt*:
Kirim perintah: \`/tt <link tiktok>\`

Contoh:
\`/tt https://vt.tiktok.com/ZSjR1234/\`
\`/tt https://www.tiktok.com/@user/video/1234567890\`

💡 *Tips*: Anda juga bisa langsung paste link TikTok di obrolan tanpa mengetik \`/tt\`!`,
      { parse_mode: 'Markdown' }
    );
  }

  await handleTikTokDownload(ctx, match);
});

// Command: /new
bot.command('new', async (ctx) => {
  const userId = ctx.from.id;
  if (isUserRunning(userId)) {
    return ctx.reply('⚠️ Agent masih menjalankan tugas sebelumnya. Gunakan /abort jika ingin membatalkannya.');
  }

  const prompt = ctx.match?.trim();
  const oldId = resetSession(userId);

  if (prompt) {
    await ctx.reply(`✨ *Sesi baru dimulai!* Memproses instruksi Anda...`, { parse_mode: 'Markdown' });
    await handleAgentTurn(ctx, prompt);
  } else {
    await ctx.reply(
      `✨ *Sesi Antigravity baru telah di-reset!*${oldId ? `\n(Sesi lama \`${oldId.slice(0, 8)}...\` tersimpan di database)` : ''}\n\nSilakan kirim pesan atau instruksi coding untuk memulai percakapan baru.`,
      { parse_mode: 'Markdown' }
    );
  }
});

// Command: /resume
bot.command('resume', async (ctx) => {
  const targetId = ctx.match?.trim();

  if (targetId) {
    // Resume specific ID
    const conv = getConversationById(targetId);
    const resolvedId = conv ? conv.conversation_id : targetId;
    updateSession(ctx.from.id, { conversationId: resolvedId });

    return ctx.reply(
      `🔄 *Sesi Berhasil Di-Resume!*

📌 **ID**: \`${resolvedId}\`
${conv?.title ? `🏷️ **Judul**: ${conv.title}` : ''}
${conv?.step_count ? `💬 **Jumlah Langkah**: ${conv.step_count}` : ''}

Silakan kirim pesan lanjutan ke agent.`,
      { parse_mode: 'Markdown' }
    );
  }

  // List recent conversations
  const recents = getRecentConversations(6);
  if (!recents.length) {
    return ctx.reply('📭 Belum ada riwayat sesi Antigravity di database VPS.');
  }

  let text = `📋 *Pilih Sesi yang Ingin Di-Resume:*\n\n`;
  const keyboard = new InlineKeyboard();

  recents.forEach((item, idx) => {
    const num = idx + 1;
    const title = item.title || item.preview || 'Percakapan Tanpa Judul';
    const shortId = item.conversation_id.slice(0, 8);
    const timeStr = item.last_modified_time ? item.last_modified_time.split('.')[0].replace('T', ' ') : '';

    text += `*${num}.* *${title}*\n   🆔 \`${shortId}...\` • ${item.step_count || 0} turn • ${timeStr}\n\n`;
    keyboard.text(`${num}. ${title.slice(0, 18)}`, `resume_${item.conversation_id}`);
    if (num % 2 === 0) keyboard.row();
  });

  keyboard.row().text('❌ Batal', 'btn_cancel');

  await sendSafeMessage(ctx, text, { reply_markup: keyboard });
});

// Command: /model
bot.command('model', async (ctx) => {
  const session = getSession(ctx.from.id);
  const targetModel = ctx.match?.trim();

  if (targetModel) {
    const found = AVAILABLE_MODELS.find(
      (m) => m.id === targetModel || m.id.toLowerCase().includes(targetModel.toLowerCase())
    );
    if (found) {
      updateSession(ctx.from.id, { model: found.id });
      return ctx.reply(`✅ Model berhasil diubah ke: \`${found.id}\``, { parse_mode: 'Markdown' });
    }
    // Allow custom model identifier
    updateSession(ctx.from.id, { model: targetModel });
    return ctx.reply(`✅ Model diubah ke: \`${targetModel}\``, { parse_mode: 'Markdown' });
  }

  const keyboard = new InlineKeyboard();
  AVAILABLE_MODELS.forEach((m) => {
    const isCurrent = m.id === session.model;
    const text = `${isCurrent ? '✓ ' : ''}${m.label}`;
    keyboard.text(text, `model_${m.id}`).row();
  });

  await ctx.reply(
    `🧠 *Pilih Model Antigravity:*\n\nModel aktif saat ini: \`${session.model}\``,
    { parse_mode: 'Markdown', reply_markup: keyboard }
  );
});

// Command: /usage
bot.command('usage', async (ctx) => {
  const session = getSession(ctx.from.id);
  const sStats = session.sessionStats || {};
  const lStats = session.lifetimeStats || {};

  const usageText =
    `📊 *Statistik Penggunaan Token Antigravity*

💬 *Sesi Saat Ini* (\`${session.conversationId ? session.conversationId.slice(0, 8) + '...' : 'Fresh'}\`):
• 📥 Input Tokens: *${formatTokens(sStats.inputTokens)}* (${(sStats.inputTokens || 0).toLocaleString()})
• 📤 Output Tokens: *${formatTokens(sStats.outputTokens)}* (${(sStats.outputTokens || 0).toLocaleString()})
• 💭 Thinking Tokens: *${formatTokens(sStats.thinkingTokens)}* (${(sStats.thinkingTokens || 0).toLocaleString()})
• 📊 Total Sesi Ini: *${formatTokens(sStats.totalTokens)}* (${(sStats.totalTokens || 0).toLocaleString()})
• 🔄 Jumlah Turn: *${sStats.turns || 0}*

🌐 *Lifetime Bot*:
• 🔄 Total Turn: *${lStats.totalTurns || 0}*
• 📈 Total Tokens: *${formatTokens(lStats.totalTokens)}*`;

  await sendSafeMessage(ctx, usageText);
});

// Command: /status
bot.command('status', async (ctx) => {
  const session = getSession(ctx.from.id);
  const running = isUserRunning(ctx.from.id);

  const statusText =
    `⚙️ *Status Sistem & Sesi Antigravity*

• 🤖 *Agent Status*: ${running ? '🟡 *Sedang Berjalan*' : '🟢 *Idle (Siap)*'}
• 💬 *Conversation ID*: \`${session.conversationId || 'Belum ada (Sesi Baru)'}\`
• 🧠 *Model*: \`${session.model}\`
• 🎯 *Effort*: \`${session.effort}\`
• 🛠️ *Mode*: \`${session.mode}\`
• 📂 *Workspace (CWD)*: \`${session.cwd}\`
• 📊 *Token Sesi Ini*: *${formatTokens(session.sessionStats?.totalTokens)}*`;

  const keyboard = new InlineKeyboard()
    .text('🔄 Refresh', 'btn_status')
    .text('🧠 Ganti Model', 'btn_model').row()
    .text('➕ Sesi Baru', 'btn_new')
    .text('📋 Resume Sesi', 'btn_resume');

  await sendSafeMessage(ctx, statusText, { reply_markup: keyboard });
});

// Command: /effort
bot.command('effort', async (ctx) => {
  const session = getSession(ctx.from.id);
  const target = ctx.match?.trim().toLowerCase();

  const found = AVAILABLE_EFFORTS.find((e) => e.id === target);
  if (found) {
    updateSession(ctx.from.id, { effort: found.id });
    return ctx.reply(`🎯 Reasoning effort diubah ke: \`${found.id}\` (${found.label})`, { parse_mode: 'Markdown' });
  }

  const keyboard = new InlineKeyboard();
  AVAILABLE_EFFORTS.forEach((e) => {
    const isCurrent = e.id === (session.effort || 'auto');
    keyboard.text(`${isCurrent ? '✓ ' : ''}${e.label}`, `effort_${e.id}`).row();
  });

  await ctx.reply(
    `🎯 *Atur Reasoning Effort:*
• *Auto*: Cepat langsung jawab saat ngobrol biasa, berpikir mendalam saat coding/tugas penting.
• *Low*: Instan tanpa mikir lama.
• *High / Max*: Berpikir mendalam sebelum bertindak.

Effort aktif saat ini: \`${session.effort || 'auto'}\``,
    { parse_mode: 'Markdown', reply_markup: keyboard }
  );
});

// Command: /mode
bot.command('mode', async (ctx) => {
  const session = getSession(ctx.from.id);
  const target = ctx.match?.trim().toLowerCase();

  const found = AVAILABLE_MODES.find((m) => m.id === target);
  if (found) {
    updateSession(ctx.from.id, { mode: found.id });
    return ctx.reply(`⚙️ Mode agent diubah ke: \`${found.id}\``, { parse_mode: 'Markdown' });
  }

  const keyboard = new InlineKeyboard();
  AVAILABLE_MODES.forEach((m) => {
    const isCurrent = m.id === session.mode;
    keyboard.text(`${isCurrent ? '✓ ' : ''}${m.label}`, `mode_${m.id}`).row();
  });

  await ctx.reply(
    `⚙️ *Atur Mode Eksekusi Agent:*

Mode saat ini: \`${session.mode}\``,
    { parse_mode: 'Markdown', reply_markup: keyboard }
  );
});

// Command: /cd and /pwd
bot.command(['cd', 'dir'], async (ctx) => {
  const session = getSession(ctx.from.id);
  const targetPath = ctx.match?.trim();

  if (!targetPath) {
    return ctx.reply(`📂 *Direktori Kerja Saat Ini:* \`${session.cwd}\``, { parse_mode: 'Markdown' });
  }

  let resolved = targetPath.startsWith('~')
    ? path.join(os.homedir(), targetPath.slice(1))
    : path.resolve(session.cwd, targetPath);

  if (!fs.existsSync(resolved)) {
    return ctx.reply(`❌ Direktori tidak ditemukan: \`${resolved}\``, { parse_mode: 'Markdown' });
  }

  const stat = fs.statSync(resolved);
  if (!stat.isDirectory()) {
    return ctx.reply(`❌ Bukan sebuah direktori: \`${resolved}\``, { parse_mode: 'Markdown' });
  }

  updateSession(ctx.from.id, { cwd: resolved });
  await ctx.reply(`📂 *Direktori kerja dipindah ke:* \`${resolved}\``, { parse_mode: 'Markdown' });
});

bot.command('pwd', async (ctx) => {
  const session = getSession(ctx.from.id);
  await ctx.reply(`📂 *Direktori Kerja:* \`${session.cwd}\``, { parse_mode: 'Markdown' });
});

// Command: /abort or /stop
bot.command(['abort', 'stop'], async (ctx) => {
  const userId = ctx.from.id;
  const running = isUserRunning(userId);

  if (!running) {
    return ctx.reply('ℹ️ Tidak ada tugas agent yang sedang berjalan saat ini.');
  }

  const stopped = abortUserProcess(userId);
  if (stopped) {
    await ctx.reply('🛑 *Tugas Antigravity berhasil dihentikan paksa.*', { parse_mode: 'Markdown' });
  } else {
    await ctx.reply('⚠️ Gagal menghentikan proses atau proses sudah selesai.');
  }
});

// Command: /bash (Direct terminal execution)
bot.command('bash', async (ctx) => {
  const cmd = ctx.match?.trim();
  if (!cmd) {
    return ctx.reply('Gunakan: `/bash <perintah>`\nContoh: `/bash uptime` atau `/bash df -h`', { parse_mode: 'Markdown' });
  }

  const session = getSession(ctx.from.id);
  const waitMsg = await ctx.reply(`⏳ Menjalankan: \`${cmd}\`...`, { parse_mode: 'Markdown' });

  exec(cmd, { cwd: session.cwd, timeout: 30000 }, async (err, stdout, stderr) => {
    try {
      await ctx.api.deleteMessage(ctx.chat.id, waitMsg.message_id);
    } catch (e) {}

    let output = (stdout || '') + (stderr ? `\n[STDERR]:\n${stderr}` : '');
    if (!output.trim()) output = '(Tidak ada output)';

    if (err && err.code) {
      output += `\n[Exit Code: ${err.code}]`;
    }

    const formatted = `💻 *Hasil:* \`${cmd}\`\n\`\`\`\n${output.slice(0, 3500)}\n\`\`\``;
    await sendSafeMessage(ctx, formatted);
  });
});

// Owner commands: /allow and /disallow
bot.command('allow', async (ctx) => {
  const config = getConfig();
  if (String(config.ownerId) !== String(ctx.from.id)) {
    return ctx.reply('⛔ Hanya bot owner yang dapat menambahkan pengguna.');
  }

  const targetId = ctx.match?.trim();
  if (!targetId) {
    return ctx.reply('Gunakan: `/allow <telegram_user_id>`', { parse_mode: 'Markdown' });
  }

  if (allowUser(targetId)) {
    await ctx.reply(`✅ User ID \`${targetId}\` berhasil diizinkan menggunakan bot.`, { parse_mode: 'Markdown' });
  } else {
    await ctx.reply(`ℹ️ User ID \`${targetId}\` sudah ada di daftar izin.`, { parse_mode: 'Markdown' });
  }
});

bot.command('disallow', async (ctx) => {
  const config = getConfig();
  if (String(config.ownerId) !== String(ctx.from.id)) {
    return ctx.reply('⛔ Hanya bot owner yang dapat mencabut izin pengguna.');
  }

  const targetId = ctx.match?.trim();
  if (!targetId) {
    return ctx.reply('Gunakan: `/disallow <telegram_user_id>`', { parse_mode: 'Markdown' });
  }

  if (disallowUser(targetId)) {
    await ctx.reply(`🚫 Izin untuk User ID \`${targetId}\` berhasil dicabut.`, { parse_mode: 'Markdown' });
  } else {
    await ctx.reply(`❌ User tidak ditemukan atau merupakan Owner.`, { parse_mode: 'Markdown' });
  }
});

bot.command('id', async (ctx) => {
  await ctx.reply(`🆔 *Telegram User ID*: \`${ctx.from.id}\``, { parse_mode: 'Markdown' });
});

// Callback Query Handler for Inline Buttons
bot.on('callback_query:data', async (ctx) => {
  const data = ctx.callbackQuery.data;
  const userId = ctx.from.id;
  await ctx.answerCallbackQuery().catch(() => {});

  if (data === 'btn_new') {
    resetSession(userId);
    return ctx.reply('✨ *Sesi baru dimulai!* Silakan kirim pesan atau instruksi coding.', { parse_mode: 'Markdown' });
  }

  if (data === 'btn_resume') {
    const recents = getRecentConversations(6);
    if (!recents.length) {
      return ctx.reply('📭 Belum ada riwayat sesi Antigravity di database VPS.');
    }
    let text = `📋 *Pilih Sesi yang Ingin Di-Resume:*\n\n`;
    const keyboard = new InlineKeyboard();
    recents.forEach((item, idx) => {
      const num = idx + 1;
      const title = item.title || item.preview || 'Percakapan Tanpa Judul';
      text += `*${num}.* *${title}*\n   🆔 \`${item.conversation_id.slice(0, 8)}...\` • ${item.step_count || 0} turn\n\n`;
      keyboard.text(`${num}. ${title.slice(0, 18)}`, `resume_${item.conversation_id}`);
      if (num % 2 === 0) keyboard.row();
    });
    keyboard.row().text('❌ Batal', 'btn_cancel');
    return sendSafeMessage(ctx, text, { reply_markup: keyboard });
  }

  if (data.startsWith('resume_')) {
    const convId = data.replace('resume_', '');
    const conv = getConversationById(convId);
    updateSession(userId, { conversationId: convId });

    return ctx.reply(
      `🔄 *Sesi Di-Resume!*\n\n📌 **Judul**: ${conv?.title || 'Sesi'}\n🆔 \`${convId}\`\n\nSilakan kirim pesan untuk melanjutkan percakapan.`,
      { parse_mode: 'Markdown' }
    );
  }

  if (data === 'btn_model') {
    const session = getSession(userId);
    const keyboard = new InlineKeyboard();
    AVAILABLE_MODELS.forEach((m) => {
      const isCurrent = m.id === session.model;
      keyboard.text(`${isCurrent ? '✓ ' : ''}${m.label}`, `model_${m.id}`).row();
    });
    return ctx.reply(`🧠 *Pilih Model Antigravity:*\nModel aktif: \`${session.model}\``, {
      parse_mode: 'Markdown',
      reply_markup: keyboard
    });
  }

  if (data.startsWith('model_')) {
    const mId = data.replace('model_', '');
    updateSession(userId, { model: mId });
    return ctx.reply(`✅ Model diubah ke: \`${mId}\``, { parse_mode: 'Markdown' });
  }

  if (data === 'btn_status') {
    const session = getSession(userId);
    const running = isUserRunning(userId);
    const statusText =
      `⚙️ *Status Sistem & Sesi Antigravity*

• 🤖 *Agent Status*: ${running ? '🟡 *Sedang Berjalan*' : '🟢 *Idle (Siap)*'}
• 💬 *Conversation ID*: \`${session.conversationId || 'Belum ada (Sesi Baru)'}\`
• 🧠 *Model*: \`${session.model}\`
• 🎯 *Effort*: \`${session.effort}\`
• 🛠️ *Mode*: \`${session.mode}\`
• 📂 *Workspace*: \`${session.cwd}\`
• 📊 *Token Sesi*: *${formatTokens(session.sessionStats?.totalTokens)}*`;

    return sendSafeMessage(ctx, statusText);
  }

  if (data.startsWith('effort_')) {
    const eff = data.replace('effort_', '');
    updateSession(userId, { effort: eff });
    return ctx.reply(`🎯 Effort diubah ke: \`${eff}\``, { parse_mode: 'Markdown' });
  }

  if (data.startsWith('mode_')) {
    const mod = data.replace('mode_', '');
    updateSession(userId, { mode: mod });
    return ctx.reply(`⚙️ Mode agent diubah ke: \`${mod}\``, { parse_mode: 'Markdown' });
  }

  if (data === 'btn_help') {
    return ctx.reply(
      `📖 *Tips Penggunaan*:
1. Chat biasa langsung direspon oleh Antigravity Agent.
2. Gunakan /new jika ingin ganti topik baru.
3. Gunakan /resume untuk melihat atau kembali ke sesi lama.
4. Gunakan /model untuk ganti model AI kapan saja.
5. Gunakan /abort jika ingin membatalkan eksekusi agent yang sedang berjalan.`,
      { parse_mode: 'Markdown' }
    );
  }

  if (data.startsWith('tt_audio_')) {
    const id = data.replace('tt_audio_', '');
    const audioData = tiktokAudioCache.get(id);
    if (!audioData || !audioData.musicUrl) {
      return ctx.reply('⚠️ Link audio sudah kedaluwarsa atau tidak tersedia.');
    }
    const waitMsg = await ctx.reply('🎵 Mengunduh file audio MP3...');
    try {
      const audioBuf = await fetchMediaBuffer(audioData.musicUrl);
      await ctx.replyWithAudio(new InputFile(audioBuf, `${audioData.title || 'tiktok_audio'}.mp3`), {
        title: audioData.title || 'TikTok Audio',
        performer: audioData.author || 'TikTok'
      });
      try {
        await ctx.api.deleteMessage(ctx.chat.id, waitMsg.message_id);
      } catch (e) {}
    } catch (err) {
      await ctx.reply(`❌ Gagal download audio: ${err.message}`);
    }
    return;
  }

  if (data === 'btn_cancel') {
    try {
      await ctx.deleteMessage();
    } catch (e) {}
  }
});

/**
 * Detect whether a prompt is a coding / system task vs casual chat
 * @param {string} prompt 
 * @returns {boolean}
 */
function isCodingOrComplexTask(prompt) {
  if (!prompt) return false;
  const p = prompt.toLowerCase().trim();

  // Code snippets, multi-line blocks, or long structured instructions
  if (prompt.includes('```') || prompt.includes('\n\n') || prompt.length > 180) {
    return true;
  }

  // Keywords that indicate coding, debugging, file manipulation, or system tasks
  const taskKeywords = [
    'buat', 'buatkan', 'bikin', 'create', 'write', 'code', 'coding', 'script', 'program',
    'fungsi', 'function', 'class', 'method', 'api', 'endpoint', 'database', 'sql',
    'query', 'debug', 'error', 'fix', 'perbaiki', 'benerin', 'cek file', 'edit',
    'ubah file', 'tulis file', 'baca file', 'install', 'jalankan', 'run', 'eksekusi',
    'terminal', 'bash', 'command', 'vps', 'server', 'deploy', 'git', 'pm2', 'docker',
    'bot', 'html', 'css', 'javascript', 'python', 'node', 'express', 'react',
    'vue', 'regex', 'algoritma', 'hitung', 'analisis', 'arsitektur', 'refactor',
    'tambah fitur', 'fitur baru', 'modifikasi', 'hapus file', 'buat folder', 'curl'
  ];

  for (const kw of taskKeywords) {
    const regex = new RegExp(`(^|\\s|[^a-zA-Z0-9])${kw}($|\\s|[^a-zA-Z0-9])`, 'i');
    if (regex.test(p)) {
      return true;
    }
  }

  return false;
}

// Core Agent Turn Execution Function
async function handleAgentTurn(ctx, prompt) {
  const userId = ctx.from.id;
  const session = getSession(userId);

  if (isUserRunning(userId)) {
    return ctx.reply('⚠️ Agent masih menjalankan tugas sebelumnya. Kirim /abort jika ingin membatalkan.');
  }

  const isTask = isCodingOrComplexTask(prompt);

  // If effort is 'auto' (or not specified):
  // casual chat -> 'low' (instant response, zero/minimal thinking tokens)
  // coding/tasks -> 'high' (deep reasoning & tool execution)
  let effectiveEffort = session.effort;
  if (!effectiveEffort || effectiveEffort === 'auto') {
    effectiveEffort = isTask ? 'high' : 'low';
  }

  let statusMsg = null;
  let typingTimer = null;

  if (isTask) {
    try {
      statusMsg = await ctx.reply('⚡ *Antigravity sedang memproses tugas...*', { parse_mode: 'Markdown' });
    } catch (e) {
      statusMsg = await ctx.reply('⚡ Antigravity sedang memproses tugas...');
    }
  } else {
    // Casual chat: send native typing action so chat feels snappy and normal
    ctx.replyWithChatAction('typing').catch(() => {});
    typingTimer = setInterval(() => {
      ctx.replyWithChatAction('typing').catch(() => {});
    }, 3500);
  }

  let lastStatusUpdate = Date.now();
  const updateStatus = async (newText) => {
    // If a tool runs during casual chat, convert to task status message
    if (!statusMsg) {
      if (typingTimer) {
        clearInterval(typingTimer);
        typingTimer = null;
      }
      try {
        statusMsg = await ctx.reply(`⚡ *Antigravity Agent*: ${newText}`, { parse_mode: 'Markdown' });
        return;
      } catch (e) {}
    }

    const now = Date.now();
    if (now - lastStatusUpdate < 1500) return;
    lastStatusUpdate = now;

    try {
      await ctx.api.editMessageText(
        ctx.chat.id,
        statusMsg.message_id,
        `⚡ *Antigravity Agent*: ${newText}`,
        { parse_mode: 'Markdown' }
      );
    } catch (e) {}
  };

  const startTime = Date.now();

  try {
    const result = await runAgy({
      userId,
      prompt,
      conversationId: session.conversationId,
      model: session.model,
      effort: effectiveEffort,
      mode: session.mode,
      cwd: session.cwd,
      onProgress: (event) => {
        if (event.type === 'tool_start') {
          const formatted = formatToolNotification(event.tool, event.params);
          updateStatus(`🛠️ Sedang mengeksekusi:\n${formatted}`);
        } else if (event.type === 'init' && event.conversation_id) {
          // Record conversation ID early
          if (!session.conversationId) {
            updateSession(userId, { conversationId: event.conversation_id });
          }
        }
      }
    });

    if (typingTimer) {
      clearInterval(typingTimer);
      typingTimer = null;
    }

    // Delete progress message
    if (statusMsg) {
      try {
        await ctx.api.deleteMessage(ctx.chat.id, statusMsg.message_id);
      } catch (e) {}
    }

    if (result.aborted) {
      return ctx.reply('🛑 *Tugas dibatalkan.*', { parse_mode: 'Markdown' });
    }

    if (!result.success) {
      return ctx.reply(
        `❌ *Terjadi Kesalahan saat memproses permintaan:*\n\n\`\`\`\n${result.error || 'Unknown error'}\n\`\`\``,
        { parse_mode: 'Markdown' }
      );
    }

    // Update conversation ID if newly assigned
    if (result.conversation_id) {
      updateSession(userId, { conversationId: result.conversation_id });
    }

    // Accumulate stats
    if (result.usage) {
      const u = result.usage;
      const sStats = session.sessionStats || {};
      const lStats = session.lifetimeStats || {};

      sStats.inputTokens = (sStats.inputTokens || 0) + (u.input_tokens || 0);
      sStats.outputTokens = (sStats.outputTokens || 0) + (u.output_tokens || 0);
      sStats.thinkingTokens = (sStats.thinkingTokens || 0) + (u.thinking_tokens || 0);
      sStats.totalTokens = (sStats.totalTokens || 0) + (u.total_tokens || 0);
      sStats.turns = (sStats.turns || 0) + 1;

      lStats.totalTurns = (lStats.totalTurns || 0) + 1;
      lStats.totalTokens = (lStats.totalTokens || 0) + (u.total_tokens || 0);

      updateSession(userId, { sessionStats: sStats, lifetimeStats: lStats });
    }

    // Prepare response with metadata footer only if it was a task
    const duration = result.duration_seconds || (Date.now() - startTime) / 1000;
    const footer = isTask ? formatMetadataFooter(duration, session.model, result.usage) : '';
    const finalContent = (result.response || '').trim() + footer;

    if (!finalContent.trim()) {
      return ctx.reply('✅ Tugas selesai dieksekusi tanpa output teks.');
    }

    await sendSafeMessage(ctx, finalContent);
  } catch (err) {
    if (typingTimer) {
      clearInterval(typingTimer);
      typingTimer = null;
    }
    if (statusMsg) {
      try {
        await ctx.api.deleteMessage(ctx.chat.id, statusMsg.message_id);
      } catch (e) {}
    }

    console.error('Error during handleAgentTurn:', err);
    await ctx.reply(`💥 *Terjadi error internal:* ${err.message}`, { parse_mode: 'Markdown' });
  }
}

// Handling Normal Text Messages
bot.on('message:text', async (ctx) => {
  const text = ctx.message.text.trim();
  if (text.startsWith('/')) return; // ignore unhandled commands

  // Auto-detect TikTok URL
  const tiktokUrl = extractTikTokUrl(text);
  if (tiktokUrl && (text.length < 250 || text.startsWith('http'))) {
    return handleTikTokDownload(ctx, tiktokUrl);
  }

  await handleAgentTurn(ctx, text);
});

// Handling Document / Photo Messages (Attachment inspection)
bot.on(['message:document', 'message:photo'], async (ctx) => {
  const caption = ctx.message.caption || 'Analisis dan jelaskan file yang saya kirimkan ini.';
  await ctx.reply('📎 Menerima file. Mengunduh ke workspace untuk diproses Antigravity...');

  try {
    const file = await ctx.getFile();
    const downloadDir = path.join(getSession(ctx.from.id).cwd, 'telegram_uploads');
    if (!fs.existsSync(downloadDir)) {
      fs.mkdirSync(downloadDir, { recursive: true });
    }

    const fileName = ctx.message.document?.file_name || `photo_${Date.now()}.jpg`;
    const localFilePath = path.join(downloadDir, fileName);

    const fileUrl = `https://api.telegram.org/file/bot${BOT_TOKEN}/${file.file_path}`;
    const res = await fetch(fileUrl);
    const arrayBuffer = await res.arrayBuffer();
    fs.writeFileSync(localFilePath, Buffer.from(arrayBuffer));

    // Smart auto-update profile photo if user asked to set it as avatar/profile
    if (/foto\s*profil|profile\s*photo|avatar|setpp/i.test(caption)) {
      try {
        const form = new FormData();
        form.append('photo', JSON.stringify({ type: 'static', photo: 'attach://bot_profile_jpg' }));
        form.append('bot_profile_jpg', new Blob([Buffer.from(arrayBuffer)]), fileName);
        const setRes = await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/setMyProfilePhoto`, {
          method: 'POST',
          body: form
        });
        const setJson = await setRes.json();
        if (setJson.ok) {
          return ctx.reply('✨ *Foto profil bot berhasil diperbarui!*', { parse_mode: 'Markdown' });
        }
      } catch (e) {
        console.error('Failed auto-updating bot profile photo:', e);
      }
    }

    const promptWithFile = `${caption}\n\n[File tersimpan di: ${localFilePath}]`;
    await handleAgentTurn(ctx, promptWithFile);
  } catch (err) {
    console.error('File download error:', err);
    await ctx.reply(`❌ Gagal mengunduh file: ${err.message}`);
  }
});

// Error handling
bot.catch((err) => {
  console.error('GrammY Bot Error:', err);
});

// Start bot
console.log('🤖 Menjalankan Antigravity Telegram Bot...');
bot.start({
  onStart: (botInfo) => {
    console.log(`✅ Bot berhasil aktif sebagai @${botInfo.username} (${botInfo.first_name})`);
  }
});
