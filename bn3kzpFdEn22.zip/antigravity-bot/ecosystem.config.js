module.exports = {
  apps: [
    {
      name: 'antigravity-bot',
      script: 'bot.js',
      cwd: '/home/nanasmuda/antigravity-bot',
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: '500M',
      env: {
        NODE_ENV: 'production',
        PATH: '/home/nanasmuda/.local/bin:/usr/local/bin:/usr/bin:/bin:' + process.env.PATH
      }
    }
  ]
};
