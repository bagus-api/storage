# 🚀 Antigravity Telegram Bot

Bot Telegram untuk mengendalikan **Google Antigravity AI Agent** di VPS Linux secara langsung dari aplikasi Telegram, tanpa perlu membuka terminal atau sesi SSH.

---

## ✨ Fitur Utama

1. **💬 Chat Biasa dengan AI Agent**:
   - Kirim pesan teks apapun seperti chatting biasa.
   - Antigravity agent akan berpikir, menggunakan tools (eksekusi terminal, membaca & mengedit file, search web), dan memberikan respon langsung ke Telegram.
   - Sesi percakapan tetap bersambung (stateful conversation) menggunakan conversation ID internal Antigravity.

2. **⚡ Notifikasi Proses Real-Time**:
   - Menampilkan status *"Sedang berpikir..."* dan notifikasi tool yang sedang dieksekusi secara live (misal: `run_command`, `edit_file`, dll).
   - Menghitung durasi respon dan penggunaan token (Input, Output, Thinking Tokens).

3. **📋 Manajemen Sesi Lengkap**:
   - `/new [prompt]` — Mulai sesi baru dari nol.
   - `/resume [id]` — Lanjutkan percakapan sebelumnya (menampilkan daftar 6 sesi terakhir dari database SQLite Antigravity dengan tombol inline interaktif atau bisa memasukkan UUID langsung).

4. **🧠 Penggantian Model Fleksibel**:
   - `/model` — Pilih model AI kapan saja menggunakan inline keyboard:
     - `gemini-3.8-flash-high` (Default - Super Cepat & Cerdas)
     - `gemini-3.8-flash-medium`
     - `gemini-3.8-flash-low`
     - `claude-sonnet-4-6` (Claude Sonnet 4.6 Thinking)
     - `claude-opus-4-6-thinking` (Claude Opus 4.6 Thinking)
     - `gpt-oss-120b-medium` (GPT-OSS 120B)

5. **📊 Statistik & Kontrol Agent**:
   - `/usage` — Rincian token input, output, thinking tokens untuk sesi ini dan total bot.
   - `/status` — Dashboard status agent, ID sesi aktif, model, mode, reasoning effort, dan direktori kerja.
   - `/effort [low|medium|high|xhigh|max]` — Atur kedalaman analisis model.
   - `/mode [auto|plan|accept-edits]` — Ganti mode agent (Auto, Plan, atau Accept-Edits).
   - `/cd <path>` & `/pwd` — Ganti atau lihat folder kerja di VPS tempat agent membuat file atau menjalankan command.
   - `/abort` — Hentikan paksa tugas agent yang sedang berjalan jika terlalu lama atau ingin dibatalkan.
   - `/bash <cmd>` — Jalankan perintah terminal VPS secara langsung.

6. **🔒 Keamanan & Proteksi Akses**:
   - Bot diproteksi sehingga orang asing tidak bisa sembarangan menjalankan script di VPS Anda.
   - Pengguna pertama yang mengirim `/start` otomatis terdaftar sebagai **Bot Owner**.
   - Owner dapat mengizinkan user lain dengan `/allow <user_id>` atau mencabut izin dengan `/disallow <user_id>`.

---

## 🛠️ Manajemen Service (PM2)

Bot ini sudah berjalan secara daemon di background VPS menggunakan PM2:

```bash
# Cek status bot
pm2 status

# Lihat log realtime bot
pm2 logs antigravity-bot

# Restart bot
pm2 restart antigravity-bot

# Hentikan bot
pm2 stop antigravity-bot
```

---

## 📁 Struktur Direktori

```text
/home/nanasmuda/antigravity-bot/
├── bot.js                  # Entry point bot Telegram (GrammY framework)
├── agy-runner.js           # Subprocess runner & streaming event parser untuk `agy`
├── conversation-db.js      # Pembaca database SQLite conversation_summaries.db
├── session-store.js        # Penyimpanan sesi per user, konfigurasi, & token stats
├── formatter.js            # Pemecah pesan <= 4000 karakter & safe markdown parser
├── ecosystem.config.js     # Konfigurasi daemon PM2
├── .env                    # Token bot Telegram & konfigurasi default
└── data/                   # Penyimpanan file sessions.json & config.json
```
