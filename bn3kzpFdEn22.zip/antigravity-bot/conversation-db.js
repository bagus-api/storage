const { DatabaseSync } = require('node:sqlite');
const path = require('node:path');
const os = require('node:os');
const fs = require('node:fs');

const DB_PATH = path.join(os.homedir(), '.gemini', 'antigravity-cli', 'conversation_summaries.db');

function getDb() {
  if (!fs.existsSync(DB_PATH)) {
    return null;
  }
  try {
    return new DatabaseSync(DB_PATH, { readOnly: true });
  } catch (err) {
    console.error('Error opening conversation_summaries.db:', err.message);
    return null;
  }
}

/**
 * Get recent conversations from SQLite summary database
 * @param {number} limit 
 * @returns {Array<{conversation_id: string, title: string, preview: string, step_count: number, last_modified_time: string}>}
 */
function getRecentConversations(limit = 8) {
  const db = getDb();
  if (!db) return [];

  try {
    const stmt = db.prepare(`
      SELECT conversation_id, title, preview, step_count, last_modified_time, status
      FROM conversation_summaries
      WHERE conversation_id != ''
      ORDER BY last_modified_time DESC
      LIMIT ?
    `);
    return stmt.all(limit);
  } catch (err) {
    console.error('Error fetching conversation summaries:', err);
    return [];
  }
}

/**
 * Get details for a specific conversation ID
 * @param {string} conversationId 
 */
function getConversationById(conversationId) {
  const db = getDb();
  if (!db) return null;

  try {
    const stmt = db.prepare(`
      SELECT conversation_id, title, preview, step_count, last_modified_time, status
      FROM conversation_summaries
      WHERE conversation_id = ? OR conversation_id LIKE ?
      LIMIT 1
    `);
    const result = stmt.get(conversationId, `${conversationId}%`);
    return result || null;
  } catch (err) {
    console.error('Error fetching conversation by id:', err);
    return null;
  }
}

module.exports = {
  getRecentConversations,
  getConversationById
};
