// Usage: node verify.js nanzzmodepoco "https://alight-creative.firebaseapp.com/..."
// apikey = true

const axios = require('axios');

const BASE_URL = 'https://www.alightfree.my.id';

async function getSession() {
    const response = await axios.get(BASE_URL, {
        headers: {
            'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Mobile Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7'
        }
    });

    const setCookie = response.headers['set-cookie'] || [];
    const cookies = setCookie.map(c => c.split(';')[0]).join('; ');

    let xsrfToken = '';
    for (const cookie of setCookie) {
        const match = cookie.match(/XSRF-TOKEN=([^;]+)/);
        if (match) {
            xsrfToken = decodeURIComponent(match[1]);
            break;
        }
    }

    if (!xsrfToken) {
        const match = response.data.match(/XSRF-TOKEN["'\s:=]+([a-f0-9-]{36})/i);
        if (match) xsrfToken = match[1];
    }

    return { cookies, xsrfToken };
}

module.exports = {
    category: 'Tools',
    post: true,
    params: ['email', 'rawLink'],
    desc: 'Verify akun Alight Motion',

    async run(req, res) {
        const email = String(req.query.email || req.body.email || '').trim();
        const rawLink = String(req.query.rawLink || req.body.rawLink || '').trim();

        if (!email || !rawLink) {
            return res.status(400).json({
                creator: 'Nanzz',
                status: false,
                message: 'Parameter email & rawLink diperlukan'
            });
        }

        try {
            const { cookies, xsrfToken } = await getSession();
            console.log('🔑 Token:', xsrfToken?.slice(0, 30) + '...');

            const response = await axios.post(
                `${BASE_URL}/api/verify`,
                { email, rawLink, website: '' },
                {
                    headers: {
                        'Accept': 'application/json, text/plain, */*',
                        'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
                        'Content-Type': 'application/json',
                        'Cookie': cookies,
                        'X-XSRF-TOKEN': xsrfToken,
                        'Origin': 'https://www.alightfree.my.id',
                        'Referer': 'https://www.alightfree.my.id/',
                        'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Mobile Safari/537.36',
                        'sec-ch-ua': '"Chromium";v="150", "Not;A=Brand";v="99"',
                        'sec-ch-ua-mobile': '?1',
                        'sec-ch-ua-platform': '"Android"'
                    },
                    timeout: 15000
                }
            );

            return res.json({
                creator: 'Nanzz',
                status: true,
                ...response.data
            });

        } catch (err) {
            // Debug: tampilkan full error
            console.error('❌ Status:', err.response?.status);
            console.error('❌ Data:', JSON.stringify(err.response?.data, null, 2));
            
            return res.status(500).json({
                creator: 'Nanzz',
                status: false,
                message: err.response?.data?.message || err.response?.data?.error || err.message,
                debug: err.response?.data
            });
        }
    }
};

// --- CLI Mode ---
if (require.main === module) {
    const email = process.argv[2];
    const rawLink = process.argv[3];

    if (!email || !rawLink) {
        console.log('Usage: node verify.js <email> <rawLink>');
        process.exit(1);
    }

    const req = { query: { email, rawLink }, body: { email, rawLink } };
    const res = {
        status: (c) => { console.log('📡 Status:', c); return res; },
        json: (d) => { console.log('\n' + JSON.stringify(d, null, 2)); return res; }
    };

    module.exports.run(req, res);
}
