/**
 * Split text into telegram-safe chunks (<= maxLength)
 * Preserves code blocks across chunks.
 * @param {string} text 
 * @param {number} maxLength 
 * @returns {string[]}
 */
function splitMessage(text, maxLength = 3900) {
  if (!text) return [''];
  if (text.length <= maxLength) return [text];

  const chunks = [];
  let remaining = text;
  let inCodeBlock = false;
  let currentCodeBlockLang = '';

  while (remaining.length > 0) {
    if (remaining.length <= maxLength) {
      chunks.push(remaining);
      break;
    }

    // Try finding a clean split point
    let splitIdx = remaining.lastIndexOf('\n\n', maxLength);
    if (splitIdx === -1 || splitIdx < maxLength * 0.4) {
      splitIdx = remaining.lastIndexOf('\n', maxLength);
    }
    if (splitIdx === -1 || splitIdx < maxLength * 0.4) {
      splitIdx = remaining.lastIndexOf(' ', maxLength);
    }
    if (splitIdx === -1 || splitIdx < maxLength * 0.3) {
      splitIdx = maxLength;
    }

    let chunk = remaining.slice(0, splitIdx);
    remaining = remaining.slice(splitIdx).replace(/^\n/, '');

    // Check code blocks balance in this chunk
    const codeBlockMatches = chunk.match(/```([a-zA-Z0-9_-]*)/g);
    if (codeBlockMatches) {
      for (const match of codeBlockMatches) {
        if (!inCodeBlock) {
          inCodeBlock = true;
          currentCodeBlockLang = match.replace('```', '').trim();
        } else {
          inCodeBlock = false;
          currentCodeBlockLang = '';
        }
      }
    }

    // If chunk ends inside a code block, close it and open in remaining
    if (inCodeBlock) {
      chunk += '\n```';
      remaining = `\`\`\`${currentCodeBlockLang}\n` + remaining;
    }

    chunks.push(chunk);
  }

  return chunks;
}

/**
 * Send safe message to Telegram, with fallback to plain text if Markdown parsing fails
 * @param {object} ctx GrammY context
 * @param {string} text
 * @param {object} [extra]
 */
async function sendSafeMessage(ctx, text, extra = {}) {
  const chunks = splitMessage(text, 3900);
  const sentMessages = [];

  for (let i = 0; i < chunks.length; i++) {
    const chunk = chunks[i];
    const isFirst = (i === 0);
    const isLast = (i === chunks.length - 1);
    
    // Pass reply_parameters to the first chunk so Telegram quote-notifies immediately
    // Pass reply_markup and other extras to the last chunk
    const options = {
      parse_mode: 'Markdown',
      ...(isFirst && extra.reply_parameters ? { reply_parameters: extra.reply_parameters } : {}),
      ...(isLast ? extra : (extra.reply_parameters ? { reply_parameters: extra.reply_parameters } : {}))
    };

    try {
      const msg = await ctx.reply(chunk, options);
      sentMessages.push(msg);
    } catch (err) {
      // If Markdown parsing error, retry as plain text
      try {
        const plainOptions = { ...options };
        delete plainOptions.parse_mode;
        const msg = await ctx.reply(chunk, plainOptions);
        sentMessages.push(msg);
      } catch (err2) {
        console.error('Failed sending message chunk:', err2.message);
      }
    }
  }

  return sentMessages;
}

/**
 * Format a human-readable tool notification
 * @param {string} toolName 
 * @param {object} params 
 * @returns {string}
 */
function formatToolNotification(toolName, params = {}) {
  switch (toolName) {
    case 'run_command':
      const cmd = (params.CommandLine || '').trim();
      const shortCmd = cmd.length > 50 ? cmd.slice(0, 47) + '...' : cmd;
      return `💻 \`run_command\`: ${shortCmd}`;
    case 'edit_file':
      return `✏️ \`edit_file\`: ${params.Path ? params.Path.split('/').pop() : ''}`;
    case 'write_file':
      return `📝 \`write_file\`: ${params.Path ? params.Path.split('/').pop() : ''}`;
    case 'read_file':
      return `📄 \`read_file\`: ${params.Path ? params.Path.split('/').pop() : ''}`;
    case 'search_web':
      return `🔍 \`search_web\`: "${params.query || ''}"`;
    case 'invoke_subagent':
      return `🤖 \`subagent\`: ${params.Role || params.TypeName || ''}`;
    default:
      return `⚙️ \`${toolName}\``;
  }
}

/**
 * Format token count nicely (e.g. 1.2k, 45.6k)
 * @param {number} num 
 * @returns {string}
 */
function formatTokens(num) {
  if (!num || isNaN(num)) return '0';
  if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
  if (num >= 1000) return (num / 1000).toFixed(1) + 'k';
  return String(num);
}

/**
 * Format metadata footer
 * @param {number|null} durationSec 
 * @param {string} model 
 * @param {object|null} usage 
 * @param {string|null} [engine=null]
 * @returns {string}
 */
function formatMetadataFooter(durationSec, model, usage, engine = null) {
  const parts = [];
  if (engine) {
    parts.push('🤖 `Antigravity`');
  }
  if (durationSec !== null && durationSec !== undefined) {
    parts.push(`⏱️ ${durationSec.toFixed(1)}s`);
  }
  if (model) {
    parts.push(`🧠 \`${model}\``);
  }
  if (usage && usage.total_tokens) {
    parts.push(`📊 ${formatTokens(usage.total_tokens)} tokens`);
  }
  return parts.length ? `\n\n—\n_${parts.join(' • ')}_` : '';
}

module.exports = {
  splitMessage,
  sendSafeMessage,
  formatToolNotification,
  formatTokens,
  formatMetadataFooter
};
