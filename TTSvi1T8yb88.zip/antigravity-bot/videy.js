const dns = require('node:dns');
const fs = require('node:fs');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const { URL } = require('node:url');

if (dns.setDefaultResultOrder) {
  dns.setDefaultResultOrder('ipv4first');
}

// Regex for matching Videy and related mirror domains
const VIDEY_DOMAINS_REGEX = /(?:videyfile\.top|videotube\.top|videy\.co)/i;
const GENERAL_URL_REGEX = /https?:\/\/[^\s<>"']+/gi;
const MAX_TELEGRAM_UPLOAD_BYTES = 49.5 * 1024 * 1024; // 49.5MB safe Telegram Bot API limit (actual is 50MB)
const MAX_COMPRESS_BYTES = 120 * 1024 * 1024; // Auto-compress videos up to 120MB to fit Telegram limit

/**
 * Clean URL from trailing punctuation
 * @param {string} url
 * @returns {string}
 */
function cleanUrl(url) {
  return url.replace(/[.,;:!?)>]+$/, '');
}

/**
 * Extract all Videy or video URLs from a given text (supports bulk)
 * @param {string} text
 * @returns {string[]}
 */
function extractVideyUrls(text) {
  if (!text) return [];
  const matches = text.match(GENERAL_URL_REGEX);
  if (!matches) return [];

  const cleaned = matches.map(cleanUrl).filter(Boolean);

  // If there are links matching known videy domains, prioritize them
  const videyMatches = cleaned.filter(u => VIDEY_DOMAINS_REGEX.test(u));
  if (videyMatches.length > 0) {
    return videyMatches;
  }

  // Otherwise return all valid URLs
  return cleaned;
}

/**
 * Helper to determine Videy file extension from id
 * (from Videy.co client-side player logic)
 * @param {string} id
 * @returns {string}
 */
function getVideyExtension(id) {
  if (!id) return 'mp4';
  if (id.length === 8 || (id.length === 9 && id.endsWith('1'))) return 'mp4';
  if (id.length === 9 && id.endsWith('2')) return 'mov';
  return 'mp4';
}

/**
 * Format bytes to human readable format
 * @param {number} bytes
 * @returns {string}
 */
function formatBytes(bytes) {
  if (!bytes || isNaN(bytes)) return 'Ukuran tidak diketahui';
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

/**
 * Check video headers via HEAD request without downloading content
 * @param {string} videoUrl
 * @returns {Promise<{ok: boolean, sizeBytes: number}>}
 */
async function checkVideoHeaders(videoUrl) {
  try {
    const res = await fetch(videoUrl, {
      method: 'HEAD',
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Referer': 'https://videy.co/'
      }
    });

    if (res.ok) {
      const contentLength = parseInt(res.headers.get('content-length') || '0', 10);
      return { ok: true, sizeBytes: contentLength };
    }
    return { ok: false, sizeBytes: 0 };
  } catch (err) {
    return { ok: false, sizeBytes: 0 };
  }
}

function buildMediaResult(id, ext, videoUrl, sourceUrl, sizeBytes) {
  const isTooLarge = sizeBytes > MAX_COMPRESS_BYTES;
  const needsCompression = sizeBytes > MAX_TELEGRAM_UPLOAD_BYTES && sizeBytes <= MAX_COMPRESS_BYTES;
  return {
    success: true,
    id,
    ext: ext || 'mp4',
    videoUrl,
    sourceUrl,
    sizeBytes,
    sizeFormatted: formatBytes(sizeBytes),
    needsCompression,
    isTooLarge
  };
}

/**
 * Resolve direct video URL and metadata from any Videy/mirror link
 * @param {string} inputUrl
 * @returns {Promise<object>}
 */
async function resolveVideyMedia(inputUrl) {
  const url = cleanUrl(inputUrl.trim());

  // 1. Check if it is already a direct CDN link
  const directCdnMatch = url.match(/https?:\/\/(?:cdn\d*\.)?videy\.co\/([a-zA-Z0-9_\-\.]+)\.(mp4|mov)/i);
  if (directCdnMatch) {
    const id = directCdnMatch[1];
    const ext = directCdnMatch[2] || 'mp4';
    const videoUrl = url;
    const meta = await checkVideoHeaders(videoUrl);
    return buildMediaResult(id, ext, videoUrl, url, meta.sizeBytes);
  }

  // 2. Check if videy.co with id parameter
  try {
    const parsed = new URL(url);
    const idParam = parsed.searchParams.get('id');
    if (parsed.hostname.includes('videy.co') && idParam) {
      const ext = getVideyExtension(idParam);
      const candidate1 = `https://cdn2.videy.co/${idParam}.${ext}`;
      const candidate2 = `https://cdn.videy.co/${idParam}.${ext}`;
      
      let meta = await checkVideoHeaders(candidate1);
      let chosenUrl = candidate1;
      if (!meta.ok) {
        meta = await checkVideoHeaders(candidate2);
        chosenUrl = candidate2;
      }

      return buildMediaResult(idParam, ext, chosenUrl, url, meta.sizeBytes);
    }
  } catch (e) {}

  // 3. Follow redirects and parse HTML (e.g. videyfile.top/live/?=... or videotube.top)
  const res = await fetch(url, {
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
      'Referer': url
    },
    redirect: 'follow'
  });

  const finalUrl = res.url;
  const contentType = res.headers.get('content-type') || '';

  // If redirect target is directly a video
  if (contentType.includes('video/') || contentType.includes('application/octet-stream')) {
    const contentLength = parseInt(res.headers.get('content-length') || '0', 10);
    const id = finalUrl.split('/').pop().split('?')[0].split('.')[0] || 'videy_video';
    return buildMediaResult(id, 'mp4', finalUrl, url, contentLength);
  }

  const html = await res.text();

  // Search for direct CDN video URL in HTML
  const cdnMatch = html.match(/https?:\/\/(?:cdn\d*\.)?videy\.co\/[a-zA-Z0-9_\-\.]+\.(?:mp4|mov)/i);
  if (cdnMatch) {
    const videoUrl = cdnMatch[0];
    const filename = videoUrl.split('/').pop().split('?')[0];
    const parts = filename.split('.');
    const id = parts[0];
    const ext = parts[1] || 'mp4';
    const meta = await checkVideoHeaders(videoUrl);
    return buildMediaResult(id, ext, videoUrl, url, meta.sizeBytes);
  }

  // Search for video tag src
  const tagMatch = html.match(/<video[^>]+src=["']([^"']+)["']/i) || html.match(/<source[^>]+src=["']([^"']+)["']/i);
  if (tagMatch && tagMatch[1]) {
    let videoUrl = tagMatch[1];
    if (videoUrl.startsWith('//')) videoUrl = 'https:' + videoUrl;
    else if (videoUrl.startsWith('/')) videoUrl = new URL(videoUrl, finalUrl).href;

    const filename = videoUrl.split('/').pop().split('?')[0];
    const parts = filename.split('.');
    const id = parts[0] || 'videy';
    const ext = parts[1] || 'mp4';
    const meta = await checkVideoHeaders(videoUrl);
    return buildMediaResult(id, ext, videoUrl, url, meta.sizeBytes);
  }

  // Check if final URL has id param
  try {
    const finalParsed = new URL(finalUrl);
    const finalId = finalParsed.searchParams.get('id');
    if (finalId) {
      const ext = getVideyExtension(finalId);
      const candidate1 = `https://cdn2.videy.co/${finalId}.${ext}`;
      const candidate2 = `https://cdn.videy.co/${finalId}.${ext}`;
      
      let meta = await checkVideoHeaders(candidate1);
      let chosenUrl = candidate1;
      if (!meta.ok) {
        meta = await checkVideoHeaders(candidate2);
        chosenUrl = candidate2;
      }

      return buildMediaResult(finalId, ext, chosenUrl, url, meta.sizeBytes);
    }
  } catch (e) {}

  throw new Error('Tidak ditemukan video yang valid di tautan tersebut.');
}

/**
 * Compress a video buffer using ffmpeg to fit within Telegram's Bot limit (<50 MB).
 * Guaranteed zero residual files (all temp files are deleted in the finally block).
 * 
 * @param {Buffer} inputBuffer
 * @param {string} [ext='mp4']
 * @returns {Buffer}
 */
function compressVideoBuffer(inputBuffer, ext = 'mp4') {
  const tempId = `${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
  const inPath = path.join('/tmp', `videy_in_${tempId}.${ext}`);
  const outPath = path.join('/tmp', `videy_out_${tempId}.mp4`);

  try {
    fs.writeFileSync(inPath, inputBuffer);

    const ffmpegRes = spawnSync('ffmpeg', [
      '-y',
      '-i', inPath,
      '-vf', "scale=-2:'min(720,ih)'",
      '-c:v', 'libx264',
      '-crf', '28',
      '-preset', 'veryfast',
      '-threads', '8',
      '-c:a', 'aac',
      '-b:a', '128k',
      '-movflags', '+faststart',
      outPath
    ], { encoding: 'utf8' });

    if (ffmpegRes.status !== 0) {
      console.error('FFmpeg compression failed:', ffmpegRes.stderr);
      throw new Error('Gagal mengompresi video dengan ffmpeg.');
    }

    if (!fs.existsSync(outPath)) {
      throw new Error('Hasil file kompresi tidak ditemukan.');
    }

    return fs.readFileSync(outPath);
  } finally {
    try { if (fs.existsSync(inPath)) fs.unlinkSync(inPath); } catch (_) {}
    try { if (fs.existsSync(outPath)) fs.unlinkSync(outPath); } catch (_) {}
  }
}

/**
 * Fast parallel downloader for Videy CDN with range requests.
 * Speeds up downloads by 4x-6x, falling back to standard stream if range is unsupported.
 * 
 * @param {string} videoUrl
 * @param {number} maxBytes
 * @returns {Promise<Buffer>}
 */
async function downloadVideoBuffer(videoUrl, maxBytes = MAX_COMPRESS_BYTES) {
  const headRes = await fetch(videoUrl, {
    method: 'HEAD',
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      'Referer': 'https://videy.co/'
    }
  });

  const contentLength = parseInt(headRes.headers.get('content-length') || '0', 10);
  if (contentLength > maxBytes) {
    const err = new Error(`Ukuran file (${formatBytes(contentLength)}) melebihi batas maksimal ${formatBytes(maxBytes)}`);
    err.code = 'FILE_TOO_LARGE';
    err.sizeBytes = contentLength;
    throw err;
  }

  const acceptRanges = (headRes.headers.get('accept-ranges') || '').toLowerCase().includes('bytes');

  // If file is > 4MB and supports ranges, use parallel segmented download (4x-6x speedup)
  if (contentLength > 4 * 1024 * 1024 && acceptRanges) {
    try {
      const concurrency = contentLength > 40 * 1024 * 1024 ? 6 : 4;
      const chunkSize = Math.ceil(contentLength / concurrency);
      const tasks = [];

      for (let i = 0; i < concurrency; i++) {
        const start = i * chunkSize;
        const end = Math.min(start + chunkSize - 1, contentLength - 1);
        tasks.push(
          fetch(videoUrl, {
            headers: {
              'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
              'Referer': 'https://videy.co/',
              'Range': `bytes=${start}-${end}`
            }
          }).then(async r => {
            if (!r.ok && r.status !== 206) {
              throw new Error(`Range chunk failed with status ${r.status}`);
            }
            return Buffer.from(await r.arrayBuffer());
          })
        );
      }

      const chunks = await Promise.all(tasks);
      const combined = Buffer.concat(chunks);
      return combined;
    } catch (segmentedErr) {
      console.warn('Parallel download failed, falling back to single stream:', segmentedErr.message);
    }
  }

  // Single-stream fallback
  const res = await fetch(videoUrl, {
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      'Referer': 'https://videy.co/'
    }
  });

  if (!res.ok) {
    throw new Error(`Gagal mendownload video (HTTP ${res.status})`);
  }

  const arrayBuf = await res.arrayBuffer();
  if (arrayBuf.byteLength > maxBytes) {
    const err = new Error(`Ukuran file (${formatBytes(arrayBuf.byteLength)}) melebihi batas ${formatBytes(maxBytes)}`);
    err.code = 'FILE_TOO_LARGE';
    err.sizeBytes = arrayBuf.byteLength;
    throw err;
  }

  return Buffer.from(arrayBuf);
}

/**
 * Fetch video buffer with automatic compression if needed.
 * Returns a Buffer with attached metadata (.isCompressed, .originalSize, .finalSize, .buffer).
 * 
 * @param {string} videoUrl
 * @param {object|number} [options]
 * @returns {Promise<Buffer>}
 */
async function fetchMediaBuffer(videoUrl, options = {}) {
  const opts = typeof options === 'number' ? { maxBytes: options } : (options || {});
  const maxBytes = opts.maxBytes || MAX_COMPRESS_BYTES;
  const onStatus = opts.onStatus;

  if (onStatus) {
    try { await onStatus('downloading'); } catch (_) {}
  }

  const rawBuffer = await downloadVideoBuffer(videoUrl, maxBytes);
  const originalSize = rawBuffer.length;

  // If video is within Telegram limit (49.5 MB), return directly
  if (originalSize <= MAX_TELEGRAM_UPLOAD_BYTES) {
    rawBuffer.isCompressed = false;
    rawBuffer.originalSize = originalSize;
    rawBuffer.finalSize = originalSize;
    rawBuffer.buffer = rawBuffer;
    return rawBuffer;
  }

  // If video is > 49.5 MB but <= maxBytes, compress with ffmpeg
  if (onStatus) {
    try { await onStatus('compressing', { originalSize }); } catch (_) {}
  }

  const compressedBuffer = compressVideoBuffer(rawBuffer);
  compressedBuffer.isCompressed = true;
  compressedBuffer.originalSize = originalSize;
  compressedBuffer.finalSize = compressedBuffer.length;
  compressedBuffer.buffer = compressedBuffer;

  return compressedBuffer;
}

module.exports = {
  extractVideyUrls,
  resolveVideyMedia,
  fetchMediaBuffer,
  compressVideoBuffer,
  formatBytes,
  cleanUrl,
  MAX_TELEGRAM_UPLOAD_BYTES,
  MAX_COMPRESS_BYTES
};
