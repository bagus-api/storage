const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');

const DATA_DIR = path.join(__dirname, 'data');
const SESSIONS_FILE = path.join(DATA_DIR, 'sessions.json');
const CONFIG_FILE = path.join(DATA_DIR, 'config.json');

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

const DEFAULT_MODEL = process.env.DEFAULT_MODEL || 'gemini-3.8-flash-high';
const DEFAULT_CWD = process.env.DEFAULT_CWD || os.homedir();

let sessions = {};
let config = {
  ownerId: null,
  allowedUsers: [],
  systemActive: true
};

// Load initial config
if (fs.existsSync(CONFIG_FILE)) {
  try {
    const loaded = JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8'));
    config = { ...config, ...loaded };
    if (config.systemActive === undefined) {
      config.systemActive = true;
    }
  } catch (e) {
    console.error('Failed reading config.json:', e);
  }
}

// Load initial sessions
if (fs.existsSync(SESSIONS_FILE)) {
  try {
    sessions = JSON.parse(fs.readFileSync(SESSIONS_FILE, 'utf8'));
  } catch (e) {
    console.error('Failed reading sessions.json:', e);
  }
}

// Check env for initial allowed users
if (process.env.ALLOWED_USERS) {
  const envUsers = process.env.ALLOWED_USERS.split(',').map(s => s.trim()).filter(Boolean);
  for (const u of envUsers) {
    if (!config.allowedUsers.includes(u)) {
      config.allowedUsers.push(u);
    }
  }
}

function saveConfig() {
  try {
    fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2), 'utf8');
  } catch (e) {
    console.error('Failed writing config.json:', e);
  }
}

function saveSessions() {
  try {
    // Avoid persisting transient fields like activeProc
    const toSave = {};
    for (const [k, v] of Object.entries(sessions)) {
      const copy = { ...v };
      delete copy.activeProc;
      delete copy.isRunning;
      toSave[k] = copy;
    }
    fs.writeFileSync(SESSIONS_FILE, JSON.stringify(toSave, null, 2), 'utf8');
  } catch (e) {
    console.error('Failed writing sessions.json:', e);
  }
}

function getSession(userId) {
  const idStr = String(userId);
  if (!sessions[idStr]) {
    sessions[idStr] = {
      userId: idStr,
      conversationId: null,
      model: DEFAULT_MODEL,
      effort: 'auto',
      mode: 'auto',
      cwd: DEFAULT_CWD,
      isRunning: false,
      activeProc: null,
      sessionStats: {
        inputTokens: 0,
        outputTokens: 0,
        thinkingTokens: 0,
        totalTokens: 0,
        turns: 0
      },
      lifetimeStats: {
        totalTurns: 0,
        totalTokens: 0
      },
      lastActivity: new Date().toISOString()
    };
    saveSessions();
  } else {
    // If effort was legacy 'high', default to 'auto' for smart detection
    if (!sessions[idStr].effort || sessions[idStr].effort === 'high') {
      sessions[idStr].effort = 'auto';
      saveSessions();
    }
  }
  return sessions[idStr];
}

function updateSession(userId, updates) {
  const sess = getSession(userId);
  Object.assign(sess, updates);
  sess.lastActivity = new Date().toISOString();
  saveSessions();
  return sess;
}

function resetSession(userId) {
  const sess = getSession(userId);
  const oldConvId = sess.conversationId;
  sess.conversationId = null;
  sess.sessionStats = {
    inputTokens: 0,
    outputTokens: 0,
    thinkingTokens: 0,
    totalTokens: 0,
    turns: 0
  };
  saveSessions();
  return oldConvId;
}

function isAllowed(userId) {
  const idStr = String(userId);
  // If no allowed users and no owner configured yet, first caller becomes owner automatically
  if (!config.ownerId && (!config.allowedUsers || config.allowedUsers.length === 0)) {
    config.ownerId = idStr;
    config.allowedUsers = [idStr];
    saveConfig();
    return true;
  }

  if (config.ownerId === idStr) return true;
  if (Array.isArray(config.allowedUsers) && config.allowedUsers.includes(idStr)) return true;

  return false;
}

function setOwner(userId) {
  const idStr = String(userId);
  config.ownerId = idStr;
  if (!config.allowedUsers.includes(idStr)) {
    config.allowedUsers.push(idStr);
  }
  saveConfig();
}

function allowUser(userId) {
  const idStr = String(userId);
  if (!config.allowedUsers.includes(idStr)) {
    config.allowedUsers.push(idStr);
    saveConfig();
    return true;
  }
  return false;
}

function disallowUser(userId) {
  const idStr = String(userId);
  if (config.ownerId === idStr) return false; // cannot disallow owner
  const idx = config.allowedUsers.indexOf(idStr);
  if (idx !== -1) {
    config.allowedUsers.splice(idx, 1);
    saveConfig();
    return true;
  }
  return false;
}

function getConfig() {
  return { ...config };
}

function isSystemActive() {
  return config.systemActive !== false;
}

function setSystemActive(active) {
  config.systemActive = Boolean(active);
  saveConfig();
  return config.systemActive;
}

module.exports = {
  getSession,
  updateSession,
  resetSession,
  isAllowed,
  setOwner,
  allowUser,
  disallowUser,
  getConfig,
  isSystemActive,
  setSystemActive,
  DEFAULT_MODEL,
  DEFAULT_CWD
};
