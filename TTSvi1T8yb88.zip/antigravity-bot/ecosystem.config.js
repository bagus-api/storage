module.exports = {
  apps: [
    {
      name: 'antigravity-bot',
      script: 'bot.js',
      cwd: '/root/antigravity-bot',
      instances: 1,
      exec_mode: 'fork',
      autorestart: true,
      watch: false,
      max_memory_restart: '500M',
      restart_delay: 2000,
      env: {
        NODE_ENV: 'production',
        PATH: '/root/.local/bin:/home/nanasmuda/.local/bin:/usr/local/bin:/usr/bin:/bin:' + process.env.PATH,
        LD_LIBRARY_PATH: '/root/.local/lib:/home/nanasmuda/.local/lib:' + (process.env.LD_LIBRARY_PATH || '')
      }
    }
  ]
};
