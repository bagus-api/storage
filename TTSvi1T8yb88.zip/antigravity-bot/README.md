# 🚀 Antigravity Telegram Bot

Bot Telegram untuk mengendalikan **Google Antigravity AI Agent** di VPS Linux secara langsung dari aplikasi Telegram, tanpa perlu membuka terminal atau sesi SSH.

---

## ✨ Fitur Utama

1. **🤖 Dual AI Engine (Antigravity & OpenCode)**:
   - **Antigravity AI (`agy`)**: Berbasis Google Gemini 3.8 / Claude / GPT dengan deep reasoning & tools sistem komprehensif.
   - **OpenCode AI (`opencode`)**: AI coding agent open-source berbasis terminal (`anomalyco/opencode` v2.2.3), responsif, ringan, dan spesialis koding multi-turn.
   - `/engine [agy|opencode]` — Switcher engine utama untuk perintah `/ai`.
   - `/oc <pesan>` atau `/opencode <pesan>` — Jalankan instruksi langsung di OpenCode AI tanpa perlu switch engine.
   - `/ai <pesan>` — Menjalankan tugas coding atau chat sesuai engine yang aktif di sesi user.
   - Sesi percakapan tetap bersambung (stateful multi-turn) baik di Antigravity maupun OpenCode.

2. **⚡ Notifikasi Proses Real-Time**:
   - Menampilkan status *"Sedang berpikir..."* dan notifikasi tool yang sedang dieksekusi secara live (misal: `run_command`, `edit_file`, dll).
   - Menghitung durasi respon dan penggunaan token (Input, Output, Thinking Tokens).

3. **📋 Manajemen Sesi Lengkap**:
   - `/new [prompt]` — Mulai sesi baru dari nol.
   - `/resume [id]` — Lanjutkan percakapan sebelumnya (menampilkan daftar 6 sesi terakhir dari database SQLite Antigravity dengan tombol inline interaktif atau bisa memasukkan UUID langsung).

4. **🧠 Penggantian Model Fleksibel**:
   - `/model` — Pilih model AI kapan saja menggunakan inline keyboard:
     - `gemini-3.8-flash-high` (Default - Super Cepat & Cerdas)
     - `gemini-3.8-flash-medium`
     - `gemini-3.8-flash-low`
     - `claude-sonnet-4-6` (Claude Sonnet 4.6 Thinking)
     - `claude-opus-4-6-thinking` (Claude Opus 4.6 Thinking)
     - `gpt-oss-120b-medium` (GPT-OSS 120B)

5. **📊 Statistik & Kontrol Agent**:
   - `/usage` — Rincian token input, output, thinking tokens untuk sesi ini dan total bot.
   - `/status` — Dashboard status agent, ID sesi aktif, model, mode, reasoning effort, dan direktori kerja.
   - `/effort [low|medium|high|xhigh|max]` — Atur kedalaman analisis model.
   - `/mode [auto|plan|accept-edits]` — Ganti mode agent (Auto, Plan, atau Accept-Edits).
   - `/cd <path>` & `/pwd` — Ganti atau lihat folder kerja di VPS tempat agent membuat file atau menjalankan command.
   - `/abort` — Hentikan paksa tugas agent yang sedang berjalan jika terlalu lama atau ingin dibatalkan.
   - `/bash <cmd>` — Jalankan perintah terminal VPS secara langsung.

6. **📥 Media & Link Utilities**:
   - `/remotion` — Render video MP4 dari file ZIP project React Remotion. Folder hasil ekstrak dan file video `.mp4` otomatis dihapus bersih dari VPS segera setelah selesai sehingga tidak memakan ruang storage.
   - `/videy <url...>` — Bulk Video Downloader untuk Videy (`videyfile.top`, `videotube.top`, `videy.co`). Mendukung download banyak link sekaligus secara langsung via RAM (in-memory streaming) tanpa disimpan di storage VPS, sehingga tidak memenuhi kapasitas disk.
   - `/tt <url>` — Download video TikTok tanpa watermark (HD) serta file audio MP3.
   - `/ouo <url...>` — Bulk Solver & Bypasser shortlink `ouo.io` dan `ouo.press` (mendukung banyak link sekaligus, melewati countdown iklan & reCAPTCHA v3 untuk mendapatkan link tujuan asli secara instan).

7. **🔒 Keamanan & Proteksi Akses**:
   - Bot diproteksi sehingga orang asing tidak bisa sembarangan menjalankan script di VPS Anda.
   - Pengguna pertama yang mengirim `/start` otomatis terdaftar sebagai **Bot Owner**.
   - Owner dapat mengizinkan user lain dengan `/allow <user_id>` atau mencabut izin dengan `/disallow <user_id>`.

---

## 🛠️ Manajemen Service (PM2)

Bot ini sudah berjalan secara daemon di background VPS menggunakan PM2:

```bash
# Cek status bot
pm2 status

# Lihat log realtime bot
pm2 logs antigravity-bot

# Restart bot
pm2 restart antigravity-bot

# Hentikan bot
pm2 stop antigravity-bot
```

---

## 📁 Struktur Direktori

```text
/home/nanasmuda/antigravity-bot/
├── bot.js                  # Entry point bot Telegram (GrammY framework)
├── agy-runner.js           # Subprocess runner & streaming event parser untuk `agy`
├── opencode-runner.js      # Subprocess runner & streaming event parser untuk `opencode`
├── conversation-db.js      # Pembaca database SQLite conversation_summaries.db
├── session-store.js        # Penyimpanan sesi per user, konfigurasi, & token stats
├── formatter.js            # Pemecah pesan <= 4000 karakter & safe markdown parser
├── ecosystem.config.js     # Konfigurasi daemon PM2
├── .env                    # Token bot Telegram & konfigurasi default
└── data/                   # Penyimpanan file sessions.json & config.json
```
