const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { spawn } = require('node:child_process');

let activeTunnelUrl = null;
let cloudflaredProcess = null;
let onUrlChangeCallback = null;

const PORT = 3344;
const WEBAPP_DIR = path.join(__dirname, 'webapp');
const LATEST_BACKUP_TXT = '/home/nanasmuda/backups/latest_url.txt';

/**
 * Native lightweight HTTP server for Telegram Mini App
 */
function createServer(handlers = {}) {
  const server = http.createServer((req, res) => {
    // Enable CORS and allow Telegram WebApp iframe embedding
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    res.removeHeader('X-Frame-Options');

    if (req.method === 'OPTIONS') {
      res.writeHead(204);
      return res.end();
    }

    const parsedUrl = new URL(req.url, `http://${req.headers.host}`);
    const pathname = parsedUrl.pathname;

    // Static WebApp HTML
    if (pathname === '/' || pathname === '/index.html') {
      const htmlPath = path.join(WEBAPP_DIR, 'index.html');
      if (fs.existsSync(htmlPath)) {
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
        return res.end(fs.readFileSync(htmlPath, 'utf-8'));
      }
      res.writeHead(404);
      return res.end('WebApp index.html not found');
    }

    // API: Live Status
    if (pathname === '/api/status' && req.method === 'GET') {
      let latestBackup = '';
      try {
        if (fs.existsSync(LATEST_BACKUP_TXT)) {
          latestBackup = fs.readFileSync(LATEST_BACKUP_TXT, 'utf-8').trim();
        }
      } catch (_) {}

      const statusData = handlers.getStatus ? handlers.getStatus() : {};
      res.writeHead(200, { 'Content-Type': 'application/json' });
      return res.end(
        JSON.stringify({
          status: 'online',
          latestBackupUrl: latestBackup,
          ...statusData
        })
      );
    }

    // API: Action Trigger from WebApp
    if (pathname === '/api/action' && req.method === 'POST') {
      let body = '';
      req.on('data', (chunk) => (body += chunk));
      req.on('end', async () => {
        try {
          const payload = JSON.parse(body || '{}');
          if (handlers.onAction) {
            await handlers.onAction(payload);
          }
          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ ok: true }));
        } catch (err) {
          res.writeHead(500, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ ok: false, error: err.message }));
        }
      });
      return;
    }

    res.writeHead(404);
    res.end('Not Found');
  });

  return server;
}

/**
 * Start Cloudflared Quick Tunnel
 */
function startTunnel(onReady) {
  if (onReady) onUrlChangeCallback = onReady;

  const bin = '/home/nanasmuda/.local/bin/cloudflared';
  if (!fs.existsSync(bin)) {
    console.warn('cloudflared binary not found at', bin);
    return;
  }

  console.log('🌐 Launching Cloudflare quick tunnel for WebApp...');
  cloudflaredProcess = spawn(bin, ['tunnel', '--url', `http://127.0.0.1:${PORT}`]);

  const handleOutput = (data) => {
    const text = data.toString();
    const match = text.match(/https:\/\/[a-z0-9-]+\.trycloudflare\.com/i);
    if (match) {
      const url = match[0];
      if (url !== activeTunnelUrl) {
        activeTunnelUrl = url;
        console.log(`🚀 Telegram WebApp URL is ready: ${activeTunnelUrl}`);
        if (onUrlChangeCallback) {
          onUrlChangeCallback(activeTunnelUrl);
        }
      }
    }
  };

  cloudflaredProcess.stdout.on('data', handleOutput);
  cloudflaredProcess.stderr.on('data', handleOutput);

  cloudflaredProcess.on('close', (code) => {
    console.warn(`cloudflared exited with code ${code}, restarting in 5s...`);
    activeTunnelUrl = null;
    setTimeout(() => startTunnel(onUrlChangeCallback), 5000);
  });
}

function getWebAppUrl() {
  return activeTunnelUrl;
}

function startWebAppService(handlers = {}, onReady) {
  const server = createServer(handlers);
  server.listen(PORT, '127.0.0.1', () => {
    console.log(`📱 WebApp local server listening on http://127.0.0.1:${PORT}`);
    startTunnel(onReady);
  });

  return {
    server,
    getWebAppUrl
  };
}

module.exports = {
  startWebAppService,
  getWebAppUrl
};
