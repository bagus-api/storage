const fs = require('node:fs');
const { execFile } = require('node:child_process');
const path = require('node:path');

const OUO_REGEX = /(?:https?:\/\/)?(?:www\.)?ouo\.(?:io|press)\/[A-Za-z0-9_-]+/i;
const OUO_GLOBAL_REGEX = /(?:https?:\/\/)?(?:www\.)?ouo\.(?:io|press)\/[A-Za-z0-9_-]+/gi;
const TERMUX_PYTHON = '/data/data/com.termux/files/usr/bin/python3';
const VENV_PYTHON = path.join(__dirname, 'venv', 'bin', 'python');
const PYTHON_PATH = fs.existsSync(TERMUX_PYTHON)
  ? TERMUX_PYTHON
  : (fs.existsSync(VENV_PYTHON) ? VENV_PYTHON : (process.env.PYTHON_PATH || 'python3'));
const SOLVER_SCRIPT = path.join(__dirname, 'ouo-solver.py');

/**
 * Clean URL from trailing punctuation and ensure scheme
 * @param {string} url
 * @returns {string}
 */
function cleanUrl(url) {
  let cleaned = (url || '').replace(/[.,;:!?)>]+$/, '').trim();
  if (cleaned && !cleaned.startsWith('http://') && !cleaned.startsWith('https://')) {
    cleaned = 'https://' + cleaned;
  }
  return cleaned;
}

/**
 * Extract all OuO URLs from a given text (supports bulk)
 * @param {string} text
 * @returns {string[]}
 */
function extractOuoUrls(text) {
  if (!text) return [];
  const matches = text.match(OUO_GLOBAL_REGEX);
  if (!matches) return [];

  const cleaned = matches.map(cleanUrl).filter(Boolean);
  return [...new Set(cleaned)];
}

/**
 * Extract single OuO URL from text string (backward compatibility)
 * @param {string} text 
 * @returns {string|null}
 */
function extractOuoUrl(text) {
  const urls = extractOuoUrls(text);
  return urls.length > 0 ? urls[0] : null;
}

/**
 * Run Python OuO solver script
 * @param {string} url 
 * @returns {Promise<object>}
 */
function runPythonSolver(url) {
  return new Promise((resolve) => {
    execFile(
      PYTHON_PATH,
      [SOLVER_SCRIPT, url],
      { timeout: 35000 },
      (error, stdout, stderr) => {
        if (stdout) {
          try {
            const data = JSON.parse(stdout.trim());
            return resolve(data);
          } catch (e) {
            // JSON parse failed
          }
        }

        if (error) {
          return resolve({
            success: false,
            original_url: url,
            error: error.message || 'Proses solver mengalami kendala atau timeout.'
          });
        }

        resolve({
          success: false,
          original_url: url,
          error: stderr ? stderr.trim() : 'Gagal memproses link OuO.'
        });
      }
    );
  });
}

/**
 * Fallback bypass using public unshorteners
 * @param {string} url 
 * @returns {Promise<string|null>}
 */
async function fallbackBypass(url) {
  try {
    const unshortenApi = `https://unshorten.me/json/${encodeURIComponent(url)}`;
    const res = await fetch(unshortenApi, { signal: AbortSignal.timeout(5000) });
    if (res.ok) {
      const data = await res.json();
      if (data && data.success && data.resolved_url && !data.resolved_url.includes('ouo.')) {
        return data.resolved_url;
      }
    }
  } catch {
    // Ignore fallback error
  }
  return null;
}

/**
 * Main solver function for OuO links
 * @param {string} inputUrl 
 * @returns {Promise<object>}
 */
async function solveOuo(inputUrl) {
  const url = extractOuoUrl(inputUrl);
  if (!url) {
    return {
      success: false,
      error: 'URL yang dimasukkan bukan link ouo.io atau ouo.press yang valid.'
    };
  }

  // 1. Run local dynamic reCAPTCHA v3 solver with TLS spoofing
  const result = await runPythonSolver(url);
  if (result.success && result.destination_url) {
    return result;
  }

  // 2. Try fallback
  const fallbackUrl = await fallbackBypass(url);
  if (fallbackUrl) {
    return {
      success: true,
      original_url: url,
      destination_url: fallbackUrl,
      duration_ms: 500,
      isFallback: true
    };
  }

  return result;
}

module.exports = {
  extractOuoUrl,
  extractOuoUrls,
  solveOuo,
  cleanUrl,
  OUO_REGEX
};
