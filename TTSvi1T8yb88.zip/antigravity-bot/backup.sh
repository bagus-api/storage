#!/bin/bash
set -e

BACKUP_DIR="/root/backups"
mkdir -p "$BACKUP_DIR"

TIMESTAMP=$(date +%Y%m%d_%H%M%S)
ZIP_FILE="$BACKUP_DIR/antigravity-bot-backup-$TIMESTAMP.zip"

echo "📦 Creating local backup archive..."
cd /root
zip -q -r "$ZIP_FILE" antigravity-bot \
  -x "antigravity-bot/node_modules/*" \
  -x "antigravity-bot/venv/*" \
  -x "antigravity-bot/.git/*" \
  -x "antigravity-bot/**/__pycache__/*" \
  -x "antigravity-bot/telegram_uploads/*" \
  -x "antigravity-bot/.pm2/*" \
  -x "antigravity-bot/*.log" \
  -x "antigravity-bot/tmp/*"

echo "🚀 Pushing code to Private GitHub Repository..."
cd /root/antigravity-bot
GITHUB_TOKEN="${GITHUB_TOKEN:-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}"
GITHUB_OWNER="${GITHUB_OWNER:-nanasmudawkwk}"
BACKUP_REPO="${BACKUP_REPO:-antigravity-bot}"

if ! git remote | grep -q "origin"; then
  git remote add origin "https://${GITHUB_OWNER}:${GITHUB_TOKEN}@github.com/${GITHUB_OWNER}/${BACKUP_REPO}.git"
else
  git remote set-url origin "https://${GITHUB_OWNER}:${GITHUB_TOKEN}@github.com/${GITHUB_OWNER}/${BACKUP_REPO}.git"
fi

git add -A
git commit -m "Backup: $TIMESTAMP" || true
git branch -M main
git push -u origin main --force || true

GITHUB_URL="https://github.com/${GITHUB_OWNER}/${BACKUP_REPO}"
echo "✅ Backup successfully synced to GitHub!"
echo "📁 Local File: $ZIP_FILE"
echo "🔗 GitHub Repo: $GITHUB_URL"

echo "$GITHUB_URL" > "$BACKUP_DIR/latest_url.txt"
