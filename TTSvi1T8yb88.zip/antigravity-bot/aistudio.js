const fs = require('node:fs');
const path = require('node:path');
const dns = require('node:dns');
const { chromium } = require('playwright');

if (dns.setDefaultResultOrder) {
  dns.setDefaultResultOrder('ipv4first');
}

const DATA_DIR = path.join(__dirname, 'data');
const CHROME_EXECUTABLE = '/home/nanasmuda/.remotion/chrome-headless-shell/linux64/chrome-headless-shell-linux64/chrome-headless-shell';

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

function getSessionFilePath(userId) {
  return path.join(DATA_DIR, `aistudio_${userId}.json`);
}

/**
 * Parse cookies from multiple input formats:
 * - JSON array from Cookie-Editor extension or storageState
 * - Key=Value header string
 * - Netscape format
 */
function parseCookies(input) {
  if (!input) return [];

  // 1. JSON Array or Object
  if (typeof input === 'string' && (input.trim().startsWith('[') || input.trim().startsWith('{'))) {
    try {
      const parsed = JSON.parse(input.trim());
      if (Array.isArray(parsed)) {
        return normalizeCookieList(parsed);
      }
      if (parsed.cookies && Array.isArray(parsed.cookies)) {
        return normalizeCookieList(parsed.cookies);
      }
    } catch (_) {}
  }

  if (Array.isArray(input)) {
    return normalizeCookieList(input);
  }

  // 2. Netscape cookie format (tab-separated lines)
  const lines = input.split('\n');
  const netscapeCookies = [];
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;
    const parts = trimmed.split('\t');
    if (parts.length >= 7) {
      netscapeCookies.push({
        domain: parts[0],
        path: parts[2],
        secure: parts[3] === 'TRUE',
        expires: Number(parts[4]) || -1,
        name: parts[5],
        value: parts[6]
      });
    }
  }
  if (netscapeCookies.length > 0) {
    return normalizeCookieList(netscapeCookies);
  }

  // 3. Raw HTTP Cookie Header (key1=value1; key2=value2)
  const headerCookies = [];
  const pairs = input.split(';');
  for (const pair of pairs) {
    const idx = pair.indexOf('=');
    if (idx > 0) {
      const name = pair.slice(0, idx).trim();
      const value = pair.slice(idx + 1).trim();
      if (name && value) {
        headerCookies.push({
          name,
          value,
          domain: '.google.com',
          path: '/',
          secure: true,
          httpOnly: false
        });
      }
    }
  }

  return normalizeCookieList(headerCookies);
}

function normalizeCookieList(cookies) {
  return cookies
    .filter(c => c && c.name && c.value !== undefined)
    .map(c => {
      let domain = c.domain || '.google.com';
      if (!domain.startsWith('.') && !domain.includes('google.com')) {
        domain = '.google.com';
      }
      const is3P = c.name.includes('3P') || c.name === 'SAPISID' || c.name === 'APISID' || c.name === 'SID';
      return {
        name: String(c.name).trim(),
        value: String(c.value).trim(),
        domain: domain,
        path: c.path || '/',
        expires: c.expirationDate || c.expires || Math.floor(Date.now() / 1000) + 86400 * 30,
        httpOnly: Boolean(c.httpOnly),
        secure: is3P ? true : (c.secure !== undefined ? Boolean(c.secure) : true),
        sameSite: is3P ? 'None' : (c.sameSite === 'no_restriction' ? 'None' : (c.sameSite === 'Strict' ? 'Strict' : 'Lax'))
      };
    });
}

/**
 * Check if the cookie array has crucial Google auth cookies
 */
function hasGoogleAuthCookies(cookies) {
  const names = new Set(cookies.map(c => c.name));
  return names.has('__Secure-1PSID') || names.has('__Secure-3PSID') || names.has('SID') || names.has('SAPISID');
}

/**
 * Load AI Studio session for user
 */
function loadSession(userId) {
  try {
    const p = getSessionFilePath(userId);
    if (fs.existsSync(p)) {
      return JSON.parse(fs.readFileSync(p, 'utf-8'));
    }
  } catch (err) {
    console.error(`Failed to load AI Studio session for ${userId}:`, err);
  }
  return null;
}

/**
 * Save AI Studio session for user
 */
function saveSession(userId, sessionData) {
  try {
    const p = getSessionFilePath(userId);
    const existing = loadSession(userId) || {};
    const updated = {
      ...existing,
      ...sessionData,
      updatedAt: new Date().toISOString()
    };
    fs.writeFileSync(p, JSON.stringify(updated, null, 2), 'utf-8');
    return updated;
  } catch (err) {
    console.error(`Failed to save AI Studio session for ${userId}:`, err);
    return null;
  }
}

/**
 * Delete AI Studio session for user
 */
function deleteSession(userId) {
  try {
    const p = getSessionFilePath(userId);
    if (fs.existsSync(p)) {
      fs.unlinkSync(p);
      return true;
    }
  } catch (err) {
    console.error(`Failed to delete AI Studio session for ${userId}:`, err);
  }
  return false;
}

/**
 * Verify Gemini API Key from Google AI Studio
 */
async function verifyApiKey(apiKey) {
  try {
    const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models?key=${apiKey}`);
    if (!res.ok) {
      const errJson = await res.json().catch(() => ({}));
      return {
        success: false,
        error: errJson.error?.message || `HTTP error ${res.status}`
      };
    }
    const data = await res.json();
    return {
      success: true,
      models: data.models ? data.models.map(m => m.name.replace('models/', '')) : []
    };
  } catch (err) {
    return {
      success: false,
      error: err.message
    };
  }
}

/**
 * Send prompt to Gemini API directly using user's AI Studio key
 */
async function sendPromptWithApiKey(apiKey, promptText, model = 'gemini-3.5-flash') {
  let targetModel = model || 'gemini-3.5-flash';
  // Map legacy or deprecated aliases
  if (targetModel === 'gemini-flash-latest' || targetModel === 'gemini-2.5-flash') {
    targetModel = 'gemini-3.5-flash';
  } else if (targetModel === 'gemini-flash-lite-latest' || targetModel === 'gemini-2.5-flash-lite') {
    targetModel = 'gemini-3.5-flash-lite';
  }

  const url = `https://generativelanguage.googleapis.com/v1beta/models/${targetModel}:generateContent?key=${apiKey}`;
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      contents: [{
        parts: [{ text: promptText }]
      }]
    })
  });

  if (!res.ok) {
    const errJson = await res.json().catch(() => ({}));
    const errMsg = errJson.error?.message || `HTTP ${res.status}`;

    // Quota exhausted on free tier for Argon or Pro
    if (res.status === 429 && (targetModel.includes('argon') || targetModel.includes('pro'))) {
      throw new Error(
        `Model <code>${targetModel}</code> pada Gemini API Key membutuhkan penautan akun Google Cloud Billing (Pay-As-You-Go).\n\n` +
        `💡 <b>Solusi:</b>\n` +
        `1. Beralih ke <b>Gemini 3.5 Flash</b> (Gratis, Cerdas & Cepat): <code>/modelais gemini-3.5-flash</code>\n` +
        `2. Atau jalankan langsung via Web Playground (Google One PRO): <code>/aismode web</code>`
      );
    }

    // Auto fallback to flash-lite if high demand 503
    if (res.status === 503 && targetModel !== 'gemini-3.5-flash-lite') {
      return await sendPromptWithApiKey(apiKey, promptText, 'gemini-3.5-flash-lite');
    }

    throw new Error(errMsg);
  }

  const data = await res.json();
  const text = data.candidates?.[0]?.content?.parts?.[0]?.text;
  if (!text) {
    throw new Error('Tidak menerima output teks dari model Gemini.');
  }
  return text;
}

/**
 * Verify and initialize AI Studio session with cookies or API Key
 */
async function verifyAndSaveSession(userId, cookieInput) {
  const trimmed = typeof cookieInput === 'string' ? cookieInput.trim() : '';

  // 1. Check if user provided Gemini API Key directly (starts with AIzaSy or AQ.)
  if (trimmed.startsWith('AIzaSy') || trimmed.startsWith('AQ.')) {
    const keyRes = await verifyApiKey(trimmed);
    if (!keyRes.success) {
      return {
        success: false,
        error: `API Key Google AI Studio tidak valid: ${keyRes.error}`
      };
    }
    const saved = saveSession(userId, {
      userId,
      type: 'apikey',
      apiKey: trimmed,
      mode: 'api',
      model: 'gemini-3.5-flash',
      email: 'Google AI Studio (Akun Pribadi)',
      activePromptUrl: 'https://aistudio.google.com/app/prompts/new_chat',
      activePromptTitle: 'Gemini 3.5 Flash (Real-Time)',
      lastVerified: new Date().toISOString()
    });
    return {
      success: true,
      isApiKey: true,
      email: saved.email,
      url: saved.activePromptUrl,
      title: saved.activePromptTitle
    };
  }

  const cookies = parseCookies(cookieInput);
  if (!cookies || cookies.length === 0) {
    return {
      success: false,
      error: 'Format cookies tidak dikenali atau kosong. Pastikan Anda menyalin cookies dengan benar.'
    };
  }

  const names = new Set(cookies.map(c => c.name));
  const hasPrimarySecure = names.has('__Secure-1PSID') || names.has('__Secure-3PSID');
  if (!hasPrimarySecure) {
    return {
      success: false,
      error: 'Cookie __Secure-1PSID tidak ditemukan!\n\nString yang Anda salin berasal dari document.cookie di mana Google sengaja menyembunyikan cookie login utama (__Secure-1PSID) karena proteksi HttpOnly.\n\nSolusi di Android:\n1. Buka aistudio.google.com/app/apikey ➔ Tap "Create API key" ➔ Copy kuncinya (AIzaSy...) ➔ Paste ke bot: /loginais <kunci>\n2. Atau gunakan Kiwi Browser di Android dengan ekstensi Cookie-Editor (Export -> JSON).'
    };
  }

  let browser = null;
  try {
    browser = await chromium.launch({
      executablePath: fs.existsSync(CHROME_EXECUTABLE) ? CHROME_EXECUTABLE : undefined,
      args: [
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-dev-shm-usage',
        '--disable-gpu',
        '--disable-blink-features=AutomationControlled'
      ]
    });

    const context = await browser.newContext({
      userAgent: 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
      viewport: { width: 1280, height: 800 }
    });

    await context.addCookies(cookies);

    const page = await context.newPage();
    await page.goto('https://aistudio.google.com/', {
      waitUntil: 'domcontentloaded',
      timeout: 25000
    });

    // Short grace period to allow client-side redirects or auth hydration
    await page.waitForTimeout(3000);

    const currentUrl = page.url();
    const title = await page.title();

    // Check if redirected to welcome or login page
    if (currentUrl.includes('/welcome') || currentUrl.includes('accounts.google.com')) {
      await browser.close();
      return {
        success: false,
        error: 'Sesi ditolak oleh Google (dialihkan ke halaman Login/Welcome). Cookies mungkin sudah kadaluarsa atau tidak lengkap.'
      };
    }

    // Try to extract user email or account identifier
    let email = null;
    try {
      email = await page.evaluate(() => {
        const els = Array.from(document.querySelectorAll('[aria-label], [title], span, a'));
        for (const el of els) {
          const text = (el.getAttribute('aria-label') || el.getAttribute('title') || el.innerText || '');
          const match = text.match(/([a-zA-Z0-9._%+-]+@(?:gmail\.com|[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}))/);
          if (match) return match[1];
        }
        return null;
      });
    } catch (_) {}

    // Extract storage state (cookies + localStorage)
    const storageState = await context.storageState();
    await browser.close();

    const hasPsidts = names.has('__Secure-1PSIDTS') || names.has('__Secure-3PSIDTS');
    const saved = saveSession(userId, {
      userId,
      email: email || 'Akun Google Terverifikasi',
      cookies,
      hasPsidts,
      mode: 'web',
      model: 'gemini-4-argon',
      storageState,
      lastVerified: new Date().toISOString(),
      activePromptUrl: currentUrl.includes('/prompts/') ? currentUrl : 'https://aistudio.google.com/prompts/new_chat',
      activePromptTitle: title || 'New Chat'
    });

    return {
      success: true,
      email: saved.email,
      url: currentUrl,
      title,
      hasPsidts
    };
  } catch (err) {
    if (browser) {
      try { await browser.close(); } catch (_) {}
    }
    return {
      success: false,
      error: `Gagal verifikasi sesi AI Studio: ${err.message}`
    };
  }
}

/**
 * Launch an authenticated browser page for user
 */
async function launchUserSession(userId) {
  const session = loadSession(userId);
  if (!session || !session.cookies) {
    throw new Error('Anda belum login ke Google AI Studio. Ketik /loginais untuk menghubungkan akun Google Anda.');
  }

  const browser = await chromium.launch({
    executablePath: fs.existsSync(CHROME_EXECUTABLE) ? CHROME_EXECUTABLE : undefined,
    args: [
      '--no-sandbox',
      '--disable-setuid-sandbox',
      '--disable-dev-shm-usage',
      '--disable-gpu',
      '--disable-blink-features=AutomationControlled'
    ]
  });

  const contextOptions = {
    userAgent: 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
    viewport: { width: 1280, height: 800 }
  };

  if (session.storageState) {
    contextOptions.storageState = session.storageState;
  }

  const context = await browser.newContext(contextOptions);

  if (session.cookies && session.cookies.length > 0) {
    await context.addCookies(session.cookies);
  }

  return { browser, context };
}

/**
 * Create a new chat / prompt in Google AI Studio
 */
async function createNewApp(userId) {
  const { browser, context } = await launchUserSession(userId);
  try {
    const page = await context.newPage();
    await page.goto('https://aistudio.google.com/prompts/new_chat', {
      waitUntil: 'domcontentloaded',
      timeout: 25000
    });

    await page.waitForTimeout(2000);
    const url = page.url();
    const title = (await page.title()) || 'New Chat';

    // Update active prompt in session
    saveSession(userId, {
      activePromptUrl: url,
      activePromptTitle: title,
      lastActivity: new Date().toISOString()
    });

    await browser.close();
    return {
      success: true,
      url,
      title
    };
  } catch (err) {
    await browser.close();
    return {
      success: false,
      error: `Gagal membuat prompt baru: ${err.message}`
    };
  }
}

/**
 * List recent prompts from Google AI Studio Library
 */
async function listRecentPrompts(userId) {
  const { browser, context } = await launchUserSession(userId);
  try {
    const page = await context.newPage();
    await page.goto('https://aistudio.google.com/library', {
      waitUntil: 'domcontentloaded',
      timeout: 25000
    });

    await page.waitForTimeout(3000);

    // Extract prompt links and titles from library table/cards
    const prompts = await page.evaluate(() => {
      const results = [];
      const links = Array.from(document.querySelectorAll('a[href*="/prompts/"]'));
      for (const a of links) {
        const href = a.href;
        const text = (a.innerText || a.getAttribute('aria-label') || '').trim();
        if (href && text && !results.some(r => r.url === href)) {
          results.push({
            title: text.split('\n')[0].slice(0, 50),
            url: href
          });
        }
      }
      return results.slice(0, 8); // max 8 recent prompts
    });

    await browser.close();
    return {
      success: true,
      prompts
    };
  } catch (err) {
    await browser.close();
    return {
      success: false,
      error: `Gagal mengambil daftar prompt: ${err.message}`,
      prompts: []
    };
  }
}

async function dismissPopups(page) {
  try {
    const continueBtn = page.locator('button:has-text("Continue"), button:has-text("Accept"), button:has-text("Get started"), [aria-label="Close dialog"]:has-text("Continue")').first();
    if (await continueBtn.isVisible({ timeout: 1500 })) {
      await continueBtn.click();
      await page.waitForTimeout(500);
    }
  } catch (_) {}
}

/**
 * Send a prompt in real-time to Google AI Studio and stream/extract the response
 */
async function sendPromptToAIStudio(userId, promptText, onProgress) {
  const session = loadSession(userId);
  if (!session) {
    return {
      success: false,
      error: 'Anda belum login. Ketik /loginais untuk menghubungkan akun Google AI Studio Anda.'
    };
  }

  // Execution mode:
  // If explicitly set to 'web', or if only cookies exist without API key.
  const isWebMode = session.mode === 'web' || (!session.apiKey && session.cookies);

  // Fast path: If session uses Google AI Studio API Key and not forced to web
  if (!isWebMode && (session.type === 'apikey' || session.apiKey)) {
    const model = session.model || 'gemini-3.5-flash';
    if (onProgress) onProgress(`Mengirim prompt ke Google AI Studio (${model})...`);
    try {
      const text = await sendPromptWithApiKey(session.apiKey, promptText, model);
      return {
        success: true,
        text,
        url: 'https://aistudio.google.com/app/prompts/new_chat'
      };
    } catch (err) {
      return {
        success: false,
        error: `Gagal dari Gemini API (${model}):\n\n${err.message}`
      };
    }
  }

  const { browser, context } = await launchUserSession(userId);
  let targetUrl = session.activePromptUrl || 'https://aistudio.google.com/prompts/new_chat';
  if (session.model && targetUrl.includes('/prompts/new_chat') && !targetUrl.includes('model=')) {
    targetUrl += `?model=${encodeURIComponent(session.model)}`;
  }

  try {
    const page = await context.newPage();
    await page.goto(targetUrl, {
      waitUntil: 'domcontentloaded',
      timeout: 30000
    });

    if (onProgress) onProgress('Memuat playground AI Studio...');
    await page.waitForTimeout(2000);
    await dismissPopups(page);

    // Selectors from Google AI Studio UI
    const inputSelector = 'textarea.textarea, ms-autosize-textarea textarea, ms-prompt-input-wrapper textarea, ms-prompt-box textarea, textarea';
    const submitSelector = 'ms-run-button button[type="submit"], button[aria-label="Run"], button.run-button';
    const responseSelector = 'ms-chat-turn .chat-turn-container.model, ms-cmark-node.cmark-node, .model-turn-container';

    await page.waitForSelector(inputSelector, { timeout: 15000 });

    if (onProgress) onProgress('Mengetik prompt ke Google AI Studio...');
    const inputEl = page.locator(inputSelector).last();
    await inputEl.fill(promptText);
    await page.waitForTimeout(500);
    await dismissPopups(page);

    // Submit prompt reliably via DOM click & Control+Enter
    const submitted = await page.evaluate(() => {
      const runBtn = document.querySelector('ms-run-button button') || document.querySelector('button.run-button') || document.querySelector('button[aria-label="Run"]');
      if (runBtn) {
        runBtn.click();
        return true;
      }
      return false;
    });

    if (!submitted) {
      const runBtn = page.locator(submitSelector).first();
      if (await runBtn.isVisible()) {
        await runBtn.click({ force: true }).catch(() => {});
      } else {
        await inputEl.press('Control+Enter');
      }
    }

    if (onProgress) onProgress('Menunggu respons model Gemini di AI Studio...');

    // Wait for response text to appear and finish generating
    let lastLength = 0;
    let unchangedCount = 0;
    let finalText = '';

    for (let i = 0; i < 60; i++) {
      await page.waitForTimeout(1000);

      // Check thinking status
      const isThinking = await page.evaluate(() => {
        const lastTurn = document.querySelector('ms-chat-turn:has(.model), .chat-turn-container.model, ms-chat-turn:not(:has(.user))');
        return lastTurn && (lastTurn.innerText.includes('Thinking') || !!lastTurn.querySelector('ms-thought-chunk, .thought-container'));
      });
      if (isThinking && onProgress && (i % 3 === 0)) {
        onProgress('Model Gemini sedang berpikir (Thinking reasoning)...');
      }

      // Check for Google AI Studio permission / Drive access errors
      const errorCheck = await page.evaluate(() => {
        const els = Array.from(document.querySelectorAll('ms-chat-turn, ms-callout, .error-container, [role="alert"], mat-snack-bar-container'));
        for (const el of els) {
          const txt = (el.innerText || '').trim();
          if (txt.includes('Permission denied') || txt.includes('The caller does not have permission')) {
            return 'PERMISSION_DENIED';
          }
          if (txt.includes('not granted access to Drive') || txt.includes('Allow Drive access') || txt.includes('Allow access to Google Drive')) {
            return 'DRIVE_PERMISSION_REQUIRED';
          }
        }
        return null;
      });

      if (errorCheck === 'PERMISSION_DENIED') {
        await browser.close();
        const hasPsidts = session.cookies && session.cookies.some(c => c.name === '__Secure-1PSIDTS');
        if (!hasPsidts) {
          return {
            success: false,
            error:
              `<b>Izin Google AI Studio Ditolak (Missing __Secure-1PSIDTS)!</b>\n\n` +
              `Google menerapkan proteksi keamanan <i>Device Bound Session</i>. Sesi cookies Anda belum menyertakan token keamanan <code>__Secure-1PSIDTS</code> sehingga Google menolak RPC di web playground.\n\n` +
              `💡 <b>Solusi:</b>\n` +
              `• <b>Cara 1 (Langsung Aktif & Cepat):</b> Beralih ke <b>Gemini 3.5 Flash</b> via API Key gratis:\n` +
              `  Ketik <code>/aismode api</code> lalu <code>/modelais gemini-3.5-flash</code>.\n\n` +
              `• <b>Cara 2 (Untuk Gemini 4 Argon via Kiwi Browser Android):</b>\n` +
              `  1. Buka Kiwi Browser ➔ Titik tiga (⋮) ➔ <b>Ekstensi</b> ➔ <b>Cookie-Editor</b> ➔ <b>Detail</b>.\n` +
              `  2. Ubah <b>Akses Situs</b> menjadi <b>"Di semua situs"</b> (On all sites).\n` +
              `  3. Buka <code>https://aistudio.google.com</code> ➔ Buka Cookie-Editor ➔ <b>Export</b> ➔ <b>Export as JSON</b>.\n` +
              `  4. Kirim file cookies tersebut ke bot ini.`
          };
        }
        return {
          success: false,
          error:
            `<b>Google AI Studio: Permission Denied.</b>\n\n` +
            `Akun Anda belum memiliki izin untuk model ini pada playground AI Studio.\n` +
            `Silakan coba alihkan model ke <code>gemini-3.5-flash</code> via <code>/modelais gemini-3.5-flash</code>.`
        };
      }

      if (errorCheck === 'DRIVE_PERMISSION_REQUIRED') {
        await browser.close();
        return {
          success: false,
          error:
            `<b>Akun Google Anda (${session.email}) belum mengizinkan akses Google Drive di AI Studio!</b>\n\n` +
            `Google AI Studio menyimpan prompt langsung di Google Drive Anda. Karena ini akun baru di AI Studio, Google meminta izin Drive 1 kali saja.\n\n` +
            `💡 <b>Solusi 1 Kali Klik di HP:</b>\n` +
            `1. Buka link ini di browser HP Anda (Chrome/Firefox):\n` +
            `   👉 <a href="https://aistudio.google.com/library">https://aistudio.google.com/library</a>\n` +
            `2. Klik tombol biru <b>"Allow Drive access"</b> (atau <i>Izinkan akses Drive</i>).\n` +
            `3. Pilih akun Google Anda lalu klik <b>"Allow" / "Izinkan"</b>.\n` +
            `4. Selesai! Setelah itu langsung ketik ulang <code>/ais &lt;pesan&gt;</code> di sini.\n\n` +
            `<i>(Catatan: Cookie Anda sudah aman tersimpan di bot, Anda TIDAK perlu menyalin cookie lagi!)</i>`
        };
      }

      // Check current model response text
      const currentText = await page.evaluate(() => {
        const modelTurns = Array.from(document.querySelectorAll('ms-chat-turn:has(.model), .chat-turn-container.model, ms-chat-turn:not(:has(.user))'));
        if (modelTurns.length === 0) return '';
        const lastTurn = modelTurns[modelTurns.length - 1];

        // 1. Direct markdown node inside last turn
        const cmarkNodes = Array.from(lastTurn.querySelectorAll('ms-cmark-node:not(.user-chunk), .cmark-node:not(.user-chunk)'));
        if (cmarkNodes.length > 0) {
          const directText = cmarkNodes.map(n => n.innerText || n.textContent || '').join('\n').trim();
          if (directText && !directText.startsWith('edit\n') && directText.length > 0) {
            return directText;
          }
        }

        // 2. Clone and strip non-text elements (buttons, icons, thoughts, headers)
        try {
          const clone = lastTurn.cloneNode(true);
          clone.querySelectorAll('button, [role="button"], ms-thought-chunk, .thought-container, .turn-header, .action-buttons, [aria-label*="thumb"], mat-icon, .material-symbols-outlined').forEach(el => el.remove());
          const cleaned = (clone.innerText || clone.textContent || '').trim();
          if (cleaned) return cleaned;
        } catch (_) {}

        return (lastTurn.innerText || '').trim();
      });

      if (currentText && currentText.length > 0) {
        finalText = currentText;
        if (currentText.length === lastLength) {
          unchangedCount++;
          if (unchangedCount >= 3) {
            // Generation stabilized
            break;
          }
        } else {
          lastLength = currentText.length;
          unchangedCount = 0;
          if (onProgress) {
            onProgress(`Menerima respons (${currentText.length} karakter)...`);
          }
        }
      }
    }

    // Clean up internal metadata headers if present
    if (finalText) {
      finalText = finalText.replace(/^(edit\s*|more_vert\s*|Model\s+\d+:\d+\s+[AP]M\s*)+/gi, '').trim();
    }

    const finalUrl = page.url();
    saveSession(userId, {
      activePromptUrl: finalUrl,
      lastActivity: new Date().toISOString()
    });

    await browser.close();

    if (!finalText) {
      return {
        success: false,
        error:
          `<b>AI Studio tidak merespons dalam waktu 60 detik.</b>\n\n` +
          `Kemungkinan koneksi playground lambat atau ada izin akun yang tertahan.\n` +
          `Pastikan Anda sudah membuka <a href="https://aistudio.google.com">Google AI Studio</a> di browser HP setidaknya sekali.`
      };
    }

    return {
      success: true,
      text: finalText,
      url: finalUrl
    };
  } catch (err) {
    try { await browser.close(); } catch (_) {}
    return {
      success: false,
      error: `Error saat mengeksekusi di AI Studio: ${err.message}`
    };
  }
}

module.exports = {
  parseCookies,
  hasGoogleAuthCookies,
  loadSession,
  saveSession,
  deleteSession,
  verifyAndSaveSession,
  verifyApiKey,
  sendPromptWithApiKey,
  createNewApp,
  listRecentPrompts,
  sendPromptToAIStudio
};
