let DatabaseSync = null;
try {
  DatabaseSync = require('node:sqlite').DatabaseSync;
} catch {
  // node:sqlite is available natively in Node.js >= 22.5.0
}

const path = require('node:path');
const os = require('node:os');
const fs = require('node:fs');
const { execFileSync } = require('node:child_process');

const DB_PATH = path.join(os.homedir(), '.gemini', 'antigravity-cli', 'conversation_summaries.db');

function getDb() {
  if (!DatabaseSync || !fs.existsSync(DB_PATH)) {
    return null;
  }
  try {
    return new DatabaseSync(DB_PATH, { readOnly: true });
  } catch (err) {
    console.error('Error opening conversation_summaries.db:', err.message);
    return null;
  }
}

function querySqliteCli(sql, args = []) {
  if (!fs.existsSync(DB_PATH)) return [];
  try {
    let query = sql;
    for (const arg of args) {
      const val = typeof arg === 'number' ? arg : `'${String(arg).replace(/'/g, "''")}'`;
      query = query.replace('?', val);
    }
    const stdout = execFileSync('sqlite3', ['-json', DB_PATH, query], {
      encoding: 'utf8',
      timeout: 5000,
      maxBuffer: 10 * 1024 * 1024
    });
    return JSON.parse(stdout.trim() || '[]');
  } catch (err) {
    console.error('Error querying sqlite3 CLI:', err.message);
    return [];
  }
}

/**
 * Get recent conversations from SQLite summary database
 * @param {number} limit 
 * @returns {Array<{conversation_id: string, title: string, preview: string, step_count: number, last_modified_time: string}>}
 */
function getRecentConversations(limit = 8) {
  const db = getDb();
  if (db) {
    try {
      const stmt = db.prepare(`
        SELECT conversation_id, title, preview, step_count, last_modified_time, status
        FROM conversation_summaries
        WHERE conversation_id != ''
        ORDER BY last_modified_time DESC
        LIMIT ?
      `);
      return stmt.all(limit);
    } catch (err) {
      console.error('Error fetching conversation summaries:', err);
      return [];
    }
  }

  return querySqliteCli(`
    SELECT conversation_id, title, preview, step_count, last_modified_time, status
    FROM conversation_summaries
    WHERE conversation_id != ''
    ORDER BY last_modified_time DESC
    LIMIT ?
  `, [limit]);
}

/**
 * Get details for a specific conversation ID
 * @param {string} conversationId 
 */
function getConversationById(conversationId) {
  const db = getDb();
  if (db) {
    try {
      const stmt = db.prepare(`
        SELECT conversation_id, title, preview, step_count, last_modified_time, status
        FROM conversation_summaries
        WHERE conversation_id = ? OR conversation_id LIKE ?
        LIMIT 1
      `);
      const result = stmt.get(conversationId, `${conversationId}%`);
      return result || null;
    } catch (err) {
      console.error('Error fetching conversation by id:', err);
      return null;
    }
  }

  const rows = querySqliteCli(`
    SELECT conversation_id, title, preview, step_count, last_modified_time, status
    FROM conversation_summaries
    WHERE conversation_id = ? OR conversation_id LIKE ?
    LIMIT 1
  `, [conversationId, `${conversationId}%`]);
  return rows && rows.length > 0 ? rows[0] : null;
}

module.exports = {
  getRecentConversations,
  getConversationById
};
