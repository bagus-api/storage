const { spawn } = require('node:child_process');
const readline = require('node:readline');
const treeKill = require('tree-kill');
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');

// Path to agy CLI binary
const AGY_BIN = fs.existsSync('/home/nanasmuda/.local/bin/agy')
  ? '/home/nanasmuda/.local/bin/agy'
  : 'agy';

// Map of active processes per userId
const activeProcesses = new Map();

/**
 * Execute Antigravity CLI with prompt and stream output
 * @param {object} options
 * @param {string} options.userId
 * @param {string} options.prompt
 * @param {string} [options.conversationId]
 * @param {string} [options.model]
 * @param {string} [options.effort]
 * @param {string} [options.mode]
 * @param {string} [options.cwd]
 * @param {function} [options.onProgress]
 * @returns {Promise<{success: boolean, response?: string, conversation_id?: string, duration_seconds?: number, usage?: object, error?: string, aborted?: boolean}>}
 */
async function runAgy({
  userId,
  prompt,
  conversationId,
  model,
  effort,
  mode,
  cwd,
  onProgress
}) {
  return new Promise((resolve) => {
    const workDir = (cwd && fs.existsSync(cwd)) ? cwd : os.homedir();

    const args = [
      '-p', prompt,
      '--dangerously-skip-permissions',
      '--output-format', 'stream-json'
    ];

    if (conversationId) {
      args.push('--conversation', conversationId);
    }
    if (model) {
      args.push('--model', model);
    }
    if (effort) {
      args.push('--effort', effort);
    }
    if (mode) {
      args.push('--mode', mode);
    }

    let finalResult = null;
    let accumulatedText = '';
    let capturedConvId = conversationId || null;
    let isAborted = false;
    let stderrOutput = '';

    const proc = spawn(AGY_BIN, args, {
      cwd: workDir,
      env: {
        ...process.env,
        PATH: `/home/nanasmuda/.local/bin:${process.env.PATH || ''}`
      }
    });

    activeProcesses.set(String(userId), {
      proc,
      kill: () => {
        isAborted = true;
        try {
          treeKill(proc.pid, 'SIGINT', (err) => {
            if (err) {
              try { treeKill(proc.pid, 'SIGKILL'); } catch (e) {}
            }
          });
        } catch (e) {
          try { proc.kill('SIGKILL'); } catch (e2) {}
        }
      }
    });

    const rl = readline.createInterface({ input: proc.stdout });

    rl.on('line', (rawLine) => {
      const line = rawLine.trim();
      if (!line) return;

      try {
        const data = JSON.parse(line);

        if (data.event === 'init') {
          if (data.conversation_id) {
            capturedConvId = data.conversation_id;
          }
          if (onProgress) {
            onProgress({ type: 'init', conversation_id: data.conversation_id, cwd: data.init?.cwd });
          }
        } else if (data.event === 'step_update') {
          const su = data.step_update;
          if (!su) return;

          if (su.conversation_id && !capturedConvId) {
            capturedConvId = su.conversation_id;
          }

          if (su.step_type === 'tool') {
            if (su.state === 'ACTIVE' && onProgress) {
              onProgress({
                type: 'tool_start',
                tool: su.tool_name,
                params: su.tool_info?.parameters
              });
            } else if (su.state === 'DONE' && onProgress) {
              onProgress({
                type: 'tool_done',
                tool: su.tool_name,
                duration: su.duration_seconds
              });
            }
          } else if (su.step_type === 'agent_response') {
            if (su.text_delta) {
              accumulatedText += su.text_delta;
              if (onProgress) {
                onProgress({ type: 'text_delta', delta: su.text_delta, accumulated: accumulatedText });
              }
            }
          }
        } else if (data.event === 'result') {
          finalResult = data.result;
          if (finalResult?.conversation_id) {
            capturedConvId = finalResult.conversation_id;
          }
        }
      } catch (err) {
        // Line might be plain text message or warning
        if (!line.startsWith('{')) {
          stderrOutput += (stderrOutput ? '\n' : '') + line;
        }
      }
    });

    proc.stderr.on('data', (chunk) => {
      stderrOutput += chunk.toString();
    });

    proc.on('error', (err) => {
      activeProcesses.delete(String(userId));
      resolve({
        success: false,
        error: `Gagal menjalankan proses Antigravity: ${err.message}`
      });
    });

    proc.on('close', (code) => {
      activeProcesses.delete(String(userId));

      if (isAborted) {
        return resolve({
          success: false,
          aborted: true,
          error: 'Operasi dihentikan oleh pengguna.'
        });
      }

      if (finalResult) {
        const isSuccess = finalResult.status === 'SUCCESS' || (!finalResult.status && !finalResult.error);
        return resolve({
          success: isSuccess,
          conversation_id: finalResult.conversation_id || capturedConvId,
          response: finalResult.response || accumulatedText,
          duration_seconds: finalResult.duration_seconds,
          usage: finalResult.usage,
          error: finalResult.error || (isSuccess ? null : 'Terjadi kesalahan saat memproses permintaan.')
        });
      }

      if (accumulatedText.trim().length > 0) {
        return resolve({
          success: true,
          conversation_id: capturedConvId,
          response: accumulatedText,
          duration_seconds: null,
          usage: null
        });
      }

      if (code !== 0) {
        return resolve({
          success: false,
          error: stderrOutput.trim() || `Antigravity CLI keluar dengan kode error ${code}`
        });
      }

      resolve({
        success: false,
        error: 'Tidak ada respons dari Antigravity.'
      });
    });
  });
}

/**
 * Abort active process for a user
 * @param {string|number} userId 
 * @returns {boolean}
 */
function abortUserProcess(userId) {
  const active = activeProcesses.get(String(userId));
  if (active) {
    active.kill();
    activeProcesses.delete(String(userId));
    return true;
  }
  return false;
}

/**
 * Check if user has an active running process
 * @param {string|number} userId 
 * @returns {boolean}
 */
function isUserRunning(userId) {
  return activeProcesses.has(String(userId));
}

module.exports = {
  runAgy,
  abortUserProcess,
  isUserRunning
};
