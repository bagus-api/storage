const { execSync } = require('node:child_process');
const fs = require('node:fs');
const path = require('node:path');

const GITHUB_TOKEN = process.env.GITHUB_TOKEN || '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';
const GITHUB_OWNER = process.env.GITHUB_OWNER || 'nanasmudawkwk';
const REMOTION_REPO = process.env.REMOTION_REPO || 'remotion-terminal-render';

/**
 * Helper to call GitHub API
 */
async function githubApi(endpoint, options = {}) {
  const url = endpoint.startsWith('http') ? endpoint : `https://api.github.com${endpoint}`;
  const headers = {
    Authorization: `token ${GITHUB_TOKEN}`,
    Accept: 'application/vnd.github.v3+json',
    'User-Agent': 'Antigravity-Telegram-Bot',
    ...options.headers
  };
  const res = await fetch(url, { ...options, headers });
  return res;
}

/**
 * Trigger GitHub Actions render and wait for video output
 * @param {object} options
 * @param {Buffer} [options.zipBuffer]
 * @param {string} [options.compositionId]
 * @param {function} [options.onProgress]
 * @returns {Promise<{videoBuffer: Buffer, fileName: string, compositionId: string, durationSeconds: number, runUrl: string}>}
 */
async function processRemotionZip({ zipBuffer, compositionId, onProgress }) {
  const startTime = Date.now();
  const repoSlug = `${GITHUB_OWNER}/${REMOTION_REPO}`;
  const authRemote = `https://${GITHUB_OWNER}:${GITHUB_TOKEN}@github.com/${repoSlug}.git`;
  const tempDir = path.join('/tmp', `remotion_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`);

  try {
    fs.mkdirSync(tempDir, { recursive: true });

    if (onProgress) onProgress(10, '📦 Menghubungkan ke GitHub Actions...');

    let pushed = false;
    if (zipBuffer && zipBuffer.length > 0) {
      // 1. Clone repository
      if (onProgress) onProgress(20, '📥 Mengunduh workspace render GitHub...');
      const cloneDir = path.join(tempDir, 'repo');
      execSync(`git clone --depth 1 "${authRemote}" "${cloneDir}"`, {
        stdio: 'pipe',
        timeout: 60000
      });

      // 2. Extract zip file
      if (onProgress) onProgress(30, '📂 Mengekstrak file proyek...');
      const zipPath = path.join(tempDir, 'upload.zip');
      fs.writeFileSync(zipPath, zipBuffer);
      const extractDir = path.join(tempDir, 'extracted');
      fs.mkdirSync(extractDir, { recursive: true });

      execSync(`python3 -c "import zipfile; zipfile.ZipFile('${zipPath}', 'r').extractall('${extractDir}')"`, {
        stdio: 'pipe'
      });

      // Locate project root inside extracted directory (handle single root folder wrapper)
      let projectRoot = extractDir;
      const entries = fs.readdirSync(extractDir);
      if (entries.length === 1 && fs.statSync(path.join(extractDir, entries[0])).isDirectory()) {
        projectRoot = path.join(extractDir, entries[0]);
      }

      // Copy src and other relevant assets to cloned repo
      const srcDir = path.join(projectRoot, 'src');
      if (fs.existsSync(srcDir)) {
        execSync(`cp -rf "${srcDir}" "${cloneDir}/"`, { stdio: 'pipe' });
      }

      const publicDir = path.join(projectRoot, 'public');
      if (fs.existsSync(publicDir)) {
        execSync(`cp -rf "${publicDir}" "${cloneDir}/"`, { stdio: 'pipe' });
      }

      // Handle custom composition ID if specified
      if (compositionId && compositionId.trim()) {
        fs.writeFileSync(path.join(cloneDir, '.composition_id'), compositionId.trim(), 'utf8');
      }

      // 3. Commit and push to main branch
      if (onProgress) onProgress(40, '🚀 Mendorong proyek ke GitHub Actions...');
      execSync(
        `cd "${cloneDir}" && git add -A && (git diff-index --quiet HEAD || git commit -m "Render Remotion: ${compositionId || 'Auto'}") && git push origin main`,
        { stdio: 'pipe', timeout: 60000 }
      );
      pushed = true;
    }

    if (!pushed) {
      // If no zip or nothing changed, manually trigger workflow_dispatch
      if (onProgress) onProgress(30, '⚡ Memulai workflow GitHub Actions...');
      const dispatchRes = await githubApi(`/repos/${repoSlug}/actions/workflows/render.yml/dispatches`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ref: 'main' })
      });
      if (!dispatchRes.ok && dispatchRes.status !== 204) {
        throw new Error(`Gagal memicu GitHub workflow: HTTP ${dispatchRes.status}`);
      }
    }

    // 4. Wait for workflow run to start
    if (onProgress) onProgress(45, '⏳ Menunggu Runner GitHub Actions siap...');
    let targetRun = null;
    const waitStart = Date.now();

    while (!targetRun && Date.now() - waitStart < 60000) {
      await new Promise((r) => setTimeout(r, 3000));
      const runsRes = await githubApi(`/repos/${repoSlug}/actions/runs?per_page=5`);
      if (runsRes.ok) {
        const data = await runsRes.json();
        const runs = data.workflow_runs || [];
        targetRun = runs.find(
          (r) => new Date(r.created_at).getTime() >= startTime - 15000
        );
      }
    }

    if (!targetRun) {
      throw new Error('Timeout: GitHub Actions workflow tidak merespon dalam waktu 60 detik.');
    }

    // 5. Poll run until completed
    const runId = targetRun.id;
    let runUrl = targetRun.html_url;
    let completed = false;
    let finalConclusion = null;
    const pollStart = Date.now();

    while (!completed && Date.now() - pollStart < 15 * 60 * 1000) {
      await new Promise((r) => setTimeout(r, 5000));

      const runCheck = await githubApi(`/repos/${repoSlug}/actions/runs/${runId}`);
      if (!runCheck.ok) continue;

      const runData = await runCheck.json();
      runUrl = runData.html_url;

      if (runData.status === 'completed') {
        completed = true;
        finalConclusion = runData.conclusion;
        break;
      }

      // Check current step for progress info
      const jobsRes = await githubApi(`/repos/${repoSlug}/actions/runs/${runId}/jobs`);
      let stepName = 'Sedang merender video...';
      if (jobsRes.ok) {
        const jobsData = await jobsRes.json();
        const mainJob = jobsData.jobs?.[0];
        if (mainJob && mainJob.steps) {
          const currentStep = mainJob.steps.find((s) => s.status === 'in_progress');
          if (currentStep) {
            stepName = currentStep.name;
          }
        }
      }

      const elapsed = Math.round((Date.now() - startTime) / 1000);
      if (onProgress) {
        onProgress(
          65,
          `⚡ [Cloud GitHub Actions] ${stepName} (${elapsed}s)`
        );
      }
    }

    if (finalConclusion !== 'success') {
      throw new Error(
        `Render di GitHub Actions gagal (Status: ${finalConclusion || 'Timeout'}). Cek detail log: ${runUrl}`
      );
    }

    // 6. Download rendered video from GitHub Release
    if (onProgress) onProgress(90, '📥 Mengunduh video hasil render dari GitHub...');

    // Wait a brief moment for release asset to be ready
    await new Promise((r) => setTimeout(r, 3000));

    const releaseRes = await githubApi(`/repos/${repoSlug}/releases/tags/v1.0.0`);
    if (!releaseRes.ok) {
      throw new Error(`Gagal membaca release v1.0.0: HTTP ${releaseRes.status}`);
    }

    const releaseData = await releaseRes.json();
    const videoAsset = (releaseData.assets || []).find(
      (a) => a.name.endsWith('.mp4') || a.name === 'video.mp4'
    );

    if (!videoAsset) {
      throw new Error('File video.mp4 tidak ditemukan di rilis GitHub Actions.');
    }

    const downloadRes = await githubApi(videoAsset.url, {
      headers: {
        Accept: 'application/octet-stream'
      }
    });

    if (!downloadRes.ok) {
      throw new Error(`Gagal mengunduh video dari GitHub: HTTP ${downloadRes.status}`);
    }

    const arrayBuf = await downloadRes.arrayBuffer();
    const videoBuffer = Buffer.from(arrayBuf);
    const durationSeconds = Math.round((Date.now() - startTime) / 1000);

    return {
      videoBuffer,
      fileName: `remotion_${compositionId || 'TerminalLesson'}.mp4`,
      compositionId: compositionId || 'TerminalLesson',
      durationSeconds,
      runUrl
    };
  } finally {
    // Cleanup temporary directory
    try {
      if (fs.existsSync(tempDir)) {
        fs.rmSync(tempDir, { recursive: true, force: true });
      }
    } catch (_) {}
  }
}

module.exports = {
  processRemotionZip
};
