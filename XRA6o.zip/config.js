const settings = {
  // BOT SETTINGS
  token: 'VØRR_VINTAGE',
  ownerId: 7313120244,
  dev: 'vorrrxone',
  
  // MEDIA
  panel: 'https://files.catbox.moe/727mxs.jpg',
};

module.exports = settings;